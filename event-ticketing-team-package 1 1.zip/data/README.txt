Excel database files will be auto-created here when you first run the app.
Files: users.xlsx, events.xlsx, bookings.xlsx, venues.xlsx, feedback.xlsx