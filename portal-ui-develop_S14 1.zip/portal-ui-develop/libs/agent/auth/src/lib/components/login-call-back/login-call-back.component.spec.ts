import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LoginCallBackComponent } from './login-call-back.component';
import { RouterModule } from '@angular/router';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { HttpClient } from '@angular/common/http';

describe('LoginCallBackComponent', () => {
  let component: LoginCallBackComponent;
  let fixture: ComponentFixture<LoginCallBackComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [LoginCallBackComponent],
      imports: [HttpClientTestingModule, RouterModule.forRoot([])],
      providers: [HttpClient]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LoginCallBackComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
