import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { LocalStorageService } from '../../local-storage.service';

@Component({
  selector: 'aflac-login-call-back',
  templateUrl: './login-call-back.component.html',
  styleUrls: ['./login-call-back.component.scss']
})
export class LoginCallBackComponent implements OnInit {
  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private localStorage: LocalStorageService
  ) {}
  jwtResponse: any;

  ngOnInit() {
    this.route.queryParamMap.subscribe(queryParams => {
      if (queryParams.get('query')) {
        this.jwtResponse = JSON.parse(queryParams.get('query'));
        this.localStorage.setToken(this.jwtResponse['id_token']);
        this.router.navigateByUrl('home');
      } else {
        // TODO - define error scenario to handle this
      }
    });
  }
}
