import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { AuthGuardService } from './auth-guard.service';
import { AuthService } from './auth.service';
import { LocalStorageService } from './local-storage.service';

@NgModule({
  imports: [CommonModule],
  providers: [AuthGuardService, AuthService, LocalStorageService]
})
export class AuthModule {}
