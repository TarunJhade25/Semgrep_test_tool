  export interface User {
    email: string;
    username: string,
    group: string,
    token: string
  }