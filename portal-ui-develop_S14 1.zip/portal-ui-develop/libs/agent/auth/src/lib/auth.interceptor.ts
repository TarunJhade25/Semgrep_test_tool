import {
  HttpEvent,
  HttpHandler,
  HttpInterceptor,
  HttpRequest
} from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { AuthService } from './auth.service';
import { LocalStorageService } from './local-storage.service';
import { UtilService } from '@aflac/shared/ui';

@Injectable({
  providedIn: 'root'
})
export class AuthInterceptor implements HttpInterceptor {
  constructor(
    private authService: AuthService,
    private utilService: UtilService,
    private localStorageService: LocalStorageService
  ) {}
  agentId = 1; // TODO - Need to replace
  intercept(
    request: HttpRequest<any>,
    next: HttpHandler
  ): Observable<HttpEvent<any>> {
    request = request.clone({
      setHeaders: {
        Authorization: `Bearer ${this.localStorageService.getToken()}`,
        'x-client-id': 'ESADGk2Gy1V40t__iOTo',
        agentId: `${this.authService.getAgentId()}`,
        'x-correlation-id': this.utilService.generateUuid()
      }
    });
    return next.handle(request);
  }
}
