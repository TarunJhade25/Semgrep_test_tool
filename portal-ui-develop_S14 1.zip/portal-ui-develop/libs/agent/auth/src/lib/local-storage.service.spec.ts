import { TestBed } from '@angular/core/testing';

import { LocalStorageService } from './local-storage.service';

describe('LocalStorageService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: LocalStorageService = TestBed.get(LocalStorageService);
    expect(service).toBeTruthy();
  });

  it('should be check getToken, setToken', () => {
    const service: LocalStorageService = TestBed.get(LocalStorageService);
    expect(service.getToken()).toBeNull();
    service.setToken('sample response');
    expect(service.getToken()).toBe('sample response');
    service.removeToken();
    expect(service.getToken()).toBeNull();
  });
});
