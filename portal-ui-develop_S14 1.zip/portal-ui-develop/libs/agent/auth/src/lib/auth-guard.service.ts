import { Injectable } from '@angular/core';
import { CanActivate, Router } from '@angular/router';
import { Observable } from 'rxjs';
import { map, take } from 'rxjs/operators';
import { LocalStorageService } from './local-storage.service';
import { AuthService } from './auth.service';
import { urlConfig } from '@aflac/shared/data-model';

@Injectable({
  providedIn: 'root'
})
export class AuthGuardService implements CanActivate {
  constructor(
    private localStorage: LocalStorageService,
    private authService: AuthService,
    private router: Router
  ) {}
  // temp to override login in dev/local env
  envName = urlConfig.envName;

  canActivate() {
    // temp to override login in dev/local env
    if (
      this.localStorage.getToken() === null &&
      (this.envName !== 'local' && this.envName !== 'dev')
    ) {
      this.authService.initRedirect();
      return false;
    } else {
      return true;
    }
  }
}
