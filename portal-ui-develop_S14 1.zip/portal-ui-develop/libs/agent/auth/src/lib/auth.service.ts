import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { User } from './model/user';
import { urlConfig } from '@aflac/shared/data-model';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  private agentId: any;

  constructor(private http: HttpClient) {}
  //temp fix to get end points
  private securityEndpoint: string = urlConfig.securityServiceBaseUrl;

  initRedirect() {
    this.http.get<any>(this.securityEndpoint + 'sso/v1/agentPortal').subscribe(
      data => {
        window.location.replace(data.url);
        // console.log(data)
      },
      error => {
        console.log(error);
      }
    );
  }

  // TODO - temp set up needs oto be removed once SSO implments
  setAgentId(agentId: any) {
    this.agentId = agentId;
  }
  // TODO - temp set up needs oto be removed once SSO implments
  getAgentId() {
    return this.agentId ? this.agentId : 1;
  }
}
