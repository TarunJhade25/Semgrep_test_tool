import { Observable, of } from 'rxjs';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class LocalStorageService {
  getToken() {
    const data = localStorage.getItem('agentSAMLToken');
    if (data) {
      return data;
    } else {
      return null;
    }
  }

  setToken(data: string) {
    localStorage.setItem('agentSAMLToken', data);
  }

  removeToken() {
    localStorage.removeItem('agentSAMLToken');
  }
}
