import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class QuoteService {
  currentPlanUpdated = new BehaviorSubject(<any>{});
  data = this.currentPlanUpdated.asObservable();
  constructor() {}

  currentPlanState(plan) {
    this.currentPlanUpdated.next(plan);
  }
}
