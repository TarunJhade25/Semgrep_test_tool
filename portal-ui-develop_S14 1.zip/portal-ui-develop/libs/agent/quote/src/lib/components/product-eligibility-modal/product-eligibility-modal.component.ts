import { Component, OnInit, Inject } from '@angular/core';
import {
  MatDialogRef,
  MAT_DIALOG_DATA,
  MatDialog
} from '@angular/material/dialog';
import { Router } from '@angular/router';
import { SaveYourQuoteState, UpdateCartOnQuoteSave } from '@aflac/agent/shared';
import { Store } from '@ngrx/store';
import { AgentSharedService } from '@aflac/agent/shared';
import { saveQuoteAgent, saveUserDetails } from '@aflac/agent/shared';

@Component({
  selector: 'aflac-product-eligibility-modal',
  templateUrl: './product-eligibility-modal.component.html',
  styleUrls: ['./product-eligibility-modal.component.scss']
})
export class ProductEligibilityModalComponent implements OnInit {
  //modalExpanded: boolean;
  selectedProfile: any;
  previousCartSum: any;
  updatedCartSum: any;
  allProductsAlreadyPurchased: boolean;
  isAgentEligibleForState: boolean;
  constructor(
    @Inject(MAT_DIALOG_DATA) public data: any,
    private dialogRef: MatDialogRef<ProductEligibilityModalComponent>,
    private router: Router,
    private store: Store<any>,
    private agentSharedService: AgentSharedService,
    private saveQuotestore: Store<SaveYourQuoteState>
  ) {}

  ngOnInit() {
    this.selectedProfile = this.data && this.data.payload;
    if (this.selectedProfile) {
      this.allProductsAlreadyPurchased = this.selectedProfile.allProductsAlreadyPurchased;
      this.isAgentEligibleForState = this.selectedProfile.isAgentEligibleForState;
      this.fetchUpdatedSum();
    }
  }

  fetchUpdatedSum() {
    this.previousCartSum = 0;
    this.updatedCartSum = 0;
    this.selectedProfile.selectedCartItems.forEach(element => {
      this.previousCartSum =
        this.previousCartSum + this.getNumeric(element.plan.price);
      if (element.selectedRiders && element.selectedRiders.length > 0) {
        element.selectedRiders.forEach(item => {
          this.previousCartSum =
            this.previousCartSum + this.getNumeric(item.rider.price);
        });
      }
    });
    if (this.selectedProfile.updatedCartItems.length > 0)
      this.selectedProfile.updatedCartItems.forEach(element => {
        this.updatedCartSum =
          this.updatedCartSum + this.getNumeric(element.plan.price);
        if (element.selectedRiders && element.selectedRiders.length > 0) {
          element.selectedRiders.forEach(item => {
            this.updatedCartSum =
              this.updatedCartSum + this.getNumeric(item.rider.price);
          });
        }
      });
    this.updatedCartSum = this.updatedCartSum.toFixed(2);
    this.previousCartSum = this.previousCartSum.toFixed(2);
  }

  getNumeric(stringVal) {
    if (isNaN(stringVal)) stringVal = stringVal.replace(/,/g, '');
    return Number(stringVal);
  }

  proceedToDependents() {
    this.agentSharedService.updateSearchQuote('sq', this.selectedProfile);
    this.updateCartWithEligibleQuote(this.selectedProfile.updatedCartItems);
    this.agentSharedService.updateExistingCustomerInfo(
      'sq',
      this.selectedProfile.saveQuoteObj
    );
    this.router.navigateByUrl('quotes');
  }

  updateCartWithEligibleQuote(quote) {
    const cartPayload = { key: 'from-list', value: quote };
    const headerPayload = { price: this.updatedCartSum, count: quote.length };
    this.agentSharedService.updateCartWithEligibleQuote(
      cartPayload,
      headerPayload
    );
    // Keep cart in session
    sessionStorage.setItem('state-agent-cart-details', JSON.stringify(quote));
  }

  editQuote() {
    this.dialogRef.close(true);
    this.agentSharedService.updateSearchQuote('sq', this.selectedProfile);
    this.updateCartWithEligibleQuote(this.selectedProfile.updatedCartItems);
    this.agentSharedService.updateExistingCustomerInfo(
      'sq',
      this.selectedProfile.saveQuoteObj
    );
    this.router.navigateByUrl('quotes');
  }
}
