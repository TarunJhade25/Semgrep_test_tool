import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { StoreModule, Store, MemoizedSelector } from '@ngrx/store';
import * as fromProduct from '@aflac/agent/shared';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { TranslateModule } from '@ngx-translate/core';
import { RouterTestingModule } from '@angular/router/testing';
import { Router } from '@angular/router';
import { ProductListComponent } from './product-list.component';
import { AgentCardComponent } from '../agent-card/agent-card.component';
import { ProductState, ProductReducer, selectPlan } from '@aflac/agent/shared';
import { provideMockStore, MockStore } from '@ngrx/store/testing';
import { of } from 'rxjs';

const product = {
  features: [
    'Accidental Death & Dismemberment',
    'Accidental Injury',
    'Non-Injury hospital admission benefits'
  ],
  id: '1001',
  image: 'assets/images/accident_2.svg',
  productName: 'Accident Insurance',
  riders: [
    { description: '', id: 5001, name: 'Accident Rider 1', value: 14.23 },
    { description: '', id: 5002, name: 'Accident Rider 2', value: 24.23 }
  ],
  startingPrice: 12.32,
  states: ['AK', 'AZ', 'CA'],
  name: 'test'
};
const productList = [
  {
    breadcrumb_text: 'Cancer Plans',
    coverage: 'ind',
    features: [
      'Annual cancer check ',
      'Initial cancer diagnosis',
      'Chemotherapy'
    ],
    icon_url: '',
    id: 'PREC-IC',
    image: 'assets/images/cancer_2.svg',
    name: 'Cancer Insurance',
    short_description:
      'Helps pay for expenses associated with screening, treatment, and recovery from a cancer diagnosis.',
    starting_price: '16.93'
  }
];
const coverageTypes = [
  {
    code: 'ind',
    defaultValue: 'You'
  },
  {
    code: 'ind_sps',
    defaultValue: 'You & Your Spouse'
  }
];
const coverage = 'ind';
const index = 1;
const plans = [
  {
    id: 'PREC-IC',
    name: 'test',
    title: 'insurance',
    benefits: [
      { id: 5001, name: 'Accident Rider 1', price: 14.23 },
      { id: 5002, name: 'Accident Rider 2', price: 24.23 }
    ]
  },
  {
    benefits: '',
    description: 'These are the benefits that you cash.',
    id: 'plan04',
    name: 'Protection',
    price: 100.1,
    riders: [],
    states: [],
    title: 'Option 2'
  }
];
const selectedPlans = {
  key: 'from-list',
  value: [
    {
      productId: 'PREC-IC',
      productName: 'Accident',
      plan: {
        id: 'PREC-IC',
        name: 'test',
        title: 'insurance',
        benefits: [
          { id: 5001, name: 'Accident Rider 1', price: 14.23 },
          { id: 5002, name: 'Accident Rider 2', price: 24.23 }
        ]
      },
      coverage: 'ind',
      selected: true,
      availableInCart: true,
      selectedRiders: [
        {
          selected: true,
          availableInCart: true,
          productId: 'prec-ic',
          rider: []
        }
      ]
    }
  ]
};
const planData = { id: 'PREC-IC', coverage: 'ind_sps', plans: plans };
const ridersOfCurrentProduct = [
  {
    title: 'Initial Diagnosis Increasing Benefit Rider',
    price: 500,
    benefit: [
      {
        title: 'Hospitalization',
        price: '$150 / day',
        benefit_category: []
      }
    ],
    riderNameCd: 'Cancer Initial Diagnosis Increasing Benefit Rider',
    productId: 'PREC-IC',
    selected: true,
    availableInCart: true,
    monthlyPremium: 500
  }
];
const ridersOfselectedProduct = [
  {
    rider: {
      title: 'Initial Diagnosis Increasing Benefit Rider',
      price: 500,
      benefit: [
        {
          title: 'Hospitalization',
          price: '$150 / day',
          benefit_category: []
        }
      ],
      riderNameCd: 'Cancer Initial Diagnosis Increasing Benefit Rider'
    },
    productId: 'PREC-IC',
    selected: true,
    availableInCart: true
  }
];

describe('ProductListComponent', () => {
  let component: ProductListComponent;
  let fixture: ComponentFixture<ProductListComponent>;
  let mockStore: MockStore<any>;
  let store: Store<ProductState>;
  let mockQuoteSelector: MemoizedSelector<any, any>;
  let mockPlanSelector: MemoizedSelector<any, any>;
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        TranslateModule.forRoot(),
        RouterTestingModule,
        StoreModule.forRoot({ ProductReducer })
      ],
      providers: [provideMockStore({})],
      declarations: [ProductListComponent, AgentCardComponent],
      schemas: [CUSTOM_ELEMENTS_SCHEMA]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ProductListComponent);
    mockStore = TestBed.get(Store);
    store = TestBed.get(Store);
    mockQuoteSelector = mockStore.overrideSelector(
      fromProduct.selectedPlans,
      selectedPlans
    );
    mockPlanSelector = mockStore.overrideSelector(
      fromProduct.retrivePlanCoverageChange,
      planData
    );
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should call ngOnChanges function', () => {
    spyOn(component, 'ngOnChanges').and.callThrough();
    component.products = productList;
    component.isProductLoaded = true;
    component.ngOnChanges();
    expect(component.ngOnChanges).toHaveBeenCalled();
  });

  it('should call displayPlans() from onProductSelected funtion', () => {
    spyOn(component, 'displayPlans').and.callThrough();
    component.selectedCoverage = ['ind', 'ind_sps'];
    component.onProductSelected(product, index);
    expect(component.displayPlans).toHaveBeenCalled();
  });

  it('should call displayPlans() from changeCoverage funtion', () => {
    component.changeCoverage(coverage, product, index);
    expect(component as any).toBeDefined();
  });

  it('should emit see plans funtion', () => {
    component.displayPlans(product, coverage, index);
    expect(component as any).toBeDefined();
  });

  it('should update cart on change in coverage', () => {
    spyOn(store, 'dispatch').and.returnValue(of(true));
    component.cartData = selectedPlans;
    component.updateCart(planData);
    expect(store.dispatch).toHaveBeenCalled();
  });

  it('should update cart with updated rider data', () => {
    const resp = component.filterRiders(
      ridersOfCurrentProduct,
      ridersOfselectedProduct
    );
    expect(resp).toBeDefined();
  });
});
