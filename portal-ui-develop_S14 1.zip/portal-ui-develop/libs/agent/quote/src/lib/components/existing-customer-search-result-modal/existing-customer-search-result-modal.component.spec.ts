import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { TranslateModule } from '@ngx-translate/core';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import {
  MatDialogModule,
  MatDialogRef,
  MatDialog,
  MAT_DIALOG_DATA
} from '@angular/material/dialog';
import { SharedvalidatorsModule } from '@aflac/shared/validators';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { MatFormFieldModule, MatInputModule } from '@angular/material';
import { RouterTestingModule } from '@angular/router/testing';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { MatTableModule } from '@angular/material';
import { provideMockStore, MockStore } from '@ngrx/store/testing';
import { StoreModule, Store, MemoizedSelector } from '@ngrx/store';
import { ExistingCustomerSearchResultModalComponent } from './existing-customer-search-result-modal.component';
import { Router } from '@angular/router';

import { SaveYourQuoteState } from '@aflac/agent/shared';
import * as fromAgentSaveQuote from '@aflac/agent/shared';
import * as fromProduct from '@aflac/agent/shared';
import { ProductState } from '@aflac/agent/shared';
import { getRetrieveQuoteData } from '@aflac/agent/landing';

const userDetails = {
  quoteDetails: [],
  customerDetails: {
    addresses: [{ stateProvCd: 'AL' }]
  },
  aflacUserGuid: 'abcx',
  availableProducts: [
    {
      productCd: 'PREC-IA'
    }
  ],
  customerNumber: '510001',
  dateOfBirth: '1985-07-13',
  emails: [
    {
      id: 0,
      email: 'john@email.com',
      consentStatus: 'GRANTED',
      consentDate: '2020-05-26'
    }
  ],
  firstName: 'john',
  lastName: 'Smith',
  middleName: 'k',
  suffix: '8',
  taxId: '123456789',
  phones: [
    {
      id: 0,
      phone: '1234567890',
      phoneTypeCd: 'WORK'
    }
  ]
};

const storeData = {
  quoteDetails: [],
  customerDetails: [
    {
      customerNumber: '510001',
      firstName: 'Johnson',
      lastName: 'S',
      middleName: 'Elizabeth',
      suffix: '8',
      dateOfBirth: '1966-03-20',
      gender: 'male',
      taxId: '123456789',
      aflacUserGuid: 'b480d9fc-8558-4507-92cb-772325011677',
      addresses: [
        {
          id: 0,
          addressLine1: '345 California Str',
          addressLine2: '10 flr',
          addressLine3: ' ',
          city: 'San Francisco',
          county: 'San Francisco',
          zipCode: '94104',
          stateProvCd: 'AL',
          countryCd: 'US',
          addressTypeCd: 'mailing'
        }
      ],
      phones: [
        {
          id: 0,
          phone: '1234567890',
          phoneTypeCd: 'WORK'
        }
      ],
      emails: [
        {
          id: 0,
          email: 'johnsmith@gmail.com',
          consentStatus: 'GRANTED',
          consentDate: '2020-05-26'
        }
      ],
      availableProducts: [
        {
          productCd: 'PREC-IA'
        }
      ]
    },
    {
      customerNumber: '510005',
      firstName: 'John',
      lastName: 'Smith',
      middleName: 'Elizabeth',
      suffix: '8',
      dateOfBirth: '1966-03-20',
      gender: 'male',
      taxId: '123456789',
      aflacUserGuid: 'b480d9fc-8558-4507-92cb-772325011677',
      addresses: [
        {
          id: 0,
          addressLine1: '345 California Str',
          addressLine2: '10 flr',
          addressLine3: ' ',
          city: 'San Francisco',
          county: 'San Francisco',
          zipCode: '94104',
          stateProvCd: 'NY',
          countryCd: 'US',
          addressTypeCd: 'mailing'
        }
      ],
      phones: [
        {
          id: 0,
          phone: '1234567890',
          phoneTypeCd: 'WORK'
        }
      ],
      emails: [
        {
          id: 0,
          email: 'johnsmith@gmail.com',
          consentStatus: 'GRANTED',
          consentDate: '2020-05-26'
        }
      ],
      availableProducts: [
        {
          productCd: 'PREC-IC'
        }
      ]
    }
  ]
};

const selectedPlans = {
  key: 'from-list',
  value: [
    {
      productId: 'PREC-IC',
      productName: 'Accident',
      plan: [],
      coverage: 'ind',
      selected: true,
      availableInCart: true,
      selectedRiders: [
        {
          selected: true,
          availableInCart: true,
          productId: 'PREC-IC',
          rider: []
        }
      ]
    }
  ]
};

const dataSource = [
  {
    customerNumber: '510001',
    name: 'Johnson',
    state: 'AL'
  },
  {
    customerNumber: '510005',
    name: 'Johnson',
    state: 'AL'
  }
];

const RetrieveQuote = {
  data: {
    quotes: [
      {
        bundleId: '000',
        policyNumber: 'a1b2',
        effectiveDate: '01/02/2019',
        expirationDate: '01/06/2019',
        transactionEffectiveDate: '03/02/2019',
        policyStatusCd: 'dummy',
        productCode: 'PREC-IC',
        lobCd: 'dummy',
        totalPremium: 1234,
        currencyCode: 'ind',
        producerCd: 'dummy',
        subProducerCd: 'd',
        quoteNumber: '111',
        customerNumber: '111'
      }
    ]
  }
};
const productByStateArray = [
  {
    name: 'Accident Insurance',
    id: 'PREC-IA'
  }
];
const stateList = [
  { code: 'AL', name: 'Alabama' },
  { code: 'AK', name: 'Alaska' }
];
class RouterStub {
  navigateByUrl(url: string) {
    return url;
  }
}

describe('ExistingCustomerSearchResultModalComponent', () => {
  let component: ExistingCustomerSearchResultModalComponent;
  let fixture: ComponentFixture<ExistingCustomerSearchResultModalComponent>;
  let mockStore: MockStore<any>;
  let saveQuoteStore: Store<SaveYourQuoteState>;
  let store: Store<ProductState>;
  let mockQuoteSelector: MemoizedSelector<any, any>;
  let mockSelectedPlanSelector: MemoizedSelector<any, any>;
  let mockRetrieveQuoteData: MemoizedSelector<any, any>;
  let mockProductByStateSelector: MemoizedSelector<any, any>;
  let mockStateList: MemoizedSelector<any, any>;
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ExistingCustomerSearchResultModalComponent],
      imports: [
        TranslateModule.forRoot(),
        ReactiveFormsModule,
        FormsModule,
        SharedvalidatorsModule,
        MatFormFieldModule,
        MatInputModule,
        RouterTestingModule,
        BrowserAnimationsModule,
        MatTableModule,
        MatDialogModule
      ],
      providers: [
        provideMockStore({}),
        { provide: MAT_DIALOG_DATA, useValue: storeData },
        { provide: MatDialogRef, useClass: DialogMock },
        { provide: Router, useClass: RouterStub }
      ],

      schemas: [CUSTOM_ELEMENTS_SCHEMA]
    }).compileComponents();
  }));
  beforeEach(() => {
    fixture = TestBed.createComponent(
      ExistingCustomerSearchResultModalComponent
    );
    mockStore = TestBed.get(Store);
    store = TestBed.get(Store);
    saveQuoteStore = TestBed.get(Store);
    mockQuoteSelector = mockStore.overrideSelector(
      fromAgentSaveQuote.selectUserDetailsFromAgent,
      userDetails
    );
    mockSelectedPlanSelector = mockStore.overrideSelector(
      fromProduct.selectedPlans,
      selectedPlans
    );
    mockRetrieveQuoteData = mockStore.overrideSelector(
      getRetrieveQuoteData,
      RetrieveQuote
    );
    mockProductByStateSelector = mockStore.overrideSelector(
      fromProduct.fetchProductsByState,
      productByStateArray
    );
    mockStateList = mockStore.overrideSelector(
      fromProduct.filteredStateList,
      stateList
    );
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should return state name from province code', () => {
    const stateProvCd = 'AL';
    component.states = [
      {
        name: 'Alabama',
        code: 'AL'
      }
    ];
    const result = component.getStateNameFromStateProvCode(stateProvCd);
    expect(result).toEqual('Alabama');
  });
  it('should open modal based on selected input', () => {
    spyOn(component.dialog, 'open').and.returnValue(true);
    component.productslist = [
      { id: 'PREC-IA', name: 'Accident Insurance' },
      { id: 'PREC-IC', name: 'Cancer Insurance' }
    ];
    component.userDetailsFromState = storeData;
    component.selectedCustomer = '510005';
    component.productsAlreadyPurchased = selectedPlans.value[1];
    component.dataSource = dataSource;
    component.customerDetailsResponse = storeData.customerDetails;
    component.onSubmit();
    expect(component.dialog.open).toHaveBeenCalled();
  });
  // it('should navigate based on eligibility', () => {
  //   component.decideNavigation(selectedPlans.value);
  //   expect(component as any).toBeDefined();
  // });

  it('should get quotenumber corresponding to selected product', () => {
    const quotenumber = component.getQuoteNumber('PREC-IC');
    expect(quotenumber).toEqual(RetrieveQuote.data.quotes[0].quoteNumber);
  });
  it('should return formatted dob', () => {
    const result = component.formatDOB('01/01/2000');
    expect(result).toEqual('01/01/2000');
  });
  it('should navigate to Save Your Progress screen of click of changeEmail', () => {
    component.changeEmail();
    expect(component as any).toBeDefined();
  });
});
class DialogMock {
  _containerInstance = { _config: { width: '380px' } };
  updatePosition() {}
  close() {}
  open(data) {
    return true;
  }
}
