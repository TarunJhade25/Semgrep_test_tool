import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { TranslateModule } from '@ngx-translate/core';
import { ProductReducer } from '@aflac/agent/shared';
import { StoreModule, Store, MemoizedSelector } from '@ngrx/store';
import * as fromProduct from '@aflac/agent/shared';
import { MockStore, provideMockStore } from '@ngrx/store/testing';
import { ProductNotFoundComponent } from './product-not-found.component';

describe('ProductNotFoundComponent', () => {
  let component: ProductNotFoundComponent;
  let fixture: ComponentFixture<ProductNotFoundComponent>;
  let mockStore: MockStore<any>;
  let mockProductErrorSelector: MemoizedSelector<any, any>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [TranslateModule.forRoot(), StoreModule.forRoot(ProductReducer)],
      declarations: [ProductNotFoundComponent],
      providers: [provideMockStore({})],
      schemas: [CUSTOM_ELEMENTS_SCHEMA]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ProductNotFoundComponent);
    component = fixture.componentInstance;
    mockStore = TestBed.get(Store);
    mockProductErrorSelector = mockStore.overrideSelector(
      fromProduct.selectProductErrors,
      { productError: 'test' }
    );
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should call getErrors() funtion', () => {
    component.getErrors();
    expect(component as any).toBeDefined();
  });
});
