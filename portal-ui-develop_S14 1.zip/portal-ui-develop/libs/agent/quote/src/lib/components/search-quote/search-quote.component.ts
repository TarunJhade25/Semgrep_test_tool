import { HttpClient } from '@angular/common/http';
import {
  Component,
  EventEmitter,
  Input,
  OnInit,
  Output,
  ViewChild,
  ElementRef
} from '@angular/core';
import { FieldValidator } from '@aflac/shared/validators';
import { FormBuilder, FormControl, FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { Store, select } from '@ngrx/store';
import { Observable, Subscription } from 'rxjs';
import { distinctUntilChanged, map, startWith } from 'rxjs/operators';
import { StartQuote } from '@aflac/agent/shared';
import {
  agentSelectedQuote,
  agentSSNValidatedState
} from '@aflac/agent/shared'; // Selectors
import { CmsService } from '@aflac/shared/cms';
import { States } from '@aflac/shared/data-model';

@Component({
  selector: 'aflac-search-quote',
  templateUrl: './search-quote.component.html',
  styleUrls: ['./search-quote.component.scss']
})
export class SearchQuoteComponent implements OnInit {
  @ViewChild('stateRef', { static: false }) stateField: ElementRef;
  @Input() startQuoteObj: any;
  @Input() agentStateMode: boolean;
  @Output() refineSearch = new EventEmitter();
  @Output() disablePlans = new EventEmitter();
  selectedQuote: StartQuote;
  minAgeValue = 18;
  maxAgeValue = 99;
  states: any;
  toHighlight = '';
  stateName: any[];
  ssnValidatedState = false;
  private subscriptions = new Subscription();

  constructor(
    private formBuilder: FormBuilder,
    private http: HttpClient,
    private store: Store<any>,
    private route: Router,
    private cmsService: CmsService
  ) {}

  searchForm = new FormGroup({
    state: new FormControl('-1'),
    age: new FormControl()
  });

  ngOnInit() {
    this.getInitData();
  }

  public getInitData() {
    this.setFormControlData();
    this.disableSeePlansButton();
    this.subscriptions = this.store
      .pipe(select(agentSSNValidatedState))
      .subscribe(data => {
        this.ssnValidatedState = data && data.ssnState;
      });
  }

  public disableSeePlansButton() {
    /**Disable see plans button */
    this.cmsService.disableSeePlans.next(false);
    this.searchForm.valueChanges.pipe(distinctUntilChanged()).subscribe(() => {
      if (this.searchForm.status === 'INVALID') {
        this.cmsService.disableSeePlans.next(true);
        this.disablePlans.emit(false);
      }
    });
  }

  // Form validation
  get f() {
    return this.searchForm.controls;
  }

  // Set Form control data
  public setFormControlData() {
    this.searchForm = this.formBuilder.group({
      state: [''],
      age: [
        '',
        [
          FieldValidator.isEmpty('lookup.find_plans_age_error_required'),
          FieldValidator.isNotNumber('lookup.find_plans_age_error_valid_age'),
          FieldValidator.isNumberLess(
            this.minAgeValue,
            'lookup.find_plans_age_error_minimum'
          ),
          FieldValidator.isNumberHigh(
            this.maxAgeValue,
            'lookup.find_plans_age_error_maximum'
          )
        ]
      ]
    });

    this.store.pipe(select(agentSelectedQuote)).subscribe(data => {
      if (data) {
        this.storeToSession();
        this.searchForm.controls['age'].setValue(data.age);
        this.searchForm.controls['state'].setValue(data.state);
      } else {
        this.sessionToStore();
      }
    });
  }

  public stateSelection(event) {}
  //Recives the states and satename from the agent-state.component
  reciveStates(stateArray) {
    this.states = stateArray.states;
    this.stateName = stateArray.stateName;
    //Dynamically Add Validators for state
    this.searchForm.controls['state'].setValidators([
      FieldValidator.isEmpty('lookup.find_plans_state_error_required'),
      FieldValidator.isNotAvailableOption(
        this.stateName,
        'lookup.find_plans_state_error_invalid'
      )
    ]);
  }
  public storeToSession() {
    this.store.select(agentSelectedQuote).subscribe(res => {
      sessionStorage.setItem('agent-state-searchQuote', JSON.stringify(res));
    });
  }

  public sessionToStore() {
    const currentURL = this.route.url;
    if (currentURL !== '/home') {
      const searchQuote = JSON.parse(
        sessionStorage.getItem('agent-state-searchQuote')
      );
      this.refineSearch.emit(searchQuote);
    }
  }

  setStateProvCode() {
    if (this.states && this.states.length > 0) {
      this.searchForm.value.stateProvCd = this.states.filter(
        data => data.name === this.searchForm.value.state
      )[0].code;
    }
  }

  onSubmit() {
    if (this.searchForm.valid) {
      this.setStateProvCode();
      this.refineSearch.emit(this.searchForm.value);
      this.cmsService.disableSeePlans.next(false);
      this.searchForm.markAsPristine();
    }
  }
}
