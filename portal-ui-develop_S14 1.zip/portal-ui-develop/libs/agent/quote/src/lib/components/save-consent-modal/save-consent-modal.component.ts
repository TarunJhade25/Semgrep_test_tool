import { Component, OnInit, Inject } from '@angular/core';
import { PerfectScrollbarConfigInterface } from 'ngx-perfect-scrollbar';
import { Subject } from 'rxjs';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';

@Component({
  selector: 'aflac-save-consent-modal',
  templateUrl: './save-consent-modal.component.html',
  styleUrls: ['./save-consent-modal.component.scss']
})
export class SaveConsentModalComponent implements OnInit {
  title: string;
  closeBtnName: string;
  public config: PerfectScrollbarConfigInterface = {
    scrollingThreshold: 0,
    minScrollbarLength: 148,
    maxScrollbarLength: 148,
    wheelSpeed: 0.6
  };
  contentTitleOne: string;
  contentDataOne: string;
  contentTitleTwo: string;
  contentDataTwoParaOne: string;
  contentDataTwoParaTwo: string;
  public onClose: Subject<boolean>;

  constructor(
    public dialogRef: MatDialogRef<SaveConsentModalComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) {}

  ngOnInit() {}

  hideModal() {
    this.dialogRef.close(true);
  }
}
