import { Component, OnInit, Input, OnChanges } from '@angular/core';
import { Store, select } from '@ngrx/store';
import { MatDialog } from '@angular/material';
import { AflacInfoModalComponent } from '../info-modal/info-modal.component';
import { CmsService } from '@aflac/shared/cms';
import {
  ProductState,
  selectedProduct,
  selectedPlans,
  updateRiderInfoInCart
} from '@aflac/agent/shared';
@Component({
  selector: 'aflac-product-rider',
  templateUrl: './product-rider.component.html',
  styleUrls: ['./product-rider.component.scss']
})
export class ProductRiderComponent implements OnInit, OnChanges {
  selectedPanleIndex = null;
  displayedColumns: string[] = [
    'beneficiary',
    'common_carrier_price',
    'other_accident_price'
  ];

  @Input() productBenefitData;
  @Input() plans;
  @Input() agentStateMode;
  benefitRiderArray = [];
  agentCmsData: any;
  selectedProductId: string;
  ridersOfCurrentProduct;
  key;
  benefitDataFiltered = [];
  selectedItemsInCart: any;
  isPlanSelectedForCurrentProdct: any;
  constructor(
    public dialog: MatDialog,
    private cmsService: CmsService,
    private store: Store<{ products: ProductState }>
  ) {}

  ngOnInit() {
    this.cmsService.getKey('agent_portal').subscribe(cmsData => {
      this.agentCmsData = cmsData;
    });
  }
  ngOnChanges() {
    this.getSelectedRidersOfProduct();
    this.manipulateRiderTabularData();
    this.getSelectedProduct();
    // this.isPlanSelected();
    this.modifySelectedRiderInCart();
  }

  modifySelectedRiderInCart() {
    if (
      this.ridersOfCurrentProduct &&
      this.ridersOfCurrentProduct.length &&
      this.benefitDataFiltered &&
      this.benefitDataFiltered.length
    ) {
      this.ridersOfCurrentProduct.forEach(element => {
        const riderMatchFromPlan = this.benefitDataFiltered.filter(
          e => e.riderNameCd === element.rider.riderNameCd
        );
        if (riderMatchFromPlan && riderMatchFromPlan.length) {
          const riderSelection = {
            checked: element.selected
          };
          const riderAvailableInCart = {
            available: element.availableInCart
          };
          this.updateRiderInfoInCart(
            riderSelection,
            riderMatchFromPlan[0],
            riderAvailableInCart
          );
        } else {
          const riderSelection = {
            checked: false
          };
          const riderAvailableInCart = {
            available: false
          };
          this.updateRiderInfoInCart(
            riderSelection,
            element.rider,
            riderAvailableInCart
          );
        }
      });
    }
  }

  getSelectedProduct() {
    this.store.select(selectedProduct).subscribe(res => {
      if (res) this.selectedProductId = res.id;
    });
  }
  //getting the checked riders of selected product
  getSelectedRidersOfProduct() {
    this.store.select(selectedPlans).subscribe(res => {
      this.selectedItemsInCart = res;
      if (res && res.value) {
        const selectedPlanForCurrentProduct = res.value.filter(
          e => e.productId === this.selectedProductId
        );
        if (selectedPlanForCurrentProduct.length > 0) {
          const selectedRidersForCurrentProduct =
            selectedPlanForCurrentProduct[0].selectedRiders;
          this.ridersOfCurrentProduct = selectedRidersForCurrentProduct;
          this.isPlanSelectedForCurrentProdct =
            selectedPlanForCurrentProduct[0].selected;
        } else {
          this.isPlanSelectedForCurrentProdct = false;
        }
      }
    });
  }
  isRiderChecked(rider) {
    let riderSelected = false;
    if (this.ridersOfCurrentProduct !== undefined) {
      this.ridersOfCurrentProduct.map(item => {
        if (item.rider.title === rider.title) {
          if (item.selected) {
            riderSelected = true;
          }
        }
      });
    }
    return riderSelected;
  }
  updateRiderInfoInCart($event, rider, availableInCart?) {
    if (this.key === undefined) {
      const selected = $event.checked; //check whether rider is checked or not
      const riderDetails = {
        rider: rider,
        productId: this.selectedProductId,
        selected: selected,
        availableInCart: availableInCart ? availableInCart.available : selected
      };
      this.store.dispatch(
        updateRiderInfoInCart({
          riderDetails: { key: 'from-list', value: riderDetails }
        })
      );
    }
  }

  togglePanel(index) {
    this.selectedPanleIndex === index
      ? (this.selectedPanleIndex = null)
      : (this.selectedPanleIndex = index);
    setTimeout(() => {
      const superscript = document.getElementById('rider-details');
      if (
        superscript &&
        superscript.getElementsByTagName('sup') &&
        superscript.getElementsByTagName('sup')[0]
      ) {
        superscript
          .getElementsByTagName('sup')[0]
          .addEventListener('click', () => {
            this.displayInfoModal(this.dialog, this.agentCmsData);
          });
      }
    }, 100);
  }

  displayInfoModal(dialog, agentCmsData) {
    dialog.open(AflacInfoModalComponent, {
      disableClose: true,
      data: {
        initialState: {
          contentParaOne:
            agentCmsData.start_quote_disease_diagnosis_benefit_rider_popup_content
        }
      },
      panelClass: 'order-review-common-carrier-modal-resizer',
      width: '747px'
    });
  }
  manipulateRiderTabularData() {
    if (this.productBenefitData && this.productBenefitData.length > 0) {
      this.benefitDataFiltered = [];
      this.productBenefitData.forEach(benefitData => {
        const cartObj = Object.assign({}, benefitData);
        cartObj.price = isNaN(benefitData.price[0])
          ? Number(benefitData.price[0].replace('$', '').replace(/,/g, ''))
          : benefitData.price[0];
        benefitData = cartObj;
        // Price manipulation
        const plansRiderData =
          this.plans && this.plans.length ? this.plans[0]['riders'] : [];
        if (plansRiderData && plansRiderData.length) {
          plansRiderData.map(ele => {
            if (ele.riderNameCd === benefitData.title) {
              benefitData.price = isNaN(ele.monthlyPremium)
                ? Number(ele.monthlyPremium.replace('$', '').replace(/,/g, ''))
                : ele.monthlyPremium;
            }
          });
        }
        this.benefitDataFiltered.push(benefitData);
        if (
          (benefitData.common_carrier_accident &&
            benefitData.common_carrier_accident.length > 0) ||
          (benefitData.other_accident && benefitData.other_accident.length > 0)
        ) {
          this.benefitRiderArray = [];
          benefitData.common_carrier_accident.forEach(
            (benefit, benefitIndex) => {
              const benefitObj = {};
              if (benefit) {
                benefitObj['beneficiary'] = benefit.beneficiary;
                benefitObj['common_carrier_price'] = benefit.price;
                benefitObj['other_accident_price'] =
                  benefitData.other_accident[benefitIndex].price;
              }
              this.benefitRiderArray.push(benefitObj);
            }
          );
        } else this.benefitRiderArray = [];
      });
    }
  }

  riderBenefitModal() {
    this.dialog.open(AflacInfoModalComponent, {
      disableClose: true,
      data: {
        initialState: {
          contentParaOne: this.agentCmsData
            .start_quote_rider_additional_benefits_coverage_popup_content
        }
      },
      panelClass: 'order-review-common-carrier-modal-resizer',
      width: '747px'
    });
  }

  riderCommonCarrierModal() {
    this.dialog.open(AflacInfoModalComponent, {
      disableClose: true,
      data: {
        initialState: {
          contentParaOne: this.agentCmsData
            .start_quote_common_carrier_accident_popup_content
        }
      },
      panelClass: 'order-review-common-carrier-modal-resizer',
      width: '747px'
    });
  }
}
