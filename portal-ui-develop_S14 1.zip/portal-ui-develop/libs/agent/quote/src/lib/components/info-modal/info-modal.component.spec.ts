import { AflacInfoModalComponent } from './info-modal.component';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { TranslateModule } from '@ngx-translate/core';
import {
  MatDialogModule,
  MAT_DIALOG_DATA,
  MatDialogRef
} from '@angular/material/dialog';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';

describe('AflacInfoModalComponent', () => {
  let component: AflacInfoModalComponent;
  let fixture: ComponentFixture<AflacInfoModalComponent>;
  const additionalBenefitData = {
    initialState: {
      title: '',
      contentTitleOne: '',
      contentParaOne: '',
      contentTitleTwo: '',
      contentParaTwo: '',
      contentTitleThree: '',
      contentParaThree: ''
    }
  };

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [TranslateModule.forRoot(), MatDialogModule],
      declarations: [AflacInfoModalComponent],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
      providers: [
        { provide: MAT_DIALOG_DATA, useValue: additionalBenefitData },
        { provide: MatDialogRef, useClass: DialogMock }
      ]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AflacInfoModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should call hideModal funtion', () => {
    component.hideModal();
    expect(component as any).toBeDefined();
  });
});
class DialogMock {
  _containerInstance = { _config: { width: '380px' } };
  updatePosition() {}
  close() {}
}
