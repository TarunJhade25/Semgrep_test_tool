import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { TranslateModule } from '@ngx-translate/core';
import { MatDialogModule } from '@angular/material';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { StoreModule, Store, MemoizedSelector } from '@ngrx/store';
import * as fromAgentSearchQuote from '@aflac/agent/shared';
import { CmsService } from '@aflac/shared/cms';

import { ProductState, ProductReducer } from '@aflac/agent/shared';
import { AgentShoppingCartComponent } from './agent-shopping-cart.component';
import { MockStore, provideMockStore } from '@ngrx/store/testing';
import { Observable, of } from 'rxjs';

const cartProducts = [
  {
    productId: 'PREC-IC',
    productName: 'Cancer Insurance',
    plan: {
      id: 'plan07',
      name: 'Lorem ipsum dolor sit',
      title: 'Standard Plan',
      description: 'These are the benefits that you cash.',
      states: ['AL', 'CT', 'LA', 'KS'],
      benefits: [
        {
          id: 'BPLAP601',
          name: 'Initial diagnosis',
          price: '1000',
          period: 'per year',
          categories: [
            {
              id: 'C001',
              name: 'Emergency Care',
              description:
                'Pays when a Covered Person is treated at a hospital emergency room, doctors office, or an ambulatory surgical center within 72 hours of a covered accident.',
              price: '$50',
              benefits: []
            },
            {
              id: 'C002',
              name: 'Blood and Plasma',
              description:
                'Pays when a Covered Person is treated at a hospital emergency room, doctors office, or an ambulatory surgical center within 72 hours of a covered accident.',
              price: '$50',
              benefits: []
            },
            {
              id: 'C003',
              name: 'Hormonal Therapy',
              description:
                'Pays when a Covered Person is treated at a hospital emergency room, doctors office, or an ambulatory surgical center within 72 hours of a covered accident.',
              price: '$50/Month',
              benefits: []
            }
          ],
          startPrice: '',
          endPrice: ''
        },
        {
          id: 'BPLAP602',
          name: 'Cancer screening',
          price: '25',
          period: 'per year',
          categories: [
            {
              id: 'C001',
              name: 'Emergency Care',
              description:
                'Pays when a Covered Person is treated at a hospital emergency room, doctors office, or an ambulatory surgical center within 72 hours of a covered accident.',
              price: '$50',
              benefits: []
            },
            {
              id: 'C002',
              name: 'Blood and Plasma',
              description:
                'Pays when a Covered Person is treated at a hospital emergency room, doctors office, or an ambulatory surgical center within 72 hours of a covered accident.',
              price: '$50',
              benefits: []
            },
            {
              id: 'C003',
              name: 'Hormonal Therapy',
              description:
                'Pays when a Covered Person is treated at a hospital emergency room, doctors office, or an ambulatory surgical center within 72 hours of a covered accident.',
              price: '$50/Month',
              benefits: []
            }
          ],
          startPrice: '',
          endPrice: ''
        },
        {
          id: 'BPLAP603',
          name: 'Radiation',
          price: '600',
          period: 'per month',
          categories: [
            {
              id: 'C001',
              name: 'Emergency Care',
              description:
                'Pays when a Covered Person is treated at a hospital emergency room, doctors office, or an ambulatory surgical center within 72 hours of a covered accident.',
              price: '$50',
              benefits: []
            },
            {
              id: 'C002',
              name: 'Blood and Plasma',
              description:
                'Pays when a Covered Person is treated at a hospital emergency room, doctors office, or an ambulatory surgical center within 72 hours of a covered accident.',
              price: '$50',
              benefits: []
            },
            {
              id: 'C003',
              name: 'Hormonal Therapy',
              description:
                'Pays when a Covered Person is treated at a hospital emergency room, doctors office, or an ambulatory surgical center within 72 hours of a covered accident.',
              price: '$50/Month',
              benefits: []
            }
          ],
          startPrice: '',
          endPrice: ''
        },
        {
          id: 'BPLAP604',
          name: 'Hospital stay',
          price: '100',
          period: 'per day',
          categories: [
            {
              id: 'C001',
              name: 'Emergency Care',
              description:
                'Pays when a Covered Person is treated at a hospital emergency room, doctors office, or an ambulatory surgical center within 72 hours of a covered accident.',
              price: '$50',
              benefits: []
            },
            {
              id: 'C002',
              name: 'Blood and Plasma',
              description:
                'Pays when a Covered Person is treated at a hospital emergency room, doctors office, or an ambulatory surgical center within 72 hours of a covered accident.',
              price: '$50',
              benefits: []
            },
            {
              id: 'C003',
              name: 'Hormonal Therapy',
              description:
                'Pays when a Covered Person is treated at a hospital emergency room, doctors office, or an ambulatory surgical center within 72 hours of a covered accident.',
              price: '$50/Month',
              benefits: []
            }
          ],
          startPrice: '',
          endPrice: ''
        }
      ],
      price: '16.93'
    },
    coverage: 'ind',
    selected: true,
    availableInCart: true,
    selectedRiders: [
      {
        rider: {
          title: 'Initial Diagnosis Increasing Benefit Rider',
          description:
            'Help ease the devastating impact and financial challenges of a cancer diagnosis with additional coverage that increases the amount you receive if you are diagnosed with a covered cancer or an associated cancerous condition. Your Initial Diagnosis Benefit will increase by the amount shown. Coverage accumulates each year on the anniversary date of your policy while it’s in effect. Example: If your plan’s Initial Diagnosis Benefit is $1,000 and you add $200, your benefit amount at your one-year anniversary date would be $1,200. At your two-year anniversary date, $1,400. Just as investing helps your money grow, this rider helps your initial Diagnosis Benefit grow.',
          price: '500',
          benefit: [
            {
              title: 'Hospitalization',
              price: '$150 / day',
              benefit_category: []
            },
            {
              title: 'ICU',
              price: '$300 / day',
              benefit_category: []
            },
            {
              title: 'Ambulance',
              price: '$200 ground $2000 air',
              benefit_category: []
            },
            {
              title: 'Transportation',
              price: '',
              benefit_category: [
                {
                  title:
                    'Via bus, trolley, boat; or private, rental or taxi vehicle',
                  price: '$100 / round trip',
                  carrier_flag: false
                },
                {
                  title: 'Via common carrier',
                  price: '$500 / round trip',
                  carrier_flag: true
                },
                {
                  title: 'For dependent child and immediate family member',
                  price: '$1,000 / round trip',
                  carrier_flag: false
                }
              ]
            },
            {
              title: 'Lodging Benefit',
              price: '$65 / night',
              benefit_category: []
            },
            {
              title: 'Continuing Care',
              price: '$50 / day',
              benefit_category: []
            }
          ]
        },
        productId: 'PREC-IC',
        selected: true,
        availableInCart: true
      },
      {
        rider: {
          title: 'Specified-Disease Diagnosis Benefit Rider',
          description:
            'Receive an extra layer of protection against the financial burden of an unexpected diagnosis. This benefit pays an additional cash amount when you and/or your covered family members are diagnosed with a specified disease and also pays an added amount every day you are in the hospital. See benefit amounts below.',
          price: '2,000',
          benefit: [
            {
              title: 'Initial Benefit',
              price: '$2,000',
              benefit_category: []
            },
            {
              title: 'Hospital confinement (30 days or less)',
              price: '$400/day',
              benefit_category: []
            },
            {
              title: 'Hospital confinement (31 days or more)',
              price: '$800/day',
              benefit_category: []
            }
          ]
        },
        productId: 'PREC-IC',
        selected: true,
        availableInCart: true
      }
    ]
  }
];

const data = {
  key: '',
  product: {
    riders: [{ selected: true, price: '10' }]
  },
  selected: true,
  price: '100',
  rider: { selected: true, price: '10' }
};
const cmsData = [{ code: 'ind', default_value: 'you' }];
class MockCmsService {
  getKey(any): Observable<any> {
    const coverage = { coverage_types: cmsData };
    return of(coverage);
  }
}

describe('AgentShoppingCartComponent', () => {
  let component: AgentShoppingCartComponent;
  let fixture: ComponentFixture<AgentShoppingCartComponent>;
  let store: MockStore<ProductState>;
  let mockStore: MockStore<any>;
  let mockQuoteSelector: MemoizedSelector<any, any>;
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        TranslateModule.forRoot(),
        StoreModule.forRoot(ProductReducer),
        MatDialogModule
      ],
      providers: [
        provideMockStore({}),
        { provide: CmsService, useClass: MockCmsService }
      ],
      declarations: [AgentShoppingCartComponent],
      schemas: [CUSTOM_ELEMENTS_SCHEMA]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AgentShoppingCartComponent);
    mockStore = TestBed.get(Store);
    store = TestBed.get(Store);
    mockQuoteSelector = mockStore.overrideSelector(
      fromAgentSearchQuote.selectedPlans,
      { key: 'from-list', value: cartProducts }
    );
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should subscribe to store data on component init', () => {
    spyOn(component, 'getCartProducts').and.callThrough();
    component.ngOnInit();
    expect(component.cartProducts.length).toBeGreaterThan(0);
  });

  it('should update value in cart and montly cost for products', () => {
    spyOn(component, 'getCartProducts').and.callThrough();
    component.ngOnInit();
    const sum = component.CartSubTotal();
    expect(sum).toBeGreaterThan(0);
  });

  it('should update montly cost when checkbox cahnges', () => {
    spyOn(component, 'monthlyPlanSubTotal');
    component.onCheckBoxChange(data);
    expect(component.monthlyPlanSubTotal).toHaveBeenCalled();
  });

  it('should map benifit data to desired format', () => {
    const benefit = component.mapBenefitAmount(10000);
    expect(benefit).toEqual('$10K');
  });
});
