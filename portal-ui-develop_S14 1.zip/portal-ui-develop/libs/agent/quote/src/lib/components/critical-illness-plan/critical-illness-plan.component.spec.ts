import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { CriticalIllnessPlanComponent } from './critical-illness-plan.component';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { TranslateModule } from '@ngx-translate/core';
import { CardComponent } from '@aflac/shared/ui';
import { NewLinePipe } from '@aflac/agent/shared';
import { StoreModule, Store, MemoizedSelector } from '@ngrx/store';
import { ProductState, ProductReducer } from '@aflac/agent/shared';
import { provideMockStore, MockStore } from '@ngrx/store/testing';
import { of } from 'rxjs';
import * as fromProduct from '@aflac/agent/shared';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatRadioModule } from '@angular/material/radio';
import * as fromProductAuth from '@aflac/agent/shared';
import { getRetrieveQuoteData } from '@aflac/agent/landing';
const plan = {
  id: 11111,
  price: '100',
  description: 'These are the benefits',
  name: 'Lorem ipsum',
  states: ['AL', 'CT'],
  title: 'Standard Plan',
  benefits: [
    {
      id: 333,
      name: 'test',
      price: 123
    }
  ]
};
const planList = [
  {
    id: 1001,
    name: 'test',
    title: 'insurance',
    benefits: [
      { id: 5001, name: 'Accident Rider 1', price: 14.23 },
      { id: 5002, name: 'Accident Rider 2', price: 24.23 }
    ]
  }
];
const productsList = [
  {
    features: [
      'Accidental Death & Dismemberment',
      'Accidental Injury',
      'Non-Injury hospital admission benefits'
    ],
    id: 1001,
    image: 'assets/images/accident_2.svg',
    productName: 'Accident Insurance',
    riders: [
      { description: '', id: 5001, name: 'Accident Rider 1', value: 14.23 },
      { description: '', id: 5002, name: 'Accident Rider 2', value: 24.23 }
    ],
    startingPrice: 12.32,
    states: ['AK', 'AZ', 'CA'],
    name: 'Accident Insurance'
  }
];
const product = {
  features: [
    'Accidental Death & Dismemberment',
    'Accidental Injury',
    'Non-Injury hospital admission benefits'
  ],
  id: 1001,
  image: 'assets/images/accident_2.svg',
  productName: 'Accident Insurance',
  riders: [
    { description: '', id: 5001, name: 'Accident Rider 1', value: 14.23 },
    { description: '', id: 5002, name: 'Accident Rider 2', value: 24.23 }
  ],
  startingPrice: 12.32,
  states: ['AK', 'AZ', 'CA'],
  name: 'test'
};
const selectedPlans = {
  key: 'from-list',
  value: [
    {
      productId: 'PREC-IC',
      productName: 'Accident',
      plan: {
        id: 'PREC-IC',
        name: 'test',
        title: 'insurance',
        benefits: [
          { id: 5001, name: 'Accident Rider 1', price: 14.23 },
          { id: 5002, name: 'Accident Rider 2', price: 24.23 }
        ]
      },
      coverage: 'ind',
      selected: true,
      availableInCart: true,
      selectedRiders: [
        {
          selected: true,
          availableInCart: true,
          productId: 'prec-ic',
          rider: []
        }
      ]
    }
  ]
};

const agentSearchedDetails = {
  stateProvCd: 'AL',
  age: 40,
  state: 'Alabama'
};
const RetrieveQuote = {
  bundleId: '000',
  policyNumber: 'a1b2',
  effectiveDate: '01/02/2019',
  expirationDate: '01/06/2019',
  transactionEffectiveDate: '03/02/2019',
  policyStatusCd: 'dummy',
  productCode: 'Ab-Ab',
  lobCd: 'dummy',
  totalPremium: 1234,
  currencyCode: 'ind',
  producerCd: 'dummy',
  subProducerCd: 'd'
};
const responseData = {
  value: [
    {
      productId: 'PREC-IC',
      selected: true,
      availableInCart: true,
      plan: { id: 'id1' },
      selectedRiders: [
        {
          rider: { title: 'title1' },
          selected: true,
          availableInCart: true,
          plan: { id: 'id1' }
        },
        {
          rider: { title: 'title2' },
          selected: true,
          availableInCart: true,
          plan: { id: 'id1' }
        }
      ]
    },
    {
      productId: 'PREC-ICI',
      selected: true,
      availableInCart: true,
      plan: { id: 'id2' },
      selectedRiders: [
        {
          rider: { title: 'title1' },
          selected: true,
          availableInCart: true,
          plan: { id: 'id1' }
        },
        {
          rider: { title: 'title2' },
          selected: true,
          availableInCart: true,
          plan: { id: 'id1' }
        }
      ]
    }
  ]
};
describe('CriticalIllnessPlanComponent', () => {
  let component: CriticalIllnessPlanComponent;
  let fixture: ComponentFixture<CriticalIllnessPlanComponent>;
  let mockStore: MockStore<any>;
  let store: Store<ProductState>;
  let mockPlanSelector: MemoizedSelector<any, any>;
  let mockQuoteSelector: MemoizedSelector<any, any>;
  let mockSelectedProductSelector: MemoizedSelector<any, any>;
  let mockRetrieveQuoteData: MemoizedSelector<any, any>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        ReactiveFormsModule,
        FormsModule,
        MatFormFieldModule,
        MatInputModule,
        TranslateModule.forRoot(),
        MatSelectModule,
        MatRadioModule,
        StoreModule.forRoot({ ProductReducer })
      ],
      providers: [provideMockStore({})],
      declarations: [CriticalIllnessPlanComponent, CardComponent, NewLinePipe],
      schemas: [CUSTOM_ELEMENTS_SCHEMA]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CriticalIllnessPlanComponent);
    mockStore = TestBed.get(Store);
    store = TestBed.get(Store);
    mockPlanSelector = mockStore.overrideSelector(
      fromProductAuth.plans,
      planList
    );

    mockQuoteSelector = mockStore.overrideSelector(
      fromProduct.selectedPlans,
      selectedPlans
    );
    mockSelectedProductSelector = mockStore.overrideSelector(
      fromProductAuth.selectedProduct,
      productsList[0]
    );
    mockRetrieveQuoteData = mockStore.overrideSelector(
      getRetrieveQuoteData,
      RetrieveQuote
    );
    component = fixture.componentInstance;
    // component.agentSelectedQuote = agentSearchedDetails;
    fixture.detectChanges();
  });

  it('should create', () => {
    console.log('Starting.Critical Illnes should create');
    expect(component).toBeTruthy();
    console.log('Ending..Critical Illnes should create');
    console.log('Ending.Critical Illnes should create');
  });

  it('should emit closePlans() from close funtion', () => {
    console.log('starting..should emit closePlans() from close funtion');
    component.close();
    expect(component as any).toBeDefined();
    console.log('ending..should emit closePlans() from close funtion');
  });

  // Test cases for add to cart functionalities
  it('should call ngOnChanges function', () => {
    console.log('starting..should call ngOnChanges function');
    spyOn(component, 'getSelectedProduct').and.returnValue(true);
    spyOn(component, 'updateCoverageInStore').and.returnValue(true);
    component.plans = plan;

    component.ngOnChanges();
    expect(component as any).toBeDefined();
  });

  it('should call getSelectedProduct funtion', () => {
    console.log('starting..should call getSelectedProduct funtion');
    const selectedProduct = product;
    spyOn(store, 'select').and.returnValue(of(selectedProduct));
    spyOn(component, 'getSelectedPlan').and.returnValue(true);
    component.getSelectedProduct();
    expect(component.selectedProductId).toEqual(selectedProduct.id);
    console.log('ending..should call getSelectedProduct funtion');
  });
  it('should call getSelectedPlan funtion', () => {
    console.log('starting..should call getSelectedPlan funtion');
    spyOn(store, 'select').and.returnValue(of(responseData));
    component.selectedProductId = 'PREC-IC';
    component.getSelectedPlan();
    expect(component.selectedPlanId).toEqual(responseData.value[1].plan.id);
    console.log('ending..should call getSelectedPlan funtion');
  });

  it('should dispatch addItemToCart function ', () => {
    console.log('starting..should dispatch addItemToCart function ');
    spyOn(store, 'dispatch').and.returnValue(true);
    spyOn(component, 'getSelectedCoverageOfCurrentProduct').and.returnValue(
      true
    );
    component.selectedProductCoverage = [
      {
        coverageType: 'ind'
      }
    ];
    component.onPlanSelected(plan);
    expect(store.dispatch).toHaveBeenCalled();
    console.log('ending..should dispatch addItemToCart function ');
  });

  it('should call updateCoverageInStore funtion', () => {
    console.log('starting..should call updateCoverageInStore funtion');
    component.updateCoverageInStore();
    expect(component as any).toBeDefined();
    console.log('ending..should call updateCoverageInStore funtion');
  });

  it('should update selectedProductCoverage eachtime coverage changes', () => {
    console.log(
      'starting..should update selectedProductCoverage eachtime coverage changes'
    );
    spyOn(store, 'select').and.returnValues(of(responseData.value));
    component.selectedProductId = 'PREC-IC';
    component.getSelectedCoverageOfCurrentProduct();
    expect(component.selectedProductCoverage).toBeTruthy();
    console.log(
      'ending..should update selectedProductCoverage eachtime coverage changes'
    );
  });
  it('should call onCriticalIllnessCoverageChange and update corresponding values', () => {
    const el = { value: '15000' };
    component.onCriticalIllnessCoverageChange(el);
    expect(component as any).toBeDefined();
  });
  it('should showHideDescription', () => {
    component.showDescription = true;
    expect(component.showHideDescription()).toBeFalsy();
  });
  it('should call criticalIllnessTobaccoOptionUpdate and update corresponding values', () => {
    const el = { value: true };
    component.criticalIllnessTobaccoOptionUpdate(el);
    expect(component as any).toBeDefined();
  });
  it('should call onCancerCoverageChange and update corresponding values', () => {
    component.onCancerCoverageChange();
    expect(component as any).toBeDefined();
  });
});
