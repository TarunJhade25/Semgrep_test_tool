import {
  Component,
  Input,
  Output,
  EventEmitter,
  AfterViewInit
} from '@angular/core';
import { CmsService } from '@aflac/shared/cms';

@Component({
  selector: 'aflac-agent-card',
  templateUrl: './agent-card.component.html',
  styleUrls: ['./agent-card.component.scss']
})
export class AgentCardComponent implements AfterViewInit {
  constructor(public cmsService: CmsService) {}
  @Input()
  buttonLabel;
  @Input()
  cardDimension;
  @Input()
  cardEntity: any;
  @Input()
  count: number;
  @Input() selectedIndex: number;

  @Output()
  cardEmitter = new EventEmitter<any>();
  ngAfterViewInit() {
    // if (this.count === 0) {
    //   document.getElementById('cardcheck').focus();
    // }
  }
}
