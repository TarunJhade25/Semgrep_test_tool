import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { TranslateModule } from '@ngx-translate/core';
import { SharedMaterialModule } from '@aflac/shared/material';
import { MatDialogModule } from '@angular/material';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { BrowserDynamicTestingModule } from '@angular/platform-browser-dynamic/testing';
import { ProductRiderComponent } from './product-rider.component';
import { AflacInfoModalComponent } from '../info-modal/info-modal.component';
import { StoreModule, Store, MemoizedSelector } from '@ngrx/store';
import { ProductState, ProductReducer } from '@aflac/agent/shared';
import { of } from 'rxjs';

const commonCarrierAccident = [
  {
    beneficiary: '',
    price: ''
  }
];
const otherAccident = [
  {
    beneficiary: '',
    price: ''
  }
];

const productBenefitData = [
  { title: 'Additional Benefit Rider', description: '', price: ['$500'] }
];
const riderResponseData = {
  value: [
    {
      productId: 'PREC-IC',
      selectedRiders: [
        { rider: { title: '' }, selected: true, availableInCart: true },
        { rider: { title: '' } }
      ]
    }
  ]
};
const ridersOfCurrentProduct = [
  {
    rider: {
      title: 'Initial Diagnosis Increasing Benefit Rider',
      price: 500,
      benefit: [
        {
          title: 'Hospitalization',
          price: '$150 / day',
          benefit_category: []
        }
      ],
      riderNameCd: 'Cancer Initial Diagnosis Increasing Benefit Rider'
    },
    productId: 'PREC-IC',
    selected: true,
    availableInCart: true
  }
];

const benefitDataFiltered = [
  {
    title: 'Initial Diagnosis Increasing Benefit Rider',
    price: 500,
    benefit: [
      {
        title: 'Hospitalization',
        price: '$150 / day',
        benefit_category: []
      }
    ],
    riderNameCd: 'Cancer Initial Diagnosis Increasing Benefit Rider'
  }
];
const index = 1;

describe('ProductRiderComponent', () => {
  let component: ProductRiderComponent;
  let fixture: ComponentFixture<ProductRiderComponent>;
  let store: Store<ProductState>;
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        TranslateModule.forRoot(),
        SharedMaterialModule,
        MatDialogModule,
        BrowserAnimationsModule,
        BrowserDynamicTestingModule,
        StoreModule.forRoot({ ProductReducer })
      ],
      declarations: [ProductRiderComponent, AflacInfoModalComponent],
      schemas: [CUSTOM_ELEMENTS_SCHEMA]
    })
      .overrideModule(BrowserDynamicTestingModule, {
        set: {
          entryComponents: [AflacInfoModalComponent]
        }
      })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ProductRiderComponent);
    component = fixture.componentInstance;
    component.benefitRiderArray = [];
    component.productBenefitData = productBenefitData;
    component.productBenefitData.common_carrier_accident = commonCarrierAccident;
    component.productBenefitData.other_accident = otherAccident;
    store = TestBed.get(Store);
    spyOn(store, 'select').and.returnValue(of(riderResponseData));
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should call ngOnChanges function', () => {
    spyOn(component, 'ngOnChanges').and.callThrough();
    component.ngOnChanges();
    expect(component.ngOnChanges).toHaveBeenCalled();
  });

  it('should call togglePanel funtion', () => {
    component.togglePanel(index);
    expect(component.selectedPanleIndex).toBe(1);
  });

  it('should call riderBenefitModal funtion', () => {
    component.riderBenefitModal();
    expect(component as any).toBeDefined();
  });

  it('should call riderCommonCarrierModal funtion', () => {
    component.riderCommonCarrierModal();
    expect(component as any).toBeDefined();
  });

  it('should call manipulateRiderTabularData funtion', () => {
    component.manipulateRiderTabularData();
    expect(component as any).toBeDefined();
  });

  it('should manipulate benefitRiderArray ', () => {
    component.manipulateRiderTabularData();
    const benefitObj = {};
    benefitObj['beneficiary'] = 'You';
    benefitObj['common_carrier_price'] = '$5';
    benefitObj['other_accident_price'] = '$10';
    component.benefitRiderArray.push(benefitObj);
    expect(component.benefitRiderArray).toBeTruthy();
  });

  it('should call getSelectedRidersOfProduct funtion', () => {
    component.selectedProductId = 'PREC-IC';
    component.getSelectedRidersOfProduct();
    expect(component.ridersOfCurrentProduct).toEqual(
      riderResponseData.value[0].selectedRiders
    );
  });

  it('should call isRiderChecked funtion', () => {
    const selectedrider = { title: '' };
    component.ridersOfCurrentProduct =
      riderResponseData.value[0].selectedRiders;
    component.selectedProductId = 'PREC-IC';
    component.isRiderChecked(selectedrider);
    expect(component.isRiderChecked(selectedrider)).toBeTruthy();
  });

  it('should update rider in cart', () => {
    spyOn(component, 'updateRiderInfoInCart').and.returnValue(true);
    component.ridersOfCurrentProduct = ridersOfCurrentProduct;
    component.benefitDataFiltered = benefitDataFiltered;
    component.modifySelectedRiderInCart();
    expect(component.updateRiderInfoInCart).toHaveBeenCalled();
  });
});
