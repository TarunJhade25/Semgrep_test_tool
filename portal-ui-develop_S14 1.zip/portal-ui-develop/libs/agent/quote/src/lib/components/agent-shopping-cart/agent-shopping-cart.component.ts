import {
  Component,
  OnInit,
  OnDestroy,
  Input,
  ChangeDetectorRef,
  AfterViewChecked
} from '@angular/core';
import { Store } from '@ngrx/store';
import {
  ProductState,
  selectedPlans,
  addItemToCart,
  updateRiderInfoInCart
} from '@aflac/agent/shared'; // Reducer
import { MatDialog } from '@angular/material';
import { CmsService } from '@aflac/shared/cms';
import { CartProducts, SelectedRiderInCart } from '@aflac/agent/quote';
import { Subscription } from 'rxjs';
import { ShoppingCartService } from '@aflac/agent/shared';

@Component({
  selector: 'aflac-agent-shopping-cart',
  templateUrl: './agent-shopping-cart.component.html',
  styleUrls: ['./agent-shopping-cart.component.scss']
})
export class AgentShoppingCartComponent
  implements OnInit, AfterViewChecked, OnDestroy {
  @Input() agentStateMode: boolean;

  public cartProducts: any;
  public shoppingCartProducts: CartProducts[];
  public cartCount: number;
  public checkBoxModal = true;
  public editable = true; // TODO: TRUE by default. FALSE - retrieve quote initial flow
  public cartSum: number;
  public coverageTypes: any;
  public currentState: any;
  public subscription = new Subscription();
  public key: any;
  constructor(
    public dialog: MatDialog,
    private cdr: ChangeDetectorRef,
    private store: Store<ProductState>,
    private cmsService: CmsService,
    private shoppingCartService: ShoppingCartService
  ) {}

  ngOnInit() {
    this.cartProducts = [];
    this.getAgentCMSData();
    this.getCartProducts();
  }

  mapBenefitAmount(intDiagnosisBenefitAmount) {
    if (intDiagnosisBenefitAmount) {
      return `$${intDiagnosisBenefitAmount / 1000}K`;
    }
  }
  ngOnDestroy() {
    this.subscription.unsubscribe();
  }
  getCartProducts() {
    this.subscription = this.store.select(selectedPlans).subscribe(res => {
      this.key = res && res.key;
      /* 
        Data mapped only for key 'from-list' for state management
       */
      if (this.key === 'from-list' || this.key === 'from-cart') {
        this.currentState = res.value;
        if (this.currentState && this.currentState.length > 0) {
          this.currentState.forEach(element => {
            const item: CartProducts = {
              productId: element.productId,
              productName: element.productName,
              plan: element.plan.title,
              coverageType: element.coverage,
              price: isNaN(element.plan.price)
                ? Number(element.plan.price.replace('$', '').replace(/,/g, ''))
                : element.plan.price,
              selected: element.selected,
              availableInCart: element.availableInCart,
              currentPlanState: element.plan,
              riders: [],
              benefitAmount: element.benefitAmount,
              tobaccoInd: element.tobaccoInd,
              cancerCoverage: element.cancerCoverage
            };
            if (element.selectedRiders) {
              element.selectedRiders.forEach(riderItem => {
                const rider: SelectedRiderInCart = {
                  name: riderItem.rider.title,
                  price: isNaN(riderItem.rider.price)
                    ? Number(
                        riderItem.rider.price.replace('$', '').replace(/,/g, '')
                      )
                    : riderItem.rider.price,
                  selected: !element.selected ? false : riderItem.selected,
                  availableInCart: riderItem.availableInCart,
                  currentRiderState: riderItem.rider
                };
                item.riders.push(rider);
              });
            }
            const index = this.cartProducts.findIndex(entry => {
              return entry.productId === item.productId;
            });
            if (index < 0) this.cartProducts.push(item);
            else this.cartProducts[index] = item;
          });
        }
        this.cartProducts.forEach(plans => {
          plans.MonthlyPrice = this.monthlyPlanSubTotal(plans);
        });
      } else if (res && res.key === undefined && res.value === undefined) {
        /* To update cart on changing the search fields */
        this.cartProducts = [];
      }
    });
  }

  /* To get coverage types code and default_value from CMS service*/
  getAgentCMSData() {
    this.coverageTypes = {};
    this.cmsService.getKey('agent_portal').subscribe(agentCMSData => {
      if (agentCMSData.coverage_types) {
        agentCMSData.coverage_types.forEach(element => {
          const data = { [element.code]: element.default_value };
          this.coverageTypes = Object.assign(this.coverageTypes, data);
        });
      }
    });
  }

  /* To find the number of selected products inside cart */
  getCartCount() {
    let cartSum = 0;
    this.cartProducts.forEach(plans => {
      cartSum = plans.selected ? cartSum + 1 : cartSum;
    });
    this.cartCount = cartSum;
    return cartSum;
  }

  /*  To eliminate change detection error / Expression change after content init Error */
  ngAfterViewChecked() {
    this.cdr.detectChanges();
  }

  /*  To find sum of individual plan and selected riders */
  monthlyPlanSubTotal(plan) {
    let monthlySum = 0;
    monthlySum = plan.selected
      ? monthlySum + this.getNumeric(plan.price)
      : monthlySum;
    if (plan.selected && plan.riders && plan.riders.length > 0) {
      plan.riders.forEach(rider => {
        monthlySum = rider.selected
          ? monthlySum + this.getNumeric(rider.price)
          : monthlySum;
      });
    }
    plan.MonthlyPrice = monthlySum.toFixed(2);
    return monthlySum.toFixed(2);
  }

  getNumeric(stringVal) {
    if (isNaN(stringVal)) stringVal = stringVal.replace(/,/g, '');
    return Number(stringVal);
  }

  /* To find the sum of all products selected inside cart */
  CartSubTotal() {
    let sumVal = 0;
    if (this.cartProducts && this.cartProducts.length > 0) {
      this.cartProducts.forEach(element => {
        sumVal = element.MonthlyPrice
          ? sumVal + Number(this.getNumeric(element.MonthlyPrice).toFixed(2))
          : sumVal;
      });
      const headerPayload = { price: sumVal.toFixed(2), count: this.cartCount };
      this.shoppingCartService.updateShoppingCartPrice(headerPayload);
      return sumVal.toFixed(2);
    }
  }

  /* To update monthly cost based on selection */
  onCheckBoxChange(changedVal) {
    if (!changedVal.product.selected) this.changeRiderStatus(changedVal);
    this.monthlyPlanSubTotal(changedVal.product);
    this.updateStoreValues(changedVal);
  }

  /* To update rider selection based on plan selection */
  changeRiderStatus(data) {
    const riders = data.product.riders;
    riders.forEach(rider => {
      if (rider.selected) {
        // dispatch action if rider is selected to update store
        rider.selected = false;
        const dataToDispatch = {
          key: 'rider',
          rider: rider,
          product: data.product
        };
        this.updateStoreValues(dataToDispatch);
      }
    });
  }
  updateStoreValues(data) {
    if (data.key === 'plan') {
      const selectedPlanDetails = {
        productId: data.product.productId,
        productName: data.product.productName,
        plan: data.product.currentPlanState,
        coverage: data.product.coverageType,
        availableInCart: true,
        selected: data.product.selected,
        startingPrice: data.product.startingPrice,
        tobaccoInd: data.product.tobaccoInd,
        cancerCoverage: data.product.cancerCoverage,
        benefitAmount: data.product.benefitAmount
      };
      const dataToSent = { key: 'from-cart', value: selectedPlanDetails };
      this.store.dispatch(addItemToCart({ selectedPlan: dataToSent }));
    } else if (data.key === 'rider') {
      const riderDetails = {
        rider: data.rider.currentRiderState,
        productId: data.product.productId,
        selected: data.rider.selected,
        availableInCart: data.rider.availableInCart
      };
      const dataToSent = { key: 'from-cart', value: riderDetails };
      this.store.dispatch(updateRiderInfoInCart({ riderDetails: dataToSent }));
    }
  }
}
