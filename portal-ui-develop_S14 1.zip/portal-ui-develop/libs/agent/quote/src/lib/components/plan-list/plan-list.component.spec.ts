import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { TranslateModule } from '@ngx-translate/core';
import { RouterTestingModule } from '@angular/router/testing';
import { PlanListComponent } from './plan-list.component';
import { CardComponent } from '@aflac/shared/ui';
import { NewLinePipe } from '@aflac/agent/shared';
import { StoreModule, Store, MemoizedSelector } from '@ngrx/store';
import { ProductState, ProductReducer } from '@aflac/agent/shared';
import { provideMockStore, MockStore } from '@ngrx/store/testing';
import { of } from 'rxjs';
import * as fromProduct from '@aflac/agent/shared';
import { MatSelectModule } from '@angular/material/select';

const plan = {
  id: 123,
  price: '100',
  description: 'These are the benefits',
  name: 'Lorem ipsum',
  states: ['AL', 'CT'],
  title: 'Standard Plan',
  benefits: [
    {
      id: 333,
      name: 'test',
      price: 123
    }
  ]
};
const plans = [
  {
    id: 'id1',
    price: '100',
    description: 'These are the benefits',
    name: 'Lorem ipsum',
    states: ['AL', 'CT'],
    title: 'Standard Plan',
    benefits: [
      {
        id: 333,
        name: 'test',
        price: 123
      }
    ]
  }
];

const product = {
  features: [
    'Accidental Death & Dismemberment',
    'Accidental Injury',
    'Non-Injury hospital admission benefits'
  ],
  id: 1001,
  image: 'assets/images/accident_2.svg',
  productName: 'Accident Insurance',
  riders: [
    { description: '', id: 5001, name: 'Accident Rider 1', value: 14.23 },
    { description: '', id: 5002, name: 'Accident Rider 2', value: 24.23 }
  ],
  startingPrice: 12.32,
  states: ['AK', 'AZ', 'CA'],
  name: 'test'
};

const responseData = {
  value: [
    {
      productId: 'PREC-IC',
      selected: true,
      availableInCart: true,
      plan: { id: 'id1' },
      selectedRiders: [
        {
          rider: { title: 'title1' },
          selected: true,
          availableInCart: true,
          plan: { id: 'id1' }
        },
        {
          rider: { title: 'title2' },
          selected: true,
          availableInCart: true,
          plan: { id: 'id1' }
        }
      ]
    }
  ]
};

describe('PlanListComponent', () => {
  let component: PlanListComponent;
  let fixture: ComponentFixture<PlanListComponent>;
  // let quoteStore: Store<ProductState>;
  let mockStore: MockStore<any>;
  let store: Store<ProductState>;
  // let mockQuoteSelector: MemoizedSelector<any, any>;
  let mockProductSelector: MemoizedSelector<any, any>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        TranslateModule.forRoot(),
        MatSelectModule,
        StoreModule.forRoot({ ProductReducer })
      ],
      providers: [provideMockStore({})],
      declarations: [PlanListComponent, CardComponent, NewLinePipe],
      schemas: [CUSTOM_ELEMENTS_SCHEMA]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PlanListComponent);
    mockStore = TestBed.get(Store);
    store = TestBed.get(Store);
    mockProductSelector = mockStore.overrideSelector(
      fromProduct.products,
      product
    );
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    console.log('Starting..Plan list should create');
    expect(component).toBeTruthy();
    console.log('Ending..Plan list should create');
  });

  it('should emit closePlans() from close funtion', () => {
    console.log(
      'Starting..Plan list should emit closePlans() from close funtion'
    );
    component.close();
    expect(component as any).toBeDefined();
    console.log(
      'Ending..Plan list should emit closePlans() from close funtion'
    );
  });

  it('should update cart on chnage in coverage type', () => {
    spyOn(component, 'onPlanSelected').and.returnValue(true);
    component.currentState = responseData.value;
    component.selectedPlanId = 'id1';
    component.selectedProductId = 'PREC-IC';
    component.plans = plans;
    component.updateCoverageInStore();
    expect(component.onPlanSelected).toHaveBeenCalled();
  });

  it('should call getSelectedProduct funtion', () => {
    console.log('Starting..Plan list should call getSelectedProduct funtion');
    const selectedProduct = product;
    spyOn(store, 'select').and.returnValue(of(selectedProduct));
    spyOn(component, 'getSelectedPlan').and.returnValue(true);
    component.getSelectedProduct();
    expect(component.selectedProductId).toEqual(selectedProduct.id);
    console.log('Ending..Plan list should call getSelectedProduct funtion');
  });
  it('should call getSelectedPlan funtion', () => {
    console.log('Starting..Plan list should call getSelectedPlan funtion');
    spyOn(store, 'select').and.returnValue(of(responseData));
    component.selectedProductId = 'PREC-IC';
    component.getSelectedPlan();
    expect(component.selectedPlanId).toEqual(responseData.value[0].plan.id);
    console.log('Ending..Plan list should call getSelectedPlan funtion');
  });

  it('should dispatch addItemToCart function ', () => {
    console.log('Starting..Plan list should dispatch addItemToCart function');
    spyOn(store, 'dispatch').and.returnValue(true);
    spyOn(component, 'getSelectedCoverageOfCurrentProduct').and.returnValue(
      true
    );
    component.selectedProductCoverage = [
      {
        coverageType: 'me'
      }
    ];
    component.onPlanSelected(plan);
    expect(store.dispatch).toHaveBeenCalled();
    console.log('Ending..Plan list should dispatch addItemToCart function');
  });

  it('should call updateCoverageInStore funtion', () => {
    console.log(
      'Starting..Plan list should call updateCoverageInStore funtion'
    );
    component.updateCoverageInStore();
    expect(component as any).toBeDefined();
    console.log('Ending..Plan list should call updateCoverageInStore funtion');
  });

  it('should update selectedProductCoverage eachtime coverage changes', () => {
    console.log(
      'Starting..Plan list should update selectedProductCoverage eachtime coverage changes'
    );
    spyOn(store, 'select').and.returnValues(of(responseData.value));
    component.selectedProductId = 'PREC-IC';
    component.getSelectedCoverageOfCurrentProduct();
    expect(component.selectedProductCoverage).toEqual(responseData.value);
    console.log(
      'Ending..Plan list should update selectedProductCoverage eachtime coverage changes'
    );
  });
});
