import { Component, OnInit, Inject } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';

@Component({
  selector: 'aflac-info-modal',
  templateUrl: './info-modal.component.html',
  styleUrls: ['./info-modal.component.scss']
})
export class AflacInfoModalComponent implements OnInit {
  constructor(
    public dialogRef: MatDialogRef<AflacInfoModalComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) {}

  ngOnInit() {}

  hideModal() {
    this.dialogRef.close(true);
  }
}
