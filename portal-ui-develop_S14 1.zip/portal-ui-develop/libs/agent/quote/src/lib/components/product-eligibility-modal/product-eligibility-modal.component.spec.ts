import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { TranslateModule } from '@ngx-translate/core';
import {
  MatDialogModule,
  MatDialogRef,
  MatDialog,
  MAT_DIALOG_DATA
} from '@angular/material/dialog';
import { RouterTestingModule } from '@angular/router/testing';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { provideMockStore } from '@ngrx/store/testing';
import { ProductEligibilityModalComponent } from './product-eligibility-modal.component';
import { CmsService } from '@aflac/shared/cms';
import { Observable, of } from 'rxjs';
import { Router } from '@angular/router';
import { AgentSharedService } from '@aflac/agent/shared';

class MockCmsService {
  getKey(any): Observable<any> {
    const data = { start_quote_cancer_rider: lookupdata };
    return of(data);
  }
}

const lookupdata = {};

const quoteDetails = {
  payload: {
    customerId: '510002',
    customerName: 'Johnson Smithish',
    eligiblePlans: [
      {
        planId: 'plan04',
        planTitle: 'Option 2',
        productId: 'PREC-ICI',
        productName: 'Critical Illness Insurance'
      }
    ],
    inEligiblePlans: [
      {
        productId: 'PREC-IC',
        productName: 'Cancer Insurance',
        planId: 'plan07',
        planTitle: 'Standard Plan'
      }
    ],
    selectedCartItems: [
      {
        productId: 'PREC-IC',
        productName: 'Cancer Insurance',
        plan: { title: 'Standard Plan', price: 16.93 },
        selectedRiders: [{ rider: { price: 10.15 } }]
      },
      {
        productId: 'PREC-IC',
        productName: 'Accident Insurance',
        plan: { title: 'Standard Plan', price: 18.93 }
      }
    ],
    updatedCartItems: [
      {
        productId: 'PREC-IC',
        productName: 'Cancer Insurance',
        plan: { title: 'Standard Plan', price: 16.93 },
        selectedRiders: [{ rider: { price: 10.15 } }]
      }
    ]
  }
};
const quote = [
  {
    productId: 'PREC-IC',
    selected: true,
    availableInCart: true,
    plan: { id: 'id1' },
    selectedRiders: [
      {
        rider: { title: 'title1' },
        selected: true,
        availableInCart: true,
        plan: { id: 'id1' }
      },
      {
        rider: { title: 'title2' },
        selected: true,
        availableInCart: true,
        plan: { id: 'id1' }
      }
    ]
  }
];

describe('ProductEligibilityModalComponent', () => {
  let component: ProductEligibilityModalComponent;
  let fixture: ComponentFixture<ProductEligibilityModalComponent>;
  let dialog: MatDialog;
  let router: Router;
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ProductEligibilityModalComponent],
      imports: [
        TranslateModule.forRoot(),
        RouterTestingModule,
        BrowserAnimationsModule,
        MatDialogModule
      ],
      providers: [
        provideMockStore({}),
        { provide: CmsService, useClass: MockCmsService },
        { provide: MatDialogRef, useClass: DialogMock },
        { provide: MAT_DIALOG_DATA, useValue: quoteDetails },
        { provide: AgentSharedService, useClass: MockAgentSharedService }
      ],

      schemas: [CUSTOM_ELEMENTS_SCHEMA]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ProductEligibilityModalComponent);
    component = fixture.componentInstance;
    dialog = TestBed.get(MatDialog);
    router = TestBed.get(Router);
    spyOn(router, 'navigateByUrl').and.returnValue(of(true));
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
  it('should update cart with eligible quote on click of continue button', () => {
    spyOn(component, 'updateCartWithEligibleQuote').and.returnValue(true);
    component.proceedToDependents();
    // expect(component as any).toBeDefined();
    expect(component.updateCartWithEligibleQuote).toHaveBeenCalled();
  });
  it('should update cart with eligible quote on click of edit button', () => {
    spyOn(component, 'updateCartWithEligibleQuote').and.returnValue(true);
    component.editQuote();
    expect(component.updateCartWithEligibleQuote).toHaveBeenCalled();
  });
  class DialogMock {
    close() {}
  }
  class MockAgentSharedService {
    updateSearchQuote() {
      return of(true);
    }
    updateExistingCustomerInfo() {
      return of(true);
    }
  }
});
