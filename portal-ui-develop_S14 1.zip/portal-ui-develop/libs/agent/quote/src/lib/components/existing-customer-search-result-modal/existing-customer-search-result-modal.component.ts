import { Component, OnInit, OnDestroy, Inject } from '@angular/core';
import { SelectionModel } from '@angular/cdk/collections';
import {
  MatDialogRef,
  MAT_DIALOG_DATA,
  MatDialog
} from '@angular/material/dialog';
import { PerfectScrollbarConfigInterface } from 'ngx-perfect-scrollbar';
import { Router } from '@angular/router';
import { Store, select } from '@ngrx/store';
import { Subscription } from 'rxjs';
import { CmsService } from '@aflac/shared/cms';
import {
  selectUserDetailsFromAgent,
  saveQuoteAgent,
  saveUserDetails,
  SaveYourQuoteState,
  Agent,
  AgentSharedService
} from '@aflac/agent/shared';
import {
  selectedPlans,
  ProductState,
  fetchProductsByState
} from '@aflac/agent/shared';
import { ProductEligibilityModalComponent } from '../product-eligibility-modal/product-eligibility-modal.component';
import { getRetrieveQuoteData } from '@aflac/agent/landing';

export interface PeriodicElement {
  id: number;
  name: string;
  state: string;
  dob: string;
}
@Component({
  selector: 'aflac-existing-customer-search-result-modal',
  templateUrl: './existing-customer-search-result-modal.component.html',
  styleUrls: ['./existing-customer-search-result-modal.component.scss']
})
export class ExistingCustomerSearchResultModalComponent
  implements OnInit, OnDestroy {
  subsc = new Subscription();
  retrieveQuoteSubscription: Subscription;
  retrievedQuoteData: any;
  public config: PerfectScrollbarConfigInterface = {
    scrollingThreshold: 0,
    minScrollbarLength: 148,
    maxScrollbarLength: 148,
    wheelSpeed: 0.6
  };
  displayedColumns: string[] = ['select', 'name', 'state', 'dob'];
  dataSource;
  selection = new SelectionModel<PeriodicElement>(true, []);
  errorFlag = false;
  errorMsg: string;
  states: any;
  stateProvCd: string;
  subscription = new Subscription();
  cartSubscription = new Subscription();
  customerDetailsArray = [];
  userDetailsFromState: any;
  plansInShoppingCart: any;
  selectedCustomer: any;
  selectedCustomerDetails: any;
  productsAlreadyPurchased: any;
  inEligiblePlans = [];
  eligiblePlans = [];
  updatedcart: any[];
  customerDetailsResponse;
  quotes;
  customerGetQuote: any;
  allProductsAlreadyPurchased = false;
  quotesObj;
  productsByStateSubscription: Subscription;
  //availableProductCountForState;
  availableProductsForState = [];
  enablescrollbar = false;
  productslist = [];
  constructor(
    private store: Store<any>,
    private router: Router,
    private cmsService: CmsService,
    private dialogRef: MatDialogRef<ExistingCustomerSearchResultModalComponent>,
    public dialog: MatDialog,
    private saveQuotestore: Store<SaveYourQuoteState>,
    private statestore: Store<Agent>,
    private agentSharedService: AgentSharedService,
    @Inject(MAT_DIALOG_DATA) public data: any // private productStore: Store<ProductState>,
  ) {}

  ngOnInit() {
    this.customerGetQuote = this.data && this.data.payload;
    this.getLookupData();
    this.getSelectedCustomerDetails();
    this.getSelectedPlansFromCart();
    this.getRetrieveQuote();
    this.getProductsByStateData();
  }
  getSelectedCustomerDetails() {
    this.subscription = this.store
      .pipe(select(selectUserDetailsFromAgent))
      .subscribe(res => {
        if (res !== undefined) {
          this.userDetailsFromState = res;
          sessionStorage.setItem(
            'state-existing-cist-details-agent',
            JSON.stringify(res)
          );
        } else {
          this.userDetailsFromState = JSON.parse(
            sessionStorage.getItem('state-existing-cist-details-agent')
          );
        }
        this.customerDetailsResponse = this.userDetailsFromState.customerDetails;
        this.createCustomerDetailsArray(
          this.userDetailsFromState.customerDetails
        );
        this.dataSource = this.customerDetailsArray;
        this.dataSource.length > 5
          ? (this.enablescrollbar = true)
          : (this.enablescrollbar = false);
      });
  }

  getRetrieveQuote() {
    this.retrieveQuoteSubscription = this.store
      .pipe(select(getRetrieveQuoteData))
      .subscribe(res => {
        this.retrievedQuoteData =
          res && res.data && res.data.quotes && res.data.quotes.length > 0
            ? res.data.quotes
            : this.getSessionRetrieveQuoteData();
      });
  }

  getSessionRetrieveQuoteData() {
    return sessionStorage.getItem('state-retrieveQuote')
      ? JSON.parse(sessionStorage.getItem('state-retrieveQuote'))
      : '';
  }

  getSelectedPlansFromCart() {
    this.cartSubscription = this.store.select(selectedPlans).subscribe(res => {
      if (res !== undefined && res.value) {
        this.plansInShoppingCart = res.value;
        sessionStorage.setItem(
          'state-selected-plans-existing-customer',
          JSON.stringify(res.value)
        );
      } else {
        this.plansInShoppingCart = JSON.parse(
          sessionStorage.getItem('state-selected-plans-existing-customer')
        );
      }
    });
  }
  getProductsByStateData() {
    this.productsByStateSubscription = this.store
      .select(fetchProductsByState)
      .subscribe(res => {
        if (res && res.length > 0) {
          this.availableProductsForState = res;
          sessionStorage.setItem(
            'state-available-products-count-exist-customer',
            JSON.stringify(res)
          );
        } else {
          this.availableProductsForState = JSON.parse(
            sessionStorage.getItem(
              'state-available-products-count-exist-customer'
            )
          );
        }
      });
  }
  formatDOB(dob) {
    const dobformattedArray = dob.split('-');
    if (dobformattedArray.length > 1) {
      // in integ
      return (
        dobformattedArray[1] +
        '/' +
        dobformattedArray[2] +
        '/' +
        dobformattedArray[0]
      );
    } else {
      // in dev
      return dob;
    }
  }

  createCustomerDetailsArray(selectedCustomerDetails) {
    for (const item of selectedCustomerDetails) {
      const name = item.firstName + ' ' + item.lastName;
      const state = this.getStateNameFromStateProvCode(
        item.addresses[0].stateProvCd
      );
      this.customerDetailsArray.push({
        customerNumber: item.customerNumber,
        name: name,
        state: state,
        dateOfBirth: this.formatDOB(item.dateOfBirth)
      });
    }
  }
  getStateNameFromStateProvCode(stateProvCd) {
    let stateName;
    if (this.states && this.states.length > 0) {
      stateName = this.states.filter(data => data.code === stateProvCd)[0].name;
    }
    return stateName;
  }

  getLookupData() {
    this.cmsService.getKey('lookup').subscribe(lookup => {
      this.states = lookup.us_states;
      this.productslist = lookup.products;
    });
  }

  // The label for the checkbox on the passed row
  checkboxLabel(row?: PeriodicElement): string {
    return `${this.selection.isSelected(row) ? 'deselect' : 'select'} row ${
      row.name
    }`;
  }
  changeEmail() {
    this.dialogRef.close(true);
    this.router.navigateByUrl('quotes/save-your-progress');
  }
  ngOnDestroy() {
    this.subscription.unsubscribe();
    this.cartSubscription.unsubscribe();
    this.productsByStateSubscription.unsubscribe();
    this.retrieveQuoteSubscription.unsubscribe();
  }

  onSubmit() {
    this.quotes = [];
    this.quotesObj = [];
    const payload = this.planEligibilityCheck();
    // for saving quote
    const selecteduser = this.customerDetailsResponse.filter(
      e => e.customerNumber === payload.customerId
    )[0];
    const firstName = selecteduser.firstName;
    const lastName = selecteduser.lastName;
    const email = selecteduser.emails[0].email;
    const consentStatus = selecteduser.emails[0].consentStatus;
    const customerNumber = selecteduser.customerNumber;
    const age = this.calculateAgeFromDOB(selecteduser.dateOfBirth);
    const searchQuoteObj = {
      riskStateCd: selecteduser.addresses[0].stateProvCd,
      caseId:
        this.customerGetQuote && this.customerGetQuote.caseId
          ? this.customerGetQuote.caseId
          : this.retrievedQuoteData && this.retrievedQuoteData.length
          ? this.retrievedQuoteData[0].caseId
          : '',
      partnerId: this.customerGetQuote && this.customerGetQuote.partnerId
    };
    const isAgentEligibleForState = this.agentSharedService.checkAgentEligibilityForState(
      selecteduser.addresses[0].stateProvCd
    );
    for (const item of this.updatedcart) {
      const riders = [];
      const riderDetails = [];
      if (item.selectedRiders !== undefined && item.selectedRiders.length > 0) {
        for (const riderItem of item.selectedRiders) {
          if (riderItem.selected) {
            riders.push({
              riderNameCd: riderItem.rider.riderNameCd
            });
            riderDetails.push(riderItem);
          }
        }
      }
      if (item.selected) {
        const commonObj = {
          productCd: item.productId,
          coverageTypeCd: item.coverage,
          riskStateCd: selecteduser.addresses[0].stateProvCd,
          series: item.plan.series ? item.plan.series : '',
          caseId:
            !this.retrievedQuoteData &&
            this.customerGetQuote &&
            this.customerGetQuote.caseId
              ? this.customerGetQuote.caseId
              : this.retrievedQuoteData && this.retrievedQuoteData.length
              ? this.retrievedQuoteData[0].caseId
              : '',
          sfrId:
            !this.retrievedQuoteData &&
            this.customerGetQuote &&
            this.customerGetQuote.leadId
              ? this.customerGetQuote.leadId
              : this.retrievedQuoteData && this.retrievedQuoteData.length
              ? this.retrievedQuoteData[0].sfrId
              : '',
          totalPremium: item.startingPrice,
          productName: item.productName,
          quoteNumber: this.getQuoteNumber(item.productId),
          producerCd:
            this.data && this.data.producerCd ? this.data.producerCd : '',
          subProducerCd:
            this.data && this.data.subProducerCd ? this.data.subProducerCd : ''
        };
        if (item.tobaccoInd !== undefined) {
          commonObj['tobaccoUseInd'] = item.tobaccoInd;
        }
        if (item.benefitAmount !== undefined) {
          commonObj['initialDiagnosisAmount'] = {
            value: item.benefitAmount,
            currencyCd: 'USD'
          };
        }
        const planAndRiderInfo = {
          packageCd: item.plan.id,
          riders: riders
        };
        const planAndRiderDetails = {
          plan: item.plan,
          riders: riderDetails
        };
        const mergedObj = { ...commonObj, ...planAndRiderInfo };
        const mergedObjDetails = { ...commonObj, ...planAndRiderDetails };
        this.quotes.push(mergedObj);
        this.quotesObj.push(mergedObjDetails);
      }
    }
    const userObj = {
      firstName: firstName,
      lastName: lastName,
      email: email,
      consentStatus: consentStatus,
      age: age,
      customerNumber: customerNumber,
      bundleId: this.retrievedQuoteData
        ? this.retrievedQuoteData[0].bundleId
        : null,
      ecommLeadStep: '001_Quote'
      // quotes: this.quotes
    };
    const quotesInfo = {
      quotes: this.quotes
    };
    const quotesDetails = {
      quotes: this.quotesObj
    };
    const userDetails = { ...userObj, ...quotesInfo };
    const stateObj = { ...userObj, ...quotesDetails };

    if (payload.inEligiblePlans.length > 0 || !isAgentEligibleForState) {
      // instead of inEligiblePlans, need  to add condition with the new object
      payload['customerName'] = this.dataSource.filter(
        e => e.customerNumber === payload.customerId
      )[0].name;
      payload['saveQuoteObj'] = userDetails;
      payload['stateObj'] = stateObj;
      payload['searchQuoteObj'] = searchQuoteObj;
      payload['isAgentEligibleForState'] = isAgentEligibleForState;
      this.dialog.open(ProductEligibilityModalComponent, {
        disableClose: true,
        panelClass: 'product-eligibility-modal-cover',
        data: { payload }
      });
    } else {
      // no ineligibility scenario
      //22643 - flow updation - evethough the agent has no ineligibility, he should be redirected to start quote page
      payload['saveQuoteObj'] = userDetails;
      payload['searchQuoteObj'] = searchQuoteObj;
      this.agentSharedService.updateSearchQuote('sq', payload);
      this.agentSharedService.updateExistingCustomerInfo('sq', userDetails);

      this.router.navigateByUrl('quotes');
    }
  }

  getQuoteNumber(id) {
    if (this.retrievedQuoteData) {
      const selectedQuote = this.retrievedQuoteData.filter(
        e => e.productCode === id
      );
      const quoteNumber =
        selectedQuote && selectedQuote.length > 0
          ? selectedQuote[0].quoteNumber
          : '';
      return quoteNumber;
    } else return '';
  }

  findProductName(productId) {
    const prod = this.productslist.filter(item => item.id === productId);
    return prod[0].name;
  }
  planEligibilityCheck() {
    this.updatedcart = [];
    this.selectedCustomerDetails = this.userDetailsFromState.customerDetails.filter(
      e => e.customerNumber === this.selectedCustomer
    )[0];
    this.productsAlreadyPurchased = this.selectedCustomerDetails.availableProducts;
    if (
      this.availableProductsForState &&
      this.availableProductsForState.length > 0
    ) {
      this.availableProductsForState = this.availableProductsForState.filter(
        ({ id: id1 }) =>
          !this.productsAlreadyPurchased.some(
            ({ productCd: id2 }) => id2 === id1
          )
      );
      if (this.availableProductsForState.length === 0) {
        this.allProductsAlreadyPurchased = true;
      }
    }
    this.plansInShoppingCart.map(item => {
      let alreadyPurchased = false;
      this.productsAlreadyPurchased.map(e => {
        if (item.productId === e.productCd) {
          alreadyPurchased = true;
          this.inEligiblePlans.push({
            // can remove this code after verifying
            productId: item.productId,
            productName: item.productName,
            planId: item.plan.id,
            planTitle: item.plan.title
          });
        }
      });
      if (!alreadyPurchased) {
        this.eligiblePlans.push({
          productId: item.productId,
          productName: item.productName,
          planId: item.plan.id,
          planTitle: item.plan.title
        });
        this.updatedcart.push(item);
      }
    });
    const allIneligibleProductsDetails = [];
    this.productsAlreadyPurchased.map(element => {
      const ineligibleItem = {
        productId: element.productCd,
        productName: this.findProductName(element.productCd)
      };
      allIneligibleProductsDetails.push(ineligibleItem);
    });
    return {
      customerId: this.selectedCustomer,
      eligiblePlans: this.eligiblePlans,
      inEligiblePlans: this.inEligiblePlans, // can remove
      selectedCartItems: this.plansInShoppingCart,
      updatedCartItems: this.updatedcart,
      allProductsAlreadyPurchased: this.allProductsAlreadyPurchased,
      //pass alreadyPurchasedProuductsDetails from here and can avoid inEligiblePlans
      allIneligibleProductsDetails: allIneligibleProductsDetails
    };
  }
  public calculateAgeFromDOB(dateOfBirth) {
    const today = new Date();
    const birthDate = new Date(dateOfBirth);
    let age = today.getFullYear() - birthDate.getFullYear();
    const m = today.getMonth() - birthDate.getMonth();

    if (m < 0 || (m === 0 && today.getDate() < birthDate.getDate())) {
      age--;
    }
    return age.toString();
  }
}
