import {
  async,
  ComponentFixture,
  TestBed,
  inject
} from '@angular/core/testing';
import { SaveYourProgressComponent } from './save-your-progress.component';
import { TranslateModule } from '@ngx-translate/core';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { MatDialogModule } from '@angular/material/dialog';
import { SharedvalidatorsModule } from '@aflac/shared/validators';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { MatFormFieldModule, MatInputModule } from '@angular/material';
import { RouterTestingModule } from '@angular/router/testing';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { provideMockStore, MockStore } from '@ngrx/store/testing';
import { Store, MemoizedSelector } from '@ngrx/store';
import { AgentSearchQuote, getAgentProfile } from '@aflac/agent/shared';
import * as fromAgentSearch from '@aflac/agent/shared';
import { ProductState } from '@aflac/agent/shared';
import * as fromProduct from '@aflac/agent/shared';

import {
  SaveYourQuoteState,
  getCustomerPersonalInfo
} from '@aflac/agent/shared';
import * as fromAgentSaveQuote from '@aflac/agent/shared';
import { Router } from '@angular/router';
import {
  getRetrieveQuoteData,
  getRetrieveLeadIdData
} from '@aflac/agent/landing';

class RouterStub {
  navigateByUrl(url: string) {
    return url;
  }
}

const agentSearchedDetails = {
  stateProvCd: 'AL',
  age: 40,
  state: 'Alabama'
};
const selectedPlans = {
  value: [
    {
      productId: 'PREC-IC',
      selected: true,
      availableInCart: true,
      plan: { id: 'id1' },
      selectedRiders: [
        {
          rider: { title: 'title1' },
          selected: true,
          availableInCart: true,
          plan: { id: 'id1' }
        },
        {
          rider: { title: 'title2' },
          selected: true,
          availableInCart: true,
          plan: { id: 'id1' }
        }
      ]
    }
  ]
};
const userDetails = {
  quoteDetails: [],
  customerDetails: {
    addresses: [{ stateProvCd: 'AL' }]
  },
  aflacUserGuid: 'abcx',
  availableProducts: [
    {
      productCd: 'PREC-IA'
    }
  ],
  customerNumber: '510001',
  dateOfBirth: '1985-07-13',
  emails: [
    {
      id: 0,
      email: 'john@email.com',
      consentStatus: 'GRANTED',
      consentDate: '2020-05-26'
    }
  ],
  firstName: 'john',
  lastName: 'Smith',
  middleName: 'k',
  suffix: '8',
  taxId: '123456789',
  phones: [
    {
      id: 0,
      phone: '1234567890',
      phoneTypeCd: 'WORK'
    }
  ]
};

const customerPersonalInfo = {
  firstName: 'jane',
  lastName: 'smith',
  email: 'janesmith@gmail.com'
};
const RetrieveQuote = {
  bundleId: '000',
  policyNumber: 'a1b2',
  effectiveDate: '01/02/2019',
  expirationDate: '01/06/2019',
  transactionEffectiveDate: '03/02/2019',
  policyStatusCd: 'dummy',
  productCode: 'Ab-Ab',
  lobCd: 'dummy',
  totalPremium: 1234,
  currencyCode: 'ind',
  producerCd: 'dummy',
  subProducerCd: 'd'
};
const LeadIdData = {
  status: true,
  data: [
    {
      sfReferenceNumber: 'sfcrm-12',
      fname: 'John',
      lname: 'Richard',
      phone: '9088767564',
      email: 'j@gmail.com',
      state: 'AL',
      caseId: 'QWESR2315 WE',
      DOB: '1990-09-01',
      age: 29
    }
  ],
  message: 'success'
};
const getAgent = {
  agencyCd: 'QAG',
  subProducerCd: '1'
};

describe('SaveYourProgressComponent', () => {
  let component: SaveYourProgressComponent;
  let fixture: ComponentFixture<SaveYourProgressComponent>;
  //new
  let mockStore: MockStore<any>;
  let store: Store<AgentSearchQuote>;
  let mockAgentSelector: MemoizedSelector<any, any>;
  let productStore: Store<ProductState>;
  let mockPlanSelector: MemoizedSelector<any, any>;
  let saveQuoteStore: Store<SaveYourQuoteState>;
  let mockQuoteSelector: MemoizedSelector<any, any>;
  let mockCustomerPersonalInfoSelector: MemoizedSelector<any, any>;
  let mockRetrieveQuoteData: MemoizedSelector<any, any>;
  let mockLeadIdSelector: MemoizedSelector<any, any>;
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [SaveYourProgressComponent],
      imports: [
        TranslateModule.forRoot(),
        ReactiveFormsModule,
        FormsModule,
        SharedvalidatorsModule,
        MatDialogModule,
        MatFormFieldModule,
        MatInputModule,
        RouterTestingModule,
        BrowserAnimationsModule
        //  StoreModule.forRoot({ agentSearchQuoteReducer })
      ],
      providers: [
        provideMockStore({}),
        { provide: Router, useClass: RouterStub }
      ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SaveYourProgressComponent);
    //new start
    mockStore = TestBed.get(Store);
    store = TestBed.get(Store);
    productStore = TestBed.get(Store);
    saveQuoteStore = TestBed.get(Store);
    mockAgentSelector = mockStore.overrideSelector(
      fromAgentSearch.agentSelectedQuote,
      agentSearchedDetails
    );
    mockPlanSelector = mockStore.overrideSelector(
      fromProduct.selectedPlans,
      selectedPlans
    );
    mockQuoteSelector = mockStore.overrideSelector(
      fromAgentSaveQuote.selectUserDetailsFromAgent,
      userDetails
    );
    mockCustomerPersonalInfoSelector = mockStore.overrideSelector(
      getCustomerPersonalInfo,
      customerPersonalInfo
    );
    mockRetrieveQuoteData = mockStore.overrideSelector(
      getRetrieveQuoteData,
      RetrieveQuote
    );
    mockLeadIdSelector = mockStore.overrideSelector(
      getRetrieveLeadIdData,
      LeadIdData
    );
    mockStore.overrideSelector(getAgentProfile, getAgent);
    //new end
    component = fixture.componentInstance;
    spyOn(component.dialog, 'open').and.returnValue(true);
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
  //new spec
  it('should display existing user details modal', () => {
    spyOn(component, 'showUserModal').and.returnValue(true);
    component.selectedStateCode = 'AL';
    component.age = '40';
    component.plansInShoppingCart = selectedPlans.value;
    component.navigateToBuyFlow();
    //  expect(component.showUserModal).toHaveBeenCalled;
    expect(component as any).toBeDefined();
  });

  it('should enable submit button is checkbox is checked', () => {
    component.disabledSaveyourQuoteSubmitButton = true;
    const event = {
      checked: true
    };
    component.changeCheck(event);
    // expect(component.disabledSaveyourQuoteSubmitButton).toBeFalsy;
    expect(component as any).toBeDefined();
  });

  it('should navigate edit quote  page', inject([Router], (router: Router) => {
    const spy = spyOn(router, 'navigateByUrl');
    component.editQuote();
    const navArgs = spy.calls.first().args[0];
    expect(navArgs).toBe('quotes');
  }));

  it('should navigate to eligibility page', inject(
    [Router],
    (router: Router) => {
      const selPlans = [
        {
          productId: 'PREC-IC',
          coverage: 'ind',
          selected: true,
          availableInCart: true,
          plan: { id: 'id1' },
          selectedRiders: [
            {
              rider: { title: 'title1' },
              selected: true,
              availableInCart: true,
              plan: { id: 'id1' }
            },
            {
              rider: { title: 'title2' },
              selected: true,
              availableInCart: true,
              plan: { id: 'id1' }
            }
          ]
        }
      ];
      const spy = spyOn(router, 'navigateByUrl');
      component.decideNavigation(selPlans);
      const navArgs = spy.calls.first().args[0];
      expect(navArgs).toBe('eligibility');
    }
  ));
  it('should navigate to dependents page', inject(
    [Router],
    (router: Router) => {
      const selPlans = [
        {
          productId: 'PREC-IC',
          coverage: 'ind_sps',
          selected: true,
          availableInCart: true,
          plan: { id: 'id1' },
          selectedRiders: [
            {
              rider: { title: 'title1' },
              selected: true,
              availableInCart: true,
              plan: { id: 'id1' }
            },
            {
              rider: { title: 'title2' },
              selected: true,
              availableInCart: true,
              plan: { id: 'id1' }
            }
          ]
        }
      ];
      const spy = spyOn(router, 'navigateByUrl');
      component.decideNavigation(selPlans);
      const navArgs = spy.calls.first().args[0];
      expect(navArgs).toBe('dependents');
    }
  ));
});
