import {
  Component,
  OnInit,
  OnChanges,
  Input,
  Output,
  EventEmitter
} from '@angular/core';
import { Product } from '@aflac/shared/data-model';
import {
  selectedPlans,
  retrivePlanCoverageChange,
  updateRiderInfoInCart
} from '@aflac/agent/shared'; // Selectors
import { findPlansAction, addItemToCart } from '@aflac/agent/shared'; // Actions
import { Router } from '@angular/router';
import { CmsService } from '@aflac/shared/cms';
import { Store, select } from '@ngrx/store';
import { ProductState } from '@aflac/agent/shared'; // Reducer

@Component({
  selector: 'aflac-product-list',
  templateUrl: './product-list.component.html',
  styleUrls: ['./product-list.component.scss']
})
export class ProductListComponent implements OnInit, OnChanges {
  @Input() products: any;
  @Input() coverageTypes: any;
  @Input() isClicked: any;
  @Input() productIndex: number;
  @Input() isProductLoaded: boolean;
  @Input() agentStateMode: boolean;
  @Input() agentSelectedQuote: any;
  @Input() isPlanLoaded: any;
  @Input() agencyId: any;
  @Input() tobaccoInd: any;
  @Input() intDiagnosisBenefitAmount: any;
  @Input() cancerCoverage: any;
  @Input() isCriticalIllnessPlan: any;
  @Output() seePlans = new EventEmitter();
  @Output() coverageChange = new EventEmitter();
  selectedCoverage: any = [];
  planClickData: any;
  selectedIndex: number;
  benefitData = [];
  cartData: any;
  selectedProductCoverage: any;

  constructor(
    private router: Router,
    private cmsService: CmsService,
    private store: Store<{ products: ProductState }>
  ) {}

  ngOnChanges() {
    if (this.products) {
      this.products.forEach((el, i) => {
        const cartCoverage = this.checkCoverageDetailsInCart(el.id);
        this.selectedCoverage[i] = cartCoverage.itemPresent
          ? cartCoverage.coverage
          : el.coverage;
      });
    }
    if (
      (this.isProductLoaded || this.productIndex) &&
      (!this.isPlanLoaded && !this.isCriticalIllnessPlan)
    ) {
      this.selectedIndex = -1;
    }
  }

  checkCoverageDetailsInCart(id) {
    if (
      this.cartData &&
      this.cartData.value &&
      this.cartData.value.length > 0
    ) {
      const itemPresent = this.cartData.value.filter(
        item => item.productId === id
      )[0];
      if (itemPresent && itemPresent.availableInCart)
        return { itemPresent: true, coverage: itemPresent.coverage };
      else return { itemPresent: false };
    } else return { itemPresent: false };
  }

  ngOnInit() {
    this.store.pipe(select(retrivePlanCoverageChange)).subscribe(planData => {
      if (planData) {
        if (
          planData &&
          planData.id !== undefined &&
          planData.plans !== undefined
        ) {
          this.updateCart(planData);
        }
      }
    });
    this.store.select(selectedPlans).subscribe(res => {
      this.cartData = res;
    });
  }

  updateCart(planData) {
    const changedProduct = planData.id;
    const latestCoverage = planData.coverage;
    if (
      this.cartData &&
      this.cartData.value &&
      this.cartData.value.length > 0
    ) {
      const selectedPlanOfChangedProduct = this.cartData.value.filter(
        el => el.productId === changedProduct
      );
      if (
        selectedPlanOfChangedProduct &&
        selectedPlanOfChangedProduct.length > 0
      ) {
        const isArray = Array.isArray(planData.plans);
        let updatedPlanToDispatch;
        if (isArray) {
          updatedPlanToDispatch = planData.plans.filter(
            updatedPlan =>
              updatedPlan.id === selectedPlanOfChangedProduct[0].plan.id
          );
        } else if (planData.plans && Object.keys(planData.plans).length) {
          updatedPlanToDispatch = [planData.plans];
        }

        if (updatedPlanToDispatch && updatedPlanToDispatch.length > 0) {
          const updatedRider = updatedPlanToDispatch[0].agentRiders;
          const updatedRiderToDispatch =
            updatedRider &&
            updatedRider.length &&
            selectedPlanOfChangedProduct[0].selectedRiders &&
            selectedPlanOfChangedProduct[0].selectedRiders.length
              ? this.filterRiders(
                  updatedRider,
                  selectedPlanOfChangedProduct[0].selectedRiders
                )
              : undefined;
          const updatedPlanDetails = {
            productId: changedProduct,
            productName: selectedPlanOfChangedProduct[0].productName,
            plan: updatedPlanToDispatch[0],
            coverage: latestCoverage,
            selected: selectedPlanOfChangedProduct[0].selected,
            availableInCart: selectedPlanOfChangedProduct[0].availableInCart,
            startingPrice: selectedPlanOfChangedProduct[0].startingPrice,
            tobaccoInd: selectedPlanOfChangedProduct[0].tobaccoInd,
            cancerCoverage: selectedPlanOfChangedProduct[0].cancerCoverage,
            benefitAmount: selectedPlanOfChangedProduct[0].benefitAmount
          };
          this.store.dispatch(
            addItemToCart({
              selectedPlan: { key: 'from-list', value: updatedPlanDetails }
            })
          );
          if (updatedRiderToDispatch && updatedRiderToDispatch.length) {
            updatedRiderToDispatch.forEach(item => {
              const riderDetails = {
                rider: item.rider,
                productId: item.productId,
                selected: item.selected,
                availableInCart: item.availableInCart
              };
              this.store.dispatch(
                updateRiderInfoInCart({
                  riderDetails: { key: 'from-list', value: riderDetails }
                })
              );
            });
          }
        }
      }
    }
  }
  filterRiders(riderFromPlan, riderFromCart) {
    const updatedArray = [];
    riderFromCart.forEach(element => {
      const selectedRider = riderFromPlan.filter(
        e =>
          e.riderNameCd === element.rider.riderNameCd ||
          e.riderNameCd === element.rider.title
      );
      if (selectedRider && selectedRider.length) {
        const tempRiderItem = {
          ...element,
          rider: {
            ...element.rider,
            price: selectedRider[0].monthlyPremium,
            benefitAmount: selectedRider[0].benefitAmount,
            riderNameCd: selectedRider[0].riderNameCd
          }
        };
        updatedArray.push(tempRiderItem);
      } else {
        const tempRiderItem = {
          ...element,
          selected: false,
          availableInCart: false
        };
        updatedArray.push(tempRiderItem);
      }
    });
    return updatedArray;
  }
  onProductSelected(product: Product, i: number) {
    this.displayPlans(product, this.selectedCoverage[i], i);
  }

  changeCoverage(e: any, product: Product, i: number) {
    const pObj = Object.assign({}, product);
    pObj['coverage'] = e.value;
    product = pObj;
    this.coverageChange.emit(product);
    if (!document.getElementById('cardcheck' + i)) {
      this.displayPlans(product, e.value, i);
    } else {
      if (
        product.id === 'PREC-ICI' &&
        this.cartData &&
        this.cartData.value &&
        this.cartData.value.length
      ) {
        const currentProduct = this.cartData.value.filter(
          item => item.productId === product.id
        );
        this.intDiagnosisBenefitAmount =
          currentProduct && currentProduct.length
            ? currentProduct[0].benefitAmount
            : this.intDiagnosisBenefitAmount;
      }
      this.store.dispatch(
        findPlansAction({
          productId: product.id,
          stateProvCd: this.agentSelectedQuote.stateProvCd,
          state: this.agentSelectedQuote.state,
          primaryInsuredAge: this.agentSelectedQuote.age,
          coverageTierCd: e.value,
          riders: [],
          planNotLoaded: true,
          agencyId: this.agencyId,
          tobaccoInd: this.tobaccoInd,
          intDiagnosisBenefitAmount: this.intDiagnosisBenefitAmount,
          cancerCoverage: this.cancerCoverage,
          caseId: this.agentSelectedQuote && this.agentSelectedQuote.caseId
        })
      );
    }
  }

  displayPlans(product: Product, coverage: string, i: number) {
    this.selectedIndex = i;
    this.planClickData = {
      product: product,
      coverage: coverage
    };
    this.seePlans.emit(this.planClickData);
  }
}
