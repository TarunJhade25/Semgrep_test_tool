import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SaveConsentModalComponent } from './save-consent-modal.component';
import { TranslateModule } from '@ngx-translate/core';
import {
  MatDialogRef,
  MatDialogModule,
  MAT_DIALOG_DATA
} from '@angular/material/dialog';

import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';

describe('SaveConsentModalComponent', () => {
  let component: SaveConsentModalComponent;
  let fixture: ComponentFixture<SaveConsentModalComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [TranslateModule.forRoot(), MatDialogModule],
      declarations: [SaveConsentModalComponent],
      providers: [
        { provide: MAT_DIALOG_DATA, useValue: { initialState: 'test' } },
        { provide: MatDialogRef, useClass: DialogMock }
      ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SaveConsentModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should call close function on hidding the dialog box ', () => {
    const spyObj = spyOn(component.dialogRef, 'close').and.callThrough();
    component.hideModal();
    expect(spyObj).toHaveBeenCalled();
  });
});
//MockClass
class DialogMock {
  close() {}
}
