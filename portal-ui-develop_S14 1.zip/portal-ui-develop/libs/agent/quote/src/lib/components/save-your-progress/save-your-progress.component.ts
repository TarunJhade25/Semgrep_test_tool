import {
  Component,
  OnInit,
  ElementRef,
  ViewChild,
  OnDestroy
} from '@angular/core';
import { CmsService } from '@aflac/shared/cms';
import { FieldValidator } from '@aflac/shared/validators';
import { FormBuilder } from '@angular/forms';
import { Store, select } from '@ngrx/store';
import { Subscription } from 'rxjs';
import { MatDialog } from '@angular/material/dialog';
import { Router } from '@angular/router';
import { SaveConsentModalComponent } from '../save-consent-modal/save-consent-modal.component';
import { SaveYourQuoteState } from '@aflac/agent/shared';
import {
  saveQuoteAgent,
  resetBuyFlowElements,
  saveUserDetails,
  selectUserDetailsFromAgent,
  ProductState,
  selectedPlans,
  AgentSearchQuote,
  agentSelectedQuote,
  getAgentProfile,
  getCustomerPersonalInfo
} from '@aflac/agent/shared';
import { ExistingCustomerSearchResultModalComponent } from '../existing-customer-search-result-modal/existing-customer-search-result-modal.component';
import {
  getRetrieveQuoteData,
  getRetrieveLeadIdData,
  HomeState
} from '@aflac/agent/landing';

@Component({
  selector: 'aflac-save-your-progress',
  templateUrl: './save-your-progress.component.html',
  styleUrls: ['./save-your-progress.component.scss']
})
export class SaveYourProgressComponent implements OnInit, OnDestroy {
  loginModelCloseObs: any;
  disabledSaveyourQuoteSubmitButton = true;
  modalButtonDisable = false;
  redirectedUserData: any;
  ancient: any;
  focusFirst: false;
  focusLast: false;
  focusEmail: false;
  firstLoad: boolean;
  subsription = new Subscription();
  agentStoreSubscription: Subscription;
  productStoreSubscription: Subscription;
  plansInShoppingCart;
  quotes = [];
  userGetQuoteDetails: any;
  selectedStateCode;
  age;
  userDetailsFromState;
  quotesObj;
  stateObj;
  producerCd;
  subProducerCd;
  agentDetailsSubscription: Subscription;
  homeStoreSubscription: Subscription;
  personalDetails;
  aboutForm = this.fb.group({
    firstName: [
      '',
      [
        FieldValidator.isEmpty(
          'agent_portal.save_quote_first_name_required_error'
        ),
        FieldValidator.patternValidator(
          /^[a-zA-Z `']*$/,
          'agent_portal.save_quote_first_name_required_error'
        )
      ]
    ],
    lastName: [
      '',
      [
        FieldValidator.isEmpty(
          'agent_portal.save_quote_last_name_required_error'
        ),
        FieldValidator.patternValidator(
          /^[a-zA-Z `']*$/,
          'agent_portal.save_quote_last_name_required_error'
        )
      ]
    ],
    emailAddress: [
      '',
      [
        FieldValidator.isEmpty('agent_portal.save_quote_email_required_error'),
        FieldValidator.patternValidator(
          /^[a-zA-Z]{1}(([^<>()\[\]\\.,;:\s@']+(\.[^<>()\[\]\\.,;:\s@']+)*)|('.+'))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/,
          'agent_portal.save_quote_email_required_error'
        )
      ]
    ]
  });
  user;
  @ViewChild('email', { static: false }) emailElement: ElementRef;
  retrieveQuoteSubscription: Subscription;
  retrievedQuoteData: any;
  getCustomerInfoSub: Subscription;
  constructor(
    private fb: FormBuilder,
    private translateService: CmsService,
    private cmsService: CmsService,
    private store: Store<SaveYourQuoteState>,
    public dialog: MatDialog,
    private router: Router,
    private productStore: Store<ProductState>,
    private agentStore: Store<AgentSearchQuote>,
    private quoteStore: Store<any>,
    private homeStore: Store<HomeState>
  ) {}

  ngOnInit() {
    this.firstLoad = true;
    this.getLeadIdInfo();
    this.getUSerDetailsFromState();
    this.getSelectedAgeAndState();
    this.getSelectedPlansFromShoppingCart();
    this.getCustomerPersonalInfo();
    this.getRetrieveQuoteInfo();
    this.scrollToPosition();
    this.getAgentDetails();
  }
  //set fname, lnmae and email based on lead id search result
  getLeadIdInfo() {
    this.homeStoreSubscription = this.homeStore
      .select(getRetrieveLeadIdData)
      .subscribe(res => {
        //check retrieve quot eflow and other flows too
        if (res && res.data && res.data.length) {
          this.aboutForm.controls['firstName'].setValue(res.data[0].fname);
          this.aboutForm.controls['lastName'].setValue(res.data[0].lname);
          this.aboutForm.controls['emailAddress'].setValue(res.data[0].email);
        }
      });
  }
  getAgentDetails() {
    this.agentDetailsSubscription = this.agentStore
      .pipe(select(getAgentProfile))
      .subscribe(data => {
        if (data && data.agencyCd) {
          this.producerCd = data.agencyCd;
          if (data && data.subProducerCd) {
            this.subProducerCd = data.subProducerCd;
          }
        } else {
          const agentData = JSON.parse(
            sessionStorage.getItem('agent-information')
          );
          this.producerCd =
            agentData && agentData.agencyCd ? agentData.agencyCd : null;
          this.subProducerCd =
            agentData && agentData.subProducerCd
              ? agentData.subProducerCd
              : null;
        }
      });
  }

  scrollToPosition() {
    window.scroll({
      behavior: 'smooth',
      left: 0,
      top: 0
    });
  }
  getRetrieveQuoteInfo() {
    this.retrieveQuoteSubscription = this.quoteStore
      .pipe(select(getRetrieveQuoteData))
      .subscribe(res => {
        this.retrievedQuoteData =
          res && res.data && res.data.quotes && res.data.quotes.length > 0
            ? res.data.quotes
            : this.getSessionRetrieveQuoteData();
      });
  }
  getSessionRetrieveQuoteData() {
    return sessionStorage.getItem('state-retrieveQuote')
      ? JSON.parse(sessionStorage.getItem('state-retrieveQuote'))
      : '';
  }
  getCustomerPersonalInfo() {
    this.getCustomerInfoSub = this.quoteStore
      .select(getCustomerPersonalInfo)
      .subscribe(res => {
        this.personalDetails = res;
        const data = res
          ? res
          : sessionStorage.getItem('state-customerDetails') &&
            sessionStorage.getItem('state-customerDetails').length > 0
          ? JSON.parse(sessionStorage.getItem('state-customerDetails'))
          : undefined;
        if (data) {
          this.aboutForm.controls['firstName'].setValue(data.firstName);
          this.aboutForm.controls['lastName'].setValue(data.lastName);
          this.aboutForm.controls['emailAddress'].setValue(data.email);
        }
      });
  }

  getSelectedAgeAndState() {
    this.agentStoreSubscription = this.agentStore
      .select(agentSelectedQuote)
      .subscribe(res => {
        if (res !== undefined && res.stateProvCd && res.age) {
          this.userGetQuoteDetails = res;
          sessionStorage.setItem(
            'state-agent-user-age-and-state',
            JSON.stringify(res)
          );
        } else {
          this.userGetQuoteDetails = JSON.parse(
            sessionStorage.getItem('state-agent-user-age-and-state')
          );
        }
        if (
          this.userGetQuoteDetails !== undefined &&
          this.userGetQuoteDetails.stateProvCd &&
          this.userGetQuoteDetails.age
        ) {
          this.selectedStateCode = this.userGetQuoteDetails.stateProvCd; // state selected from start quote
          this.age =
            typeof this.userGetQuoteDetails.age === 'number'
              ? this.userGetQuoteDetails.age.toString()
              : this.userGetQuoteDetails.age;
        }
      });
  }
  getSelectedPlansFromShoppingCart() {
    this.productStoreSubscription = this.productStore
      .select(selectedPlans)
      .subscribe(res => {
        if (res !== undefined && res.value) {
          this.plansInShoppingCart = res.value;
          sessionStorage.setItem(
            'state-save-progress-selected-plans',
            JSON.stringify(res.value)
          );
        } else {
          this.plansInShoppingCart = JSON.parse(
            sessionStorage.getItem('state-save-progress-selected-plans')
          );
        }
      });
  }
  getUSerDetailsFromState() {
    this.subsription = this.store
      .pipe(select(selectUserDetailsFromAgent))
      .subscribe(res => {
        if (res !== undefined) {
          this.userDetailsFromState = res;
          sessionStorage.setItem(
            'agent-user-details-state',
            JSON.stringify(res)
          );
        } else {
          this.userDetailsFromState = JSON.parse(
            sessionStorage.getItem('agent-user-details-state')
          );
        }
        if (this.userDetailsFromState !== undefined && !this.firstLoad) {
          if (
            this.userDetailsFromState.quoteDetails !== undefined &&
            this.userDetailsFromState.quoteDetails.length === 0 &&
            (this.userDetailsFromState.customerDetails !== undefined &&
              this.userDetailsFromState.customerDetails.length !== 0)
          ) {
            this.showUserModal();
            this.firstLoad = true;
          } else if (
            this.userDetailsFromState.quoteDetails !== undefined &&
            this.userDetailsFromState.quoteDetails.length !== 0 &&
            (this.userDetailsFromState.customerDetails !== undefined &&
              this.userDetailsFromState.customerDetails.length === 0)
          ) {
            if (
              this.plansInShoppingCart !== undefined &&
              this.plansInShoppingCart.length !== 0
            ) {
              this.store.dispatch(resetBuyFlowElements());
              sessionStorage.removeItem('state-agent-buy-flow-elements');
              this.store.dispatch(
                saveUserDetails({ userDetails: this.stateObj })
              );
              this.decideNavigation(this.plansInShoppingCart);
            }
            this.firstLoad = true;
          }
        }
      });
  }
  decideNavigation(selPlans) {
    let navigationTarget = 'eligibility';
    selPlans.map(item => {
      if (item.coverage !== 'ind' && item.selected) {
        navigationTarget = 'dependents';
      }
    });
    this.router.navigateByUrl(`${navigationTarget}`);
  }
  editQuote() {
    this.router.navigateByUrl('quotes');
  }
  changeCheck(event) {
    this.disabledSaveyourQuoteSubmitButton = !event.checked;
  }
  get f() {
    if (this.aboutForm) {
      return this.aboutForm.controls;
    }
  }
  openConsentModalWithComponent(event?) {
    if (event) {
      event.preventDefault();
    }
    const initialState = {
      title: this.cmsService.getKey('lookup.consent_modal_title'),
      contentTitleNew: this.cmsService.getKey(
        'lookup.consent_modal_header_text_title'
      ),
      contentTitleOne: this.cmsService.getKey(
        'lookup.consent_modal_header_text_one'
      ),
      contentTitleDataOne: this.cmsService.getKey(
        'lookup.consent_modal_header_content_one'
      ),
      contentTitleDataTwo: this.cmsService.getKey(
        'lookup.consent_modal_header_content_two'
      ),
      contentTitleDataThree: this.cmsService.getKey(
        'lookup.consent_modal_header_content_three'
      ),
      contentDataOne: this.cmsService.getKey(
        'lookup.consent_modal_body_content_one'
      ),
      contentTitleTwo: this.cmsService.getKey(
        'lookup.consent_modal_header_text_two'
      ),
      contentDataTwoParaOne: this.cmsService.getKey(
        'lookup.consent_modal_body_content_two_para_one'
      ),
      contentDataTwoParaTwo: this.cmsService.getKey(
        'lookup.consent_modal_body_content_two_para_two'
      ),
      contentTitleThree: this.cmsService.getKey(
        'lookup.consent_modal_header_text_three'
      ),
      contentDataThree: this.cmsService.getKey(
        'lookup.consent_modal_body_content_three'
      ),
      contentTitleFour: this.cmsService.getKey(
        'lookup.consent_modal_header_text_four'
      ),
      contentDataFour: this.cmsService.getKey(
        'lookup.consent_modal_body_content_four'
      ),
      contentTitleFive: this.cmsService.getKey(
        'lookup.consent_modal_header_text_five'
      ),
      contentDataFive: this.cmsService.getKey(
        'lookup.consent_modal_body_content_five'
      ),
      contentTitleSix: this.cmsService.getKey(
        'lookup.consent_modal_header_text_six'
      ),
      contentDataSix: this.cmsService.getKey(
        'lookup.consent_modal_body_content_six'
      ),
      closeBtnName: this.cmsService.getKey(
        'lookup.consent_modal_close_button_text'
      )
    };
    const dialogRef = this.dialog.open(SaveConsentModalComponent, {
      data: {
        initialState
      },
      panelClass: 'consent-modal-resizer',
      ariaLabelledBy: 'mat-consent-dialog-title'
    });
  }

  navigateToBuyFlow() {
    this.quotes = [];
    this.quotesObj = [];
    if (
      this.plansInShoppingCart !== undefined &&
      this.plansInShoppingCart.length > 0
    ) {
      for (const item of this.plansInShoppingCart) {
        const riders = [];
        const riderDetails = [];
        if (
          item.selectedRiders !== undefined &&
          item.selectedRiders.length > 0
        ) {
          for (const riderItem of item.selectedRiders) {
            if (riderItem.selected) {
              riders.push({
                riderNameCd: riderItem.rider.riderNameCd
              });
              riderDetails.push(riderItem);
            }
          }
        }
        if (item.selected) {
          const commonObj = {
            productCd: item.productId,
            coverageTypeCd: item.coverage,
            // riskStateCd: this.selectedStateCode,
            riskStateCd:
              this.personalDetails && this.personalDetails.riskStateCd
                ? this.personalDetails.riskStateCd
                : this.selectedStateCode,
            series: item.plan.series ? item.plan.series : '',
            caseId:
              !this.retrievedQuoteData &&
              this.userGetQuoteDetails &&
              this.userGetQuoteDetails.caseId
                ? this.userGetQuoteDetails.caseId
                : this.retrievedQuoteData && this.retrievedQuoteData.length
                ? this.retrievedQuoteData[0].caseId
                : '',
            sfrId:
              !this.retrievedQuoteData &&
              this.userGetQuoteDetails &&
              this.userGetQuoteDetails.leadId
                ? this.userGetQuoteDetails.leadId
                : this.retrievedQuoteData && this.retrievedQuoteData.length
                ? this.retrievedQuoteData[0].sfrId
                : '',
            totalPremium: item.startingPrice,
            productName: item.productName,
            quoteNumber: this.getQuoteNumber(item.productId),
            producerCd: this.producerCd,
            subProducerCd: this.subProducerCd
          };
          if (item.tobaccoInd !== undefined) {
            commonObj['tobaccoUseInd'] = item.tobaccoInd;
          }
          if (item.benefitAmount !== undefined) {
            commonObj['initialDiagnosisAmount'] = {
              value: item.benefitAmount,
              currencyCd: 'USD'
            };
          }
          const planAndRiderInfo = {
            packageCd: item.plan.id,
            riders: riders
          };
          const planAndRiderDetails = {
            plan: item.plan,
            riders: riderDetails
          };
          const mergedObj = { ...commonObj, ...planAndRiderInfo };
          const mergedObjDetails = { ...commonObj, ...planAndRiderDetails };
          this.quotes.push(mergedObj);
          this.quotesObj.push(mergedObjDetails);
        }
      }
    }

    const userObj = {
      firstName: this.aboutForm.controls.firstName.value.trim(),
      lastName: this.aboutForm.controls.lastName.value.trim(),
      email: this.aboutForm.controls.emailAddress.value,
      consentStatus: 'GRANTED',
      // age: this.age,
      age:
        this.personalDetails && this.personalDetails.age
          ? this.personalDetails.age
          : this.age,
      // customerNumber: '', // To show existing customer popup regardless of get/retrieve quote flow.
      customerNumber:
        this.personalDetails && this.personalDetails.customerNumber
          ? this.personalDetails.customerNumber
          : '',
      bundleId: this.retrievedQuoteData
        ? this.retrievedQuoteData[0].bundleId
        : null,
      ecommLeadStep: '001_Quote',
      deleteQuoteList: this.getDeletedQuote()
    };
    const quotesInfo = {
      quotes: this.quotes
    };
    const quotesDetails = {
      quotes: this.quotesObj
    };
    const userDetails = { ...userObj, ...quotesInfo };
    this.stateObj = { ...userObj, ...quotesDetails };
    this.store.dispatch(saveQuoteAgent({ userDetails: userDetails }));
    this.firstLoad = false;
  }

  getQuoteNumber(id) {
    if (this.retrievedQuoteData) {
      const selectedQuote = this.retrievedQuoteData.filter(
        e => e.productCode === id
      );
      const quoteNumber =
        selectedQuote && selectedQuote.length > 0
          ? selectedQuote[0].quoteNumber
          : '';
      return quoteNumber;
    } else return '';
  }
  getDeletedQuote() {
    const deletedArray = [];
    if (this.retrievedQuoteData && this.retrievedQuoteData.length) {
      this.retrievedQuoteData.forEach(element => {
        const planPresent = this.plansInShoppingCart.filter(
          e => e.productId === element.productCode
        );
        if (!(planPresent && planPresent.length))
          deletedArray.push({ policyNumber: element.quoteNumber });
      });
      return deletedArray;
    } else return [];
  }
  showUserModal() {
    const payload = this.userGetQuoteDetails;
    this.dialog.open(ExistingCustomerSearchResultModalComponent, {
      width: '786px',
      disableClose: true,
      panelClass: 'customer-search-result-modal-cover',
      data: {
        payload,
        producerCd: this.producerCd,
        subProducerCd: this.subProducerCd
      }
    });
  }

  ngOnDestroy() {
    this.subsription.unsubscribe();
    this.agentStoreSubscription.unsubscribe();
    this.productStoreSubscription.unsubscribe();
    this.retrieveQuoteSubscription.unsubscribe();
    this.getCustomerInfoSub.unsubscribe();
    this.agentDetailsSubscription.unsubscribe();
    this.homeStoreSubscription.unsubscribe();
  }
}
