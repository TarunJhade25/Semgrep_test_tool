import {
  Component,
  OnInit,
  Input,
  Output,
  EventEmitter,
  OnChanges,
  OnDestroy,
  ChangeDetectorRef
} from '@angular/core';
import { Store, select } from '@ngrx/store';
import {
  ProductState,
  addItemToCart,
  SaveAgentCriticalIllnessPlansAction,
  selectCiPlanData
} from '@aflac/agent/shared'; // Reducer
import { Plan } from '@aflac/shared/data-model';
import {
  selectedPlans,
  selectedCoverages,
  selectedProduct
} from '@aflac/agent/shared'; //selectors
import { resetBuyFlowElements } from '@aflac/agent/shared';
import { Subscription } from 'rxjs';

@Component({
  selector: 'aflac-critical-illness-plan',
  templateUrl: './critical-illness-plan.component.html',
  styleUrls: ['./critical-illness-plan.component.scss']
})
export class CriticalIllnessPlanComponent
  implements OnInit, OnChanges, OnDestroy {
  @Input() plans: any;
  @Input() isPlanLoaded: boolean;
  @Input() productName: string;
  @Input() agentStateMode: boolean;
  @Output() closePlans = new EventEmitter();
  @Output() seePlans = new EventEmitter();
  @Input() tobaccoInd: any;
  @Input() intDiagnosisBenefitAmount: any;
  @Input() cancerCoverage: any;
  @Input() isCiPlanLoaded: boolean;
  @Input() selectAmount: any;

  currentState: any;
  SelectedProductPrice: any;

  constructor(
    private store: Store<ProductState>,
    private cdr: ChangeDetectorRef
  ) {}
  selectedProductId;
  selectedProductCoverage;
  changeLabelAsAddedToCart = false;
  labelsArray = [];
  selectedPlanId;
  selectedProductName;
  key;
  isSelectedKeyTrue: boolean;
  isAvailableInCartTrue: boolean;

  tobaccoRadioOptions: any;
  tobaccoIndValue: any;
  monthlyPay: any;
  showDescription: any;
  productDetails: any;
  selectedPlanBenefitsForDisplay: any;
  cartSubscription = new Subscription();

  ngOnInit() {
    this.showDescription = false;
    this.tobaccoRadioOptions = [
      { text: 'Yes', value: true },
      { text: 'No', value: false }
    ];
    this.isSelectedKeyTrue = this.getSelectedPlan();
    this.tobaccoIndValue = this.tobaccoInd;
    if (this.intDiagnosisBenefitAmount === undefined) {
      this.intDiagnosisBenefitAmount = 20000; //To be updated
    }
  }

  ngOnChanges() {
    // if (Array.isArray(this.plans)) {
    if (this.plans && !Array.isArray(this.plans)) {
      this.monthlyPay = this.plans.price;
      this.selectedPlanBenefitsForDisplay = this.plans.benefits;

      // Scroll to plan area
      const planView = document.getElementById('planArea');
      if (planView) {
        planView.scrollIntoView();
      }
      this.getSelectedProduct();
      if (this.plans !== undefined) {
        this.updateCoverageInStore();
      }
      //this.getCiPlanData();
    }
  }

  updateCoverageInStore() {
    if (this.currentState !== undefined && this.currentState.length > 0) {
      this.currentState.forEach(element => {
        if (element.productId === this.selectedProductId) {
          if (element.plan.id === this.selectedPlanId) {
            if (Array.isArray(this.plans)) {
              let itemData: Array<any> = [];
              itemData = this.plans.filter(
                item => item.id === this.selectedPlanId
              );
              if (itemData.length > 0) {
                this.onPlanSelected(
                  itemData[0],
                  this.isSelectedKeyTrue,
                  this.isAvailableInCartTrue
                );
              }
            } else {
              this.onPlanSelected(
                this.plans,
                this.isSelectedKeyTrue,
                this.isAvailableInCartTrue
              );
            }
          }
        }
      });
    }
  }
  getSelectedProduct() {
    this.store.select(selectedProduct).subscribe(res => {
      if (res) {
        this.productDetails = res;
        this.selectedProductId = res.id;
        this.selectedProductName = res.name;
        this.SelectedProductPrice = res.starting_price;
      }
    });
  }
  getSelectedPlan() {
    this.isSelectedKeyTrue = false;
    this.isAvailableInCartTrue = false;
    this.cartSubscription = this.store.select(selectedPlans).subscribe(res => {
      this.currentState = res && res.value;
      if (res && res.value && res.value.length > 0) {
        const selectedPlanOfCurrentProduct = res.value.filter(
          e => e.productId === 'PREC-ICI'
        );
        if (selectedPlanOfCurrentProduct.length > 0) {
          this.isSelectedKeyTrue = selectedPlanOfCurrentProduct[0].selected;
          this.selectedPlanId = selectedPlanOfCurrentProduct[0].plan.id;
          this.isAvailableInCartTrue =
            selectedPlanOfCurrentProduct[0].availableInCart;
          this.intDiagnosisBenefitAmount = selectedPlanOfCurrentProduct[0]
            .benefitAmount
            ? selectedPlanOfCurrentProduct[0].benefitAmount
            : this.intDiagnosisBenefitAmount;
          this.cdr.detectChanges();
        }
      }
    });
    return this.isSelectedKeyTrue;
  }
  getSelectedCoverageOfCurrentProduct() {
    this.store.select(selectedCoverages).subscribe(res => {
      this.selectedProductCoverage = res.filter(item => {
        return item.productId === this.selectedProductId;
      });
    });
  }
  onPlanSelected(
    plan?: Plan,
    isSelectedKeyTrue?: boolean,
    isAvailableInCartTrue?: boolean
  ) {
    this.store.dispatch(resetBuyFlowElements());

    if (!plan) {
      plan = this.plans;
    }
    this.selectedPlanId = plan.id; // for label updation as added to cart

    if (isSelectedKeyTrue === undefined) {
      this.isSelectedKeyTrue = true;
    } else {
      this.isSelectedKeyTrue = isSelectedKeyTrue;
    }
    if (isAvailableInCartTrue === undefined) {
      this.isAvailableInCartTrue = true;
    } else {
      this.isAvailableInCartTrue = isAvailableInCartTrue;
    }
    this.getSelectedCoverageOfCurrentProduct();
    const selectedPlanDetails = {
      productId: this.selectedProductId,
      productName: this.selectedProductName,
      plan: plan,
      coverage: this.selectedProductCoverage[0].coverageType,
      selected: this.isSelectedKeyTrue,
      availableInCart: this.isAvailableInCartTrue,
      startingPrice: this.SelectedProductPrice,
      tobaccoInd: this.tobaccoInd,
      cancerCoverage: this.cancerCoverage,
      benefitAmount: this.intDiagnosisBenefitAmount
    };
    this.store.dispatch(
      addItemToCart({
        selectedPlan: { key: 'from-list', value: selectedPlanDetails }
      })
    );
  }
  //Close plan List on clicking the close button
  close() {
    this.closePlans.emit();
  }

  onCriticalIllnessCoverageChange(el) {
    this.intDiagnosisBenefitAmount = el.value;
    let tobaccoInd;

    if (this.tobaccoIndValue) {
      tobaccoInd = true;
    } else if (!this.tobaccoIndValue && this.tobaccoIndValue !== undefined) {
      tobaccoInd = false;
    } else {
      tobaccoInd = this.tobaccoIndValue;
    }
    const selectedCoverage =
      this.selectedProductCoverage && this.selectedProductCoverage.length
        ? this.selectedProductCoverage[0].coverageType
        : this.productDetails && this.productDetails.coverage;
    const plandata = {
      product: this.productDetails,
      coverage: selectedCoverage,
      tobaccoInd: tobaccoInd,
      intDiagnosisBenefitAmount: this.intDiagnosisBenefitAmount,
      cancerCoverage: this.cancerCoverage,
      fromCiComponent: true
    };
    this.seePlans.emit(plandata);
    //this.setCiPlanData();
  }
  criticalIllnessTobaccoOptionUpdate(el) {
    this.tobaccoIndValue = el.value;
    const selectedCoverage =
      this.selectedProductCoverage && this.selectedProductCoverage.length
        ? this.selectedProductCoverage[0].coverageType
        : this.productDetails && this.productDetails.coverage;
    const plandata = {
      product: this.productDetails,
      coverage: selectedCoverage,
      tobaccoInd: this.tobaccoIndValue,
      intDiagnosisBenefitAmount: this.intDiagnosisBenefitAmount,
      cancerCoverage: this.cancerCoverage,
      fromCiComponent: true
    };
    this.seePlans.emit(plandata);
    // this.setCiPlanData();
  }

  showHideDescription() {
    return (this.showDescription = !this.showDescription);
  }
  onCancerCoverageChange() {
    let tobaccoInd;
    if (this.tobaccoIndValue) {
      tobaccoInd = true;
    } else if (!this.tobaccoIndValue && this.tobaccoIndValue !== undefined) {
      tobaccoInd = false;
    } else {
      tobaccoInd = this.tobaccoIndValue;
    }
    const selectedCoverage =
      this.selectedProductCoverage && this.selectedProductCoverage.length
        ? this.selectedProductCoverage[0].coverageType
        : this.productDetails && this.productDetails.coverage;
    const plandata = {
      product: this.productDetails,
      coverage: selectedCoverage,
      tobaccoInd: tobaccoInd,
      intDiagnosisBenefitAmount: this.intDiagnosisBenefitAmount,
      cancerCoverage: this.cancerCoverage,
      fromCiComponent: true
    };
    this.seePlans.emit(plandata);
    // this.setCiPlanData();
  }

  /*   getCiPlanData() { 
      this.getCiPlanData$ = this.store
        .pipe(select(selectCiPlanData))
        .subscribe(data => {
          if (data) {
            this.tobaccoIndValue = data.tobaccoInd;
            this.intDiagnosisBenefitAmount = data.intDiagnosisBenefitAmount;
            this.cancerCoverage = data.cancerCoverage;
          }
        });
    } */

  /*   setCiPlanData() {
      this.store.dispatch(
        SaveAgentCriticalIllnessPlansAction({
          data: {
            tobaccoInd: this.tobaccoIndValue,
            intDiagnosisBenefitAmount: this.intDiagnosisBenefitAmount,
            cancerCoverage: this.cancerCoverage
          }
        })
      );
    } */
  ngOnDestroy() {
    this.cartSubscription.unsubscribe();
  }
}
