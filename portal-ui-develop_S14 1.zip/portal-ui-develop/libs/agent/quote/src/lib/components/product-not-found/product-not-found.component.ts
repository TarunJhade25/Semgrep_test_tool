import { Component, OnInit, Input, ViewEncapsulation } from '@angular/core';
import { Store, select } from '@ngrx/store';
import { selectProductErrors } from '@aflac/agent/shared';

@Component({
  selector: 'aflac-product-not-found',
  templateUrl: './product-not-found.component.html',
  styleUrls: ['./product-not-found.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class ProductNotFoundComponent implements OnInit {
  @Input() data: any;
  productError: any;

  constructor(private store: Store<any>) {}

  ngOnInit() {
    this.getErrors();
  }

  getErrors() {
    const errors = this.store.pipe(select(selectProductErrors));
    errors.subscribe(res => {
      this.productError = res;
    });
  }
}
