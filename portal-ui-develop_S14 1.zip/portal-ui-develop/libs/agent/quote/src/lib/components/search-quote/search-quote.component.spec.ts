import { state } from '@angular/animations';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SearchQuoteComponent } from './search-quote.component';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { SharedCmsModule, CmsService } from '@aflac/shared/cms';
import { TranslateModule } from '@ngx-translate/core';
import { SharedvalidatorsModule } from '@aflac/shared/validators';
import { StoreModule, MemoizedSelector, Store } from '@ngrx/store';
import { provideMockStore, MockStore } from '@ngrx/store/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { CUSTOM_ELEMENTS_SCHEMA, DebugElement } from '@angular/core';
import { MatAutocompleteModule } from '@angular/material/autocomplete';
import { of, BehaviorSubject } from 'rxjs';
import { MatSelectModule } from '@angular/material/select';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { SharedPipesModule } from '@aflac/shared/pipes';
import * as fromsearchQuoteSelector from '@aflac/agent/shared'; // Selectors
import { AgentStateComponent } from '@aflac/agent/shared';
import { By } from '@angular/platform-browser';
import * as fromAgentSearchQuote from '@aflac/agent/shared';
import { ExistingCustomerSearchResultModalComponent } from '../existing-customer-search-result-modal/existing-customer-search-result-modal.component';
const filteredStateListMock = [
  {
    code: 'AL',
    name: 'Alabama'
  },
  {
    code: 'AK',
    name: 'Alaska'
  },
  {
    code: 'CO',
    name: 'Colorado'
  },
  {
    code: 'CT',
    name: 'Connecticut'
  },
  {
    code: 'FL',
    name: 'Florida'
  },
  {
    code: 'GA',
    name: 'Georgia'
  },
  {
    code: 'IL',
    name: 'Illinois'
  },
  {
    code: 'MA',
    name: 'Massachusetts'
  },
  {
    code: 'MI',
    name: 'Michigan'
  },
  {
    code: 'MO',
    name: 'Missouri'
  },
  {
    code: 'NE',
    name: 'Nebraska'
  },
  {
    code: 'NJ',
    name: 'New Jersey'
  },
  {
    code: 'NM',
    name: 'New Mexico'
  },
  {
    code: 'NV',
    name: 'Nevada'
  },
  {
    code: 'PA',
    name: 'Pennsylvania'
  },
  {
    code: 'TN',
    name: 'Tennessee'
  },
  {
    code: 'TX',
    name: 'Texas'
  },
  {
    code: 'WA',
    name: 'Washington'
  },
  {
    code: 'WI',
    name: 'Wisconsin'
  }
];
describe('SearchQuoteComponent', () => {
  let component: SearchQuoteComponent;
  let fixture: ComponentFixture<SearchQuoteComponent>;
  let mockStore: MockStore<any>;
  let de: DebugElement;
  let el: HTMLElement;
  let mockgefilteredStateListSelector: MemoizedSelector<any, any>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        ReactiveFormsModule,
        SharedCmsModule,
        TranslateModule,
        SharedvalidatorsModule,
        TranslateModule.forRoot(),
        RouterTestingModule,
        HttpClientTestingModule,
        MatAutocompleteModule,
        FormsModule,
        MatFormFieldModule,
        MatInputModule,
        MatSelectModule,
        BrowserAnimationsModule,
        SharedPipesModule
      ],
      declarations: [SearchQuoteComponent, AgentStateComponent],
      providers: [
        provideMockStore({}),
        { provide: CmsService, useClass: MockCmsService }
      ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SearchQuoteComponent);
    component = fixture.componentInstance;
    component.states = [{ us_states: [{ code: 'AL', name: 'Alabama' }] }];
    mockStore = TestBed.get(Store);
    mockStore.overrideSelector(fromsearchQuoteSelector.agentSelectedQuote, {});
    mockStore.overrideSelector(
      fromsearchQuoteSelector.agentSSNValidatedState,
      false
    );
    mockgefilteredStateListSelector = mockStore.overrideSelector(
      fromAgentSearchQuote.filteredStateList,
      filteredStateListMock
    );
    de = fixture.debugElement.query(By.css('form'));
    el = de.nativeElement;
    fixture.detectChanges();
    component.ngOnInit();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('age field validity - valid case', () => {
    const age = component.searchForm.controls['age'];
    age.setValue('55');
    expect(age.valid).toBeTruthy();
  });

  it('form valid when filled correctly', () => {
    component.searchForm.setValue({
      state: 'Alabama',
      age: '31'
    });
    expect(component.searchForm.valid).toBeTruthy();
  });

  it('should set value of form and to be emitted ', () => {
    let searchOutput = null;
    component.states = [];
    component.searchForm.setValue({
      state: 'Alabama',
      age: '31'
    });
    component.refineSearch.subscribe(tv => {
      searchOutput = tv;
    });
    component.onSubmit();
    expect(searchOutput).not.toBeNull();
  });

  it('should call sessionToStore funtion', () => {
    component.sessionToStore();
    expect(component as any).toBeDefined();
  });

  it('should call storeToSession funtion', () => {
    component.storeToSession();
    expect(component as any).toBeDefined();
  });
});

class MockCmsService {
  public disableSeePlans = new BehaviorSubject(false);
  getKey(key: string | Array<string>, interpolateParams?: Object): any {
    return of({
      us_states: [
        { code: 'AL', name: 'Alabama' },
        { code: 'AK', name: 'Alaska' }
      ]
    });
  }
}
