export interface CartProducts {
  productId: string;
  productName?: string;
  plan: string;
  coverageType: string;
  price: any;
  selected: boolean;
  availableInCart: boolean;
  benefitAmount?: string;
  riders?: SelectedRiderInCart[];
  MonthlyPrice?: string;
  currentPlanState: any;
  tobaccoInd?: boolean;
  cancerCoverage?: boolean;
}

export interface SelectedRiderInCart {
  name: string;
  price: any;
  selected: boolean;
  availableInCart: boolean;
  currentRiderState: any;
}
