import {
  async,
  ComponentFixture,
  TestBed,
  inject
} from '@angular/core/testing';
import { provideMockStore, MockStore } from '@ngrx/store/testing';
import { StoreModule, Store, MemoizedSelector } from '@ngrx/store';
import { RouterTestingModule } from '@angular/router/testing';
import { Router } from '@angular/router';
import { TranslateModule } from '@ngx-translate/core';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { ProductReducer, ProductState } from '@aflac/agent/shared';
import * as fromProduct from '@aflac/agent/shared';
import * as fromAgentSearchQuote from '@aflac/agent/shared';
import * as fromAgent from '@aflac/agent/shared';
import { getRetrieveQuoteData } from '@aflac/agent/landing';
import {
  CUSTOM_ELEMENTS_SCHEMA,
  Component,
  Input,
  Output,
  EventEmitter
} from '@angular/core';
import { StartQuoteComponent } from './start-quote.component';
import { MatSelectModule } from '@angular/material/select';
import { of, Observable } from 'rxjs';
import { CmsService } from '@aflac/shared/cms';

@Component({
  selector: 'aflac-plan-list',
  template: '<div></div>'
})
export class PlanListComponent {
  @Input() plans: any;
  @Input() isPlanLoaded: boolean;
  @Input() productName: string;
  @Input() agentStateMode: boolean;
  @Output() closePlans = new EventEmitter();
}

@Component({
  selector: 'aflac-critical-illness-plan',
  template: '<div></div>'
})
export class CriticalIllnessPlanComponent {
  @Input() plans: any;
  @Input() isPlanLoaded: boolean;
  @Input() productName: string;
  @Input() agentStateMode: boolean;
  @Output() closePlans = new EventEmitter();
  @Output() seePlans = new EventEmitter();
  @Input() tobaccoInd: any;
  @Input() intDiagnosisBenefitAmount: any;
  @Input() cancerCoverage: any;
  @Input() isCiPlanLoaded: boolean;
}

describe('StartQuoteComponent', () => {
  let component: StartQuoteComponent;
  let fixture: ComponentFixture<StartQuoteComponent>;
  let mockStore: MockStore<any>;
  let mockQuoteSelector: MemoizedSelector<any, any>;
  let mockAgentQuoteStateSelector: MemoizedSelector<any, any>;
  let mockProductSelector: MemoizedSelector<any, any>;
  let mockRetrieveQuoteData: MemoizedSelector<any, any>;
  let mockSelectedPlanSelector: MemoizedSelector<any, any>;
  let mockPlanSelector: MemoizedSelector<any, any>;
  let mockEditQuoteSelector: MemoizedSelector<any, any>;
  let mockRetrieveCartDataSelector: MemoizedSelector<any, any>;
  let mockNavigationSrcSelector: MemoizedSelector<any, any>;
  let mockPlanForStateSelector: MemoizedSelector<any, any>;
  let store: Store<ProductState>;
  let quoteStore: Store<any>;

  const getAgent = {
    agencyCd: 'QAG'
  };
  const startQuoteObj = {
    stateProvCd: 'AL',
    age: 45,
    partnerId: 'ABD',
    caseId: 'PROMO123',
    coverage: 'ind'
  };
  const product = [
    {
      features: [
        'Accidental Death & Dismemberment',
        'Accidental Injury',
        'Non-Injury hospital admission benefits'
      ],
      id: 'PREC-IA',
      image: 'assets/images/accident_2.svg',
      productName: 'Accident Insurance',
      riders: [
        { description: '', id: 5001, name: 'Accident Rider 1', value: 14.23 },
        { description: '', id: 5002, name: 'Accident Rider 2', value: 24.23 }
      ],
      startingPrice: 12.32,
      states: ['AK', 'AZ', 'CA'],
      name: 'test'
    },
    {
      features: [
        'Accidental Death & Dismemberment',
        'Accidental Injury',
        'Non-Injury hospital admission benefits'
      ],
      id: 'PREC-IC',
      image: 'assets/images/cancer_2.svg',
      productName: 'Cancer Insurance',
      riders: [
        { description: '', id: 5001, name: 'Cancer Rider 1', value: 14.23 },
        { description: '', id: 5002, name: 'Cancer Rider 2', value: 24.23 }
      ],
      startingPrice: 17.32,
      states: ['AK', 'AZ', 'CA'],
      name: 'test'
    }
  ];

  const plans = [
    {
      id: 111,
      name: 'test',
      title: 'insurance',
      benefits: [
        { id: 5001, name: 'Accident Rider 1', price: 14.23 },
        { id: 5002, name: 'Accident Rider 2', price: 24.23 }
      ]
    }
  ];

  const coverageTypes = [
    {
      code: 'ind',
      default_value: 'You'
    },
    {
      code: 'ind_sps',
      default_value: 'You & Your Spouse'
    }
  ];
  const responseData = {
    value: [
      {
        productId: 'PREC-IC',
        selected: true,
        availableInCart: true,
        plan: { id: 'id1' },
        selectedRiders: [
          {
            rider: { title: 'title1' },
            selected: true,
            availableInCart: true,
            plan: { id: 'id1' }
          },
          {
            rider: { title: 'title2' },
            selected: true,
            availableInCart: true,
            plan: { id: 'id1' }
          }
        ]
      }
    ]
  };

  const agentGetQuoteState = true;

  const RetrieveQuote = {
    data: {
      quotes: [
        {
          bundleId: '000',
          policyNumber: 'a1b2',
          effectiveDate: '01/02/2019',
          expirationDate: '01/06/2019',
          transactionEffectiveDate: '03/02/2019',
          policyStatusCd: 'dummy',
          productCode: 'PREC-IC',
          lobCd: 'dummy',
          totalPremium: 1234,
          currencyCode: 'ind',
          producerCd: 'dummy',
          subProducerCd: 'd',
          quoteNumber: '111',
          customerNumber: '111'
        }
      ]
    }
  };

  const selectedPlans = {
    key: 'from-list',
    value: [
      {
        productId: 'PREC-IC',
        productName: 'Accident',
        plan: [],
        coverage: 'ind',
        selected: true,
        availableInCart: true,
        selectedRiders: [
          {
            selected: true,
            availableInCart: true,
            productId: 'PREC-IC',
            rider: []
          }
        ]
      }
    ]
  };

  const lookupdata = {
    name: 'Cancer - Elite Plan',
    price: '$6.99',
    riders: [
      {
        title: 'Initial Diagnosis Increasing Benefit Rider',
        description:
          'Help ease the devastating impact and financial challenges of a cancer diagnosis',
        price: ['$500'],
        benefit: [
          {
            title: 'Hospitalization',
            price: '$150 / day',
            benefit_category: []
          },
          {
            title: 'Ambulance',
            price: '$200 ground $2000 air',
            benefit_category: []
          }
        ]
      },
      {
        title: 'Specified-Disease Diagnosis Benefit Rider',
        description:
          'Receive an extra layer of protection against the financial burden of an unexpected diagnosis.',
        price: ['$2,000'],
        benefit: [
          {
            title: 'Initial Benefit',
            price: '$2,000',
            benefit_category: []
          }
        ]
      }
    ]
  };

  const retriveData = [
    {
      policyNumber: '196',
      customerNumber: '1212',
      effectiveDate: '2019-12-12',
      expirationDate: '2020-12-12',
      transactionEffectiveDate: '2020-02-28T12:51:20Z',
      policyStatusCd: 'dataGather',
      transactionTypeCd: 'quote',
      timedPolicyStatusCd: 'dataGather',
      revisionNumber: 0,
      pendingRevisionNumber: 0,
      productCode: 'PREC-IA',
      productVersion: 1,
      lobCd: 'ACCIDENT&HEALTH',
      totalPremium: 0,
      monthlyPremium: 0,
      currencyCode: 'USD',
      coverageTypeCd: 'ind_fml',
      packageCd: 'Low',
      countryCd: 'US',
      riskStateCd: 'CA',
      sourceCd: 'New',
      producerCd: 'New',
      subProducerCd: 'New',
      contractTermTypeCd: 'Annual',
      underwriterCd: 'Tier One',
      overrideRateEffectiveDateInd: true,
      rateEffectiveDate: '2019-12-12',
      isOffTheJobOnlyInd: false,
      enrollmentMetadata: 'String',
      insureds: [
        {
          primaryInsuredInd: true,
          relationshipToPrimaryInsuredCd: 'self',
          beneficiaryTypeCd: '',
          title: '',
          firstName: 'David',
          lastName: 'Bower',
          middleName: '',
          suffix: '',
          ssn: '',
          genderCd: 'Male',
          maritalStatusCd: '',
          dateOfBirth: '1984-07-13',
          splitPercentage: ''
        },
        {
          primaryInsuredInd: false,
          relationshipToPrimaryInsuredCd: '1',
          beneficiaryTypeCd: '',
          title: '',
          firstName: 'Katherine',
          lastName: 'Evans',
          middleName: '',
          suffix: '',
          ssn: '',
          genderCd: 'Female',
          maritalStatusCd: '',
          dateOfBirth: '1992-07-13',
          splitPercentage: ''
        }
      ],
      riders: [
        {
          riderNameCd: 'Additional Accidental-Death Benefit Rider'
        }
      ]
    }
  ];

  const dummyRetrieveCartdata = {
    quoteNumber: '301',
    bundleId: 3,
    customerNumber: '20000000003',
    effectiveDate: '2019-12-12',
    expirationDate: '2020-12-12',
    transactionEffectiveDate: '2020-02-28T12:51:20Z',
    policyStatusCd: 'dataGather',
    transactionTypeCd: 'quote',
    timedPolicyStatusCd: 'dataGather',
    revisionNumber: 0,
    pendingRevisionNumber: 0,
    productCode: 'PREC-IA',
    productVersion: 1,
    lobCd: 'ACCIDENT&HEALTH',
    totalPremium: 0,
    monthlyPremium: 50,
    currencyCode: 'USD',
    coverageTypeCd: 'ind_sps',
    sourceCd: 'New',
    producerCd: 'New',
    subProducerCd: 'New',
    caseId: 'CaseLinkTest',
    sfrId: 'abc123',
    basePremium: 100,
    monthlyBasePremium: 100,
    totalMonthlyPremium: 150,
    initialDiagnosisAmount: {},
    riders: [],
    plans: [
      {
        id: 'Low',
        name: 'Lorem ipsum dolor sit',
        title: 'Standard Plan',
        description: 'These are the benefits that you cash.',
        states: [
          'AL',
          'AZ',
          'AR',
          'CA',
          'CO',
          'CT',
          'DE',
          'FL',
          'GA',
          'HI',
          'IL'
        ],
        price: 37.8,
        riders: []
      }
    ]
  };
  const editQuote = {
    edited: true,
    initialCartState: selectedPlans.value
  };
  const agentInfData = {
    subProducerCd: '1',
    firstName: 'John',
    middleName: 'R',
    lastName: 'Smith',
    agencyCd: 'QAG',
    agencyName: 'QA Agency',
    electronicSignature: false,
    voiceRecording: false
  };
  const accidentRiderFromCms = {
    title: 'Additional Accidental-Death Benefit Rider',
    riderNameCd: 'Accident Death Benefit Rider',
    description: 'xyz',
    price: ['$8.58'],
    isBenefitPresent: true,
    common_carrier_accident_code: 'AflacRiderADBCommonCarrierAccident',
    other_accident_code: 'AflacRiderADBOtherAccident'
  };
  const criticalIllnessPlanRider = {
    formNumber: 'T71051',
    riderNameCd: 'Critical Illness Event Hospitalization Benefit Rider',
    title: 'Critical Illness Event Hospitalization Benefit Rider',
    rider_name: 'AflacCIEventHospitalizationBenefitRider',
    description: 'xyz',
    benefits: [
      {
        benefit_code: 'AMB',
        title: 'Ambulance',
        price: '$200 ground<br/>$2,000 air',
        description: '',
        type: 'LH',
        sub_benefits: []
      },
      {
        benefit_code: 'Transportation',
        title: 'Transportation',
        description: '',
        sub_benefits: [
          {
            sub_benefit_code:
              'AflacTransportationBusTrolleyBoatoraPrivateRentalorTaxiVehicle',
            title: 'Via bus, trolley, boat; or private, rental or taxi vehicle',
            description: '',
            price: '$100/round trip',
            type: 'MP'
          },
          {
            sub_benefit_code: 'AflacTransportationCommonCarrierVehicle',
            title: 'Via common carrier',
            description: '',
            price: '$500/round trip',
            type: 'MP'
          },
          {
            sub_benefit_code:
              'AflacTransportationBusTrolleyBoatoraPrivateRentalorTaxiVehicle',
            title: 'For dependent child and immediate family member',
            price: '$100/round trip',
            type: 'MP',
            description: ''
          }
        ]
      }
    ],
    monthlyPremium: 2.38
  };
  const criticalIllnessRiderMatchCMS = {
    title: 'Critical Illness Event Hospitalization Benefit Rider',
    riderNameCd: 'Critical Illness Event Hospitalization Benefit Rider',
    description: 'xyz',
    price: ['$2.39'],
    isBenefitPresent: true,
    sub_benefit_info_flag: 'AflacTransportationCommonCarrierVehicle',
    benefit: [
      {
        title: 'Ambulance',
        price: '@200 ground / $2000 air',
        benefit_category: []
      },
      {
        title: 'Transportation',
        price: '',
        benefit_category: [
          {
            title: 'Via bus, trolley, boat; or private, rental or taxi vehicle',
            price: '$100 / round trip',
            carrier_flag: false
          },
          {
            title: 'Via common carrier',
            price: '$500 / round trip',
            carrier_flag: true
          },
          {
            title: 'For dependent child and immediate family member',
            price: '$1,000 / round trip',
            carrier_flag: false
          }
        ]
      }
    ]
  };
  const accidentRiderFromPlan = {
    formNumber: 'T37050',
    riderNameCd: 'Accident Death Benefit Rider',
    title: 'Additional Accidental-Death Benefit Rider',
    rider_name: 'AflacAccidentDeathBenefitRider',
    description: 'xyz',
    benefits: [
      {
        benefit_code: 'AflacRiderADBCommonCarrierAccident',
        title: 'Common Carrier Accident',
        description: '',
        sub_benefits: [],
        price: [
          {
            key: 'You',
            value: '$100,000'
          }
        ]
      },
      {
        benefit_code: 'AflacRiderADBOtherAccident',
        title: 'Other Accident',
        description: '',
        sub_benefits: [],
        price: [
          {
            key: 'You',
            value: '$100,000'
          }
        ]
      }
    ],
    monthlyPremium: 8.58
  };
  const navigationSrc = {
    isNavigatedFromSYP: false
  };

  const plansForState = {
    productId: 'PREC-IA',
    planDetails: [
      {
        id: 111,
        name: 'test',
        title: 'insurance',
        benefits: [
          { id: 5001, name: 'Accident Rider 1', price: 14.23 },
          { id: 5002, name: 'Accident Rider 2', price: 24.23 }
        ]
      }
    ]
  };

  class RouterStub {
    navigateByUrl(url: string) {
      return url;
    }
  }

  class MockCmsService {
    getKey(any): Observable<any> {
      const data = { start_quote_cancer_rider: lookupdata };
      return of(data);
    }
  }
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [
        StartQuoteComponent,
        PlanListComponent,
        CriticalIllnessPlanComponent
      ],
      imports: [
        TranslateModule.forRoot(),
        ReactiveFormsModule,
        FormsModule,
        StoreModule.forRoot(ProductReducer),
        RouterTestingModule,
        MatSelectModule
      ],
      providers: [
        provideMockStore({}),
        { provide: Router, useClass: RouterStub },
        { provide: CmsService, useClass: MockCmsService }
      ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(StartQuoteComponent);
    mockStore = TestBed.get(Store);
    store = TestBed.get(Store);
    quoteStore = TestBed.get(Store);
    mockQuoteSelector = mockStore.overrideSelector(
      fromAgentSearchQuote.agentSelectedQuote,
      startQuoteObj
    );
    mockAgentQuoteStateSelector = mockStore.overrideSelector(
      fromAgentSearchQuote.agentGetQuoteState,
      agentGetQuoteState
    );
    mockProductSelector = mockStore.overrideSelector(
      fromProduct.products,
      product
    );
    mockSelectedPlanSelector = mockStore.overrideSelector(
      fromProduct.selectedPlans,
      selectedPlans
    );
    mockRetrieveCartDataSelector = mockStore.overrideSelector(
      fromProduct.RetrieveCartData,
      dummyRetrieveCartdata
    );
    mockRetrieveQuoteData = mockStore.overrideSelector(
      getRetrieveQuoteData,
      RetrieveQuote
    );
    mockPlanSelector = mockStore.overrideSelector(fromProduct.plans, plans);
    mockEditQuoteSelector = mockStore.overrideSelector(
      fromAgentSearchQuote.selectEditQuoteState,
      editQuote
    );
    mockStore.overrideSelector(
      fromAgentSearchQuote.agentSSNValidatedState,
      false
    );
    mockNavigationSrcSelector = mockStore.overrideSelector(
      fromProduct.getNavigationSource,
      navigationSrc
    );
    mockPlanForStateSelector = mockStore.overrideSelector(
      fromProduct.getPlansForState,
      plansForState
    );
    sessionStorage.setItem('agent-information', JSON.stringify(agentInfData));
    mockStore.overrideSelector(fromAgent.getAgentProfile, getAgent);
    sessionStorage.setItem('agent-information', JSON.stringify(agentInfData));
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    console.log('should create');
    expect(component).toBeTruthy();
    console.log('should create end');
  });

  it('should set coverageTypes variable', () => {
    console.log('should set coverageTypes variable');
    component.coverageTypes = coverageTypes;
    expect(component.coverageTypes).toBeDefined();
    console.log('should set coverageTypes variable end');
  });

  it('should fetch plans', () => {
    console.log('should fetch plans');
    component.plans = plans;
    expect(component.plans).toBeDefined();
    console.log('should fetch plans end');
  });

  it('should fetch products', () => {
    console.log('should fetch products');
    expect(component.productList).toBeDefined();
    console.log('should fetch products end');
  });

  it('getImage should return image path based on Product', () => {
    console.log('getImage should return image path based on Product');
    const val = component.getImage('Accident Insurance');
    expect(val).toEqual('assets/images/accident_2.svg');
    console.log('getImage should return image path based on Product 1 end');
  });

  it('getImage should return image path based on Product', () => {
    console.log('getImage should return image path based on Product');
    const val = component.getImage('Critical Illness Insurance');
    expect(val).toEqual('assets/images/critical-illness_2.svg');
    console.log('getImage should return image path based on Product 2 end');
  });

  it('getImage should return image path based on Product', () => {
    console.log('getImage should return image path based on Product');
    const val = component.getImage('Cancer Insurance');
    expect(val).toEqual('assets/images/cancer_2.svg');
    console.log('getImage should return image path based on Product 3 end');
  });

  it('getImage should return image path based on Product', () => {
    console.log('getImage should return image path based on Product');
    const val = component.getImage('XYZ');
    expect(val).toEqual('assets/images/errro.svg');
    console.log('getImage should return image path based on Product 4 end');
  });

  it('should dispatch the agentGetQuote', () => {
    console.log('should dispatch the agentGetQuote');
    const spyObj = spyOn(store, 'dispatch').and.returnValue(of(true));
    component.refineSearch(startQuoteObj);
    expect(spyObj).toHaveBeenCalled();
    console.log('should dispatch the agentGetQuote end');
  });

  it('should call closePlans funtion', () => {
    console.log('should call closePlans funtion');
    component.closePlans();
    expect(component as any).toBeDefined();
    console.log('should call closePlans funtion end');
  });
  it('should update rider info in cart', () => {
    console.log('should update rider info in cart');
    component.updateCartRider('cancer Insurance', 'prec-ic', product[1].riders);
    expect(component as any).toBeDefined();
    console.log('should update rider info in cart end');
  });

  it('should prepopulate cart on retrieve quote flow', () => {
    console.log('should prepopulate cart on retrieve quote flow');
    component.retrievedQuoteData = retriveData;
    component.prepopulateCart();
    expect(component as any).toBeDefined();
    console.log('should prepopulate cart on retrieve quote flow end');
  });

  it('should enable user to edit quote in retrieve quote flow ', () => {
    console.log('should enable user to edit quote in retrieve quote flow');
    spyOn(store, 'dispatch');
    component.changeToEditMode();
    expect(store.dispatch).toHaveBeenCalled();
    expect(component as any).toBeDefined();
    console.log('should enable user to edit quote in retrieve quote flow end');
  });
  it('should map coverage type ', () => {
    console.log('should map coverage type ');
    component.retrievedQuoteData = retriveData;
    component.mapCoverageType('PREC-IA');
    expect(component as any).toBeDefined();
    console.log('should map coverage type end ');
  });
  it('should disable plans on changing search fields', () => {
    console.log('should disable plans on changing search fields');
    component.disablePlans(true);
    expect(component.isPlanLoaded).toBeFalsy();
    console.log('should disable plans on changing search fields end');
  });
  it('should navigate to save quote on clicking continue', () => {
    spyOn(component, 'filterCartWithSelectedQuotes').and.returnValue(true);
    component.agentStateMode = true;
    component.navigateToSaveQuote();
    expect(component as any).toBeDefined();
  });
  it('should navigate to home page if product not loaded', () => {
    component.navigateToHome();
    expect(component as any).toBeDefined();
  });
  it('should fetch plans on clicking see plans', () => {
    const productData = {
      product: { name: 'cancer Insurance', id: 'PREC-IC' }
    };
    component.seePlans(productData);
    expect(component.productName).toEqual(productData.product.name);
    expect(component.productId).toEqual(productData.product.id);
  });
  it('should fetch CI plans on clicking see plans', () => {
    const productData = {
      product: { name: 'cancer Insurance', id: 'PREC-ICI' },
      intDiagnosisBenefitAmount: 500,
      tobaccoInd: true,
      cancerCoverage: true
    };
    component.seePlans(productData);
    expect(component.intDiagnosisBenefitAmount).toBeDefined();
    expect(component.cancerCoverage).toBeDefined();
  });
  it('should update coverage in product list', () => {
    const data = { id: 'PREC-IC', coverage: 'ind' };
    component.coverageChange(data);
    expect(component as any).toBeDefined();
  });
  it('should call seePlanDetails and update the values', () => {
    component.seePlanDetails();
    expect(component as any).toBeDefined();
  });
  it('should filterCartWithSelectedQuotes', () => {
    component.filterCartWithSelectedQuotes();
    expect(component as any).toBeDefined();
  });
  it('should be able to navigate to proper url', () => {
    const selplans = [{ coverage: 'ind-sps', selected: true }];
    component.decideNavigation(selplans);
    expect(component as any).toBeDefined();
  });
  it('should return todays date', () => {
    const today = component.getTodayDate();
    expect(today).toBeTruthy();
  });
  it('should map rider benefit values from plan response', () => {
    let benefits = component.getBenefits(
      'critical_illness',
      criticalIllnessRiderMatchCMS,
      criticalIllnessPlanRider
    );
    expect(Object.keys(benefits).length).toBeGreaterThan(0);
    benefits = component.getBenefits(
      'accident',
      accidentRiderFromCms,
      accidentRiderFromPlan
    );
    expect(Object.keys(benefits).length).toBeGreaterThan(0);
  });
  it('should filter rider from cart based on selectedplan', () => {
    const riderFromCart = [
      {
        selected: true,
        availableInCart: true,
        rider: { riderNameCd: 'Accident Death Benefit Rider' }
      }
    ];
    const updatedRider = component.filterRiders(
      [accidentRiderFromPlan],
      riderFromCart
    );
    expect(updatedRider.length).toBeGreaterThan(0);
  });
});
