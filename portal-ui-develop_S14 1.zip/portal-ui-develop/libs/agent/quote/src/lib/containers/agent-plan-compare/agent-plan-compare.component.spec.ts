import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { RouterModule } from '@angular/router';
import { CUSTOM_ELEMENTS_SCHEMA, Input, Component } from '@angular/core';
import { StoreModule, Store, MemoizedSelector } from '@ngrx/store';
import { APP_BASE_HREF } from '@angular/common';
import { MockStore, provideMockStore } from '@ngrx/store/testing';
import { EffectsModule } from '@ngrx/effects';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { TranslateModule } from '@ngx-translate/core';
import { AgentPlanCompareComponent } from './agent-plan-compare.component';
import { AgentQuoteModule } from '../../agent-quote.module';
import { ProductState, ProductReducer } from '@aflac/agent/shared';
import { CmsService } from '@aflac/shared/cms';
import { SeoService } from '@aflac/shared/ui';
import { of } from 'rxjs';
import * as fromProduct from '@aflac/agent/shared';
import { RouterTestingModule } from '@angular/router/testing';

@Component({
  selector: 'aflac-compare-plan',
  template: '<div></div>'
})
export class ComparePlansComponent {
  @Input() portalKey;
}

class MockSeoServiceService {
  updateTitle(title: string) {}

  /**Update Description tag */
  updateDescription(desc: string) {}
}
const coverageMockDataType = { productId: 'PREC-IC', coverage: 'ind' };
const searchQuoteMockData = {
  age: '22',
  caseId: 'QWESR2314 WE',
  leadId: '',
  partnerId: 'AA00118',
  state: 'Alabama',
  stateProvCd: 'AL'
};
const selectedPlans = {
  key: 'from-list',
  value: [
    {
      productId: 'PREC-IC',
      productName: 'Accident',
      plan: {
        id: 123,
        price: '100',
        description: 'These are the benefits',
        name: 'Lorem ipsum',
        states: ['AL', 'CT'],
        title: 'Standard Plan',
        benefits: [
          {
            id: 333,
            name: 'test',
            price: 123
          }
        ]
      },
      coverage: 'ind',
      selected: true,
      availableInCart: true,
      selectedRiders: [
        {
          rider: { title: 'title1', price: '100' },
          selected: true,
          availableInCart: true,
          plan: { id: 'id1' }
        },
        {
          rider: { title: 'title2', price: '200' },
          selected: true,
          availableInCart: true,
          plan: { id: 'id1' }
        }
      ]
    }
  ]
};
describe('AgentPlanCompareComponent', () => {
  let component: AgentPlanCompareComponent;
  let fixture: ComponentFixture<AgentPlanCompareComponent>;
  let quoteStore: Store<ProductState>;
  let mockStore: MockStore<any>;
  let mockSelectedPlanSelector: MemoizedSelector<any, any>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        RouterTestingModule,
        StoreModule.forRoot({ ProductReducer }),
        RouterModule.forRoot([]),
        TranslateModule.forRoot(),
        HttpClientTestingModule
      ],
      declarations: [ComparePlansComponent, AgentPlanCompareComponent],
      providers: [
        provideMockStore({}),
        { provide: APP_BASE_HREF, useValue: '/' },
        { provide: SeoService, useClass: MockSeoServiceService },
        { provide: CmsService, useClass: MockCmsService }
      ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA]
    }).compileComponents();
  }));

  beforeEach(() => {
    quoteStore = TestBed.get(Store);
    mockStore = TestBed.get(Store);
    fixture = TestBed.createComponent(AgentPlanCompareComponent);
    component = fixture.componentInstance;
    mockSelectedPlanSelector = mockStore.overrideSelector(
      fromProduct.selectedPlans,
      selectedPlans
    );
    sessionStorage.setItem(
      'state-selectedCoverageType',
      JSON.stringify(coverageMockDataType)
    );
    sessionStorage.setItem(
      'agent-state-searchQuote',
      JSON.stringify(searchQuoteMockData)
    );
    sessionStorage.setItem(
      'state-selectedProduct',
      JSON.stringify({
        id: 'PREC-IA',
        name: 'Accident Insurance'
      })
    );
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
  it('should check coverageData function is called', () => {
    component.coverageData();
    expect(component.coverageData).toBeDefined();
  });
  it('should check setStateSearchQuoteData function is called', () => {
    component.setStateSearchQuoteData();
    expect(component.setStateSearchQuoteData).toBeDefined();
  });
  // it('should navigate on clicking back button', () => {
  //   spyOn(component.navigationService, 'triggerBackButton').and.returnValue(
  //     true
  //   );
  //   component.navigateBack();
  //   expect(component.navigationService.triggerBackButton).toHaveBeenCalled();
  // });

  class MockCmsService {
    getKey(key: string | Array<string>, interpolateParams?: Object): any {
      return of({
        coverage_types: [
          {
            code: 'ind',
            defaultValue: 'Me'
          },
          {
            code: 'ind_sps',
            defaultValue: 'Me & My Spouse'
          },
          {
            code: 'ind_fml',
            defaultValue: 'Me, My Spouse & Children'
          },
          {
            code: 'ind_chd',
            defaultValue: 'Me & My Children'
          }
        ],
        agencyid: 'TestAgencyId'
      });
    }
  }
});
