import {
  Component,
  OnInit,
  OnDestroy,
  Output,
  EventEmitter,
  ViewChild,
  ChangeDetectorRef
} from '@angular/core';
import { Product, Plan } from '@aflac/shared/data-model';
import { Store, select, ActionsSubject } from '@ngrx/store';
import { Observable, Subscription } from 'rxjs';
import { StartQuote, Agent } from '@aflac/agent/shared';
import {
  findProductsAction,
  findPlansAction,
  findPlansForState,
  selectProduct,
  saveCoverageTypeOfSelectedProduct,
  initCart,
  addItemToCart,
  updateRiderInfoInCart,
  populateRetrieveCart,
  populateRetrieveCartSuccess,
  UpdateCartOnQuoteSave,
  getProductsByState,
  ResetPlanState,
  RetrieveCartData,
  SaveAgentCriticalIllnessPlansAction,
  getNavigationSource,
  SetNavigationSource,
  getPlansForState
} from '@aflac/agent/shared'; // Product Actions
import {
  agentGetQuote,
  agentGetQuoteStateAction,
  agentEditedQuoteAction,
  resetBuyFlowElements,
  saveUserDetails
} from '@aflac/agent/shared'; // Agent Actions
import { ProductState } from '@aflac/agent/shared'; // Reducer
import { products, plans, selectedPlans } from '@aflac/agent/shared'; // Product Selectors
import {
  agentSelectedQuote,
  agentGetQuoteState,
  selectEditQuoteState,
  agentSSNValidatedState,
  getAgentProfile
} from '@aflac/agent/shared'; // Agent Selectors
import { getRetrieveQuoteData } from '@aflac/agent/landing'; // Agent Selectors
import { retrieveBundleCloneAction } from '@aflac/agent/landing'; // Agent Action
import { Router } from '@angular/router';
import { CmsService } from '@aflac/shared/cms';
import { QuoteService } from '../../services/quote-service.service';

@Component({
  selector: 'aflac-start-quote',
  templateUrl: './start-quote.component.html',
  styleUrls: ['./start-quote.component.scss']
})
export class StartQuoteComponent implements OnInit, OnDestroy {
  subscription = new Subscription();
  retrieveQuoteSubscription = new Subscription();
  productSubscription = new Subscription();
  cmsSubscription = new Subscription();
  agentStateMode: boolean;
  agentSelectedQuote: StartQuote;
  agentSelectedQuoteObj$: Observable<StartQuote>;
  productList: any;
  coverageTypes: any;
  states: any;
  isProductLoaded = false;
  plans: Plan[];
  isPlanLoaded = false;
  productName: string;
  productId: string;
  product: Product;
  indexValue = -1;
  benefitData = [];
  productBenefitData = [];
  isCartEmpty = true;
  selectedPlansObj;
  showShoppingCart = true;
  prevBundleId: any;
  ssnValidatedData: any;
  ssnValidatedState = false;
  @Output()
  sample = new EventEmitter<any>();
  retrievedQuoteData: any;
  selectedPlanDetails: any;
  cartFiltered = [];
  image_1: string;
  image_2: string;
  editQuoteStatus: any;
  agentCMSData: any;
  editquoteSubscription = new Subscription();
  cartSubscription = new Subscription();
  planSubscription = new Subscription();
  retrieveCartDataSub = new Subscription();
  planChangeSub = new Subscription();
  ssnSub = new Subscription();

  isCriticalIllnessPlan: boolean;
  tobaccoInd: any;
  cancerCoverage = false;
  agentDetails$ = new Subscription();
  agencyId: any;
  isCiPlanLoaded: any;
  intDiagnosisBenefitAmount: number;
  selectAmount: any;
  initialLoad: boolean;
  srcSubscription: Subscription;
  navigationSrc;
  statePlanSubscription: Subscription;
  updatedProductsArray = [];

  constructor(
    private router: Router,
    public cmsService: CmsService,
    private store: Store<{ products: ProductState }>,
    private quoteStore: Store<any>,
    private agentStore: Store<Agent>,
    private actionsSubject$: ActionsSubject,
    private cdr: ChangeDetectorRef,
    private quoteService: QuoteService
  ) {}

  ngOnInit() {
    this.initialLoad = true;
    this.getNavigationSrc();
    this.prevBundleId = undefined;
    this.selectAmount = [
      { text: '$10K', value: 10000 },
      { text: '$15K', value: 15000 },
      { text: '$20K', value: 20000 }
    ];
    this.store.dispatch(ResetPlanState());
    this.quoteService.currentPlanState(undefined);
    this.getEditQuoteStatus();
    this.getAgentCMSData();
    this.getLookUpData();
    this.getCustomerQuoteData();
    //Hidding the no product page
    this.isProductLoaded = false;
    // Scroll to product area
    this.scrollToProductArea(75);
    //Get SSN Status
    this.getSSNValidatedState();
    this.isCriticalIllnessPlan = false;
    this.getAgentDetails();
    this.detectChangeInPlan();
    this.getPlansForUsersState();
    this.updatePlanPrice();
  }
  getPlansForUsersState() {
    this.statePlanSubscription = this.store
      .pipe(select(getPlansForState))
      .subscribe(planData => {
        if (planData) {
          // this.plans = planData;
          this.getSelectedPlanRiderArray(
            planData.planDetails,
            planData.productId
          );
        }
      });
  }

  updatePlanPrice() {
    if (
      this.selectedPlansObj &&
      this.selectedPlansObj.length &&
      this.navigationSrc &&
      this.navigationSrc.isNavigatedFromSYP
    ) {
      this.selectedPlansObj.map(item => {
        const obj = {
          productId: item.productId,
          stateProvCd: this.agentSelectedQuote.stateProvCd,
          state: this.agentSelectedQuote.state,
          primaryInsuredAge: this.agentSelectedQuote.age,
          coverageTierCd: item.coverage,
          riders: [],
          agencyId: this.agencyId,
          caseId: this.agentSelectedQuote && this.agentSelectedQuote.caseId
        };
        if (item.productId === 'PREC-ICI') {
          obj['tobaccoInd'] = item.tobaccoInd;
          obj['cancerCoverage'] = item.cancerCoverage;
          obj['intDiagnosisBenefitAmount'] = item.benefitAmount;
        }
        // this.cdr.detectChanges();
        this.store.dispatch(findPlansForState(obj));
        //   this.cdr.detectChanges();
      });
    }
  }
  getNavigationSrc() {
    this.srcSubscription = this.quoteStore
      .select(getNavigationSource)
      .subscribe(data => {
        if (data) {
          this.navigationSrc = data;
        }
      });
  }

  detectChangeInPlan() {
    // Listen to change in plan and on getting data, update rider in cart and rider area
    this.planChangeSub = this.quoteService.data.subscribe(data => {
      if (data && data.plan && data.productId)
        this.getSelectedPlanRiderArray(data.plan, data.productId);
    });
  }

  getAgentDetails() {
    const agentDetails$ = this.agentStore
      .pipe(select(getAgentProfile))
      .subscribe(data => {
        if (data && data.agencyCd) {
          this.agencyId = data.agencyCd;
        } else {
          const agentData = JSON.parse(
            sessionStorage.getItem('agent-information')
          );
          this.agencyId =
            agentData && agentData.agencyCd ? agentData.agencyCd : null;
        }
      });
  }
  scrollToProductArea(offset) {
    const productView = document.getElementById('productArea');
    if (productView) {
      this.scrollToPosition(productView, offset);
    }
  }
  getSSNValidatedState() {
    this.ssnSub = this.store
      .pipe(select(agentSSNValidatedState))
      .subscribe(data => {
        if (data) {
          this.ssnValidatedData = data.filterProducts;
          this.ssnValidatedState = data.ssnState;
        }
      });
  }

  getEditQuoteStatus() {
    this.editquoteSubscription = this.quoteStore
      .select(selectEditQuoteState)
      .subscribe(data => {
        if (data) this.storeEditQuoteInSession(data);
        this.editQuoteStatus =
          data && data.edited !== undefined
            ? data
            : JSON.parse(sessionStorage.getItem('state-edit-quote-status'));
      });
  }

  storeEditQuoteInSession(data) {
    sessionStorage.setItem('state-edit-quote-status', JSON.stringify(data));
  }
  getAgentStateMode() {
    this.store.pipe(select(agentGetQuoteState)).subscribe(mode => {
      if (mode !== undefined) this.setSessionAgentStateMode(mode);
      this.agentStateMode =
        mode !== undefined
          ? mode
          : JSON.parse(sessionStorage.getItem('state-agentStateMode'));
    });
  }

  getCustomerQuoteData() {
    this.retrieveQuoteSubscription = this.quoteStore
      .pipe(select(getRetrieveQuoteData))
      .subscribe(quoteData => {
        this.retrievedQuoteData =
          quoteData &&
          !quoteData.isCloned &&
          quoteData.data &&
          quoteData.data.quotes &&
          quoteData.data.quotes.length > 0
            ? quoteData.data.quotes
            : this.getSessionRetrieveQuoteData();

        if (
          quoteData &&
          quoteData.data &&
          quoteData.data.quotes &&
          quoteData.isCloned
        ) {
          sessionStorage.setItem(
            'state-retrieveQuote',
            JSON.stringify(quoteData.data.quotes)
          );
        }
        // Update bundleId in session
        this.setBundleIdToSession();
      });
  }

  getLookUpData() {
    const sub = this.cmsService.getKey('lookup').subscribe(lookup => {
      this.states = lookup.us_states;
    });
    this.cmsSubscription.add(sub);
  }

  getAgentCMSData() {
    this.cmsSubscription = this.cmsService
      .getKey('agent_portal')
      .subscribe(agentCMSData => {
        this.agentCMSData = agentCMSData;
        if (agentCMSData) {
          this.coverageTypes = agentCMSData.coverage_types;
          this.getSelectedPlans();
          this.getAgentStateMode();
          this.agentSelectedQuoteObj$ = this.store.pipe(
            select(agentSelectedQuote)
          );
          this.getSelectedQuote();
          this.getProducts();
          this.getPlans();
          this.RetrieveCartData();
        }
      });
  }

  getSelectedQuote() {
    const sub = this.agentSelectedQuoteObj$.subscribe(res => {
      this.agentSelectedQuote = res;
      if (res !== undefined) {
        this.getAvailableProductsViaService(res);
      } else {
        const searchQuote = JSON.parse(
          sessionStorage.getItem('agent-state-searchQuote')
        );
        if (!searchQuote) this.router.navigateByUrl('home');
      }
    });
    this.cmsSubscription.add(sub);
  }

  getSessionRetrieveQuoteData() {
    return sessionStorage.getItem('state-retrieveQuote')
      ? JSON.parse(sessionStorage.getItem('state-retrieveQuote'))
      : '';
  }

  setSessionAgentStateMode(agentStateMode) {
    sessionStorage.setItem(
      'state-agentStateMode',
      JSON.stringify(agentStateMode)
    );
  }

  getSessionSelectedProductData() {
    return JSON.parse(sessionStorage.getItem('state-selectedProduct'));
  }

  // Get available products via service call
  getAvailableProductsViaService(startQuoteObj) {
    this.store.dispatch(findProductsAction({ startQuote: startQuoteObj }));
  }

  // Get products list from store
  getProducts() {
    this.productList = [];
    this.productSubscription = this.store
      .pipe(select(products))
      .subscribe(productData => {
        if (productData && productData.length) {
          // Filter out purchased products
          if (this.ssnValidatedState) {
            productData = productData.filter(
              ({ id: id1 }) =>
                !this.ssnValidatedData.some(({ productCd: id2 }) => id2 === id1)
            );
          }
          // Keep products by state
          this.store.dispatch(
            getProductsByState({ productsByState: productData })
          );
          this.storeToSession('productDetails', productData);
          this.productList = productData
            .map(product => {
              return {
                ...product,
                image: this.getImage(product.name),
                coverage: this.mapCoverageType(product.id)
              };
            })
            .sort((a, b) => a.starting_price - b.starting_price);
          this.prepopulateCart();
          this.isProductLoaded = true;
        } else {
          this.productList = [];
          this.isProductLoaded = true;
        }
      });
  }

  // Get the image urls based on each product
  getImage(productName: string): string {
    const urlPath = 'assets/images/';
    let productImage;
    switch (productName) {
      case 'Accident Insurance':
        productImage = `${urlPath}accident_2.svg`;
        break;
      case 'Critical Illness Insurance':
        productImage = `${urlPath}critical-illness_2.svg`;
        break;
      case 'Cancer Insurance':
        productImage = `${urlPath}cancer_2.svg`;
        break;
      default:
        productImage = `${urlPath}errro.svg`;
        break;
    }
    return productImage;
  }

  mapCoverageType(productId: string) {
    let updateCoverage = [];
    if (
      this.retrievedQuoteData &&
      this.retrievedQuoteData.length > 0 &&
      !this.editQuoteStatus
    ) {
      updateCoverage = this.retrievedQuoteData.filter(
        rData => rData.productCode === productId
      );
      return updateCoverage && updateCoverage.length > 0
        ? updateCoverage[0].coverageTypeCd
        : 'ind';
    } else if (
      this.retrievedQuoteData &&
      this.retrievedQuoteData.length > 0 &&
      this.editQuoteStatus
    ) {
      updateCoverage =
        this.selectedPlansObj &&
        this.selectedPlansObj.filter(data => data.productId === productId);
      return updateCoverage &&
        updateCoverage.length > 0 &&
        updateCoverage[0].availableInCart
        ? updateCoverage[0].coverage
        : 'ind';
    } else return 'ind';
  }

  coverageChange(data) {
    this.productList.forEach((element, index) => {
      if (element.id === data.id && element.coverage !== data.coverage) {
        this.productList[index] = data;
      }
    });
  }

  // Get benefit data per product
  benefitsData(productName: string, planRiderArray?) {
    if (productName) {
      const productNameKey = productName
        .replace('Insurance', '')
        .trim()
        .replace(' ', '_')
        .toLowerCase();
      const productLookUpKey = 'start_quote_' + productNameKey + '_rider';
      this.benefitData[productName] = this.agentCMSData[productLookUpKey];
      const riderFromCms =
        this.benefitData[productName] && this.benefitData[productName].riders;
      if (riderFromCms && riderFromCms.length) {
        if (planRiderArray && planRiderArray.length) {
          const riderFromPlans = [];
          planRiderArray.forEach(element => {
            const riderMatchFromCms = riderFromCms.filter(
              e =>
                e.riderNameCd === element.riderNameCd ||
                e.title === element.riderNameCd
            )[0];
            const benefits = this.getBenefits(
              productNameKey,
              riderMatchFromCms,
              element
            );
            const riderTempObj = {
              ...benefits,
              price: [element.monthlyPremium],
              benefitAmount: element.benefitAmount,
              riderNameCd: element.riderNameCd,
              description: element.description,
              title: element.title
            };
            riderFromPlans.push(riderTempObj);
          });
          return {
            riderData: riderFromPlans
          };
        } else {
          return {
            riderData: riderFromCms
          };
        }
      }
    }
  }
  getBenefits(productNameKey, riderMatchFromCms, riderMatchFromPlans) {
    if (riderMatchFromCms && riderMatchFromCms.isBenefitPresent) {
      const benefitObj = {};
      if (productNameKey === 'accident') {
        riderMatchFromPlans.benefits.forEach(element => {
          if (
            element.benefit_code ===
            riderMatchFromCms.common_carrier_accident_code
          ) {
            benefitObj['common_carrier_accident'] = element.price.map(item => {
              return {
                beneficiary: item.key,
                price: item.value
              };
            });
          }
          if (element.benefit_code === riderMatchFromCms.other_accident_code) {
            benefitObj['other_accident'] = element.price.map(item => {
              return {
                beneficiary: item.key,
                price: item.value
              };
            });
          }
        });
      } else if (productNameKey === 'cancer') {
        benefitObj['benefit_details'] = riderMatchFromPlans.benefits.map(
          element => {
            return { key: element.title, value: element.price };
          }
        );
      } else if (productNameKey === 'critical_illness') {
        benefitObj['benefit'] = riderMatchFromPlans.benefits.map(element => {
          return {
            ...element,
            benefit_category: element.sub_benefits.map(item => {
              return {
                ...item,
                carrier_flag:
                  item.sub_benefit_code ===
                  riderMatchFromCms.sub_benefit_info_flag
                    ? true
                    : false
              };
            })
          };
        });
      }
      return benefitObj;
    } else return {};
  }
  // Get plan data
  getPlans() {
    this.planSubscription = this.store
      .pipe(select(plans))
      .subscribe(planData => {
        if (planData) {
          this.plans = planData;
          this.getSelectedPlanRiderArray(planData);
        }
      });
  }

  getSelectedPlanRiderArray(planData, productIdOfCurrentPlan?) {
    let riderArray;
    const isArray = Array.isArray(planData);
    let currentPlanInCart;
    let currentProductDetailsFromCart;
    let currentPlanRiders;
    const currentProductId = productIdOfCurrentPlan
      ? productIdOfCurrentPlan
      : this.productId;
    if (this.selectedPlansObj && this.selectedPlansObj.length) {
      this.selectedPlansObj.forEach(item => {
        if (item.productId === currentProductId) {
          currentPlanInCart = item.plan.id;
          currentProductDetailsFromCart = item;
        }
      });
    }
    if (currentPlanInCart) {
      if (isArray && planData.length) {
        planData.forEach(element => {
          currentPlanRiders =
            element.id === currentPlanInCart
              ? element.agentRiders
              : currentPlanRiders;
        });
      }
    }
    if (
      currentProductDetailsFromCart &&
      this.selectedPlansObj &&
      this.selectedPlansObj.length &&
      this.navigationSrc &&
      this.navigationSrc.isNavigatedFromSYP
    ) {
      //update cart
      this.updateCart(
        currentProductDetailsFromCart.productId,
        currentProductDetailsFromCart.productName,
        planData,
        currentProductDetailsFromCart.plan.id,
        currentProductDetailsFromCart.coverage,
        planData.price,
        currentProductDetailsFromCart.tobaccoInd,
        currentProductDetailsFromCart.cancerCoverage,
        currentProductDetailsFromCart.benefitAmount
      );
      this.updatedProductsArray.push(currentProductDetailsFromCart.productId);
      if (this.updatedProductsArray.length === this.selectedPlansObj.length) {
        this.store.dispatch(
          SetNavigationSource({
            payload: { isNavigatedFromSYP: false }
          })
        );
        this.statePlanSubscription.unsubscribe();
      }
    }
    if (isArray) {
      riderArray =
        currentPlanRiders && currentPlanRiders.length
          ? currentPlanRiders
          : planData.length
          ? planData[0].agentRiders
          : undefined;
    } else {
      riderArray =
        planData.agentRiders && planData.agentRiders.length
          ? planData.agentRiders
          : undefined;
    }
    if (!productIdOfCurrentPlan || productIdOfCurrentPlan === this.productId) {
      const ridrTemp = this.benefitsData(this.productName, riderArray);
      this.productBenefitData = ridrTemp && ridrTemp.riderData;
    }
    if (productIdOfCurrentPlan && currentProductDetailsFromCart) {
      const updatedRiderToDispatch =
        currentProductDetailsFromCart.selectedRiders &&
        currentProductDetailsFromCart.selectedRiders.length &&
        riderArray &&
        riderArray.length
          ? this.filterRiders(
              riderArray,
              currentProductDetailsFromCart.selectedRiders
            )
          : undefined;
      if (updatedRiderToDispatch && updatedRiderToDispatch.length) {
        updatedRiderToDispatch.forEach(item => {
          const riderDetails = {
            rider: item.rider,
            productId: item.productId,
            selected: item.selected,
            availableInCart: item.availableInCart
          };
          this.updateRiderInStore(riderDetails);
        });
      }
    }
  }

  filterRiders(riderFromPlan, riderFromCart) {
    const updatedArray = [];
    riderFromCart.forEach(element => {
      const selectedRider = riderFromPlan.filter(
        e =>
          e.riderNameCd === element.rider.riderNameCd ||
          e.riderNameCd === element.rider.title
      );
      if (selectedRider && selectedRider.length) {
        const tempRiderItem = {
          ...element,
          rider: {
            ...element.rider,
            price: selectedRider[0].monthlyPremium,
            benefitAmount: selectedRider[0].benefitAmount,
            riderNameCd: selectedRider[0].riderNameCd
          }
        };
        updatedArray.push(tempRiderItem);
      } else {
        const tempRiderItem = {
          ...element,
          selected: false,
          availableInCart: false
        };
        updatedArray.push(tempRiderItem);
      }
    });
    return updatedArray;
  }

  updateRiderInStore(data) {
    this.store.dispatch(
      updateRiderInfoInCart({
        riderDetails: { key: 'from-list', value: data }
      })
    );
  }

  disablePlans(value) {
    this.isPlanLoaded = false;
    this.isCriticalIllnessPlan = false;
    this.store.dispatch(
      SaveAgentCriticalIllnessPlansAction({ data: undefined })
    );
    this.store.dispatch(initCart());
    this.indexValue === -1 ? (this.indexValue = -2) : (this.indexValue = -1);
    this.cdr.detectChanges();
  }

  refineSearch(selectQuote: StartQuote) {
    const agentInfo = JSON.parse(sessionStorage.getItem('agent-information'));
    this.isPlanLoaded = false;
    this.showShoppingCart = true;
    // Scroll to product area
    this.scrollToProductArea(0);
    let sQouteObj;
    sQouteObj = Object.assign({}, this.agentSelectedQuote);
    if (selectQuote) {
      sQouteObj.stateProvCd = selectQuote.stateProvCd
        ? selectQuote.stateProvCd
        : this.agentSelectedQuote && this.agentSelectedQuote.stateProvCd;
      sQouteObj.state = selectQuote.state;
      sQouteObj.age = selectQuote.age;
      sQouteObj.partnerId = agentInfo.agencyCd;
      this.store.dispatch(agentGetQuote({ agentGetQuote: sQouteObj }));
      this.store.dispatch(initCart());
      this.getAvailableProductsViaService(sQouteObj);
    }
  }

  seePlans(productData: any) {
    this.productBenefitData = undefined;
    this.isCiPlanLoaded = false;
    this.cdr.detectChanges();
    this.showShoppingCart = true;
    this.isPlanLoaded = false;
    if (
      productData &&
      productData.product !== undefined &&
      productData.product !== null
    ) {
      this.productName = productData.product.name;
      this.productId = productData.product.id;
      this.storeSelectedProductsToSession(productData.product);

      const productCoverageDetails = {
        productId: productData.product.id,
        coverageType: productData.coverage
      };
      this.store.dispatch(
        saveCoverageTypeOfSelectedProduct({
          coverageType: productCoverageDetails
        })
      );
      let Obj;
      if (productData.product.id === 'PREC-ICI') {
        const dataFromCart =
          this.selectedPlansObj &&
          this.selectedPlansObj.length &&
          this.selectedPlansObj.filter(
            cartItem => cartItem.productId === productData.product.id
          );
        if (productData.intDiagnosisBenefitAmount) {
          this.intDiagnosisBenefitAmount =
            productData.intDiagnosisBenefitAmount;
        }
        this.intDiagnosisBenefitAmount = this.intDiagnosisBenefitAmount
          ? this.intDiagnosisBenefitAmount
          : dataFromCart && dataFromCart.length
          ? dataFromCart[0].benefitAmount
          : this.intDiagnosisBenefitAmount;
        if (productData.tobaccoInd) {
          this.tobaccoInd = productData.tobaccoInd;
        } else if (
          productData.tobaccoInd === false &&
          productData.tobaccoInd !== undefined
        ) {
          this.tobaccoInd = productData.tobaccoInd;
        } else if (dataFromCart && dataFromCart.length) {
          this.tobaccoInd = dataFromCart[0].tobaccoInd;
        }
        if (productData.cancerCoverage) {
          this.cancerCoverage = productData.cancerCoverage;
        } else if (
          productData.cancerCoverage === false &&
          productData.cancerCoverage !== undefined
        ) {
          this.cancerCoverage = productData.cancerCoverage;
        } else if (dataFromCart && dataFromCart.length) {
          this.cancerCoverage = dataFromCart[0].cancerCoverage;
        }
        this.isCriticalIllnessPlan = true;
        this.cdr.detectChanges();
        if (
          productData.fromCiComponent ||
          this.tobaccoInd !== undefined ||
          this.ssnValidatedState //this.ssnValidatedState should be removed on integration
        ) {
          // from CI box input trigger || edit case
          this.isCiPlanLoaded = true;
        }
        Obj = {
          productId: this.productId,
          stateProvCd: this.agentSelectedQuote.stateProvCd,
          state: this.agentSelectedQuote.state,
          primaryInsuredAge: this.agentSelectedQuote.age,
          coverageTierCd: productData.coverage,
          riders: [], // Riders set to be empty since rider values alter plan monthly permium in response
          agencyId: this.agencyId,
          tobaccoInd: this.tobaccoInd,
          intDiagnosisBenefitAmount: this.intDiagnosisBenefitAmount,
          cancerCoverage: this.cancerCoverage,
          caseId: this.agentSelectedQuote && this.agentSelectedQuote.caseId
        };
      } else {
        this.isCriticalIllnessPlan = false;
        Obj = {
          productId: this.productId,
          stateProvCd: this.agentSelectedQuote.stateProvCd,
          state: this.agentSelectedQuote.state,
          primaryInsuredAge: this.agentSelectedQuote.age,
          coverageTierCd: productData.coverage,
          riders: [],
          agencyId: this.agencyId,
          caseId: this.agentSelectedQuote && this.agentSelectedQuote.caseId
        };
        this.isPlanLoaded = true;
      }
      this.saveCoverageToSession(productData, Obj);
      this.store.dispatch(findPlansAction(Obj));
    }
  }

  saveCoverageToSession(selectedProduct, Obj) {
    const content = { ...Obj };
    content.caseId = this.agentSelectedQuote && this.agentSelectedQuote.caseId;
    if (selectedProduct && selectedProduct.coverage) {
      const sessionData = {
        productId: selectedProduct.product.id,
        coverage: selectedProduct.coverage,
        comparePlanproductdata: content
      };
      sessionStorage.setItem(
        'state-selectedCoverageType',
        JSON.stringify(sessionData)
      );
    }
  }

  updateCart(
    productId,
    productName,
    productPlans,
    packageCd,
    coverageTypeCd,
    productPrice,
    tobaccoInd?,
    cancerCoverage?,
    benefitAmount?
  ) {
    let plan;
    if (productId === 'PREC-ICI') {
      plan = productPlans;
    } else {
      plan = productPlans
        ? productPlans.filter(pl => pl.id === packageCd)[0]
        : '';
    }
    const selectedPlanDetails = {
      productId: productId,
      productName: productName,
      plan: plan,
      coverage: coverageTypeCd,
      selected: true,
      availableInCart: true,
      startingPrice: productPrice,
      tobaccoInd: tobaccoInd,
      cancerCoverage: cancerCoverage,
      benefitAmount: benefitAmount
    };
    this.store.dispatch(
      addItemToCart({
        selectedPlan: { key: 'from-list', value: selectedPlanDetails }
      })
    );
  }

  updateCartRider(productName, productId, riders, planRiderArray?) {
    const riderTemp = this.benefitsData(productName, planRiderArray);
    let defaultRiderData = riderTemp && riderTemp.riderData;
    const ids = riders.map(item => item.riderNameCd);
    if (defaultRiderData) {
      defaultRiderData = defaultRiderData.filter(riData => {
        return (
          ids.indexOf(riData.riderNameCd) !== -1 ||
          ids.indexOf(riData.title) !== -1
        );
      });
      defaultRiderData.forEach(rdData => {
        const cartObj = Object.assign({}, rdData);
        cartObj.price = Array.isArray(rdData.price)
          ? isNaN(rdData.price[0])
            ? Number(rdData.price[0].replace('$', '').replace(/,/g, ''))
            : rdData.price[0]
          : rdData.price[0];

        const riderDetails = {
          rider: cartObj,
          productId: productId,
          selected: true,
          availableInCart: true
        };
        this.updateRiderInStore(riderDetails);
      });
    }
  }
  RetrieveCartData() {
    this.retrieveCartDataSub = this.store
      .select(RetrieveCartData)
      .subscribe(data => {
        if (data && (!this.editQuoteStatus || !this.editQuoteStatus.edited)) {
          const planData = data;
          let productFilteredArray = [];

          if (this.productList && this.productList.length > 0) {
            productFilteredArray = this.productList.filter(
              el => el.id === planData.productCode
            );
          }
          if (productFilteredArray && productFilteredArray.length > 0) {
            const productName = productFilteredArray[0].name;
            const productPrice = productFilteredArray[0].starting_price;
            const initialDiagnosisAmount =
              planData.initialDiagnosisAmount &&
              planData.initialDiagnosisAmount.value;
            if (planData.productCode === 'PREC-ICI') {
              if (
                planData.packageCd === 'plan04' ||
                planData.packageCd === 'CIwCancer'
              ) {
                this.cancerCoverage = true;
              } else if (
                planData.packageCd === 'plan05' ||
                planData.packageCd === 'CIwoCancer'
              ) {
                this.cancerCoverage = false;
              }
              if (planData.tobaccoUseInd !== undefined) {
                this.tobaccoInd = planData.tobaccoUseInd;
              }
              this.intDiagnosisBenefitAmount = initialDiagnosisAmount;
              this.isCiPlanLoaded = true;
            }
            const cancerCoverage =
              planData.productCode === 'PREC-ICI' && this.cancerCoverage;
            // Update cart
            this.updateCart(
              planData.productCode,
              productName,
              planData.plans,
              planData.packageCd,
              planData.coverageTypeCd,
              productPrice,
              planData.tobaccoUseInd,
              cancerCoverage,
              initialDiagnosisAmount
            );
            // Update riders
            if (planData.riders && planData.riders.length > 0) {
              let planRiders;
              if (planData.productCode === 'PREC-ICI') {
                planRiders = planData.plans.agentRiders;
              } else {
                const plan = planData.plans
                  ? planData.plans.filter(pl => pl.id === planData.packageCd)
                  : [];
                planRiders = plan && plan.length ? plan[0].agentRiders : [];
              }
              this.updateCartRider(
                productName,
                planData.productCode,
                planData.riders,
                planRiders
              );
            }
          }
        }
      });
  }
  prepopulateCart() {
    if (
      this.retrievedQuoteData &&
      this.retrievedQuoteData.length > 0 &&
      !this.editQuoteStatus &&
      !this.ssnValidatedState
    ) {
      const cartObj = {
        retrieveQuoteData: this.retrievedQuoteData,
        searchQuoteObj: this.agentSelectedQuote,
        agencyId: this.agencyId
      };
      if (
        !this.prevBundleId ||
        this.prevBundleId !== this.retrievedQuoteData[0].bundleId
      ) {
        this.prevBundleId = this.retrievedQuoteData[0].bundleId;

        this.store.dispatch(populateRetrieveCart({ payload: cartObj }));
      }
    }
  }

  seePlanDetails() {
    const selectedProduct = this.getSessionSelectedProductData();
    const productId = this.productId
      ? this.productId
      : selectedProduct && selectedProduct.id;
    this.router.navigateByUrl(`quotes/compare/${productId}`);
  }

  scrollToPosition(e, offset) {
    window.scroll({
      behavior: 'smooth',
      left: 0,
      top: e.offsetTop + offset
    });
  }

  closePlans() {
    this.isPlanLoaded = false;
    this.isCiPlanLoaded = false;
    this.isCriticalIllnessPlan = false;
    this.indexValue === -1 ? (this.indexValue = -2) : (this.indexValue = -1);
  }

  getSelectedPlans() {
    this.cartSubscription = this.store.select(selectedPlans).subscribe(res => {
      this.selectedPlansObj = res.value;
      if (res === undefined || res.value === undefined) {
        this.isCartEmpty = true;
      } else {
        let checkval = true;
        res.value.forEach(element => {
          checkval = element.selected === true ? false : checkval;
        });
        this.isCartEmpty = checkval;
      }
    });
  }

  navigateToSaveQuote() {
    this.filterCartWithSelectedQuotes();
    if (this.agentStateMode) {
      this.router.navigateByUrl('quotes/save-your-progress');
    } else {
      this.decideNavigation(this.selectedPlansObj);
    }
    // Remove buyflow session
    this.quoteStore.dispatch(resetBuyFlowElements());
    sessionStorage.removeItem('state-agent-buy-flow-elements');
    sessionStorage.removeItem('state-agent-user-details');
    this.quoteStore.dispatch(saveUserDetails({ userDetails: undefined }));
  }
  navigateToHome() {
    this.isProductLoaded = false;
    this.router.navigateByUrl('home');
  }

  filterCartWithSelectedQuotes() {
    let currentQuote = [];
    const filteredQuote = [];
    if (this.selectedPlansObj && this.selectedPlansObj.length > 0) {
      currentQuote = this.selectedPlansObj.filter(item => item.selected);
      currentQuote.forEach(quote => {
        const filterItem = {
          productId: quote.productId,
          productName: quote.productName,
          plan: quote.plan,
          availableInCart: quote.availableInCart,
          selected: quote.selected,
          coverage: quote.coverage,
          startingPrice: quote.startingPrice,
          selectedRiders: quote.selectedRiders
            ? quote.selectedRiders.filter(rider => rider.selected)
            : [],
          tobaccoInd: quote.tobaccoInd,
          cancerCoverage: quote.cancerCoverage,
          benefitAmount: quote.benefitAmount
        };
        filteredQuote.push(filterItem);
      });
    }
    const payload = { key: 'from-list', value: filteredQuote };
    this.store.dispatch(UpdateCartOnQuoteSave({ payload }));
    // Keep cart in session
    this.storeToSession('cartDetails', filteredQuote);
  }

  decideNavigation(selPlans) {
    let navigationTarget = 'eligibility';
    selPlans.map(item => {
      if (item.coverage !== 'ind' && item.selected) {
        navigationTarget = 'dependents';
      }
    });
    this.router.navigateByUrl(`${navigationTarget}`);
  }

  changeToEditMode() {
    const editMode = {
      edited: true,
      initialCartState: this.selectedPlansObj
    };
    this.cloneExistingQuote();
    this.store.dispatch(agentGetQuoteStateAction({ payload: true }));
    this.editActionTrigger(editMode);
    sessionStorage.setItem('state-retrieveQuote', '');
    window.scroll(0, 0);
  }

  /* Update edit state once edit quote clicked */
  editActionTrigger(editMode) {
    this.quoteStore.dispatch(agentEditedQuoteAction({ payload: editMode }));
    this.storeEditQuoteInSession(editMode);
  }
  // Save data from store to session storage
  public storeSelectedProductsToSession(product) {
    this.store.dispatch(selectProduct({ selectedProduct: product }));
    sessionStorage.setItem('state-selectedProduct', JSON.stringify(product));
  }

  cloneExistingQuote() {
    const agentInfo = JSON.parse(sessionStorage.getItem('agent-information'));
    const quoteDetails =
      this.retrievedQuoteData && this.retrievedQuoteData.length > 0
        ? this.retrievedQuoteData[0]
        : undefined;
    const payload = {
      customerNumber: quoteDetails && quoteDetails.customerNumber,
      bundleId: quoteDetails && quoteDetails.bundleId,
      producerCd: agentInfo && agentInfo.agencyCd,
      subProducerCd: agentInfo && agentInfo.subProducerCd,
      submissionDate: new Date().toISOString(),
      caseId: quoteDetails && quoteDetails.caseId,
      sfrId: quoteDetails && quoteDetails.sfrId
    };
    this.quoteStore.dispatch(retrieveBundleCloneAction({ payload }));
  }

  setBundleIdToSession() {
    if (this.getSessionRetrieveQuoteData()) {
      const data = this.getSessionRetrieveQuoteData();
      sessionStorage.setItem(
        'state-agent-bundleId',
        JSON.stringify(data[0].bundleId)
      );
    }
  }

  // Save data from store to session storage
  public storeToSession(statename: string, stateData) {
    switch (statename) {
      case 'productDetails': {
        sessionStorage.setItem(
          'state-agent-product-details',
          JSON.stringify(stateData)
        );
        break;
      }
      case 'cartDetails': {
        sessionStorage.setItem(
          'state-agent-cart-details',
          JSON.stringify(stateData)
        );
        break;
      }
      default: {
        break;
      }
    }
  }

  getTodayDate() {
    let today: any = new Date();
    const dd = String(today.getDate()).padStart(2, '0');
    const mm = String(today.getMonth() + 1).padStart(2, '0');
    const yyyy = today.getFullYear();

    today = yyyy + '-' + mm + '-' + dd;
    return today;
  }
  ngOnDestroy() {
    this.cmsSubscription.unsubscribe();
    this.subscription.unsubscribe();
    this.productSubscription.unsubscribe();
    this.retrieveQuoteSubscription.unsubscribe();
    this.editquoteSubscription.unsubscribe();
    this.cartSubscription.unsubscribe();
    this.planSubscription.unsubscribe();
    this.agentDetails$.unsubscribe();
    this.planChangeSub.unsubscribe();
    if (this.ssnSub !== undefined) this.ssnSub.unsubscribe();
    if (this.retrieveCartDataSub) this.retrieveCartDataSub.unsubscribe();
  }
}
