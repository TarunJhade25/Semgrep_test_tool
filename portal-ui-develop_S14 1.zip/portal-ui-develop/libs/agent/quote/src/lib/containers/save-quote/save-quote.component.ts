import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'aflac-save-quote',
  templateUrl: './save-quote.component.html',
  styleUrls: ['./save-quote.component.scss']
})
export class SaveQuoteComponent implements OnInit {
  constructor() {}

  ngOnInit() {}
}
