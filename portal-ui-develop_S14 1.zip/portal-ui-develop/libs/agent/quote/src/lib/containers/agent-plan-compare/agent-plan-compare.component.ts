import { Component, OnInit, OnDestroy } from '@angular/core';
import { PageNavigationService } from '@aflac/agent/shared';
import { Subscription } from 'rxjs';
import { ProductState, selectedPlans } from '@aflac/agent/shared';
import { Store } from '@ngrx/store';
import { ActivatedRoute, Router } from '@angular/router';
import { SuccessGetComparisonProductPlan } from '@aflac/shared/product';

@Component({
  selector: 'aflac-agent-plan-compare',
  templateUrl: './agent-plan-compare.component.html',
  styleUrls: ['./agent-plan-compare.component.scss']
})
export class AgentPlanCompareComponent implements OnInit, OnDestroy {
  public portalInfo: any;
  public stateSearchQuote: any;
  public subscription = new Subscription();
  public urlParams: any;
  public coverageValue: any;
  public hideTheWindow = false;
  constructor(
    public navigationService: PageNavigationService,
    private activatedRoute: ActivatedRoute,
    private store: Store<ProductState>,
    private router: Router
  ) {}

  ngOnInit() {
    this.portalInfo = { portal: 'agent' };
    this.coverageData();
    this.hideTheWindow = false;
    this.setStateSearchQuoteData();
    setTimeout(() => {
      window.scrollTo(0, 0);
    }, 100);
    this.store.dispatch(
      SuccessGetComparisonProductPlan({ payload: undefined })
    );
  }
  coverageData() {
    const coverageType = JSON.parse(
      sessionStorage.getItem('state-selectedCoverageType')
    );
    this.coverageValue = coverageType.coverage;
    this.portalInfo.comparePlanproductdata =
      coverageType.comparePlanproductdata;
    //get plans from service and store
    this.activatedRoute.queryParams.subscribe(data => {
      this.urlParams = this.activatedRoute.snapshot.params;
    });
    this.subscription = this.store.select(selectedPlans).subscribe(res => {
      if (res && res.value) {
        res.value.forEach(data => {
          if (this.urlParams.productId === data.productId)
            this.coverageValue = data.coverage;
        });
      }
    });
  }
  setStateSearchQuoteData() {
    const searchQuote = JSON.parse(
      sessionStorage.getItem('agent-state-searchQuote')
    );
    const stateSearchQuote = {
      coverage: this.coverageValue,
      stateProvCd: searchQuote.stateProvCd,
      state: searchQuote.state,
      age: searchQuote.age
    };
    //Seting the Data for compare Plan
    sessionStorage.setItem(
      'state-searchQuote',
      JSON.stringify(stateSearchQuote)
    );
  }
  navigateBack() {
    this.hideTheWindow = true;
    setTimeout(() => {
      this.router.navigateByUrl('quotes');
    });
  }
  ngOnDestroy() {
    this.subscription.unsubscribe();
  }
}
