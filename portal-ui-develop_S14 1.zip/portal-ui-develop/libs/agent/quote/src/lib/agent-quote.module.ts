import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { EffectsModule } from '@ngrx/effects';
import { StoreModule } from '@ngrx/store';
import { SelectProductEffects } from '@aflac/agent/shared';
import { GetRetrieveQuoteEffects } from '@aflac/agent/landing';
import { SharedCmsModule } from '@aflac/shared/cms';
import { SharedUiModule } from '@aflac/shared/ui';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatAutocompleteModule } from '@angular/material/autocomplete';
import { MatFormFieldModule } from '@angular/material/form-field';
import { SharedMaterialModule } from '@aflac/shared/material';
import { SharedvalidatorsModule } from '@aflac/shared/validators';
import { DeviceCheckerService } from '@aflac/shared/ui';
import * as fromAgentSearchQuote from '@aflac/agent/shared';
import * as fromProduct from '@aflac/agent/shared';
import * as fromProductSales from '@aflac/shared/product';
import * as fromHome from '@aflac/agent/landing';
import { SalesProductModule } from '@aflac/shared/product';
import { StartQuoteComponent } from './containers/start-quote/start-quote.component';
import { SearchQuoteComponent } from './components/search-quote/search-quote.component';
import { ProductListComponent } from './components/product-list/product-list.component';
import { PlanListComponent } from './components/plan-list/plan-list.component';
import { ProductNotFoundComponent } from './components/product-not-found/product-not-found.component';
import { AgentCardComponent } from './components/agent-card/agent-card.component';
import { ProductRiderComponent } from './components/product-rider/product-rider.component';
import { AgentPlanCompareComponent } from './containers/agent-plan-compare/agent-plan-compare.component';
import { AflacInfoModalComponent } from './components/info-modal/info-modal.component';
import { PerfectScrollbarModule } from 'ngx-perfect-scrollbar';
import { AgentShoppingCartComponent } from './components/agent-shopping-cart/agent-shopping-cart.component';
import { SharedPipesModule } from '@aflac/shared/pipes';
import { AgentSharedModule } from '@aflac/agent/shared';
import { SaveQuoteComponent } from './containers/save-quote/save-quote.component';
import { SaveYourProgressComponent } from './components/save-your-progress/save-your-progress.component';
import { SaveConsentModalComponent } from './components/save-consent-modal/save-consent-modal.component';
import { ExistingCustomerSearchResultModalComponent } from './components/existing-customer-search-result-modal/existing-customer-search-result-modal.component';
import * as fromSaveYourQuote from '@aflac/agent/shared';
import { SaveYourQuoteEffects } from '@aflac/agent/shared';
import { ProductEligibilityModalComponent } from './components/product-eligibility-modal/product-eligibility-modal.component';
import { CriticalIllnessPlanComponent } from './components/critical-illness-plan/critical-illness-plan.component';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    MatAutocompleteModule,
    MatFormFieldModule,
    SharedMaterialModule,
    SharedUiModule,
    SharedCmsModule,
    SharedvalidatorsModule,
    SharedPipesModule,
    SalesProductModule,
    PerfectScrollbarModule,
    AgentSharedModule,
    StoreModule.forFeature(
      fromSaveYourQuote.saveYourQuoteFeatureKey,
      fromSaveYourQuote.saveYourQuoteReducer
    ),
    EffectsModule.forFeature([SaveYourQuoteEffects]),
    StoreModule.forFeature(fromHome.homeFeatureKey, fromHome.homeReducer),
    EffectsModule.forFeature([GetRetrieveQuoteEffects]),
    StoreModule.forFeature(
      fromAgentSearchQuote.agentSearchQuoteFeatureKey,
      fromAgentSearchQuote.agentSearchQuoteReducer
    ),
    StoreModule.forFeature(
      fromProduct.ProductFeatureKey,
      fromProduct.ProductReducer
    ),
    StoreModule.forFeature(
      fromProductSales.ProductFeatureKey,
      fromProductSales.ProductReducer
    ),
    EffectsModule.forFeature([SelectProductEffects]),
    RouterModule.forChild([
      {
        path: '',
        pathMatch: 'full',
        component: StartQuoteComponent
      },
      {
        path: 'compare/:productId',
        component: AgentPlanCompareComponent,
        data: { showBreadcrumb: true, pageType: 'comparePlan' }
      },
      {
        path: 'save-your-progress',
        component: SaveQuoteComponent
      }
    ])
  ],
  declarations: [
    StartQuoteComponent,
    ProductListComponent,
    SearchQuoteComponent,
    PlanListComponent,
    ProductNotFoundComponent,
    AgentCardComponent,
    ProductRiderComponent,
    AgentPlanCompareComponent,
    AflacInfoModalComponent,
    AgentShoppingCartComponent,
    SaveQuoteComponent,
    SaveYourProgressComponent,
    SaveConsentModalComponent,
    ExistingCustomerSearchResultModalComponent,
    ProductEligibilityModalComponent,
    CriticalIllnessPlanComponent
  ],
  providers: [DeviceCheckerService],
  entryComponents: [
    AflacInfoModalComponent,
    SaveConsentModalComponent,
    ExistingCustomerSearchResultModalComponent,
    ProductEligibilityModalComponent
  ]
})
export class AgentQuoteModule {}
