import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { EffectsModule } from '@ngrx/effects';
import { StoreModule } from '@ngrx/store';
import { SharedCmsModule } from '@aflac/shared/cms';
import { SharedUiModule } from '@aflac/shared/ui';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { SharedMaterialModule } from '@aflac/shared/material';
import { SharedvalidatorsModule } from '@aflac/shared/validators';
import { NgxMaskModule } from 'ngx-mask';
import { formatDate } from '@angular/common';
import * as fromSaveYourQuote from '@aflac/agent/shared';
import { SaveYourQuoteEffects } from '@aflac/agent/shared';
import * as fromProduct from '@aflac/agent/shared';
import { SelectProductEffects } from '@aflac/agent/shared';
import * as fromAgentSearchQuote from '@aflac/agent/shared';
import * as fromHome from '@aflac/agent/landing';
import { GetRetrieveQuoteEffects } from '@aflac/agent/landing';

import { BuyFlowHomeComponent } from './containers/buy-flow-home/buy-flow-home.component';
import { QuoteReviewComponent } from './components/quote-review/quote-review.component';
import { EligibilityComponent } from './components/eligibility/eligibility.component';
import { UwrReactComponentWrapper } from './components/uwr-react-component/UwrReactComponentWrapper';
import { DependentsComponent } from './components/dependents/dependents.component';
import { DependentCardComponent } from './components/dependents/dependent-card/dependent-card.component';
import { AddEditDependentComponent } from './components/dependents/add-edit-dependent/add-edit-dependent.component';
import { PersonalDetailsComponent } from './components/personal-details/personal-details.component';
import { PersonalDetailsMyInfoComponent } from './components/personal-details/personal-details-my-info/personal-details-my-info.component';
import { PersonalDetailsHomeAddressComponent } from './components/personal-details/personal-details-home-address/personal-details-home-address.component';
import { PersonalDetailsContactInfoComponent } from './components/personal-details/personal-details-contact-info/personal-details-contact-info.component';
import { SsnValidationCustomerListModalComponent } from './components/personal-details/personal-details-modal/ssn-validation/ssn-validation-customer-list-modal/ssn-validation-customer-list-modal.component';
import { SsnValidationCoverageEligibilityModalComponent } from './components/personal-details/personal-details-modal/ssn-validation/ssn-validation-coverage-eligibility-modal/ssn-validation-coverage-eligibility-modal.component';
import { SsnValidationCoverageChangeModalComponent } from './components/personal-details/personal-details-modal/ssn-validation/ssn-validation-coverage-change-modal/ssn-validation-coverage-change-modal.component';
import { HomeAddressModelComponent } from './components/personal-details/personal-details-modal/home-address-model/home-address-model.component';
import { AgeChangeInPremiumComponent } from './components/personal-details/personal-details-modal/age-validation-modal/age-change-in-premium/age-change-in-premium.component';
import { AgeNotEligibleForProductComponent } from './components/personal-details/personal-details-modal/age-validation-modal/age-not-eligible-for-product/age-not-eligible-for-product.component';
import { OrderReviewComponent } from './components/order-review/order-review.component';
import { CheckoutComponent } from './components/checkout/checkout.component';
import { PaymentCheckoutComponent } from './components/payment-checkout/payment-checkout.component';
import { PaymentMethodActionListComponent } from './components/payment-checkout/payment-method-action-list/payment-method-action-list.component';
import { PaymentMethodActionComponent } from './components/payment-checkout/payment-method-action/payment-method-action.component';
import { PaymentCardDetailsComponent } from './components/payment-checkout/payment-card-details/payment-card-details.component';
import {
  PerfectScrollbarModule,
  PerfectScrollbarConfigInterface,
  PERFECT_SCROLLBAR_CONFIG
} from 'ngx-perfect-scrollbar';
import { SsnInfoModalComponent } from './components/personal-details/personal-details-modal/ssn-info-modal/ssn-info-modal.component';
import { DependentIneligibilityModalComponent } from './components/dependent-ineligibility-modal/dependent-ineligibility-modal.component';
import { AgentOrderReviewEffectiveDateComponent } from './components/order-review/agent-order-review-effective-date/agent-order-review-effective-date.component';
import { AgentOrderReviewFreeLookupPeriodComponent } from './components/order-review/agent-order-review-free-lookup-period/agent-order-review-free-lookup-period.component';
import {
  NativeDateAdapter,
  DateAdapter,
  MAT_DATE_FORMATS
} from '@angular/material';

import { AgentSharedModule } from '@aflac/agent/shared';
import { CheckoutMethodComponent } from './components/checkout/checkout-method/checkout-method.component';
import { CheckoutSignaturesComponent } from './components/checkout/checkout-signatures/checkout-signatures.component';
import { VoiceSignatureComponent } from './components/checkout/checkout-signatures/voice-signature/voice-signature.component';
import { ESignatureComponent } from './components/checkout/checkout-signatures/e-signature/e-signature.component';
import { StatementPolicyDocsComponent } from './components/checkout/checkout-signatures/statement-policy-docs/statement-policy-docs.component';
import { CheckoutSuccessComponent } from './components/checkout/checkout-success/checkout-success.component';
import { CheckoutEmailSuccessComponent } from './components/checkout/checkout-email-success/checkout-email-success.component';
import { ConsentModalComponent } from './components/dependents/consent-modal/consent-modal.component';
const DEFAULT_PERFECT_SCROLLBAR_CONFIG: PerfectScrollbarConfigInterface = {
  wheelPropagation: true
};
const CUSTOM_DATE_FORMATS = {
  parse: { dateInput: 'input' },
  display: {
    dateInput: 'input',
    monthYearLabel: 'MMM YYYY',
    dateA11yLabel: 'LL',
    monthYearA11yLabel: 'MMMM YYYY'
  }
};
export class PickDateAdapter extends NativeDateAdapter {
  format(date: Date, displayFormat: Object): string {
    if (displayFormat === 'input') {
      return formatDate(date, 'MM/dd/yyyy', this.locale);
    } else {
      return date.toDateString();
    }
  }
}

@NgModule({
  imports: [
    CommonModule,
    SharedCmsModule,
    SharedUiModule,
    SharedMaterialModule,
    SharedvalidatorsModule,
    NgxMaskModule,
    FormsModule,
    ReactiveFormsModule,
    AgentSharedModule,
    StoreModule.forFeature(
      fromSaveYourQuote.saveYourQuoteFeatureKey,
      fromSaveYourQuote.saveYourQuoteReducer
    ),
    EffectsModule.forFeature([SaveYourQuoteEffects]),
    StoreModule.forFeature(
      fromProduct.ProductFeatureKey,
      fromProduct.ProductReducer
    ),
    EffectsModule.forFeature([SelectProductEffects]),
    StoreModule.forFeature(
      fromAgentSearchQuote.agentSearchQuoteFeatureKey,
      fromAgentSearchQuote.agentSearchQuoteReducer
    ),
    StoreModule.forFeature(fromHome.homeFeatureKey, fromHome.homeReducer),
    EffectsModule.forFeature([GetRetrieveQuoteEffects]),
    RouterModule.forChild([
      {
        path: 'buy-flow',
        component: BuyFlowHomeComponent
      }
    ]),
    PerfectScrollbarModule
  ],
  providers: [
    {
      provide: PERFECT_SCROLLBAR_CONFIG,
      useValue: DEFAULT_PERFECT_SCROLLBAR_CONFIG
    },
    { provide: DateAdapter, useClass: PickDateAdapter },
    { provide: MAT_DATE_FORMATS, useValue: CUSTOM_DATE_FORMATS }
  ],
  declarations: [
    BuyFlowHomeComponent,
    QuoteReviewComponent,
    EligibilityComponent,
    DependentsComponent,
    DependentCardComponent,
    AddEditDependentComponent,
    PersonalDetailsComponent,
    PersonalDetailsMyInfoComponent,
    PersonalDetailsHomeAddressComponent,
    PersonalDetailsContactInfoComponent,
    SsnValidationCustomerListModalComponent,
    SsnValidationCoverageEligibilityModalComponent,
    SsnValidationCoverageChangeModalComponent,
    HomeAddressModelComponent,
    AgeChangeInPremiumComponent,
    AgeNotEligibleForProductComponent,
    OrderReviewComponent,
    CheckoutComponent,
    PaymentCheckoutComponent,
    PaymentMethodActionListComponent,
    PaymentMethodActionComponent,
    PaymentCardDetailsComponent,
    SsnInfoModalComponent,
    DependentIneligibilityModalComponent,
    AgentOrderReviewEffectiveDateComponent,
    AgentOrderReviewFreeLookupPeriodComponent,
    CheckoutMethodComponent,
    CheckoutSignaturesComponent,
    VoiceSignatureComponent,
    ESignatureComponent,
    StatementPolicyDocsComponent,
    CheckoutSuccessComponent,
    CheckoutEmailSuccessComponent,
    ConsentModalComponent,
    UwrReactComponentWrapper
  ],
  entryComponents: [
    SsnValidationCustomerListModalComponent,
    SsnValidationCoverageEligibilityModalComponent,
    SsnValidationCoverageChangeModalComponent,
    HomeAddressModelComponent,
    AgeChangeInPremiumComponent,
    AgeNotEligibleForProductComponent,
    SsnInfoModalComponent,
    DependentIneligibilityModalComponent,
    CheckoutEmailSuccessComponent,
    ConsentModalComponent
  ]
})
export class AgentBuyFlowModule {}
