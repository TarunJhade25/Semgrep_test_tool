import { TestBed } from '@angular/core/testing';
import { TranslateModule } from '@ngx-translate/core';
import { RouterTestingModule } from '@angular/router/testing';
import { FormBuilder } from '@angular/forms';
import { DependentService } from './dependent.service';
import { Store, StoreModule } from '@ngrx/store';
import { MockStore, provideMockStore } from '@ngrx/store/testing';
import { saveYourQuoteReducer } from '@aflac/agent/shared';
import { buyFlowElementsSelector } from '@aflac/agent/shared'; // Selectors

describe('DependentService', () => {
  let mockStore: MockStore<any>;
  const formBuilder: FormBuilder = new FormBuilder();
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [
        StoreModule.forRoot(saveYourQuoteReducer),
        TranslateModule.forRoot(),
        RouterTestingModule
      ],
      providers: [
        provideMockStore({}),
        { provide: FormBuilder, useValue: formBuilder }
      ]
    });
    mockStore = TestBed.get(Store);
  });

  it('should be created', () => {
    const service: DependentService = TestBed.get(DependentService);
    expect(service).toBeTruthy();
  });

  it('should return formatted date', () => {
    const service: DependentService = TestBed.get(DependentService);
    const date = '2-2-2000';
    const returnDate = service.convertDateFormat(date);
    expect(returnDate).toBe('02/02/2000');
  });

  it('should fetch getDependentData', () => {
    const service: DependentService = TestBed.get(DependentService);
    service.getDependentData('/dependents');
    expect(service.getDependentData).toBeDefined();
  });

  it('should set setPersonalData', () => {
    const service: DependentService = TestBed.get(DependentService);
    service.setPersonalData('111111');
    expect(service.setPersonalData).toBeDefined();
  });

  it('should set setDependentRelationshipData', () => {
    const service: DependentService = TestBed.get(DependentService);
    service.setDependentRelationshipData('111111');
    expect(service.setDependentRelationshipData).toBeDefined();
  });

  it('should call getRandomId', () => {
    const service: DependentService = TestBed.get(DependentService);
    service.getRandomId();
    expect(service.getRandomId).toBeDefined();
  });

  it('should fetch getDependentRelationshipData', () => {
    const service: DependentService = TestBed.get(DependentService);
    service.getDependentRelationshipData();
    expect(service.getDependentRelationshipData).toBeDefined();
  });

  it('should call getDependentForm for spouse', () => {
    const service: DependentService = TestBed.get(DependentService);
    const params = {
      dependentData: {
        'PREC-IC': {
          spouse: {
            firstName: 'Ryan',
            lastName: 'John',
            dateOfBirth: '01/01/1990',
            gender: 'M',
            editMode: false
          },
          children: [
            {
              firstName: 'Joan',
              lastName: 'Keit',
              dateOfBirth: '01/01/1990',
              gender: '',
              editMode: false
            }
          ]
        },
        'PREC-IA': {
          spouse: {
            firstName: 'Ryan',
            lastName: 'John',
            dateOfBirth: '01/01/1990',
            gender: 'M',
            editMode: false
          },
          children: [
            {
              firstName: 'Joan',
              lastName: 'Keit',
              dateOfBirth: '01/01/1990',
              gender: '',
              editMode: false
            }
          ]
        }
      },
      route: '/dependents',
      parentIndex: 'PREC-IC',
      type: 'spouse'
    };
    service.getDependentForm(params, true);
    expect(service.getDependentForm).toBeDefined();
  });

  it('should call getDependentForm for child', () => {
    const service: DependentService = TestBed.get(DependentService);
    const params = {
      dependentData: {
        'PREC-IA': {
          children: [
            {
              firstName: 'Joan',
              lastName: 'Keit',
              dateOfBirth: '01/01/1990',
              gender: '',
              editMode: false
            }
          ]
        }
      },
      index: 0,
      parentContainerIndex: 0,
      parentIndex: 'PREC-IA',
      route: '/dependents',
      type: 'child'
    };
    service.getDependentForm(params, true);
    expect(service.getDependentForm).toBeDefined();
  });

  it('should call setDependentData', () => {
    const service: DependentService = TestBed.get(DependentService);
    const formValue = {
      addedDate: 1602162390321,
      dateOfBirth: '09/09/2000',
      editMode: false,
      firstName: 'John',
      gender: 'male',
      lastName: 'Sal',
      oid: '41vi6m',
      relationshipToPrimaryInsuredCd: '1',
      selected: true
    };
    const params = {
      dependentData: {},
      parentIndex: 'PREC-IA',
      route: 'dependents',
      type: 'spouse'
    };
    const buyStepsC = [
      {
        route: 'dependents',
        link: 'dependents',
        data: {
          'PREC-IA': {
            spouse: {
              firstName: 'Ryan',
              lastName: 'John',
              dateOfBirth: '01/01/1990',
              gender: 'M',
              editMode: false
            },
            children: [
              {
                firstName: 'Joan',
                lastName: 'Keit',
                dateOfBirth: '01/01/1990',
                gender: '',
                editMode: false
              }
            ]
          }
        }
      }
    ];
    mockStore.overrideSelector(buyFlowElementsSelector, buyStepsC);
    service.setDependentData(formValue, params);
    expect(service.setDependentData).toBeDefined();
  });

  it('should return false', () => {
    const service: DependentService = TestBed.get(DependentService);
    const param = {
      dependentData: {},
      type: 'child'
    };
    const dependentForm = {
      valid: false
    };
    const result = service.submitDependent(dependentForm, param);
    expect(result).toBeFalsy();
  });
  /*
  it('should submit spouse form ', () => {
    const service: DependentService = TestBed.get(DependentService);
    const param = {
      dependentData: {},
      parentIndex: 'PREC-IA',
      route: '/dependents',
      type: 'spouse'
    };
    const dependentForm = {
      valid: true,
      value: {
        dateOfBirth: '01/01/1990',
        firstName: 'Ann',
        gender: 'female',
        lastName: 'philip',
        oid: 'o2d6u8',
        selected: true
      }
    };
    service.submitDependent(dependentForm, param);
    expect(service.submitDependent).toBeDefined();
  });
  
  it('should submit child form ', () => {
    const service: DependentService = TestBed.get(DependentService);
    const param = {
      dependentData: {},
      parentIndex: 'PREC-IA',
      route: '/dependents',
      type: 'child'
    };
    const dependentForm = {
      valid: true,
      value: {
        dateOfBirth: '01/01/1990',
        firstName: 'Ann',
        gender: 'female',
        lastName: 'philip',
        oid: 'o2d6u8',
        selected: true
      }
    };
    service.submitDependent(dependentForm, param);
    expect(service.submitDependent).toBeDefined();
  });
*/
  it('should call deleteChildByIndex', () => {
    const service: DependentService = TestBed.get(DependentService);
    const params = {
      dependentData: {
        'PREC-IA': {
          spouse: {
            firstName: 'Ryan',
            lastName: 'John',
            dateOfBirth: '01/01/1990',
            gender: 'M',
            editMode: false
          },
          children: [
            {
              firstName: 'Joan',
              lastName: 'Keit',
              dateOfBirth: '01/01/1990',
              gender: '',
              editMode: false
            }
          ]
        }
      },
      index: 0,
      parentIndex: 'PREC-IA',
      route: '/dependents',
      type: 'child'
    };
    const buyStepsC = [
      {
        route: 'dependents',
        link: '/dependents',
        data: {
          'PREC-IA': {
            spouse: {
              firstName: 'Ryan',
              lastName: 'John',
              dateOfBirth: '01/01/1990',
              gender: 'M',
              editMode: false
            },
            children: [
              {
                firstName: 'Joan',
                lastName: 'Keit',
                dateOfBirth: '01/01/1990',
                gender: '',
                editMode: false
              }
            ]
          }
        }
      }
    ];
    mockStore.overrideSelector(buyFlowElementsSelector, buyStepsC);
    service.deleteChildByIndex(params, true);
    expect(service.deleteChildByIndex).toBeDefined();
  });

  it('should call getSaveDependentParams', () => {
    const service: DependentService = TestBed.get(DependentService);
    const dependents = { spouse: {}, child: {} };
    const formValue = { firstName: 'John', lastName: 'Smith' };
    service.getSaveDependentParams(dependents, formValue);
    expect(service.getSaveDependentParams).toBeDefined();
  });

  it('should call addUserDependentData', () => {
    const service: DependentService = TestBed.get(DependentService);
    const dependents = { spouse: {}, child: {} };
    const route = '/dependents';
    const cartData = [
      {
        productId: 'PREC-IA',
        productName: 'Accident',
        plan: {
          id: 123,
          price: '100',
          description: 'These are the benefits',
          name: 'Lorem ipsum',
          states: ['AL', 'CT'],
          title: 'Standard Plan',
          benefits: [
            {
              id: 333,
              name: 'test',
              price: 123
            }
          ]
        },
        coverage: 'ind',
        selected: true,
        availableInCart: true,
        selectedRiders: [
          {
            rider: { title: 'title1', price: '100' },
            selected: true,
            availableInCart: true,
            plan: { id: 'id1' }
          },
          {
            rider: { title: 'title2', price: '200' },
            selected: true,
            availableInCart: true,
            plan: { id: 'id1' }
          }
        ]
      }
    ];
    const coverageArray = ['ind_fml'];
    const depRelationshipTypes = ['SPOUSE', 'CHILD'];
    const buyStepsC = [
      {
        route: 'dependents',
        link: '/dependents',
        data: {
          'PREC-IA': {
            spouse: {
              firstName: 'Ryan',
              lastName: 'John',
              dateOfBirth: '01/01/1990',
              gender: 'M',
              editMode: false
            },
            children: [
              {
                firstName: 'Joan',
                lastName: 'Keit',
                dateOfBirth: '01/01/1990',
                gender: '',
                editMode: false
              }
            ]
          }
        }
      }
    ];
    mockStore.overrideSelector(buyFlowElementsSelector, buyStepsC);
    spyOn(service, 'updateExistingDependentData').and.returnValue(true);
    service.addUserDependentData(
      dependents,
      route,
      cartData,
      coverageArray,
      depRelationshipTypes,
      false,
      'PREC-IA'
    );
    expect(service.addUserDependentData).toBeDefined();
  });

  it('should call updateExistingDependentData', () => {
    const service: DependentService = TestBed.get(DependentService);
    const dependents = [
      {
        firstName: 'John',
        lastName: 'Smith',
        genderCd: 'male',
        relationshipRole: 'SPOUSE',
        oid: 'fgsddshgfgd'
      }
    ];
    const coverageArray = ['ind_fml'];

    const cartData = {
      productId: 'PREC-IA',
      productName: 'Accident',
      plan: {
        id: 123,
        price: '100',
        description: 'These are the benefits',
        name: 'Lorem ipsum',
        states: ['AL', 'CT'],
        title: 'Standard Plan',
        benefits: [
          {
            id: 333,
            name: 'test',
            price: 123
          }
        ]
      },
      coverage: 'ind_fml',
      selected: true,
      availableInCart: true,
      selectedRiders: [
        {
          rider: { title: 'title1', price: '100' },
          selected: true,
          availableInCart: true,
          plan: { id: 'id1' }
        },
        {
          rider: { title: 'title2', price: '200' },
          selected: true,
          availableInCart: true,
          plan: { id: 'id1' }
        }
      ]
    };

    const buySteps = [
      {
        route: 'dependents',
        link: '/dependents',
        data: {
          'PREC-IA': {
            spouse: {
              firstName: 'Ryan',
              lastName: 'John',
              dateOfBirth: '01/01/1990',
              gender: 'M',
              editMode: false
            },
            children: [
              {
                firstName: 'Joan',
                lastName: 'Keit',
                dateOfBirth: '01/01/1990',
                gender: '',
                editMode: false
              }
            ]
          }
        }
      }
    ];
    service.updateExistingDependentData(
      dependents,
      true,
      coverageArray,
      cartData,
      buySteps,
      0
    );
    expect(service.updateExistingDependentData).toBeDefined();
  });

  it('should call updateSelectedChildData', () => {
    const service: DependentService = TestBed.get(DependentService);
    const params = {
      firstName: 'John',
      lastName: 'Smith',
      type: 'spouse',
      route: '/dependents'
    };
    const buySteps = [
      {
        route: 'dependents',
        link: '/dependents',
        data: {
          'PREC-IA': {
            spouse: {
              firstName: 'Ryan',
              lastName: 'John',
              dateOfBirth: '01/01/1990',
              gender: 'M',
              editMode: false
            },
            children: [
              {
                firstName: 'Joan',
                lastName: 'Keit',
                dateOfBirth: '01/01/1990',
                gender: '',
                editMode: false
              }
            ]
          }
        }
      }
    ];
    mockStore.overrideSelector(buyFlowElementsSelector, buySteps);
    service.updateSelectedChildData(true, params);
    expect(service.updateSelectedChildData).toBeDefined();
  });

  it('should call createDependentArrayWithQuoteNumber', () => {
    const service: DependentService = TestBed.get(DependentService);
    const bundleData = [
      {
        bundleId: '000',
        policyNumber: 'a1b2',
        effectiveDate: '01/02/2019',
        expirationDate: '01/06/2019',
        transactionEffectiveDate: '03/02/2019',
        policyStatusCd: 'dummy',
        productCode: 'PREC-IC',
        lobCd: 'dummy',
        totalPremium: 1234,
        currencyCode: 'ind',
        producerCd: 'dummy',
        subProducerCd: 'd',
        quoteNumber: '111',
        customerNumber: '111'
      }
    ];
    const dependentDataArray = {
      'PREC-IC': {
        spouse: {
          firstName: 'Ryan',
          lastName: 'John',
          dateOfBirth: '01/01/1990',
          gender: 'M',
          editMode: false
        },
        children: [
          {
            firstName: 'Joan',
            lastName: 'Keit',
            dateOfBirth: '01/01/1990',
            gender: '',
            editMode: false
          }
        ]
      },
      'PREC-IA': {
        spouse: {
          firstName: 'Ryan',
          lastName: 'John',
          dateOfBirth: '01/01/1990',
          gender: 'M',
          editMode: false
        },
        children: [
          {
            firstName: 'Joan',
            lastName: 'Keit',
            dateOfBirth: '01/01/1990',
            gender: '',
            editMode: false
          }
        ]
      }
    };
    service.createDependentArrayWithQuoteNumber(dependentDataArray, bundleData);
    expect(service.createDependentArrayWithQuoteNumber).toBeDefined();
  });

  it('should call findDependents', () => {
    const service: DependentService = TestBed.get(DependentService);
    const dependentDataArray = {
      'PREC-IC': {
        spouse: {
          firstName: 'Ryan',
          lastName: 'John',
          dateOfBirth: '01/01/1990',
          gender: 'M',
          editMode: false
        },
        children: [
          {
            firstName: 'Joan',
            lastName: 'Keit',
            dateOfBirth: '01/01/1990',
            gender: '',
            editMode: false
          }
        ]
      },
      'PREC-IA': {
        spouse: {
          firstName: 'Ryan',
          lastName: 'John',
          dateOfBirth: '01/01/1990',
          gender: 'M',
          editMode: false
        },
        children: [
          {
            firstName: 'Joan',
            lastName: 'Keit',
            dateOfBirth: '01/01/1990',
            gender: '',
            editMode: false
          }
        ]
      }
    };
    service.findDependents('PREC-IC', dependentDataArray);
    expect(service.findDependents).toBeDefined();
  });

  it('should call findQuoteNumber', () => {
    const service: DependentService = TestBed.get(DependentService);
    const bundleData = [
      {
        bundleId: '000',
        policyNumber: 'a1b2',
        effectiveDate: '01/02/2019',
        expirationDate: '01/06/2019',
        transactionEffectiveDate: '03/02/2019',
        policyStatusCd: 'dummy',
        productCode: 'PREC-IC',
        lobCd: 'dummy',
        totalPremium: 1234,
        currencyCode: 'ind',
        producerCd: 'dummy',
        subProducerCd: 'd',
        quoteNumber: '111',
        customerNumber: '111'
      }
    ];
    service.findQuoteNumber('PREC-IC', bundleData);
    expect(service.findQuoteNumber).toBeDefined();
  });
});
