import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material';
import { CheckoutEmailSuccessComponent } from '../../checkout-email-success/checkout-email-success.component';
import { Router } from '@angular/router';
import { Store, select } from '@ngrx/store';
import {
  SaveYourQuoteState,
  ProductState,
  dependentDataByRouteSelector
} from '@aflac/agent/shared'; //stores
import {
  agentESign,
  selectedProduct,
  dependentEligibilityDataSelector,
  effectiveDate
} from '@aflac/agent/shared'; //selectors

@Component({
  selector: 'aflac-e-signature',
  templateUrl: './e-signature.component.html',
  styleUrls: ['./e-signature.component.scss']
})
export class ESignatureComponent implements OnInit {
  effectiveDate: string;

  fetchedEmail: string;
  constructor(
    public checkoutEmailSuccessDialog: MatDialog,
    private store: Store<SaveYourQuoteState>,
    private prodStore: Store<ProductState>,
    public _router: Router
  ) {}

  ngOnInit() {
    this.store.select(effectiveDate).subscribe(effDate => {
      if (effDate) this.effectiveDate = this.showFormattedDate(effDate);
    });

    this.store
      .pipe(select(dependentDataByRouteSelector, '/my-details'))
      .subscribe(personalInfo => {
        if (personalInfo && personalInfo.emails) {
          this.fetchedEmail = personalInfo.emails[0].email || '';
        }
      });
    this.showEmailSuccessPopup();
    this.prodStore
      .pipe(select(selectedProduct))
      .subscribe(el => console.log('prod', el));
    this.store.select(dependentEligibilityDataSelector).subscribe(eff => {
      console.log(eff);
    });
  }
  redirectHome() {
    this._router.navigateByUrl('home');
  }
  showFormattedDate(date) {
    const today = new Date(date);
    let formattedDate = '';
    const dd = today.getDate();
    let ddStr = dd.toString();
    const mm = today.getMonth() + 1;
    let mmStr = mm.toString();
    const yyyy = today.getFullYear();
    const yyyyStr = yyyy.toString();
    if (dd < 10) {
      ddStr = `0${ddStr}`;
    }

    if (mm < 10) {
      mmStr = `0${mmStr}`;
    }
    formattedDate = mmStr + '/' + ddStr + '/' + yyyyStr;
    return formattedDate;
  }

  showEmailSuccessPopup() {
    const dialogRef = this.checkoutEmailSuccessDialog.open(
      CheckoutEmailSuccessComponent,
      {
        width: '315px',
        panelClass: 'agent-checkout-email-success-modal',
        disableClose: false,
        backdropClass: 'agent-checkout-email-success-backdrop'
      }
    );
    setTimeout(function() {
      dialogRef.close();
    }, 3000);
    console.log(this.store.pipe(select(agentESign)));
  }
}
