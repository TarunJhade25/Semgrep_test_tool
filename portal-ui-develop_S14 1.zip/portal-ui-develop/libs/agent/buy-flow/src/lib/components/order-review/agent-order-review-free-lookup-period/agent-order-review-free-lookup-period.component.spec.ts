import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AgentOrderReviewFreeLookupPeriodComponent } from './agent-order-review-free-lookup-period.component';

describe('AgentOrderReviewFreeLookupPeriodComponent', () => {
  let component: AgentOrderReviewFreeLookupPeriodComponent;
  let fixture: ComponentFixture<AgentOrderReviewFreeLookupPeriodComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [AgentOrderReviewFreeLookupPeriodComponent]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(
      AgentOrderReviewFreeLookupPeriodComponent
    );
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
