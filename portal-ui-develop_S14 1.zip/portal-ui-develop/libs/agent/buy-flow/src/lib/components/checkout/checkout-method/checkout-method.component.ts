import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { CheckoutService } from '../services/checkout.service';
import { Store, select } from '@ngrx/store';
import { CheckOutPostSignModel as Model } from '../model/checkoutPostSign.model';
import { SaveYourQuoteState } from '@aflac/agent/shared'; //stores
import { getAgentESign, selectUserDetailsFromAgent } from '@aflac/agent/shared'; //selectors
import { BuyFlowService } from '../../../services/buy-flow.service';

@Component({
  selector: 'aflac-checkout-method',
  templateUrl: './checkout-method.component.html',
  styleUrls: ['./checkout-method.component.scss']
})
export class CheckoutMethodComponent implements OnInit {
  signOptions: Array<any> = [];
  showTextBox: any = false;
  redirector: any;
  radioSelection: any;
  prodId: string;
  quoteNo: string;
  dateStamp: string;
  signatureInd: boolean;
  checked: boolean;
  capturedAgentSign: string;
  isFilled: any;
  @Output() signatureType: any = new EventEmitter<string>();
  model: Model;
  constructor(
    private checkoutService: CheckoutService,
    private store: Store<SaveYourQuoteState>,
    public buyFlowService: BuyFlowService
  ) {}

  ngOnInit() {
    this.getSignMethodRes();
    // todo
    // this.signOptions = [
    //   {
    //     text: 'Voice Signature',
    //     value: 'v',
    //     checked: false,
    //     type: 'voice-sign'
    //   }
    // ];
    this.buyFlowService.getBundleDataFromBundleId().subscribe(bundle => {
      if (bundle && bundle.data) {
        this.prodId = bundle.data.quotes[0].productCode;
        this.quoteNo = bundle.data.quotes[0].quoteNumber;
        this.dateStamp = bundle.data.quotes[0].submissionDate;
      }
      // console.log('bundle', bundle);
    });
  }

  showIp() {
    this.showTextBox = true;
  }
  watchOptionSelected(state) {
    this.redirector = state.type;
  }
  OnBlurCaptureInput(capturedInput: string) {
    this.capturedAgentSign = capturedInput;
    if (capturedInput) {
      this.signatureInd = true;
    }
  }
  handleSubmit() {
    if (this.redirector) {
      this.signatureType.emit(this.redirector);
    }
    this.store.dispatch(getAgentESign({ payload: this.capturedAgentSign })); // dispatch action agent sign
    if (this.redirector === 'e-sign') {
      this.handlePostReq();
    }
  }

  /****Post RequestHandling */
  handlePostReq() {
    const PostSign: Model = {
      policyNumber: this.quoteNo,
      productCode: this.prodId,
      signatureInd: this.signatureInd,
      signatureTypeCd: this.redirector,
      dateTimestamp: this.dateStamp,
      signedName: this.capturedAgentSign,
      ipNumber: '10.10.0.1',
      voiceRRNum: null
    };
    this.checkoutService.postSignInfo$(PostSign).subscribe();
  }

  getSignMethodRes() {
    this.checkoutService.getSignMethodAvl().subscribe(res => {
      if (res && res.voiceRecording) {
        this.signOptions = [
          ...this.signOptions,
          {
            text: 'Voice Signature',
            value: 'v',
            checked: false,
            type: 'voice-sign'
          }
        ];
      }
      if (res && res.electronicSignature) {
        this.signOptions = [
          ...this.signOptions,
          { text: 'e-Signature', value: 'e', checked: false, type: 'e-sign' }
        ];
      }
      if (this.signOptions) {
        const firstFalse = this.signOptions.findIndex(
          element => element.checked === false
        );
        this.signOptions[firstFalse] = {
          ...this.signOptions[firstFalse],
          checked: !this.signOptions[firstFalse].checked
        };
        this.signOptions.forEach(data => {
          if (data.checked) {
            this.redirector = data.type;
            return false;
          }
        });
      }
    });
  }
}
