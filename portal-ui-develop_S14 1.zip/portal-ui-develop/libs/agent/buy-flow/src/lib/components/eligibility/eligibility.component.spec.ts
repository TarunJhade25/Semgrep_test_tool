import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { RouterModule } from '@angular/router';
import { StoreModule, MemoizedSelector, Store } from '@ngrx/store';
import { TranslateModule } from '@ngx-translate/core';
import { RouterTestingModule } from '@angular/router/testing';
import { of, BehaviorSubject, Observable } from 'rxjs';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { BuyFlowService } from '../../services/buy-flow.service';
import { HttpClientTestingModule } from '@angular/common/http/testing';

import { EligibilityComponent } from './eligibility.component';

describe('EligibilityComponent', () => {
  let component: EligibilityComponent;
  let fixture: ComponentFixture<EligibilityComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        TranslateModule.forRoot(),
        RouterModule,
        RouterTestingModule,
        HttpClientTestingModule
      ],
      declarations: [EligibilityComponent],
      providers: [{ provide: BuyFlowService, useClass: MockBuyflowService }],
      schemas: [CUSTOM_ELEMENTS_SCHEMA]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EligibilityComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  class MockBuyflowService {
    enableStepperByRoute(route) {
      return of(true);
    }
  }
});
