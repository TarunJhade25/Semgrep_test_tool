import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { SsnValidationCustomerListModalComponent } from './ssn-validation-customer-list-modal.component';
import { TranslateModule } from '@ngx-translate/core';
import {
  MatDialogModule,
  MatDialogRef,
  MatDialog,
  MAT_DIALOG_DATA
} from '@angular/material/dialog';
import { StoreModule, Store, MemoizedSelector } from '@ngrx/store';
import { saveYourQuoteReducer } from '@aflac/agent/shared';
import { RouterTestingModule } from '@angular/router/testing';
import { NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { SharedMaterialModule } from '@aflac/shared/material';
import { PersonalDetailsService } from '../../../services/personal-details.service';
import { AgentSharedService } from '@aflac/agent/shared';
import { of, Observable } from 'rxjs';
import { StateEntityService } from '@aflac/shared/data-model';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { provideMockStore, MockStore } from '@ngrx/store/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { Router } from '@angular/router';
import { BuyFlowService } from '../../../../../services/buy-flow.service';

describe('SsnValidationCustomerListModalComponent', () => {
  let component: SsnValidationCustomerListModalComponent;
  let fixture: ComponentFixture<SsnValidationCustomerListModalComponent>;
  let dialog: MatDialog;
  let router: Router;
  let mockStore: MockStore<any>;

  const cartData = {
    key: 'from-list',
    value: [
      {
        productId: 'PREC-IC',
        productName: 'Accident',
        plan: {
          id: 123,
          price: '100',
          description: 'These are the benefits',
          name: 'Lorem ipsum',
          states: ['AL', 'CT'],
          title: 'Standard Plan',
          benefits: [
            {
              id: 333,
              name: 'test',
              price: 123
            }
          ]
        },
        coverage: 'ind',
        selected: true,
        availableInCart: true,
        selectedRiders: [
          {
            rider: { title: 'title1', price: '100' },
            selected: true,
            availableInCart: true,
            plan: { id: 'id1' }
          },
          {
            rider: { title: 'title2', price: '200' },
            selected: true,
            availableInCart: true,
            plan: { id: 'id1' }
          }
        ]
      }
    ]
  };

  const productData = [
    {
      id: 'PREC-IA',
      name: 'Accident Insurance'
    },
    {
      id: 'PREC-IC',
      name: 'Cancer Insurance'
    }
  ];

  const bundleData = {
    data: {
      quotes: [
        {
          bundleId: '000',
          policyNumber: 'a1b2',
          effectiveDate: '01/02/2019',
          expirationDate: '01/06/2019',
          transactionEffectiveDate: '03/02/2019',
          policyStatusCd: 'dummy',
          productCode: 'PREC-IC',
          lobCd: 'dummy',
          totalPremium: 1234,
          currencyCode: 'ind',
          producerCd: 'dummy',
          subProducerCd: 'd',
          quoteNumber: '111',
          customerNumber: '111'
        }
      ]
    }
  };

  const ssnDetailsArray = [
    {
      firstName: 'John',
      lastName: 'Doe',
      gender: 'M',
      ssn: '123456789',
      middleInitials: 'A',
      suffix: 'Jr.',
      dateOfBirth: '1985-07-13',
      aflacUserGuid: 'adskjk2764sdsd-sfsf',
      addresses: [
        {
          addressLine1: '11',
          addressLine2: 'a',
          city: 'Maa',
          stateProvCd: 'AL',
          zipCode: 12345
        }
      ],
      emails: [
        {
          email: 'a@gmail.com'
        }
      ],
      phones: [
        {
          phone: '1234567892'
        }
      ],
      customerNumber: '121212',
      availableProducts: [
        {
          productCd: 'PREC-IA'
        },
        {
          productCd: 'PREC-IC'
        }
      ]
    }
  ];

  const payloadData = {
    customerName: 'Johnson S',
    eligiblePlans: [
      {
        planId: 'plan07',
        planTitle: 'Standard Plan',
        productId: 'PREC-IC',
        productName: 'Cancer Insurance'
      }
    ],
    inEligiblePlans: [
      {
        productId: 'PREC-IA',
        productName: 'Accident Insurance',
        planId: 'Low',
        planTitle: 'Standard Plan'
      }
    ],
    purchasedProducts: [
      { productId: 'PREC-IA', productName: 'Accident Insurance' }
    ],
    updatedCartItems: [
      {
        availableInCart: true,
        coverage: 'ind',
        plan: {
          id: 'plan07',
          name: 'Lorem ipsum dolor sit',
          title: 'Standard Plan',
          description: 'These are the benefits that you cash.',
          states: []
        },
        productId: 'PREC-IC',
        productName: 'Cancer Insurance',
        selected: true,
        selectedRiders: [],
        startingPrice: '16.93'
      }
    ]
  };

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [SsnValidationCustomerListModalComponent],
      imports: [
        MatDialogModule,
        RouterTestingModule,
        SharedMaterialModule,
        TranslateModule.forRoot(),
        StoreModule.forRoot(saveYourQuoteReducer),
        BrowserAnimationsModule,
        HttpClientTestingModule
      ],
      schemas: [NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA],
      providers: [
        provideMockStore({}),
        { provide: MAT_DIALOG_DATA, useValue: ssnDetailsArray },
        { provide: MatDialogRef, useClass: DialogMock },
        { provide: Router, useClass: RouterStub },
        { provide: StateEntityService, useClass: MockStateEntityService },
        {
          provide: PersonalDetailsService,
          useClass: MockPersonalDetailsService
        },
        {
          provide: AgentSharedService,
          useClass: MockAgentSharedService
        },
        {
          provide: BuyFlowService,
          useClass: MockBuyFlowService
        }
      ]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SsnValidationCustomerListModalComponent);
    mockStore = TestBed.get(Store);
    component = fixture.componentInstance;
    dialog = TestBed.get(MatDialog);
    router = TestBed.get(Router);
    component.ssnDetailsArray = ssnDetailsArray;
    component.ssnDetails = ssnDetailsArray[0];
    component.productsByStateArray = productData;
    component.productsByStateFilteredArray = productData;
    component.productsAlreadyPurchased = ssnDetailsArray[0].availableProducts;
    component.storeDetailsArray = cartData.value;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('check for setSSNValidationDetails', () => {
    spyOn(component, 'createCustomerDetailsArray').and.returnValue(true);
    component.setSSNValidationDetails();
    expect(component.setSSNValidationDetails).toBeDefined();
  });

  it('check for getStoreDetails', () => {
    component.getStoreDetails();
    expect(component.getStoreDetails).toBeDefined();
  });

  it('check for getProductByStateDetails', () => {
    component.getProductByStateDetails();
    expect(component.getProductByStateDetails).toBeDefined();
  });

  it('check for goBackAndEdit', () => {
    component.goBackAndEdit();
    expect(component.goBackAndEdit).toBeDefined();
  });

  it('check for closePopUp', () => {
    component.closePopUp();
    expect(component.closePopUp).toBeDefined();
  });

  it('check for onSubmit', () => {
    component.ssnDetailsArray = ssnDetailsArray;
    component.selectedCustomer = '121212';
    spyOn(component, 'productEligibilityCheck').and.returnValue(payloadData);
    component.onSubmit();
    expect(component.onSubmit).toBeDefined();
  });

  it('check for filterProductStateArray', () => {
    component.ssnDetails = ssnDetailsArray[0];
    component.filterProductStateArray();
    expect(component.filterProductStateArray).toBeDefined();
  });

  it('check for manipulatePurchasedArray', () => {
    component.ssnDetails = ssnDetailsArray[0];
    component.manipulatePurchasedArray();
    expect(component.manipulatePurchasedArray).toBeDefined();
  });

  it('check for productEligibilityCheck', () => {
    component.ssnDetails = ssnDetailsArray[0];
    component.productEligibilityCheck();
    expect(component.productEligibilityCheck).toBeDefined();
  });

  //Mock class
  class MockStateEntityService {
    entities$ = of([{ states: [{ code: 'AL', name: 'Alabama' }] }]);
  }

  class MockPersonalDetailsService {
    getCartData(): Observable<any> {
      return of(cartData);
    }
    getProductsByStateData(): Observable<any> {
      return of(productData);
    }
    fetchUpdatedSum() {
      return of(true);
    }
  }

  class MockAgentSharedService {
    getStateNameFromStateProvCode() {
      return of(true);
    }
    updateSearchQuote() {
      return of(true);
    }
    updateExistingCustomerInfo() {
      return of(true);
    }
    checkAgentEligibilityForState() {
      return of(true);
    }
    /*
    updateRetrieveQuote() {
      return of(true);
    } */
  }

  class MockBuyFlowService {
    convertDOB() {
      return of(true);
    }
  }

  class RouterStub {
    navigateByUrl(url: string) {
      return url;
    }
  }
  class DialogMock {
    close() {}
  }
});
