import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { HomeAddressModelComponent } from './home-address-model.component';
import { TranslateModule } from '@ngx-translate/core';
import {
  MatDialogModule,
  MatDialogRef,
  MatDialog,
  MAT_DIALOG_DATA
} from '@angular/material/dialog';
import { StoreModule } from '@ngrx/store';
import { saveYourQuoteReducer } from '@aflac/agent/shared';
import { RouterTestingModule } from '@angular/router/testing';
import { NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { SharedMaterialModule } from '@aflac/shared/material';
import { PersonalDetailsService } from '../../services/personal-details.service';
import { BehaviorSubject } from 'rxjs';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { Router } from '@angular/router';

describe('HomeAddressModelComponent', () => {
  let component: HomeAddressModelComponent;
  let fixture: ComponentFixture<HomeAddressModelComponent>;
  let dialog: MatDialog;
  let router: Router;

  const dataSource = {
    initialState: {
      contentText: 'test',
      statecontent: 'statecon',
      contentNewAddressbuttontext: 'test',
      contentGobackbuttontext: 'test'
    }
  };

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [HomeAddressModelComponent],
      imports: [
        MatDialogModule,
        RouterTestingModule,
        SharedMaterialModule,
        TranslateModule.forRoot(),
        StoreModule.forRoot(saveYourQuoteReducer),
        BrowserAnimationsModule,
        HttpClientTestingModule
      ],
      schemas: [NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA],
      providers: [
        { provide: MAT_DIALOG_DATA, useValue: dataSource },
        { provide: MatDialogRef, useClass: DialogMock },
        {
          provide: PersonalDetailsService,
          useClass: MockPersonalDetailsService
        }
      ]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(HomeAddressModelComponent);
    component = fixture.componentInstance;
    dialog = TestBed.get(MatDialog);
    router = TestBed.get(Router);
    component.data = dataSource;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('check for ngOnInit', () => {
    component.ngOnInit();
    expect(component.ngOnInit).toBeDefined();
  });

  it('check for doAction', () => {
    component.doAction();
    expect(component.doAction).toBeDefined();
  });

  it('check for updateNewAddress', () => {
    component.updateNewAddress();
    expect(component.updateNewAddress).toBeDefined();
  });

  //Mock class
  class MockPersonalDetailsService {
    public confirmNewAddress = new BehaviorSubject(false);
  }
  class DialogMock {
    close() {}
  }
});
