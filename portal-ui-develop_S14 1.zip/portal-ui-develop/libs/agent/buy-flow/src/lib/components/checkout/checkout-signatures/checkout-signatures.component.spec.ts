import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CheckoutSignaturesComponent } from './checkout-signatures.component';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';

describe('CheckoutSignaturesComponent', () => {
  let component: CheckoutSignaturesComponent;
  let fixture: ComponentFixture<CheckoutSignaturesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [CheckoutSignaturesComponent],
      schemas: [CUSTOM_ELEMENTS_SCHEMA]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CheckoutSignaturesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
