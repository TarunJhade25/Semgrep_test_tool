import { TestBed } from '@angular/core/testing';

import { PersonalDetailsService } from './personal-details.service';
import { StoreModule } from '@ngrx/store';
import { saveYourQuoteReducer } from '@aflac/agent/shared';
import { FormBuilder } from '@angular/forms';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { of } from 'rxjs';
import { RouterTestingModule } from '@angular/router/testing';

describe('PersonalDetailsService', () => {
  const formBuilder: FormBuilder = new FormBuilder();
  beforeEach(() =>
    TestBed.configureTestingModule({
      imports: [
        StoreModule.forRoot(saveYourQuoteReducer),
        HttpClientTestingModule,
        RouterTestingModule
      ]
    })
  );

  it('should be created', () => {
    const service: PersonalDetailsService = TestBed.get(PersonalDetailsService);
    expect(service).toBeTruthy();
  });

  it('format on save event', () => {
    const service: PersonalDetailsService = TestBed.get(PersonalDetailsService);
    const myInfoForm = formBuilder.group({
      firstName: '',
      lastName: '',
      gender: '',
      dateOfBirth: '',
      middleInitials: '',
      ssn: '',
      suffix: ''
    });
    const addressForm = formBuilder.group({
      addressLine1: '',
      addressLine2: '',
      city: '',
      stateProvCd: '',
      zipCode: ''
    });
    const data = {
      firstName: 'John',
      lastName: 'Doe',
      gender: 'M',
      ssn: '123456789',
      middleInitials: 'A',
      suffix: 'Jr.',
      dateOfBirth: '1985-07-13'
    };
    service.formateDataOnFormSubmit(myInfoForm, addressForm, null, data);
  });

  it('should be return cta status and error status', () => {
    const data = '0';
    const service: PersonalDetailsService = TestBed.get(PersonalDetailsService);
    service.returnAddressValidation(data);
    expect(service.returnAddressValidation(data).errorStatus).toBeTruthy();
  });

  it('should get ssn value', () => {
    const ssn = '123456789';
    const service: PersonalDetailsService = TestBed.get(PersonalDetailsService);
    service.setSSNValue(ssn);
    expect(service.getSSNValue()).toEqual(ssn);
  });

  it('should get customer number', () => {
    const customerNo = '1212';
    const service: PersonalDetailsService = TestBed.get(PersonalDetailsService);
    service.setCustomerNumber(customerNo);
    expect(service.getCustomerNumber()).toEqual(customerNo);
  });

  /*
  it('should get personal data', () => {
    const personalData = {
      firstName: 'John',
      lastName: 'Doe',
      gender: 'M',
      ssn: '123456789',
      middleInitials: 'A',
      suffix: 'Jr.',
      dateOfBirth: '1985-07-13',
      aflacUserGuid: 'adskjk2764sdsd-sfsf',
      addresses: [
        {
          addressLine1: '11',
          addressLine2: 'a',
          city: 'Maa',
          stateProvCd: 'AL',
          zipCode: 12345
        }
      ],
      emails: [
        {
          email: 'a@gmail.com'
        }
      ],
      phones: [
        {
          phone: '1234567892'
        }
      ],
      customerNumber: '1212',
      requestHeader: {
        jscPayload: 'test',
        hdimayload: 'test'
      }
    };
    const route = 'my-details';
    const service: PersonalDetailsService = TestBed.get(PersonalDetailsService);
    spyOn(service, 'getPersonalData').and.returnValue(of(personalData));
    service.getPersonalData(route);
    //expect(service.getPersonalData(route)).toHaveBeenCalled();
  }); */
});
