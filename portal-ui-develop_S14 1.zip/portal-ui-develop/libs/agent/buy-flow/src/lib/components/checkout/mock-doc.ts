export const Docs = [
  { type: 'Accident Policy', docs: ['doc1', 'doc2', 'doc3', 'doc4'] },
  { type: 'CI Policy', docs: ['doc1', 'doc2', 'doc3', 'doc4'] },
  { type: 'Cancer Policy', docs: ['doc1', 'doc2', 'doc3', 'doc4'] }
];
