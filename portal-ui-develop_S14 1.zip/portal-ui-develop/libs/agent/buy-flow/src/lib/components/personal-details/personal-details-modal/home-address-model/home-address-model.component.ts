import { Component, OnInit, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { Subject } from 'rxjs';
import { PersonalDetailsService } from '../../services/personal-details.service';

@Component({
  selector: 'aflac-home-address-model',
  templateUrl: './home-address-model.component.html',
  styleUrls: ['./home-address-model.component.scss']
})
export class HomeAddressModelComponent implements OnInit {
  title: string;
  closeBtnName: string;
  user: any;
  contentText: string;
  contentText1: string;
  contentNewAddressbuttontext: string;
  contentChangeAddressbuttontext: string;
  public onClose: Subject<boolean>;
  constructor(
    public dialogRef: MatDialogRef<HomeAddressModelComponent>,
    public personalInfoServ: PersonalDetailsService,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) {}

  ngOnInit() {}

  doAction() {
    this.dialogRef.close(true);
  }
  updateNewAddress() {
    this.dialogRef.close(true);
    this.personalInfoServ.confirmNewAddress.next(true);
  }
}
