import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PersonalDetailsMyInfoComponent } from './personal-details-my-info.component';
import { TranslateModule } from '@ngx-translate/core';
import { ReactiveFormsModule, FormsModule, FormBuilder } from '@angular/forms';
import { SharedvalidatorsModule } from '@aflac/shared/validators';
import { StoreModule } from '@ngrx/store/src/store_module';
import { saveYourQuoteReducer } from '@aflac/agent/shared';
import { provideMockStore, MockStore } from '@ngrx/store/testing';
import { Store } from '@ngrx/store';
import { CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA } from '@angular/core';
import { DatePipe } from '@angular/common';
import { personalDataUpdateStatus } from '@aflac/agent/shared';
import { MatDialog, MatDialogModule } from '@angular/material/dialog';
import { CmsService } from '@aflac/shared/cms';
import { NgxMaskModule } from 'ngx-mask';
import { MaskInputPipe } from '../pipes/mask-input.pipe';
import { SharedMaterialModule } from '@aflac/shared/material';
import { of, BehaviorSubject, Observable } from 'rxjs';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { By } from '@angular/platform-browser';
import { PersonalDetailsService } from '../services/personal-details.service';
import { BuyFlowService } from '../../../services/buy-flow.service';
import { Router } from '@angular/router';
import { RouterTestingModule } from '@angular/router/testing';
import { BrowserDynamicTestingModule } from '@angular/platform-browser-dynamic/testing';
import { SsnValidationCustomerListModalComponent } from '../personal-details-modal/ssn-validation/ssn-validation-customer-list-modal/ssn-validation-customer-list-modal.component';
import { SsnValidationCoverageEligibilityModalComponent } from '../personal-details-modal/ssn-validation/ssn-validation-coverage-eligibility-modal/ssn-validation-coverage-eligibility-modal.component';
import { SsnValidationCoverageChangeModalComponent } from '../personal-details-modal/ssn-validation/ssn-validation-coverage-change-modal/ssn-validation-coverage-change-modal.component';
import { AgeChangeInPremiumComponent } from '../personal-details-modal/age-validation-modal/age-change-in-premium/age-change-in-premium.component';
import { AgeNotEligibleForProductComponent } from '../personal-details-modal/age-validation-modal/age-not-eligible-for-product/age-not-eligible-for-product.component';
import { SsnInfoModalComponent } from '../personal-details-modal/ssn-info-modal/ssn-info-modal.component';

describe('PersonalDetailsMyInfoComponent', () => {
  let component: PersonalDetailsMyInfoComponent;
  let fixture: ComponentFixture<PersonalDetailsMyInfoComponent>;
  let mockStore: MockStore<any>;
  let dialog: MatDialog;
  let router: Router;
  const formBuilder: FormBuilder = new FormBuilder();
  const personalData = {
    firstName: 'John',
    lastName: 'Doe',
    gender: 'M',
    taxId: '123456789',
    middleName: 'Anu',
    suffix: 'Jr.',
    dateOfBirth: '1985-07-13',
    customerNumber: '1212'
  };
  const data = ['M', 'F', 'X'];
  const userDetails = {
    age: '54',
    consentStatus: 'GRANTED',
    customerNumber: '510001',
    email: 'johnsmith@gmail.com',
    firstName: 'Johnson',
    lastName: 'S',
    quotes: [
      {
        caseId: 'QWESR2314 WE',
        coverageTypeCd: 'ind_sps',
        packageCd: 'plan07',
        productCd: 'PREC-IC',
        productName: 'Cancer Insurance',
        riders: [],
        riskStateCd: 'AL',
        series: 'test',
        sfrId: '',
        totalPremium: '16.93'
      }
    ]
  };

  const cartData = {
    key: 'from-list',
    value: [
      {
        productId: 'PREC-IC',
        productName: 'Accident',
        plan: {
          id: 123,
          price: '100',
          description: 'These are the benefits',
          name: 'Lorem ipsum',
          states: ['AL', 'CT'],
          title: 'Standard Plan',
          benefits: [
            {
              id: 333,
              name: 'test',
              price: 123
            }
          ]
        },
        coverage: 'ind',
        selected: true,
        availableInCart: true,
        selectedRiders: [
          {
            rider: { title: 'title1', price: '100' },
            selected: true,
            availableInCart: true,
            plan: { id: 'id1' }
          },
          {
            rider: { title: 'title2', price: '200' },
            selected: true,
            availableInCart: true,
            plan: { id: 'id1' }
          }
        ]
      }
    ]
  };

  const riders = [
    {
      rider: { title: 'title1', price: '100' },
      selected: true,
      availableInCart: true,
      plan: { id: 'id1' }
    },
    {
      rider: { title: 'title2', price: '200' },
      selected: true,
      availableInCart: true,
      plan: { id: 'id1' }
    }
  ];

  const ageValData = {
    status: true,
    data: [
      {
        PRECIA: {
          data: {
            planTypeCd: 'Low',
            monthlyPremium: 28.05,
            monthPremium: 28.05,
            coverageTierCd: 'EC',
            minAge: 20,
            maxAge: 65,
            riders: [],
            productCd: 'PREC-IA'
          },
          message: 'Success'
        }
      },
      {
        PRECIC: {
          data: {
            planTypeCd: 'plan07',
            monthlyPremium: 209.87,
            monthPremium: 201.3,
            coverageTierCd: 'EF',
            minAge: 20,
            maxAge: 40,
            riders: [],
            productCd: 'PREC-IC'
          },
          message: 'Success'
        }
      }
    ]
  };

  const ssnData = {
    status: true,
    data: {
      customerNumber: '510002',
      firstName: 'Johnson',
      lastName: 'Smithish',
      middleName: 'Elizabeth',
      suffix: 'Sr.',
      dateOfBirth: '03/20/1966',
      gender: 'male',
      taxId: '108754683',
      serviceCommunicationsInd: true,
      otherCommunicationsInd: true,
      aflacUserGuid: 'b480d9fc-8558-4507-92cb-772325011677',
      extSysCustId: '',
      addresses: [
        {
          id: 0,
          addressLine1: '345 California Str',
          addressLine2: '10 flr',
          addressLine3: ' ',
          city: 'San Francisco',
          county: 'San Francisco',
          zipCode: '94104',
          stateProvCd: 'AL',
          countryCd: 'US',
          addressTypeCd: 'mailing'
        }
      ],
      phones: [{ id: 0, phone: '1234567890', phoneTypeCd: 'WORK' }],
      emails: [
        {
          id: 0,
          email: 'johnsmith@gmail.com',
          consentStatus: 'GRANTED',
          consentDate: '2020-05-26'
        }
      ],
      availableProducts: [
        {
          productCd: 'PREC-IA'
        },
        {
          productCd: 'PREC-IC'
        }
      ]
    },
    message: 'Success'
  };

  const agePayload = {
    ageEligibilityDetails: [
      {
        productId: 'PREC-IA',
        productName: 'Accident Insurance',
        currentPremium: 28.05,
        riders: []
      },
      {
        productId: 'PREC-IC',
        productName: 'Cancer Insurance',
        currentPremium: 209.87,
        riders: []
      }
    ],
    ageInEligibilityDetails: [],
    agePremiumChangeDetails: [
      {
        productId: 'PREC-IA',
        productName: 'Accident Insurance',
        dateOfBirth: '01/01/2000',
        currentPremium: 28.05,
        prevPremium: 25.1,
        riders: []
      },
      {
        productId: 'PREC-IC',
        productName: 'Cancer Insurance',
        dateOfBirth: '01/01/2000',
        currentPremium: 209.87,
        prevPremium: 25.5,
        riders: []
      }
    ]
  };

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        TranslateModule.forRoot(),
        ReactiveFormsModule,
        FormsModule,
        SharedvalidatorsModule,
        MatDialogModule,
        NgxMaskModule.forRoot(),
        SharedMaterialModule,
        BrowserAnimationsModule,
        HttpClientTestingModule,
        RouterTestingModule
      ],
      declarations: [
        PersonalDetailsMyInfoComponent,
        MaskInputPipe,
        SsnValidationCustomerListModalComponent,
        SsnValidationCoverageEligibilityModalComponent,
        SsnValidationCoverageChangeModalComponent,
        AgeChangeInPremiumComponent,
        AgeNotEligibleForProductComponent,
        SsnInfoModalComponent
      ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA],
      providers: [
        DatePipe,
        provideMockStore({}),
        MatDialogModule,
        CmsService,
        { provide: FormBuilder, useValue: formBuilder },
        { provide: BuyFlowService, useClass: MockBuyflowService },
        {
          provide: PersonalDetailsService,
          useClass: MockPersonalDetailsService
        }
      ]
    })
      .overrideModule(BrowserDynamicTestingModule, {
        set: {
          entryComponents: [
            SsnValidationCustomerListModalComponent,
            SsnValidationCoverageEligibilityModalComponent,
            SsnValidationCoverageChangeModalComponent,
            AgeChangeInPremiumComponent,
            AgeNotEligibleForProductComponent,
            SsnInfoModalComponent
          ]
        }
      })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PersonalDetailsMyInfoComponent);
    component = fixture.componentInstance;
    component.data = null;
    component.myInfoForm = formBuilder.group({
      firstName: '',
      lastName: '',
      gender: '',
      dateOfBirth: '',
      middleInitials: '',
      taxId: '',
      suffix: ''
    });
    mockStore = TestBed.get(Store);
    router = TestBed.get(Router);
    dialog = TestBed.get(MatDialog);
    const cmsService = TestBed.get(CmsService);
    spyOn(cmsService, 'getKey').and.returnValue(of([data]));
    mockStore.overrideSelector(personalDataUpdateStatus, {});
    component.cartDetails = cartData.value;
    component.myInfoFormData = {
      statusOnComplete: 'myinfo-succcess',
      formData: component.myInfoForm,
      customerId: '111111'
    };
    fixture.detectChanges();
  });

  it('should create my info component', () => {
    expect(component).toBeTruthy();
  });

  it('should call ngOnInit', () => {
    component.ngOnInit();
    expect(component.ngOnInit).toBeDefined();
  });

  it('should sets data for returning customer', () => {
    component.data = personalData;
    spyOn(component, 'getDataForToggleView').and.returnValue(true);
    component.getDataForToggleView(personalData);
  });

  it('should check ageSSNResetAction function is called', () => {
    component.ageSSNResetAction();
    expect(component.ageSSNResetAction).toBeDefined();
  });

  it('should check ageSSNValidationAction function is called', () => {
    component.ageSSNValidationAction();
    expect(component.ageSSNValidationAction).toBeDefined();
  });

  it('should check ageValidationFlow function is called', () => {
    spyOn(component, 'getDataForToggleView').and.returnValue(personalData);
    component.ageValidationFlow(ageValData);
    expect(component.ageValidationFlow).toBeDefined();
  });

  // it('should check ageEligibilityCheck function is called', () => {
  //   component.ageEligibilityCheck(ageValData);
  //   expect(component.ageEligibilityCheck).toBeDefined();
  // });

  // it('should check calculateRiderSum function is called', () => {
  //   component.calculateRiderSum(riders);
  //   expect(component.calculateRiderSum).toBeDefined();
  // });

  it('should initialise the form', () => {
    expect(component.myInfoForm).toBeDefined();
  });

  it('hide event', () => {
    component.hide = true;
    component.data = personalData;
    spyOn(component, 'getDataForToggleView').and.returnValue(personalData);
    component.hideValue();
    const taxId = component.myInfoForm.controls['taxId'];
    taxId.setValue('123456789');
  });

  it('set data for new user', () => {
    const mockData = {
      firstName: 'John',
      lastName: 'Doe'
    };
    component.setFormDataForNewUser(mockData);
  });

  it('set form data ', () => {
    component.data = personalData;
    component.setMyInfoFormData(personalData);
  });

  it('toggle view mode event', () => {
    component.isEdit = false;
    component.data = personalData;
    component.toggleViewMode();
  });

  it('should check trackFirstValueChange', () => {
    component.trackFirstValueChange();
    expect(component.trackFirstValueChange).toBeDefined();
  });

  it('should check saveMyInfoFormData function is called', () => {
    component.data = personalData;
    spyOn(component, 'getDataForToggleView').and.returnValue(personalData);
    component.saveMyInfoFormData();
    expect(component.saveMyInfoFormData).toBeDefined();
  });

  it('should check saveMyinfoDataOnSuccess function is called', () => {
    component.data = personalData;
    spyOn(component, 'getDataForToggleView').and.returnValue(personalData);
    component.saveMyinfoDataOnSuccess(component.myInfoFormData);
    expect(component.saveMyinfoDataOnSuccess).toBeDefined();
  });

  it('should check applyAgeValidation function is called', () => {
    spyOn(component, 'getDataForToggleView').and.returnValue(true);
    component.applyAgeValidation();
    expect(component.applyAgeValidation).toBeDefined();
  });

  it('should set value of my info form ', () => {
    component.myInfoForm.setValue({
      firstName: 'John',
      lastName: 'Johnes',
      middleInitials: '',
      suffix: '',
      taxId: 123456789,
      dateOfBirth: '07/13/1995',
      gender: 'M'
    });
    component.data = personalData;
    component.onSubmit();
  });

  it('should check openSsnCustomerModal function is called', () => {
    component.openSsnCustomerModal(ssnData);
    expect(component.openSsnCustomerModal).toBeDefined();
  });

  it('should check openCoverageEligiblePopup function is called', () => {
    const payload = {
      customerName: 'Johnson Smithish',
      eligiblePlans: [],
      inEligiblePlans: [
        {
          productId: 'PREC-IA',
          productName: 'Accident Insurance',
          planId: 'Low',
          planTitle: 'Standard Plan'
        },
        {
          productId: 'PREC-IC',
          productName: 'Cancer Insurance',
          planId: 'plan07',
          planTitle: 'Standard Plan'
        }
      ],
      mode: 'Hope',
      purchasedProducts: [
        { productId: 'PREC-IA', productName: 'Accident Insurance' },
        { productId: 'PREC-IC', productName: 'Cancer Insurance' }
      ],
      ssnData: ssnData,
      updatedCartItems: []
    };
    component.openCoverageEligiblePopup(payload);
    expect(component.openCoverageEligiblePopup).toBeDefined();
  });

  it('should check openAgeChangeInPremiumModel function is called', () => {
    component.openAgeChangeInPremiumModel(agePayload);
    expect(component.openAgeChangeInPremiumModel).toBeDefined();
  });

  it('should check openAgeNotEligibleModel function is called', () => {
    component.openAgeNotEligibleModel(agePayload);
    expect(component.openAgeNotEligibleModel).toBeDefined();
  });

  it('should check openSsnInfoModal function is called', () => {
    const event = {
      stopPropagation: function() {
        return true;
      }
    };
    spyOn(event, 'stopPropagation');
    component.openSsnInfoModal(event);
    expect(component.openSsnInfoModal).toBeDefined();
  });

  it('should check openSsnCoverageChangePopup function is called', () => {
    const payload = {
      customerName: 'Johnson Smithish',
      eligiblePlans: [],
      inEligiblePlans: [
        {
          productId: 'PREC-IA',
          productName: 'Accident Insurance',
          planId: 'Low',
          planTitle: 'Standard Plan'
        },
        {
          productId: 'PREC-IC',
          productName: 'Cancer Insurance',
          planId: 'plan07',
          planTitle: 'Standard Plan'
        }
      ],
      mode: 'continue',
      purchasedProducts: [
        { productId: 'PREC-IA', productName: 'Accident Insurance' },
        { productId: 'PREC-IC', productName: 'Cancer Insurance' }
      ],
      ssnData: ssnData,

      updatedCartItems: []
    };
    component.openSsnCoverageChangePopup(payload);
    expect(component.openSsnCoverageChangePopup).toBeDefined();
  });

  it('should check showSSNLastChar function is called', () => {
    component.showSSNLastChar();
    expect(component.showSSNLastChar).toBeDefined();
  });

  it('should check showMaskedSSN function is called', () => {
    component.showMaskedSSN();
    expect(component.showMaskedSSN).toBeDefined();
  });

  it('should check replaceLastChar function is called', () => {
    component.replaceLastChar('576687796');
    expect(component.replaceLastChar).toBeDefined();
  });

  it('should check resetMaskPattern function is called', () => {
    component.resetMaskPattern();
    expect(component.resetMaskPattern).toBeDefined();
  });

  it('should check setMaskPattern function is called', () => {
    component.maskPattern = 'YYY-YY-0000';
    component.setMaskPattern();
    expect(component.setMaskPattern).toBeDefined();
  });

  class MockBuyflowService {
    getAgentSearchQuote() {
      return of(true);
    }
    convertDOB() {
      return of(true);
    }
    ageEligibilityCheck() {
      return of(true);
    }
  }

  class MockPersonalDetailsService {
    public isFormValid = new BehaviorSubject(false);
    public confirmNewAddress = new BehaviorSubject(false);
    public isMyInfoFormStatus = new BehaviorSubject(true);
    public isAddressFormStatus = new BehaviorSubject(true);
    public isShowContactForm = new BehaviorSubject(true);
    public isContactFormView = new BehaviorSubject(true);
    public buttonVisibleStatus = new BehaviorSubject(false);
    public userType = new BehaviorSubject('new');
    public isContactFormStatus = new BehaviorSubject(true);

    getPersonalData(route): Observable<any> {
      return of(personalData);
    }
    getUserDataFomSaveQuoteResponse(): Observable<any> {
      return of(userDetails);
    }
    getCartData(): Observable<any> {
      return of(cartData);
    }
    getAgeValidationData(): Observable<any> {
      return of(ageValData);
    }
    setMyInfoForm() {
      return of(true);
    }
    getCustomerNumber() {
      return of(true);
    }
    formateDataOnFormSubmit() {
      return of(true);
    }
    addUserDependentData() {
      return of(true);
    }
  }
});
