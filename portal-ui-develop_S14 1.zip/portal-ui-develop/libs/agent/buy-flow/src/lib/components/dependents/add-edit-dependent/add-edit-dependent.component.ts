import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { DependentService } from '../services/dependent.service';
import { BuyFlowService } from '../../../services/buy-flow.service';
import { CmsService } from '@aflac/shared/cms';
import { MatDialog } from '@angular/material';
import { ConfirmModalComponent } from '@aflac/agent/shared';

@Component({
  selector: 'aflac-add-edit-dependent',
  templateUrl: './add-edit-dependent.component.html',
  styleUrls: ['./add-edit-dependent.component.scss']
})
export class AddEditDependentComponent implements OnInit {
  @Input() childLength;
  @Input() params;
  @Input() dependentEdited: boolean;
  @Output() updateFlag = new EventEmitter();

  dependentForm: FormGroup;
  isSpouseAdd = true;
  dataCount: any = 0;
  genderData: any[];

  constructor(
    private cmsService: CmsService,
    private dependentService: DependentService,
    private buyflowService: BuyFlowService,
    public dialog: MatDialog
  ) {}

  ngOnInit() {
    this.dependentForm = this.dependentService.getDependentForm(
      this.params,
      this.dependentEdited
    );
    this.isSpouseAddCheck();

    this.cmsService
      .getKey('lookup.personal_details_gender_options')
      .subscribe(res => {
        if (res instanceof Array) this.genderData = res;
      });

    if (this.dependentForm.invalid) {
      this.dependentService.isFormValid.next(true);
    }
    /*
    this.dependentForm.valueChanges.subscribe(val => {
      this.dependentService.isFormValid.next(true);
    }); */
  }

  getDependentDataEditModeCount() {
    if (
      this.params &&
      this.params.dependentData &&
      Object.keys(this.params.dependentData).length > 0
    ) {
      let spouseCount = 0,
        childCount = 0,
        childCountArray = [];
      Object.keys(this.params.dependentData).forEach(k => {
        if (Object.keys(this.params.dependentData[k]).length > 0) {
          if (
            this.params.dependentData[k].spouse &&
            this.params.dependentData[k].spouse.editMode === true
          ) {
            spouseCount = 1;
          }
          if (this.params.dependentData[k].children) {
            this.params.dependentData[k].children.filter(item => {
              if (item.editMode === true) {
                childCountArray.push(item);
              }
            });
            childCountArray = childCountArray.filter(
              (v, i) =>
                childCountArray.findIndex(item => item.oid === v.oid) === i
            );
          }
        }
      });
      childCount = childCountArray.length;
      this.dataCount = spouseCount + childCount;
    }
  }

  submitDependent() {
    this.dependentService.submitDependent(this.dependentForm, this.params);
    this.getDependentDataEditModeCount();
    if (this.dependentForm.valid && this.dataCount <= 1) {
      this.dependentService.isFormValid.next(false);
      this.dependentService.disableNextProduct.next(false);
    } else {
      this.dependentService.isFormValid.next(true);
    }

    const updateObj = {
      mode: 'submit',
      parentIndex: this.params.parentIndex,
      type: this.params.type,
      editMode:
        this.params.dependentData &&
        Object.keys(this.params.dependentData).length > 0
          ? true
          : false
    };
    this.updateFlag.emit(updateObj);
    //this.buyflowService.clearStepperElementData(this.params.route);
    if (this.params.type === 'spouse') {
      const element = document.getElementById(
        'childBlock' + this.params.parentContainerIndex
      );
      if (element) {
        this.scrollToPosition(element);
      }
    }
  }

  scrollToPosition(e) {
    setTimeout(() => {
      window.scroll({
        behavior: 'smooth',
        left: 0,
        top: e.offsetTop
      });
    }, 100);
  }

  get f() {
    if (this.dependentForm) {
      return this.dependentForm.controls;
    }
  }

  isSpouseAddCheck() {
    if (this.params.type === 'spouse') {
      const data = this.params.dependentData
        ? this.params.dependentData[this.params.parentIndex]
        : '';
      if (data && data.spouse) {
        this.isSpouseAdd = false;
      }
    }
  }

  deleteDependent() {
    const initialState = {
      contentTitle: this.cmsService.getKey(
        'lookup.delete_dependent_modal_header'
      ),
      contentText: this.cmsService.getKey('lookup.delete_dependent_modal_body'),
      contentButtonText: this.cmsService.getKey(
        'lookup.buy_flow_checkout_address_payment_address_yes'
      )
    };
    const dialogRef = this.dialog.open(ConfirmModalComponent, {
      disableClose: true,
      data: {
        initialState
      },
      panelClass: 'remove-dependent-modal-resizer'
    });
    dialogRef.afterClosed().subscribe(result => {
      if (result && result === 'delete') {
        this.dependentService.deleteChildByIndex(
          this.params,
          this.dependentEdited
        );
        this.dependentService.isFormValid.next(false);
        this.dependentService.disableNextProduct.next(false);
        const updateObj = {
          mode: 'delete',
          parentIndex: this.params.parentIndex
        };
        this.updateFlag.emit(updateObj);
      }
    });
  }
}
