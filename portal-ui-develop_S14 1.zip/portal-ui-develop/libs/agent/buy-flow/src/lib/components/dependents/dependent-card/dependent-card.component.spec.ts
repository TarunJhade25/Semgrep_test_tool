import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { DependentCardComponent } from './dependent-card.component';
import { TranslateModule } from '@ngx-translate/core';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { MatDialogModule } from '@angular/material/dialog';
import { SharedvalidatorsModule } from '@aflac/shared/validators';
import { MatFormFieldModule, MatInputModule } from '@angular/material';
import { RouterTestingModule } from '@angular/router/testing';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { BrowserDynamicTestingModule } from '@angular/platform-browser-dynamic/testing';
import { provideMockStore, MockStore } from '@ngrx/store/testing';
import { DependentService } from '../services/dependent.service';
import { BehaviorSubject } from 'rxjs';
import { ConfirmModalComponent } from '@aflac/agent/shared';

class DependentServiceMock {
  public isFormValid = new BehaviorSubject(false);
  public disableNextProduct = new BehaviorSubject(false);
  setDependentData() {
    return true;
  }
  deleteChildByIndex() {
    return true;
  }
  updateSelectedChildData() {
    return true;
  }
}

describe('DependentCardComponent', () => {
  let component: DependentCardComponent;
  let fixture: ComponentFixture<DependentCardComponent>;
  const changes = {
    dependentDetails: {}
  };
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [DependentCardComponent, ConfirmModalComponent],
      imports: [
        TranslateModule.forRoot(),
        ReactiveFormsModule,
        FormsModule,
        SharedvalidatorsModule,
        MatDialogModule,
        MatFormFieldModule,
        MatInputModule,
        RouterTestingModule,
        BrowserAnimationsModule
      ],
      providers: [
        provideMockStore({}),
        { provide: DependentService, useClass: DependentServiceMock }
      ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA]
    })
      .overrideModule(BrowserDynamicTestingModule, {
        set: {
          entryComponents: [ConfirmModalComponent]
        }
      })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DependentCardComponent);
    component = fixture.componentInstance;
    component.params = {
      type: 'child'
    };
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should call ngOnChanges funtion', () => {
    component.ngOnChanges();
    expect(component as any).toBeDefined();
  });

  it('should call selectChild funtion', () => {
    const val = true;
    component.selectChild(val);
    expect(component as any).toBeDefined();
  });

  it('should call editDependent funtion', () => {
    component.editDependent();
    expect(component as any).toBeDefined();
  });

  it('should call deleteDependent funtion', () => {
    component.deleteDependent();
    expect(component as any).toBeDefined();
  });
});
