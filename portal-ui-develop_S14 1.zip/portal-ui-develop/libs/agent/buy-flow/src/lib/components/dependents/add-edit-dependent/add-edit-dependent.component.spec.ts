import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { TranslateModule } from '@ngx-translate/core';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { MatDialogModule } from '@angular/material/dialog';
import { SharedvalidatorsModule } from '@aflac/shared/validators';
import { MatFormFieldModule, MatInputModule } from '@angular/material';
import { RouterTestingModule } from '@angular/router/testing';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { provideMockStore } from '@ngrx/store/testing';
import { NgxMaskModule } from 'ngx-mask';
import { BehaviorSubject } from 'rxjs';
import { FormGroup, FormControl } from '@angular/forms';

import { AddEditDependentComponent } from './add-edit-dependent.component';
import { DependentService } from '../services/dependent.service';
import { ConfirmModalComponent } from '@aflac/agent/shared';

import { BrowserDynamicTestingModule } from '@angular/platform-browser-dynamic/testing';

class DependentServiceMock {
  public isFormValid = new BehaviorSubject(false);
  public disableNextProduct = new BehaviorSubject(false);
  setDependentData() {
    return true;
  }
  deleteChildByIndex() {
    return true;
  }
  submitDependent() {
    return true;
  }
  getDependentForm() {
    return true;
  }
}

const params = {
  type: 'spouse',
  parentIndex: 'PREC-IC',
  dependentData: {
    'PREC-IC': {
      spouse: {
        firstName: 'Ryan',
        lastName: 'John',
        dateOfBirth: '01/01/1990',
        gender: 'M',
        editMode: false
      },
      children: [
        {
          firstName: 'Joan',
          lastName: 'Keit',
          dateOfBirth: '01/01/1990',
          gender: '',
          editMode: false
        }
      ]
    },
    'PREC-IA': {
      spouse: {
        firstName: 'Ryan',
        lastName: 'John',
        dateOfBirth: '01/01/1990',
        gender: 'M',
        editMode: false
      },
      children: [
        {
          firstName: 'Joan',
          lastName: 'Keit',
          dateOfBirth: '01/01/1990',
          gender: '',
          editMode: false
        }
      ]
    }
  }
};

describe('AddEditDependentComponent', () => {
  let component: AddEditDependentComponent;
  let fixture: ComponentFixture<AddEditDependentComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [AddEditDependentComponent, ConfirmModalComponent],
      imports: [
        TranslateModule.forRoot(),
        ReactiveFormsModule,
        FormsModule,
        SharedvalidatorsModule,
        MatDialogModule,
        MatFormFieldModule,
        MatInputModule,
        RouterTestingModule,
        BrowserAnimationsModule,
        NgxMaskModule.forRoot(),
        BrowserDynamicTestingModule
      ],
      providers: [
        provideMockStore({}),
        { provide: DependentService, useClass: DependentServiceMock }
      ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA]
    })
      .overrideModule(BrowserDynamicTestingModule, {
        set: { entryComponents: [ConfirmModalComponent] }
      })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddEditDependentComponent);
    component = fixture.componentInstance;
    component.dependentForm = new FormGroup({
      firstName: new FormControl(),
      lastName: new FormControl(),
      dateOfBirth: new FormControl(),
      gender: new FormControl()
    });
    component.params = params;
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
  it('should call submitDependent funtion', () => {
    spyOn(component.dependentForm, 'valid').and.returnValue(true);
    component.dataCount = 2;
    component.submitDependent();
    expect(component as any).toBeDefined();
  });
  it('should call isSpouseAddCheck funtion', () => {
    component.isSpouseAddCheck();
    expect(component as any).toBeDefined();
  });
  it('should call getDependentDataEditModeCount funtion', () => {
    spyOn(component, 'getDependentDataEditModeCount').and.callThrough();
    component.getDependentDataEditModeCount();
    expect(component as any).toBeDefined();
  });
  it('should call deleteDependent funtion', () => {
    component.deleteDependent();
    expect(component as any).toBeDefined();
  });
});
