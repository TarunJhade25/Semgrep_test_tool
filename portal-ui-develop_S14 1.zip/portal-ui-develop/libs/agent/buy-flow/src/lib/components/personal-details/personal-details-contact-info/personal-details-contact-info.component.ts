import {
  Component,
  OnInit,
  Input,
  Output,
  EventEmitter,
  OnDestroy
} from '@angular/core';
import { PersonalDetailsService } from '../services/personal-details.service';
import { Subscription, Observable } from 'rxjs';
import { Store, select } from '@ngrx/store';
import { CmsService } from '@aflac/shared/cms';
import { buyFlowElementsSelector } from '@aflac/agent/shared';
import * as _ from 'lodash';

@Component({
  selector: 'aflac-personal-details-contact-info',
  templateUrl: './personal-details-contact-info.component.html',
  styleUrls: [
    './personal-details-contact-info.component.scss',
    '../personal-details.component.scss'
  ]
})
export class PersonalDetailsContactInfoComponent implements OnInit, OnDestroy {
  @Input() contactForm;
  @Input() isFromMemberPortal;
  @Output() formContactEvent = new EventEmitter<boolean>();
  userData: any;
  private subscriptions = new Subscription();
  personalData: any;
  route = '/my-details';
  data: any;
  appRoutes: any;
  buttonText: any = this.cmsService.getKey('lookup.personal_details_next_btn');
  constructor(
    public personalInfoService: PersonalDetailsService,
    private store: Store<any>,
    private cmsService: CmsService
  ) {
    //this.getUrlStructures();
  }

  ngOnInit() {
    this.personalData = this.personalInfoService.getPersonalData(this.route);
    const subs = this.personalData.subscribe(data => {
      if (
        !(
          this.data &&
          this.data.emails &&
          this.data.emails.length &&
          this.data.phones &&
          this.data.phones.length
        )
      ) {
        this.data = data;
        if (
          JSON.stringify(data) === '{}' ||
          !(
            data &&
            data.emails &&
            data.emails.length &&
            data.phones &&
            data.phones.length
          )
        ) {
          /* value setting for new prospect */
          this.userData = this.personalInfoService.getPrevCustomerData();
          if (!_.isEmpty(this.userData)) {
            const email =
              this.userData.emails && this.userData.emails.length > 0
                ? this.userData.emails[0].email
                : this.userData.email;
            this.contactForm.controls['email'].setValue(email);
          }
        } else {
          /* value seeting for returning customer/prospect*/
          this.setContactFormData();
        }
      }
    });
    this.subscriptions.add(subs);
  }

  keyPress(event: any) {
    const pattern = /[0-9]/;
    const inputChar = String.fromCharCode(event.charCode);

    if (!pattern.test(inputChar) || event.target.value.length > 9) {
      // invalid character, prevent input
      event.preventDefault();
    }
  }

  formChangeEvent() {
    this.contactForm.valueChanges.subscribe(val => {
      if (this.personalInfoService.buttonVisibleStatus.value) {
        if (this.contactForm.dirty) {
          this.personalInfoService.isFormValid.next(false);
          this.personalInfoService.isContactFormStatus.next(false);
        }
      }
      /*
      if (
        this.contactForm.valid &&
        this.personalInfoService.isMyInfoFormStatus.value &&
        this.personalInfoService.isAddressFormStatus.value
      ) {
        this.personalInfoService.isFormValid.next(true);
      } else {
        this.personalInfoService.isFormValid.next(false);
      } */
    });
  }

  onSubmit() {
    if (this.contactForm.valid) {
      const personalInfoData = {
        formData: this.personalInfoService.formateDataOnFormSubmit(
          null,
          null,
          this.contactForm,
          this.data
        ),
        customerId: this.data.customerNumber,
        statusOnComplete: 'contact-success'
      };
      this.saveDataOnContactSuccess(personalInfoData);
      this.formContactEvent.emit(true);
      this.personalInfoService.isShowContactForm.next(false);
      //this.personalInfoService.isContactFormView.next(true);
      //this.storeToSession('buyFlowElements');
    }
  }

  saveDataOnContactSuccess(contactJson) {
    if (
      this.personalInfoService.buttonVisibleStatus.value &&
      this.personalInfoService.isAddressFormStatus.value &&
      this.personalInfoService.isMyInfoFormStatus.value
    ) {
      this.personalInfoService.isFormValid.next(true);
    }

    this.personalInfoService.addUserDependentData(
      contactJson.formData,
      this.route
    );
    this.data = contactJson.formData;
    this.personalInfoService.isContactFormStatus.next(true);
  }

  toggleViewMode() {
    this.buttonText = this.cmsService.getKey(
      'lookup.find_plans_update_button_text'
    );
    this.personalInfoService.isShowContactForm.next(true);
    this.personalInfoService.isContactFormView.next(false);
    this.setContactFormData();
    this.personalInfoService.isContactFormStatus.next(false);
    this.personalInfoService.isFormValid.next(false);
    this.formChangeEvent();
  }

  //Prepopulate the data to form
  setContactFormData() {
    if (this.data.phones) {
      this.contactForm.controls['phone_number'].setValue(
        this.data.phones[0].phone
      );
      const eleCopy = this.data.isElectronicCopy
        ? this.data.isElectronicCopy
        : false;
      this.contactForm.controls['electronic_delivery'].setValue(eleCopy);
    }
    if (this.data.emails && this.data.emails.length > 0) {
      this.contactForm.controls['email'].setValue(this.data.emails[0].email);
      this.contactForm.controls['confirm_email'].setValue(
        this.data.emails[0].email
      );
    }
  }

  get f() {
    if (this.contactForm) {
      return this.contactForm.controls;
    }
  }

  /*
  public storeToSession(statename: string) {
    switch (statename) {
      case 'buyFlowElements': {
        this.store.select(buyFlowElementsSelector).subscribe(res => {
          if (res.length > 0) {
            sessionStorage.setItem(
              'state-agent-buy-flow-elements',
              JSON.stringify(res)
            );
          }
        });
        break;
      }
      default: {
        break;
      }
    }
  } */

  ngOnDestroy() {
    this.subscriptions.unsubscribe();
  }
}
