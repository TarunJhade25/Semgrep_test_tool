import { Component, OnInit, Inject } from '@angular/core';
import {
  MAT_DIALOG_DATA,
  MatDialogRef,
  MatDialog
} from '@angular/material/dialog';
import { Router } from '@angular/router';
import { Subscription } from 'rxjs';
import { Store, select } from '@ngrx/store';
import { ProductState, UpdateCartOnQuoteSave } from '@aflac/agent/shared';
import { PersonalDetailsService } from '../../../services/personal-details.service';
import { ShoppingCartService } from '@aflac/agent/shared';
@Component({
  selector: 'aflac-age-not-eligible-for-product',
  templateUrl: './age-not-eligible-for-product.component.html',
  styleUrls: ['./age-not-eligible-for-product.component.scss']
})
export class AgeNotEligibleForProductComponent implements OnInit {
  subscription = new Subscription();
  ageEligibilityData: any;
  popupMode: any;
  cartPremium: any = 0;
  currentPremium: any = 0;
  storeDetailsArray: any;
  storeDetailsFilteredArray: any;
  storeDetailsFilteredUpdatedArray: any = [];
  updatedCartSum: any;
  showAcceptContinueBtn = false;

  constructor(
    private router: Router,
    private productStore: Store<ProductState>,
    private personalInfoService: PersonalDetailsService,
    private shoppingCartService: ShoppingCartService,
    private dialogRef: MatDialogRef<AgeNotEligibleForProductComponent>,
    public dialog: MatDialog,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) {}

  ngOnInit() {
    this.ageEligibilityData = this.data && this.data.payload;
    this.showAcceptContinueBtn =
      this.data &&
      this.data.payload &&
      this.data.payload.src &&
      this.data.payload.src === 'order-review'
        ? true
        : false;
    //console.log('age elig popup : ', this.ageEligibilityData);
    this.popupMode = this.ageEligibilityData.mode === 'Exit' ? true : false;
    this.getStoreDetails();
    this.getProductPremiumChange();
  }

  getProductPremiumChange() {
    if (this.ageEligibilityData) {
      if (
        this.ageEligibilityData.cartProducts &&
        this.ageEligibilityData.cartProducts.length > 0
      ) {
        let cartRiderPremium = 0,
          cartProductTotalPremium = 0;
        this.ageEligibilityData.cartProducts.map(cartItem => {
          // Sum cart total premium plan+riders start
          if (cartItem.riders && cartItem.riders.length > 0) {
            cartRiderPremium = cartItem.riders.reduce(
              (a, b) => a + b.rider.price,
              0
            );
            //console.log('riderSum : ', cartRiderPremium);
          }
          cartProductTotalPremium =
            Number(cartRiderPremium) + Number(cartItem.monthlyPremium);
          //console.log('cartProductTotalPremium : ' + cartProductTotalPremium);
          // Sum cart total premium plan+riders end
          this.cartPremium += cartProductTotalPremium;
        });
      }
      if (
        this.ageEligibilityData.ageEligibilityDetails &&
        this.ageEligibilityData.ageEligibilityDetails.length > 0
      ) {
        this.ageEligibilityData.ageEligibilityDetails.map(item => {
          this.currentPremium += item.currentPremium;
        });
      }
    }
  }

  getStoreDetails() {
    this.subscription = this.personalInfoService
      .getCartData()
      .subscribe(res => {
        if (res !== undefined && res.value && res.value.length > 0) {
          this.storeDetailsArray = res.value;
        }
      });
  }

  filterProductInEligible() {
    if (this.storeDetailsArray && this.storeDetailsArray.length > 0) {
      this.storeDetailsFilteredArray = this.storeDetailsArray.filter(
        ({ productId: id1 }) =>
          !this.ageEligibilityData.ageInEligibilityDetails.some(
            ({ productId: id2 }) => id2 === id1
          )
      );
    }
  }

  updateCartPremium() {
    let planPremium = 0;
    if (
      this.storeDetailsFilteredArray &&
      this.storeDetailsFilteredArray.length > 0
    ) {
      this.storeDetailsFilteredArray.map(cartItem => {
        const cloneCartItem = Object.assign({}, cartItem);
        const cloneCartPlanItem = Object.assign({}, cartItem.plan);
        if (
          this.ageEligibilityData.agePremiumChangeDetails &&
          this.ageEligibilityData.agePremiumChangeDetails.length > 0
        ) {
          this.ageEligibilityData.agePremiumChangeDetails.map(premiumItem => {
            if (cartItem.productId === premiumItem.productId) {
              let newRiderPremium = 0;
              if (
                cartItem.selectedRiders &&
                cartItem.selectedRiders.length > 0
              ) {
                cloneCartItem['selectedRiders'] = [];
                cartItem.selectedRiders.forEach(cartRiderItem => {
                  const cloneCartSelectedRiderItem = Object.assign(
                    {},
                    cartRiderItem
                  );
                  const cloneCartRiderItem = Object.assign(
                    {},
                    cartRiderItem.rider
                  );
                  if (premiumItem.riders && premiumItem.riders.length > 0) {
                    const premiumRiderItemObj = premiumItem.riders.find(
                      premiumRiderItem =>
                        premiumRiderItem.riderNameCd ===
                        cartRiderItem.rider.title
                    );
                    if (premiumRiderItemObj) {
                      cloneCartRiderItem['price'] =
                        premiumRiderItemObj.monthlyPremium;
                    }
                    cloneCartSelectedRiderItem['rider'] = cloneCartRiderItem;
                    cloneCartItem['selectedRiders'].push(
                      cloneCartSelectedRiderItem
                    );
                  }
                });
                newRiderPremium = premiumItem.riders.reduce(
                  (a, b) => a + b.monthlyPremium,
                  0
                );
              }
              planPremium =
                premiumItem.currentPremium >= newRiderPremium
                  ? premiumItem.currentPremium - newRiderPremium
                  : premiumItem.currentPremium;
              cloneCartPlanItem.price = planPremium.toFixed(2);
              cloneCartItem['plan'] = cloneCartPlanItem;
              cartItem = cloneCartItem;
              //console.log('cartItem : ', cartItem);
            }
          });
        }
        this.storeDetailsFilteredUpdatedArray.push(cartItem);
      });
    }
  }

  goBackAndEdit() {
    this.dialogRef.close('goback');
  }
  onSubmit() {
    this.filterProductInEligible();
    this.updateCartPremium();
    this.dialogRef.close(this.ageEligibilityData);
    this.updateCartWithEligibleQuote(this.storeDetailsFilteredUpdatedArray);
  }

  updateCartWithEligibleQuote(quote) {
    const cartSum = this.personalInfoService.fetchUpdatedSum(quote);
    //console.log('quote : ', quote);
    const cartPayload = {
      key: 'from-list',
      value: quote
    };
    const headerPayload = {
      price: cartSum,
      count: quote.length
    };
    this.productStore.dispatch(UpdateCartOnQuoteSave({ payload: cartPayload }));
    this.shoppingCartService.updateShoppingCartPrice(headerPayload);
  }
}
