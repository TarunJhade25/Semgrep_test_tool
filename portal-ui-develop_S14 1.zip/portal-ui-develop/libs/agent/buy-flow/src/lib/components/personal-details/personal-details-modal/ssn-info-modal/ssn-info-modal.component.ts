import { Component, OnInit, Inject } from '@angular/core';
import { PerfectScrollbarConfigInterface } from 'ngx-perfect-scrollbar';
import { Subject } from 'rxjs';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';

@Component({
  selector: 'aflac-ssn-info-modal',
  templateUrl: './ssn-info-modal.component.html',
  styleUrls: ['./ssn-info-modal.component.scss']
})
export class SsnInfoModalComponent implements OnInit {
  title: string;
  closeBtnName: string;
  public config: PerfectScrollbarConfigInterface = {
    scrollingThreshold: 0,
    minScrollbarLength: 148,
    maxScrollbarLength: 148,
    wheelSpeed: 0.6
  };
  contentTitleOne: string;
  contentDataOne: string;
  contentTitleTwo: string;
  contentDataTwoParaOne: string;
  contentDataTwoParaTwo: string;
  public onClose: Subject<boolean>;

  constructor(
    public dialogRef: MatDialogRef<SsnInfoModalComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) {}

  ngOnInit() {}

  hideModal() {
    this.dialogRef.close(true);
  }
}
