import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { RouterModule } from '@angular/router';
import { StatementPolicyDocsComponent } from './statement-policy-docs.component';
import { Store } from '@ngrx/store';
import { SaveYourQuoteState } from '@aflac/agent/shared'; //stores
import { selectUserDetailsFromAgent } from '@aflac/agent/shared';
import { provideMockStore, MockStore } from '@ngrx/store/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { BuyFlowService } from '../../../../services/buy-flow.service';
import { CheckoutService } from '../../services/checkout.service';
import { of, Observable } from 'rxjs';

describe('StatementPolicyDocsComponent', () => {
  let component: StatementPolicyDocsComponent;
  let fixture: ComponentFixture<StatementPolicyDocsComponent>;
  let mockStore: MockStore<SaveYourQuoteState>;
  const mockSelectUserDetailsFromAgent = {
    quoteDetails: [
      { productCd: 'PREC-IC', quoteNumber: 193, bundleId: 1 },
      { productCd: 'PREC-IA', quoteNumber: 192, bundleId: 1 }
    ],

    customerDetails: []
  };

  const cartData = {
    key: 'from-list',
    value: [
      {
        productId: 'PREC-IC',
        productName: 'Accident',
        plan: {
          id: 123,
          price: '100',
          description: 'These are the benefits',
          name: 'Lorem ipsum',
          states: ['AL', 'CT'],
          title: 'Standard Plan',
          benefits: [
            {
              id: 333,
              name: 'test',
              price: 123
            }
          ]
        },
        coverage: 'ind',
        selected: true,
        availableInCart: true,
        selectedRiders: [
          {
            rider: { title: 'title1', price: '100' },
            selected: true,
            availableInCart: true,
            plan: { id: 'id1' }
          },
          {
            rider: { title: 'title2', price: '200' },
            selected: true,
            availableInCart: true,
            plan: { id: 'id1' }
          }
        ]
      }
    ]
  };
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [StatementPolicyDocsComponent],
      imports: [RouterTestingModule, HttpClientTestingModule],
      providers: [
        provideMockStore({}),
        { provide: BuyFlowService, useClass: MockBuyflowService },
        { provide: CheckoutService, useClass: MockCheckoutService }
      ]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(StatementPolicyDocsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
    mockStore = TestBed.get(Store);
    mockStore.overrideSelector(
      selectUserDetailsFromAgent,
      mockSelectUserDetailsFromAgent
    );
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
  class MockBuyflowService {
    getCartData(): Observable<any> {
      return of(cartData);
    }
  }
  class MockCheckoutService {}
});
