import { Component, OnInit } from '@angular/core';
import { BuyFlowService } from '../../services/buy-flow.service';
import { Router } from '@angular/router';
import { CheckoutService } from '../checkout/services/checkout.service';
@Component({
  selector: 'aflac-eligibility',
  templateUrl: './eligibility.component.html',
  styleUrls: ['./eligibility.component.scss']
})
export class EligibilityComponent implements OnInit {
  route = '/eligibility';
  constructor(
    public buyFlowService: BuyFlowService,
    private router: Router,
    private checkoutService: CheckoutService
  ) {}

  ngOnInit() {
    this.route = this.router.url;
    this.buyFlowService.enableStepperByRoute(this.route);
  }

  saveEligibility() {
    this.buyFlowService.completeCurrentStepAndMoveToNext(this.route);
  }
}
