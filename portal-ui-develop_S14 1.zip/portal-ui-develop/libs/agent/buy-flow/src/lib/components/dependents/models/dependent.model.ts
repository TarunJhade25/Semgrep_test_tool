export interface IDependent {
  oid: string;
  firstName: string;
  lastName: string;
  editMode: boolean;
  dateOfBirth: string;
  gender?: string;
  selected?: boolean;
  customerNumber?: string;
  genderTitle?: string;
  invalid?: boolean;
}
