import { Injectable } from '@angular/core';
import { Store, select } from '@ngrx/store';
import { SaveYourQuoteState } from '@aflac/agent/shared';
import {
  dependentDataByRouteSelector,
  buyFlowElementsSelector,
  dependentRelationshipDataSelector
} from '@aflac/agent/shared'; // Selectors
import { first, take } from 'rxjs/operators';
import {
  updateBuyFlowElements,
  getPersonalDetails,
  getDependentRelationships
} from '@aflac/agent/shared'; // Actions
import { FieldValidator } from '@aflac/shared/validators';
import { FormBuilder } from '@angular/forms';
import { BehaviorSubject } from 'rxjs';
import { BuyFlowService } from '../../../services/buy-flow.service';
import { getTreeMultipleDefaultNodeDefsError } from '@angular/cdk/tree';

@Injectable({
  providedIn: 'root'
})
export class DependentService {
  constructor(
    private store: Store<SaveYourQuoteState>,
    private fb: FormBuilder,
    public buyFlowService: BuyFlowService
  ) {}
  public isAddChild = new BehaviorSubject(true);
  public isFormValid = new BehaviorSubject(false);
  public disableNextProduct = new BehaviorSubject(false);
  public userType = new BehaviorSubject('new');
  public buyFlowElementSelectorObj$ = this.store.pipe(
    select(buyFlowElementsSelector),
    first()
  );

  getDependentData(route) {
    return this.store.pipe(select(dependentDataByRouteSelector, route));
  }

  setPersonalData(custNumber) {
    this.store.dispatch(getPersonalDetails({ customerId: custNumber }));
  }
  setDependentRelationshipData(custNumber) {
    this.store.dispatch(getDependentRelationships({ customerId: custNumber }));
  }

  getDependentRelationshipData() {
    return this.store.pipe(
      select(dependentRelationshipDataSelector),
      take(2)
    );
  }

  convertDateFormat(date) {
    const newDate = new Date(date);
    return (
      ('0' + (newDate.getMonth() + 1)).slice(-2) +
      '/' +
      ('0' + newDate.getDate()).slice(-2) +
      '/' +
      newDate.getFullYear()
    );
  }

  getRandomId() {
    return Math.random()
      .toString(36)
      .substr(2, 10);
  }

  getDependentForm(params, dependentEdited?) {
    let oid = '';
    let firstName = '';
    let lastName = '';
    let dateOfBirth = '';
    let gender = '';
    let selected = true;
    let addedDate = Date.now();

    if (params.dependentData && Object.keys(params.dependentData).length > 0) {
      const data = params.dependentData[params.parentIndex];
      if (params.type === 'spouse' && data.spouse) {
        firstName = data.spouse.firstName;
        lastName = data.spouse.lastName;
        dateOfBirth = this.convertDateFormat(data.spouse.dateOfBirth);
        gender = data.spouse.gender;
        oid = data.spouse.oid;
        selected = dependentEdited ? data.spouse.selected : selected;
      }
      if (params.type === 'child' && data.children) {
        firstName = data.children[params.index].firstName;
        lastName = data.children[params.index].lastName;
        dateOfBirth = this.convertDateFormat(
          data.children[params.index].dateOfBirth
        );
        oid = data.children[params.index].oid;
        selected = data.children[params.index].selected;
        addedDate = data.children[params.index].addedDate;
      }
    } else {
      oid = this.getRandomId();
    }

    return this.fb.group({
      firstName: [
        firstName,
        [
          FieldValidator.isEmpty(
            'agent_portal.save_quote_first_name_required_error'
          ),
          FieldValidator.patternValidator(
            /^[a-zA-Z ]*$/,
            'lookup.save_your_quote_fname_nonalphabet_error'
          )
        ]
      ],
      lastName: [
        lastName,
        [
          FieldValidator.isEmpty(
            'agent_portal.save_quote_last_name_required_error'
          ),
          FieldValidator.patternValidator(
            /^[a-zA-Z ]*$/,
            'lookup.save_your_quote_lname_nonalphabet_error'
          )
        ]
      ],
      dateOfBirth: [
        dateOfBirth,
        params && params.type === 'spouse'
          ? [
              FieldValidator.isEmpty(
                'agent_portal.personal_details_dob_required_error'
              ),
              FieldValidator.patternValidator(
                /^((0?[1-9]|1[012])[- /.](0?[1-9]|[12][0-9]|3[01])[- /.][0-9]{4})*$/,
                'agent_portal.buy_flow_dob_format_error'
              ),
              FieldValidator.ageRangeValidator(
                18,
                99,
                'lookup.find_plans_age_error_minimum',
                'agent_portal.buy_flow_dob_future_error'
              )
            ]
          : [
              FieldValidator.isEmpty(
                'agent_portal.personal_details_dob_required_error'
              ),
              FieldValidator.patternValidator(
                /^((0?[1-9]|1[012])[- /.](0?[1-9]|[12][0-9]|3[01])[- /.][0-9]{4})*$/,
                'agent_portal.buy_flow_dob_format_error'
              ),
              FieldValidator.ageRangeValidator(
                0,
                99,
                'agent_portal.dependent_child_age_validation',
                'agent_portal.buy_flow_dob_future_error'
              ),
              FieldValidator.futureAgeValidator(
                'agent_portal.buy_flow_dob_format_error',
                'agent_portal.buy_flow_dob_future_error'
              )
            ]
      ],
      gender: [
        gender,
        params && params.type === 'spouse'
          ? [
              FieldValidator.isEmpty(
                'agent_portal.personal_details_gender_required_error'
              )
            ]
          : []
      ],
      oid: [oid],
      selected: [selected],
      addedDate: [addedDate]
    });
  }

  setDependentData(formValue, params) {
    this.store
      .pipe(
        select(buyFlowElementsSelector),
        first()
      )
      .subscribe(data => {
        const buySteps = JSON.parse(JSON.stringify(data));
        if (params.type === 'spouse') {
          buySteps.forEach((value, index) => {
            if (value.link === params.route) {
              if (!buySteps[index].data[params.parentIndex])
                buySteps[index].data[params.parentIndex] = {};
              // Edit mode
              if (
                params.dependentData &&
                params.dependentData[params.parentIndex] &&
                params.dependentData[params.parentIndex].spouse &&
                params.dependentData[params.parentIndex].spouse.editMode ===
                  true &&
                formValue != null
              ) {
                Object.keys(buySteps[index].data).forEach(key => {
                  if (buySteps[index].data[key].spouse) {
                    const formValueModSpouse = { ...formValue };
                    formValueModSpouse['selected'] =
                      buySteps[index].data[key].spouse.selected;
                    buySteps[index].data[key].spouse = formValueModSpouse;
                  }
                });
              } else {
                // Add
                if (formValue != null) {
                  buySteps[index].data[params.parentIndex].spouse = formValue;
                } else
                  buySteps[index].data[
                    params.parentIndex
                  ].spouse.editMode = true;
              }
            }
          });
        } else {
          buySteps.forEach((value, index) => {
            if (value.link === params.route) {
              // Edit mode
              if (
                params.dependentData &&
                params.dependentData[params.parentIndex] &&
                params.dependentData[params.parentIndex].children &&
                params.dependentData[params.parentIndex].children[
                  params.index
                ] &&
                formValue != null
              ) {
                const currentChild =
                  params.dependentData[params.parentIndex].children[
                    params.index
                  ];
                if (currentChild.editMode === true) {
                  Object.keys(buySteps[index].data).forEach(key => {
                    if (
                      buySteps[index].data[key] &&
                      buySteps[index].data[key].children
                    ) {
                      buySteps[index].data[key].children = buySteps[index].data[
                        key
                      ].children.map(item => {
                        let itemMod = Object.assign({}, item);
                        if (item.oid === currentChild.oid) {
                          const formValueMod = { ...formValue };
                          formValueMod['selected'] = item.selected;
                          itemMod = formValueMod;
                        }
                        return (item = itemMod);
                      });
                    }
                  });
                }
              } else {
                // Add
                if (formValue !== null) {
                  if (
                    params.index !== null &&
                    buySteps[index].data[params.parentIndex] &&
                    buySteps[index].data[params.parentIndex].children[
                      params.index
                    ]
                  ) {
                    buySteps[index].data[params.parentIndex].children[
                      params.index
                    ] = formValue;
                  } else if (
                    buySteps[index].data[params.parentIndex] &&
                    buySteps[index].data[params.parentIndex].children
                  ) {
                    buySteps[index].data[params.parentIndex].children.push(
                      formValue
                    );
                  } else if (Object.keys(buySteps[index].data).length === 0) {
                    buySteps[index].data[params.parentIndex] = {};
                    buySteps[index].data[params.parentIndex].children = [
                      formValue
                    ];
                  } else if (buySteps[index].data[params.parentIndex]) {
                    buySteps[index].data[params.parentIndex].children = [
                      formValue
                    ];
                  } else {
                    buySteps[index].data[params.parentIndex] = {};
                    buySteps[index].data[params.parentIndex].children = [
                      formValue
                    ];
                  }
                } else {
                  buySteps[index].data[params.parentIndex].children[
                    params.index
                  ].editMode = true;
                }
              }
            }
          });
        }
        this.store.dispatch(updateBuyFlowElements({ payload: buySteps }));
      });
  }

  submitDependent(dependentForm, param) {
    if (dependentForm.valid) {
      if (param.type === 'spouse') {
        const spouse = { ...dependentForm.value };
        spouse.editMode = false;
        spouse.relationshipToPrimaryInsuredCd = '1';
        this.setDependentData(spouse, param);
      } else {
        const child = { ...dependentForm.value };
        child.editMode = false;
        child.relationshipToPrimaryInsuredCd = '2';
        this.setDependentData(child, param);
      }
    } else {
      return false;
    }
  }

  deleteChildByIndex(params, dependentEdited?) {
    let childList = [];
    this.store
      .pipe(
        select(buyFlowElementsSelector),
        first()
      )
      .subscribe(data => {
        const buySteps = JSON.parse(JSON.stringify(data));
        buySteps.forEach((value, index) => {
          if (value.link === params.route) {
            childList = [...buySteps[index].data[params.parentIndex].children];
            childList.splice(params.index, 1);
            // Update checkbox selection to true if only 2 children with one child is gonna delete
            if (childList.length === 1 && !dependentEdited) {
              childList[0]['selected'] = true;
            }
            buySteps[index].data[params.parentIndex].children = [...childList];
            this.store.dispatch(updateBuyFlowElements({ payload: buySteps }));
          }
        });
      });
  }

  getSaveDependentParams(dependents, userData) {
    const results = {
      productCode: userData.id,
      coverageTypeCd: userData.coverageType,
      packageCd: userData.planCode,
      riskStateCd: userData.state,
      insureds: []
    };
    if (dependents && dependents.spouse) {
      results.insureds.push({
        relationshipRole: 'SPOUSE',
        firstName: dependents.spouse.firstName,
        lastName: dependents.spouse.lastName,
        dateOfBirth: dependents.spouse.dob,
        genderCd: dependents.spouse.gender
      });
    }
    if (dependents && dependents.children) {
      dependents.children.forEach(element => {
        results.insureds.push({
          relationshipRole: 'CHILD',
          firstName: element.firstName,
          lastName: element.lastName,
          dateOfBirth: element.dob
        });
      });
    }
    return results;
  }

  addUserDependentData(
    userData,
    route,
    cartData,
    coverageArray,
    depRelationshipTypes,
    spFlag,
    productId
  ) {
    /*
    console.log('userData in DS : ', userData);
    console.log('cartData in DS : ', cartData);
    console.log('coverageArray in DS : ', coverageArray);
    console.log('depRelationshipTypes in DS : ', depRelationshipTypes);
    console.log('productId in DS : ', productId);
    */

    const spouseFlag = spFlag
      ? spFlag
      : depRelationshipTypes.includes('SPOUSE')
      ? true
      : false;
    const childFlag = depRelationshipTypes.includes('CHILD') ? true : false;
    const coverageIncludes =
      coverageArray.includes('ind_fml') || coverageArray.includes('ind_sps')
        ? true
        : false;
    const coverageChildIncludes =
      coverageArray.includes('ind_fml') || coverageArray.includes('ind_chd')
        ? true
        : false;
    if (coverageChildIncludes && !childFlag) productId = cartData[0].productId;
    this.store
      .pipe(
        select(buyFlowElementsSelector),
        first()
      )
      .subscribe(data => {
        const buySteps = JSON.parse(JSON.stringify(data));
        //console.log('buySteps : ', buySteps);
        buySteps.forEach((value, index) => {
          if (value.link === route && userData) {
            if (!productId) {
              //console.log('if');
              cartData.map(cData => {
                if (cData.coverage !== 'ind') {
                  this.updateExistingDependentData(
                    userData,
                    spouseFlag,
                    coverageIncludes,
                    cData,
                    buySteps,
                    index
                  );
                }
                // Filter if no data for a product
                if (
                  buySteps[index].data[cData.productId] &&
                  Object.keys(buySteps[index].data[cData.productId]).length ===
                    0
                ) {
                  delete buySteps[index].data[cData.productId];
                }
              });
            } else {
              //console.log('else buySteps : ', buySteps);
              const cData = cartData.filter(
                item => item.productId === productId
              );
              this.updateExistingDependentData(
                userData,
                spouseFlag,
                coverageIncludes,
                cData[0],
                buySteps,
                index
              );
            }
          }
        });
        this.store.dispatch(updateBuyFlowElements({ payload: buySteps }));
      });
  }

  updateExistingDependentData(
    userData,
    spouseFlag,
    coverageIncludes,
    cData,
    buySteps,
    index
  ) {
    /*
    console.log('userData : ', userData);
    console.log('spouseFlag : ', spouseFlag);
    console.log('coverageIncludes : ', coverageIncludes);
    console.log('cData : ', cData.productId);
    console.log('buySteps : ', buySteps[index].data);
    */

    if (!buySteps[index].data[cData.productId])
      buySteps[index].data[cData.productId] = {};
    userData.forEach(dependent => {
      if (dependent.relationshipRole === 'SPOUSE') {
        spouseFlag = true;
        coverageIncludes = true;
        const newDependent = { ...dependent };
        for (const key in newDependent) {
          if (newDependent.hasOwnProperty(key)) {
            /*
            if (newDependent[key] === 'Male') newDependent[key] = 'M';
            if (newDependent[key] === 'Female') newDependent[key] = 'F';
            if (newDependent[key] === 'Other') newDependent[key] = 'X';
            */
            if (key === 'genderCd')
              newDependent['gender'] = newDependent['genderCd'];
            newDependent['selected'] = true;
            newDependent['oid'] = dependent.oid
              ? dependent.oid
              : dependent.customerNumber;
          }
        }
        if (cData.coverage !== 'ind_chd') {
          buySteps[index].data[cData.productId].spouse = {
            ...newDependent,
            ...{ editMode: false }
          };
        }
      } else {
        //console.log('spouseFlag : ', spouseFlag);
        //console.log('coverageIncludes : ', coverageIncludes);
        //console.log('cData.coverage : ', cData.coverage);
        if (!coverageIncludes || (coverageIncludes && spouseFlag)) {
          const newChildDependent = { ...dependent };
          newChildDependent['selected'] = true;
          newChildDependent['oid'] = dependent.oid
            ? dependent.oid
            : dependent.customerNumber;
          newChildDependent['editMode'] = false;
          if (cData.coverage !== 'ind_sps') {
            if (
              buySteps[index].data[cData.productId] &&
              buySteps[index].data[cData.productId].children
            ) {
              buySteps[index].data[cData.productId].children.push(
                newChildDependent
              );
            } else {
              buySteps[index].data[cData.productId].children = [
                newChildDependent
              ];
            }
          }
        }
      }
    });
    //console.log('buySteps final : ', buySteps[index].data);
    //this.store.dispatch(updateBuyFlowElements({ payload: buySteps }));
  }

  addUserDependentDataFromBundle(userData, route) {
    //console.log('userData in DS : ', userData);
    this.store
      .pipe(
        select(buyFlowElementsSelector),
        first()
      )
      .subscribe(data => {
        const buySteps = JSON.parse(JSON.stringify(data));
        buySteps.forEach((value, index) => {
          if (value.link === route && userData) {
            buySteps[index].data = userData;
          }
        });
        this.store.dispatch(updateBuyFlowElements({ payload: buySteps }));
      });
  }

  updateSelectedChildData(childSelected, params) {
    this.buyFlowElementSelectorObj$.subscribe(buyFlowData => {
      const buySteps = JSON.parse(JSON.stringify(buyFlowData));
      buySteps.forEach((value, index) => {
        if (value.link === params.route) {
          if (params.type === 'child') {
            if (
              buySteps[index].data[params.parentIndex] &&
              buySteps[index].data[params.parentIndex].children &&
              buySteps[index].data[params.parentIndex].children[params.index]
            ) {
              buySteps[index].data[params.parentIndex].children[
                params.index
              ].selected = childSelected;
            }
          } else if (params.type === 'spouse') {
            if (
              buySteps[index].data[params.parentIndex] &&
              buySteps[index].data[params.parentIndex].spouse
            ) {
              buySteps[index].data[
                params.parentIndex
              ].spouse.selected = childSelected;
            }
          }
        }
      });
      this.store.dispatch(updateBuyFlowElements({ payload: buySteps }));
    });
  }

  createDependentArrayWithQuoteNumber(dependentsDetails, bundleData) {
    const modifiedDepArray = [];
    const productKeysArray = Object.keys(dependentsDetails);
    productKeysArray.map(productId => {
      const quoteNumData = this.findQuoteNumber(productId, bundleData);
      const modifiedDepObj = {
        dependents: this.findDependents(productId, dependentsDetails),
        quoteNumber: quoteNumData && quoteNumData.quoteNumber,
        productCd: this.findQuoteNumber(productId, bundleData).productCd
      };
      modifiedDepArray.push(modifiedDepObj);
    });
    return modifiedDepArray;
  }

  findDependents(productId, dependentsDetails) {
    const depDataMod = dependentsDetails[productId];
    const depDataModClone = Object.assign({}, depDataMod);
    if (depDataMod) {
      if (depDataMod.spouse && depDataMod.spouse.selected)
        depDataModClone['spouse'] = depDataMod.spouse;
      if (depDataMod.children)
        depDataModClone['children'] = depDataMod.children.filter(
          item => item.selected
        );
    }
    return depDataModClone;
  }

  findQuoteNumber(productId, bundleData) {
    let quoteNumber, productCd;
    const currentProduct = bundleData.filter(e => e.productCode === productId);

    if (currentProduct && currentProduct.length > 0) {
      quoteNumber = currentProduct[0].quoteNumber;
      productCd = currentProduct[0].productCode;
    }
    return {
      quoteNumber: quoteNumber,
      productCd: productCd
    };
  }
}
