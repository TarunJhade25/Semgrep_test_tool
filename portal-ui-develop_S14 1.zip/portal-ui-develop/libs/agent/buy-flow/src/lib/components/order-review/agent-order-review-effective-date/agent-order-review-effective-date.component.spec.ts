import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { AgentOrderReviewEffectiveDateComponent } from './agent-order-review-effective-date.component';
import { TranslateModule } from '@ngx-translate/core';
import { MatDialogModule } from '@angular/material/dialog';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { SharedMaterialModule } from '@aflac/shared/material';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { StoreModule, MemoizedSelector } from '@ngrx/store';
import { MockStore, provideMockStore } from '@ngrx/store/testing';
import { ProductState, ProductReducer } from '@aflac/agent/shared';
import { SaveYourQuoteState, getEffectiveDate } from '@aflac/agent/shared'; //stores
import { Store, select } from '@ngrx/store';

describe('AgentOrderReviewEffectiveDateComponent', () => {
  let component: AgentOrderReviewEffectiveDateComponent;
  let fixture: ComponentFixture<AgentOrderReviewEffectiveDateComponent>;
  let mockStore: MockStore<SaveYourQuoteState>;
  // beforeEach(async(() => {
  //   TestBed.configureTestingModule({
  //     declarations: [AgentOrderReviewEffectiveDateComponent]
  //   }).compileComponents();
  // }));
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        TranslateModule.forRoot(),
        MatDialogModule,
        StoreModule.forRoot(ProductReducer),
        BrowserAnimationsModule,
        SharedMaterialModule,
        FormsModule,
        ReactiveFormsModule
      ],
      declarations: [AgentOrderReviewEffectiveDateComponent],
      schemas: [CUSTOM_ELEMENTS_SCHEMA]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AgentOrderReviewEffectiveDateComponent);
    mockStore = TestBed.get(Store);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
