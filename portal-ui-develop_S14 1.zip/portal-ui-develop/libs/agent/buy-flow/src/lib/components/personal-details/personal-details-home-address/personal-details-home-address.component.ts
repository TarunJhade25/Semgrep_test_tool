import {
  Component,
  OnInit,
  Input,
  Output,
  EventEmitter,
  OnDestroy
} from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { CmsService } from '@aflac/shared/cms';
import { States } from '@aflac/shared/data-model';
import { Observable, Subscription } from 'rxjs';
import { Store, select } from '@ngrx/store';
import { Router } from '@angular/router';
import { PersonalDetailsService } from '../services/personal-details.service';
import { SaveYourQuoteState } from '@aflac/agent/shared';
import { HomeAddressModelComponent } from '../personal-details-modal/home-address-model/home-address-model.component';
import { buyFlowElementsSelector } from '@aflac/agent/shared';
import { AddressValidationObj } from '@aflac/agent/shared';
import { BuyFlowService } from '../../../services/buy-flow.service';
import { urlConfig } from '@aflac/shared/data-model';
import * as _ from 'lodash';

@Component({
  selector: 'aflac-personal-details-home-address',
  templateUrl: './personal-details-home-address.component.html',
  styleUrls: [
    './personal-details-home-address.component.scss',
    '../personal-details.component.scss'
  ]
})
export class PersonalDetailsHomeAddressComponent implements OnInit, OnDestroy {
  isEdit = false;
  errorStatus = true;
  errorText: any;
  @Input() addressForm;
  @Input() isFromMemberPortal;
  @Output() formAddressEvent = new EventEmitter<boolean>();
  states$: Observable<States[]>;
  us_states: any = [];
  selectedState: any;
  addressInfo: any = {};
  addressViewTitle: string;
  addressViewContent: string;
  pattern = { Y: { pattern: new RegExp('\\d') } };
  buttonText: any = this.cmsService.getKey('lookup.personal_details_next_btn');

  route = '/my-details';
  userData: Observable<any>;
  private subscriptions = new Subscription();
  private initialSubscriptions = new Subscription();
  personalData: any;
  data: any;
  disableBtn = true;
  addressVal: string;
  formValueEvent: any;
  appRoutes: any;
  currentRoute: string;
  envName = urlConfig.envName;
  constructor(
    public dialog: MatDialog,
    private cmsService: CmsService,
    private store: Store<SaveYourQuoteState>,
    public personalInfoService: PersonalDetailsService,
    private router: Router,
    public buyFlowService: BuyFlowService
  ) {
    //this.getUrlStructures();
  }

  ngOnInit() {
    this.currentRoute = this.router.url;
    const stateSub = this.cmsService.getKey('lookup').subscribe(lookup => {
      this.us_states = lookup.us_states;
      if (this.us_states && this.us_states.length) {
        this.personalData = this.personalInfoService.getPersonalData(
          this.route
        );
        const subs = this.personalData.subscribe(data => {
          if (
            !(this.data && this.data.addresses && this.data.addresses.length)
          ) {
            this.data = data;
            if (
              JSON.stringify(data) === '{}' ||
              !(data && data.addresses && data.addresses.length)
            ) {
              // value setting for new prospect
              this.setFormDataForNewProspect();
            } else {
              // value setting for returning customer/prospect
              this.isEdit = false;
              if (this.us_states && this.us_states.length) {
                this.selectedState = this.getSelectedState(this.data, false);
                this.setAddressFormControlData();
              }
            }
            this.updateViewModeData();
          } else {
            if (this.personalInfoService.buttonVisibleStatus.value) {
              if (this.addressForm.dirty && this.isEdit) {
                this.personalInfoService.isFormValid.next(false);
              }
            }
          }
        });
        this.subscriptions.add(subs);
      }
    });
    this.subscriptions.add(stateSub);
  }

  setFormDataForNewProspect() {
    this.isEdit = true;
    this.userData = this.personalInfoService.getUserDataFomSaveQuoteResponse();
    const subs = this.userData.subscribe(data => {
      if (!_.isEmpty(data) && this.us_states && this.us_states.length) {
        this.selectedState = this.getSelectedState(data, true);
        if (this.selectedState && this.selectedState.length) {
          this.addressForm.controls['stateProvCd'].setValue(
            this.selectedState[0].code
          );
          this.addressForm.get('stateProvCd').disable();
        }
      } else {
        const searchQuoteSub = this.buyFlowService.getAgentSearchQuote();
        if (searchQuoteSub) {
          this.addressForm.controls['stateProvCd'].setValue(
            searchQuoteSub.stateProvCd
          );
          this.addressForm.get('stateProvCd').disable();
        }
      }
    });
    this.subscriptions.add(subs);
  }

  public setAddressFormControlData() {
    const {
      addressLine1,
      addressLine2,
      city,
      zipCode
    } = this.data.addresses[0];
    const controls = this.addressForm.controls;
    this.addressForm.get('stateProvCd').disable();
    controls['addressLine1'].setValue(addressLine1);
    controls['addressLine2'].setValue(addressLine2);
    controls['city'].setValue(city);
    controls['zipCode'].setValue(zipCode);
    controls['stateProvCd'].setValue(this.selectedState[0].code);
  }

  focusFunction() {
    this.disableBtn = true;
  }

  newAddressConfirmationPop(data) {
    const initialState = {
      contentText1: this.cmsService.getKey('lookup.home_adrress_modal_content')
        .value,
      contentText: this.getAddressStr(data).address1,
      statecontent: this.getAddressStr(data).address2,
      contentNewAddressbuttontext: this.cmsService.getKey(
        'lookup.home_address_modal_new_button'
      ).value,
      contentGobackbuttontext: this.cmsService.getKey(
        'lookup.personal_details_home_address_update_button_label'
      ).value
    };
    const dialogRef = this.dialog.open(HomeAddressModelComponent, {
      disableClose: true,
      data: {
        initialState
      },
      panelClass: 'address-modal-resizer'
    });
  }

  onSubmit() {
    let street, street2, zip, city;
    if (this.addressForm.valid) {
      street = this.addressForm.getRawValue().addressLine1;
      street2 = this.addressForm.getRawValue().addressLine2;
      zip = this.addressForm.getRawValue().zipCode;
      city = this.addressForm.getRawValue().city;
      const addressValObj: AddressValidationObj = {
        street: street,
        street2: street2,
        zip: zip,
        city: city,
        state: this.addressForm.getRawValue().stateProvCd
      };
      this.personalInfoService.setAddressFormData(addressValObj);
      // TODO - to bypass address validation
      if (this.envName !== 'local' && this.envName !== 'dev') {
        this.personalInfoService
          .PostAddressForValidation$(addressValObj)
          .subscribe(data => {
            const obj: any = this.personalInfoService.returnAddressValidation(
              data.lookupReturnCode
            );
            this.errorStatus = obj.errorStatus;
            this.errorText = data.lookupReturnDescription;
            this.disableBtn = obj.ctaStatus;
            // if (
            //   this.personalInfoService.returnAddressValidation(
            //     data.lookupReturnCode
            //   ).ctaStatus &&
            //   !this.personalInfoService.returnAddressValidation(
            //     data.lookupReturnCode
            //   ).errorStatus
            // ) {
            //   this.newAddressConfirmationPop(data);
            //   this.callSuccessFunction();
            // }
            // if (
            //   this.personalInfoService.returnAddressValidation(
            //     data.lookupReturnCode
            //   ).errorStatus
            // ) {
            //   this.checkAfterAddressValidation();
            // }
            // if (
            //   !this.personalInfoService.returnAddressValidation(
            //     data.lookupReturnCode
            //   ).ctaStatus
            // ) {
            //   this.newAddressConfirmationPop(data);
            //   this.callSuccessFunction();
            // }

            if (
              this.personalInfoService.returnAddressValidation(
                data.lookupReturnCode
              ).ctaStatus &&
              !this.personalInfoService.returnAddressValidation(
                data.lookupReturnCode
              ).errorStatus
            ) {
              this.newAddressConfirmationPop(data);
              this.callSuccessFunction();
            }
            if (
              this.personalInfoService.returnAddressValidation(
                data.lookupReturnCode
              ).errorStatus
            ) {
              this.checkAfterAddressValidation();
            }
          });
      } else {
        this.checkAfterAddressValidation();
      }
      this.storeToSession('buyFlowElements');
    }
  }

  get f() {
    if (this.addressForm) {
      return this.addressForm.controls;
    }
  }

  callSuccessFunction() {
    this.personalInfoService.confirmNewAddress.subscribe(value => {
      if (value) this.checkAfterAddressValidation();
    });
  }

  getAddressStr(data) {
    if (data.street) {
      const state: any = this.us_states.filter(
        stateVal => stateVal.code === data.state
      );

      if (data.street2 === '')
        return {
          address1: data.street + ', ' + data.city + ', ',
          address2: state[0].name + ' - ' + data.zip + '.'
        };
      else
        return {
          address1: data.street + ', ' + data.street2 + ', ' + data.city + ', ',
          address2: state[0].name + ' - ' + data.zip + '.'
        };
    }
  }

  checkAfterAddressValidation() {
    let customerNumber;
    if (this.data.customerNumber) {
      customerNumber = this.data.customerNumber;
    } else if (this.personalInfoService.getCustomerNumber()) {
      customerNumber = this.personalInfoService.getCustomerNumber();
    }
    const addressJson: any = {};
    addressJson['formData'] = this.personalInfoService.formateDataOnFormSubmit(
      null,
      this.addressForm,
      null,
      this.data
    );
    addressJson['customerId'] = customerNumber;
    addressJson['statusOnComplete'] = 'address-success';
    this.saveDataOnAddressSuccess(addressJson);
  }

  saveDataOnAddressSuccess(addressJson) {
    if (
      this.personalInfoService.buttonVisibleStatus.value &&
      this.personalInfoService.isContactFormStatus.value &&
      this.personalInfoService.isMyInfoFormStatus.value
    ) {
      this.personalInfoService.isFormValid.next(true);
    }

    this.isEdit = false;
    this.personalInfoService.isAddressFormStatus.next(true);
    this.personalInfoService.addUserDependentData(
      addressJson.formData,
      this.currentRoute
    );
    this.data = addressJson.formData;
    if (this.formValueEvent) this.formValueEvent.unsubscribe();

    this.updateViewModeData();

    this.errorStatus = true;
    this.personalInfoService.confirmNewAddress.next(false);
    this.formAddressEvent.emit(true);
  }

  getSelectedState(data, isNewUser) {
    let selectedState = [];
    if (!isNewUser) {
      selectedState = this.us_states.filter(
        state => state.code === data.addresses[0].stateProvCd
      );
    } else {
      const stateVal =
        data.quotes && data.quotes.length > 0 ? data.quotes[0].riskStateCd : '';
      selectedState = this.us_states.filter(state => state.code === stateVal);
    }
    return selectedState;
  }

  keyPress(event: any) {
    const pattern = /[0-9]/;
    const inputChar = String.fromCharCode(event.charCode);

    if (!pattern.test(inputChar) || event.target.value.length > 4) {
      // invalid character, prevent input
      event.preventDefault();
    }
  }

  updateViewModeData() {
    if (
      this.data &&
      this.data.addresses &&
      this.selectedState &&
      this.selectedState.length
    ) {
      const addressData = this.data.addresses[0];
      this.addressViewTitle =
        addressData.addressLine1 + ' ' + addressData.addressLine2;
      this.addressViewContent =
        addressData.city +
        ', ' +
        this.selectedState[0].name +
        ' ' +
        addressData.zipCode;
    } else {
      const selectedState = (this.selectedState = this.us_states.filter(
        state => state.code === this.addressForm.get('stateProvCd').value
      ));
      if (selectedState && selectedState.length) {
        this.addressViewTitle =
          this.addressForm.get('addressLine1').value +
          ' ' +
          this.addressForm.get('addressLine2').value;
        this.addressViewContent =
          this.addressForm.get('city').value +
          ', ' +
          selectedState[0].name +
          ' ' +
          this.addressForm.get('zipCode').value;
      }
    }
  }
  toggleViewMode() {
    this.isEdit = !this.isEdit;
    this.buttonText = this.cmsService.getKey(
      'lookup.find_plans_update_button_text'
    );
    this.personalInfoService.isAddressFormStatus.next(false);
    this.personalInfoService.isFormValid.next(false);
    this.setAddressFormControlData();
    this.addressForm.markAsPristine();
    this.trackFirstValueChange();
  }

  trackFirstValueChange() {
    this.formValueEvent = this.addressForm.valueChanges.subscribe(val => {
      if (this.personalInfoService.buttonVisibleStatus.value) {
        if (this.addressForm.dirty && this.isEdit) {
          this.personalInfoService.isFormValid.next(false);
          this.personalInfoService.isAddressFormStatus.next(false);
        }
      }
    });
  }

  ngOnDestroy() {
    this.subscriptions.unsubscribe();
  }

  /**
   * Save data from store to session storage
   */
  public storeToSession(statename: string) {
    switch (statename) {
      case 'buyFlowElements': {
        this.store.select(buyFlowElementsSelector).subscribe(res => {
          if (res.length > 0) {
            sessionStorage.setItem(
              'state-agent-buy-flow-elements',
              JSON.stringify(res)
            );
          }
        });
        break;
      }
      default: {
        break;
      }
    }
  }
}
