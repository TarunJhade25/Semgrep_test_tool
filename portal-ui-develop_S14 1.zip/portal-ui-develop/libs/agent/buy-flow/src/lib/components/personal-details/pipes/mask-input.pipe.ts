import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'maskInput'
})
export class MaskInputPipe implements PipeTransform {
  transform(value: any, ...args: any[]): any {
    let maskValue = '';
    if (value) {
      for (let index = 0; index < value.length; index++) {
        maskValue = maskValue + 'X';
      }
    }

    return maskValue;
  }
}
