import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { TranslateModule } from '@ngx-translate/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { VoiceSignatureComponent } from './voice-signature.component';
import { MatDialogModule } from '@angular/material';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { Store } from '@ngrx/store';
import { SaveYourQuoteState, getVoiceSignId } from '@aflac/agent/shared'; //stores
import { provideMockStore, MockStore } from '@ngrx/store/testing';
import { MatFormFieldModule, MatInputModule } from '@angular/material';

describe('VoiceSignatureComponent', () => {
  let component: VoiceSignatureComponent;
  let fixture: ComponentFixture<VoiceSignatureComponent>;
  let mockStore: MockStore<SaveYourQuoteState>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [VoiceSignatureComponent],
      imports: [
        MatDialogModule,
        TranslateModule.forRoot(),
        FormsModule,
        ReactiveFormsModule,
        MatFormFieldModule,
        MatInputModule
      ],
      providers: [provideMockStore({})],
      schemas: [CUSTOM_ELEMENTS_SCHEMA]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(VoiceSignatureComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
    mockStore = TestBed.get(Store);
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
  it('should toogle the purchaseClicked flag', () => {
    component.purchaseClicked = true;
    component.openSuccessPage();
    expect(component.purchaseClicked).toBeFalsy();
  });
  it('should set the showTextBox to true', () => {
    component.showTextBox = false;
    component.showIp();
    expect(component.showTextBox).toBeTruthy();
  });
});
