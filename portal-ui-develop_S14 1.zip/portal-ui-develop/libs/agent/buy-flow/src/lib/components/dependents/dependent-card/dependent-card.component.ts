import {
  Component,
  OnInit,
  OnChanges,
  Input,
  Output,
  EventEmitter
} from '@angular/core';
import { IDependent } from '../models/dependent.model';
import { DependentService } from '../services/dependent.service';
import { CmsService } from '@aflac/shared/cms';
import { MatDialog } from '@angular/material';
import { ConfirmModalComponent } from '@aflac/agent/shared';
@Component({
  selector: 'aflac-dependent-card',
  templateUrl: './dependent-card.component.html',
  styleUrls: ['./dependent-card.component.scss']
})
export class DependentCardComponent implements OnChanges {
  @Input() params;
  @Input() dependentDetails: IDependent;
  @Input() dependentEdited: boolean;
  @Output() updateFlag = new EventEmitter();
  genderTitle: string;
  constructor(
    private cmsService: CmsService,
    public dependentService: DependentService,
    public dialog: MatDialog
  ) {}

  ngOninit() {}

  ngOnChanges() {
    this.dependentDetails = Object.assign({}, this.dependentDetails);
  }

  selectChild(val) {
    this.dependentService.updateSelectedChildData(val, this.params);
  }

  editDependent() {
    this.dependentService.disableNextProduct.next(true);
    this.dependentService.setDependentData(null, this.params);
    this.dependentService.isFormValid.next(true);
    if (
      //this.params.type === 'child' &&
      this.dependentDetails &&
      this.dependentDetails.editMode === false
    ) {
      const updateObj = {
        mode: 'edit',
        parentIndex: this.params.parentIndex,
        type: this.params.type
      };
      this.updateFlag.emit(updateObj);
    }
  }

  deleteDependent() {
    const initialState = {
      contentTitle: this.cmsService.getKey(
        'lookup.delete_dependent_modal_header'
      ),
      contentText: this.cmsService.getKey('lookup.delete_dependent_modal_body'),
      contentButtonText: this.cmsService.getKey(
        'lookup.buy_flow_checkout_address_payment_address_yes'
      )
    };
    const dialogRef = this.dialog.open(ConfirmModalComponent, {
      disableClose: true,
      data: {
        initialState
      },
      panelClass: 'remove-dependent-modal-resizer'
    });
    dialogRef.afterClosed().subscribe(result => {
      if (result && result === 'delete') {
        this.dependentService.deleteChildByIndex(
          this.params,
          this.dependentEdited
        );
      }
    });
  }
}
