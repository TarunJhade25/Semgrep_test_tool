import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PaymentCheckoutComponent } from './payment-checkout.component';
import { provideMockStore, MockStore } from '@ngrx/store/testing';
import { StoreModule, Store, MemoizedSelector } from '@ngrx/store';
import { RouterTestingModule } from '@angular/router/testing';
import { RouterModule } from '@angular/router';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { PersonalDetailsService } from '../personal-details/services/personal-details.service';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { of, Observable } from 'rxjs';
import { TranslateModule } from '@ngx-translate/core';
import { PaymentService } from './services/payment.service';
import { quoteReducer, SeoService } from '@aflac/shared/ui';
import { BuyFlowService } from '../../services/buy-flow.service';
import { buyFlowElementsSelector } from '@aflac/agent/shared';
import { DatePipe } from '@angular/common';
import * as fromMockSaveYourQuoteSelector from '@aflac/agent/shared';

class MockPersonalDetailsService {
  getUserDataFomSaveQoute() {
    return of(1, 2, 3);
  }
}
class MockBuyflowService {
  enableStepperByRoute(route) {
    return of(true);
  }
  completeCurrentStepAndMoveToNext(route) {
    return of(true);
  }
  getBundleDataFromBundleId(): Observable<any> {
    return of(bundleData);
  }
}

const bundleData = {
  data: {
    quotes: [
      {
        bundleId: '000',
        policyNumber: 'a1b2',
        effectiveDate: '01/02/2019',
        expirationDate: '01/06/2019',
        transactionEffectiveDate: '03/02/2019',
        policyStatusCd: 'dummy',
        productCode: 'PREC-IC',
        lobCd: 'dummy',
        totalPremium: 1234,
        currencyCode: 'ind',
        producerCd: 'dummy',
        subProducerCd: 'd',
        quoteNumber: '111',
        customerNumber: '111'
      }
    ]
  }
};
const buyFlowElements = [
  {
    completed: true,
    data: {},
    disabled: false,
    header: 'Quote',
    inactive: false,
    link: '/review',
    required: true,
    title: 'Quote'
  },
  {
    completed: false,
    data: {},
    disabled: false,
    header: 'Dependents Information',
    inactive: false,
    link: '/dependents',
    required: true,
    title: 'Dependents Information'
  },
  {
    completed: false,
    data: {},
    disabled: false,
    header: 'Eligibility',
    inactive: false,
    link: '/eligibility',
    required: true,
    title: 'Eligibility'
  }
];
describe('PaymentCheckoutComponent', () => {
  let component: PaymentCheckoutComponent;
  let fixture: ComponentFixture<PaymentCheckoutComponent>;
  let mockSaveQuoteSelector: MemoizedSelector<any, any>;

  let mockStore: MockStore<any>;
  const Routes = [
    {
      quote_error: 'quote-error',
      buy_flow: 'buy-flow',
      buy_flow_review_accident: 'accident-review-your-quote',
      buy_flow_review_cancer: 'cancer-review-your-quote',
      buy_flow_review_critical_illness: 'critical-illness-review-your-quote',
      buy_flow_dependents: 'dependents',
      buy_flow_eligibility: 'eligibility',
      buy_flow_personal_details: 'my-details',
      buy_flow_order_review: 'order-review',
      buy_flow_payment: 'payment',
      buy_flow_checkout: 'checkout',
      identity_validation: 'identity-validation',
      kba_validation: 'kba-validation',
      error_validation: 'error-validation'
    }
  ];

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        StoreModule.forRoot(quoteReducer),
        RouterTestingModule,
        RouterModule,
        HttpClientTestingModule,
        TranslateModule.forRoot()
      ],
      declarations: [PaymentCheckoutComponent],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
      providers: [
        { provide: SeoService, useClass: MockSeoServiceService },
        { provide: BuyFlowService, useClass: MockBuyflowService },
        {
          provide: PersonalDetailsService,
          useClass: MockPersonalDetailsService
        },
        provideMockStore({}),
        DatePipe
      ]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PaymentCheckoutComponent);
    component = fixture.componentInstance;
    mockStore = TestBed.get(Store);
    mockStore.overrideSelector(buyFlowElementsSelector, buyFlowElements);
    mockSaveQuoteSelector = mockStore.overrideSelector(
      fromMockSaveYourQuoteSelector.buyFlowElementsSelector,
      buyFlowElements
    );
    const buyflowService = TestBed.get(BuyFlowService);
    spyOn(buyflowService, 'enableStepperByRoute');
    component.route = '/buy-flow/payment';
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
  it('receives message; url is not valid hence stays on screen', () => {
    component.receiveMessage({
      data: 'http://'
    });
    expect(component.session.cancelled).toBeFalsy();
    expect(component.session.submitted).toBeFalsy();
  });

  it('receives message; url is valid; iframe target variable(submiy) should flip', () => {
    component.receiveMessage({
      data: 'JPMC-http://testurl.com&DLAction=submit&accountId=1018'
    });
    expect(component.session.submitted).toBeTruthy();
  });

  it('on change of payment method', () => {
    component.changePaymentMethod();
    expect(component.session.started).toBeTruthy();
    expect(component.session.submitted).toBeFalsy();
  });
  it('on selection of add should show the add screen and call the url', () => {
    const paymentService = TestBed.get(PaymentService);
    spyOn(paymentService, 'getJPMCSessionUrl').and.returnValue({
      subscribe: () => {}
    });
    component.addPaymentMethod({ type: 'CC' });
    expect(component.session.startIframe).toBeTruthy();
  });

  // it('should call get payment accounts when triggered', () => {
  //   const paymentService = TestBed.get(PaymentService);
  //   spyOn(paymentService, 'getPaymentAccount').and.returnValue({
  //     subscribe: () => {}
  //   });
  //   component.ngOnInit();
  //   expect(paymentService.getPaymentAccount).toHaveBeenCalled();
  // });

  it('should hide the progress if the event src realizes', () => {
    component.loadJPMCFrame({
      target: {
        src: 'http://'
      }
    });
    expect(component.isFrameLoaded).toBeTruthy();
  });

  it('should be a valid URL if prefixed with JPMC', () => {
    const retvalue = component.isValidURL('JPMC-UUUU.COM');
    expect(retvalue).toBe(true);
    const retvalue1 = component.isValidURL('JPMx-UUUU.COM');
    expect(retvalue1).toBe(false);
  });

  it('is on edit payment method and gets the url from api end point', () => {
    const paymentService = TestBed.get(PaymentService);
    spyOn(paymentService, 'getUpdateAccountUrl').and.returnValue({
      subscribe: () => {}
    });
    component.editPaymentMethod({ accountId: '1018' });
    expect(paymentService.getUpdateAccountUrl).toHaveBeenCalled();
  });
});

class MockSeoServiceService {
  updateTitle(title: string) {}
  /**Update Description tag */
  updateDescription(desc: string) {}
}
