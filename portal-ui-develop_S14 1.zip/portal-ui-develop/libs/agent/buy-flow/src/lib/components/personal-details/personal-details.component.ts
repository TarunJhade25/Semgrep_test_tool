import {
  Component,
  OnInit,
  OnDestroy,
  NgZone,
  AfterViewInit
} from '@angular/core';
import { Store, select, ActionsSubject } from '@ngrx/store';
import { Subscription, combineLatest } from 'rxjs';
import { first } from 'rxjs/operators';

import { Router } from '@angular/router';
import { FieldValidator } from '@aflac/shared/validators';
import { FormBuilder, Validators } from '@angular/forms';
import {
  savePersonalDetails,
  updatePersonalData,
  getPersonalDetailsSuccess,
  validateUserIdentity,
  idValidationStatusSelector
} from '@aflac/agent/shared'; // Actions
import {
  personalDetailsSelectorProspect,
  dependentDataByRouteSelector,
  SaveYourQuoteState,
  personalDataSaveStatus,
  personalDataUpdateStatus
} from '@aflac/agent/shared';
import { BuyFlowService } from '../../services/buy-flow.service';
import { PersonalDetailsService } from './services/personal-details.service';
import { CmsService } from '@aflac/shared/cms';
import { urlConfig } from '@aflac/shared/data-model';
declare const aflac_eic: any;

@Component({
  selector: 'aflac-personal-details',
  templateUrl: './personal-details.component.html',
  styleUrls: ['./personal-details.component.scss']
})
export class PersonalDetailsComponent
  implements OnInit, OnDestroy, AfterViewInit {
  private subscriptions = new Subscription();
  personalDetailsData: any = {};
  isFromMemberPortal = false;
  isProspect = false;
  isShowContact = false;
  isShowAddress = false;
  isShowContinue = false;
  route = '/my-details';
  myInfoForm: any;
  addressForm: any;
  contactForm: any;
  subHeaderText: any = this.cmsService.getKey(
    'sales_portal.personal_details_main_sub_header_text'
  );
  idvValidCustomerData: any;
  returningProspectUserData: any = {};
  customerNumber: any;
  userType: string;
  bundleData: any;
  isAnonymousFlag: boolean;
  bundleId: any;
  selectedUserData: any;
  deleteQuoteListData: any;

  constructor(
    private store: Store<SaveYourQuoteState>,
    private fb: FormBuilder,
    private router: Router,
    public buyFlowService: BuyFlowService,
    public personalInfoService: PersonalDetailsService,
    private actionsSubject$: ActionsSubject,
    private zone: NgZone,
    private cmsService: CmsService
  ) {}

  ngOnInit() {
    this.route = this.router.url;
    this.buyFlowService.enableStepperByRoute(this.route);
    this.userType = 'new';
    this.createFormGroupInstance();
    this.personalInfoService.setCustomerNumber('');

    this.subscriptions = this.buyFlowService
      .getBundleDataFromBundleId()
      .subscribe(bundleData => {
        if (bundleData && bundleData.data) {
          const cNumber =
            bundleData.data.quotes && bundleData.data.quotes[0].customerNumber;
          this.customerNumber = cNumber;
          this.bundleId = bundleData.data.id;
          this.isAnonymousFlag = bundleData.data.isAnonymous;
          this.bundleData = bundleData.data.quotes;
          this.personalInfoService.setBundleData(this.bundleData);
          this.personalInfoService.setCustomerNumber(cNumber);
          const subscribe = this.personalInfoService
            .getPersonalData(this.route)
            .subscribe(data => {
              if (JSON.stringify(data) === '{}') {
                if (
                  urlConfig.envName === 'local' ||
                  urlConfig.envName === 'dev'
                ) {
                  // Get customerNumber
                  //this.getCustomerNumber();
                }
                this.manipulateCustomerType();
              } else {
                this.checkCustomerIsProspectOrMember(data);
                this.isShowAddress = true;
                if (data && data.addresses) {
                  this.isShowContact = true;
                  this.personalInfoService.buttonVisibleStatus.next(true);
                  if (
                    data.emails &&
                    data.emails.length &&
                    data.phones &&
                    data.phones.length &&
                    this.personalInfoService.isContactFormView.value
                  ) {
                    this.isShowContinue = true;
                    this.personalInfoService.isShowContactForm.next(false);
                    if (
                      this.personalInfoService.isMyInfoFormStatus.value &&
                      this.personalInfoService.isAddressFormStatus.value
                    ) {
                      this.personalInfoService.isFormValid.next(true);
                    }
                  }
                }
              }
              if (cNumber) {
                data = Object.assign({}, data, {
                  customerNumber: cNumber
                });
              }
              this.personalDetailsData = data;
              this.subscriptions.add(subscribe);
            });
        }
      });
  }

  getCustomerNumber() {
    // TODO - Can remove in the real integration if needed
    this.subscriptions = combineLatest(
      this.personalInfoService.getUserDataFomSaveQuoteResponse(),
      this.store.pipe(select(personalDetailsSelectorProspect))
    ).subscribe(([userDataFromSave, customerNum]) => {
      if (userDataFromSave && userDataFromSave.customerNumber) {
        this.customerNumber = userDataFromSave.customerNumber;
      } else {
        if (customerNum) this.customerNumber = customerNum;
      }
      //console.log('this.customerNumber : ', this.customerNumber);
      this.personalInfoService.setCustomerNumber(this.customerNumber);
    });
  }

  manipulateCustomerType() {
    if (this.customerNumber) {
      this.personalInfoService.setPersonalDataProspect(this.customerNumber);
      const pdsub = this.actionsSubject$.subscribe((action: any) => {
        if (action.type === getPersonalDetailsSuccess.type) {
          const pData = action.payload;
          if (
            pData &&
            pData.status === true &&
            pData.data &&
            !pData.data.isAnonymous &&
            !this.isAnonymousFlag
          ) {
            const personalData = pData.data;
            this.checkCustomerIsProspectOrMember(personalData);
            this.personalInfoService.addUserDependentData(
              personalData,
              this.route
            );
            this.personalDetailsData = personalData;
            this.personalInfoService.isFormValid.next(true);
            this.personalInfoService.buttonVisibleStatus.next(true);
            if (this.userType === 'prospect') this.isProspect = true;
            else if (this.userType === 'member') {
              this.isFromMemberPortal = true;
            }
          }
        }
      });
      this.subscriptions.add(pdsub);
    }
  }

  checkCustomerIsProspectOrMember(personalData) {
    this.userType = this.buyFlowService.checkCustomerIsProspectOrMember(
      personalData,
      this.isAnonymousFlag
    );
    this.personalInfoService.userType.next(this.userType);
  }

  ngAfterViewInit() {
    this.zone.run(() => {
      if (aflac_eic) {
        aflac_eic.initiate(null);
      }
    });
  }

  createFormGroupInstance() {
    // form group for my info section
    this.myInfoForm = this.fb.group({
      firstName: [
        '',
        [
          FieldValidator.isEmpty(
            'agent_portal.save_quote_first_name_required_error'
          ),
          FieldValidator.patternValidator(
            /^[a-zA-Z ]*$/,
            'agent_portal.save_quote_first_name_required_error'
          ),
          FieldValidator.patternValidatorWithSpaceCheck(
            /^\S+(?: \S+)*$/,
            'agent_portal.save_quote_first_name_required_error'
          )
        ]
      ],
      middleInitials: [
        '',
        FieldValidator.patternValidator(
          /^[a-zA-Z ]*$/,
          'agent_portal.personal_details_middle_initial_required_error'
        )
      ],
      lastName: [
        '',
        [
          FieldValidator.isEmpty(
            'agent_portal.save_quote_last_name_required_error'
          ),
          FieldValidator.patternValidator(
            /^[a-zA-Z ]*$/,
            'agent_portal.save_quote_last_name_required_error'
          ),
          FieldValidator.patternValidatorWithSpaceCheck(
            /^\S+(?: \S+)*$/,
            'agent_portal.save_quote_last_name_required_error'
          )
        ]
      ],
      suffix: [],
      dateOfBirth: [
        '',
        [
          FieldValidator.isEmpty(
            'agent_portal.personal_details_dob_required_error'
          ),
          FieldValidator.patternValidator(
            /^((0?[1-9]|1[012])[- /.](0?[1-9]|[12][0-9]|3[01])[- /.](19|20)?[0-9]{2})*$/,
            'agent_portal.personal_details_dob_required_error'
          ),
          FieldValidator.ageRangeValidator(
            18,
            99,
            'agent_portal.personal_details_dob_required_error',
            'agent_portal.personal_details_dob_required_error',
            /^((0?[1-9]|1[012])[- /.](0?[1-9]|[12][0-9]|3[01])[- /.][0-9]{4})*$/
          ),
          FieldValidator.patternValidator(
            /^((0?[1-9]|1[012])[- /.](0?[1-9]|[12][0-9]|3[01])[- /.][0-9]{4})*$/,
            'agent_portal.personal_details_dob_required_error'
          )
        ]
      ],
      taxId: [
        '',
        [
          FieldValidator.isEmpty(
            'agent_portal.personal_details_ssn_required_error'
          ),
          FieldValidator.ssnValidator(
            'agent_portal.personal_details_ssn_required_error'
          ),
          Validators.minLength(9)
        ]
      ],
      gender: []
    });
    // Form group for address sesction

    this.addressForm = this.fb.group({
      addressLine1: [
        '',
        [
          FieldValidator.isEmpty(
            'agent_portal.personal_details_address_required_error'
          ),
          FieldValidator.patternValidatorWithSpaceCheck(
            /^\S+(?: \S+)*$/,
            'agent_portal.personal_details_address_required_error'
          )
        ]
      ],
      addressLine2: [
        '',
        [
          FieldValidator.patternValidatorWithSpaceCheck(
            /^\S+(?: \S+)*$/,
            'agent_portal.personal_details_address_required_error'
          )
        ]
      ],
      city: [
        '',
        [
          FieldValidator.isEmpty(
            'agent_portal.personal_details_city_required_error'
          ),
          ,
          FieldValidator.patternValidator(
            /^[a-zA-Z ]*$/,
            'agent_portal.personal_details_city_required_error'
          ),
          FieldValidator.patternValidatorWithSpaceCheck(
            /^\S+(?: \S+)*$/,
            'agent_portal.personal_details_city_required_error'
          )
        ]
      ],
      stateProvCd: ['', [Validators.required]],
      zipCode: [
        '',
        [
          FieldValidator.isEmpty(
            'agent_portal.personal_details_zip_required_error'
          ),
          FieldValidator.patternValidator(
            /[0-9\*]{5}/g,
            'agent_portal.personal_details_zip_valid_error'
          ),
          Validators.minLength(5)
        ]
      ]
    });

    // Form group for Contacts section
    this.contactForm = this.fb.group(
      {
        phone_number: [
          '',
          [
            FieldValidator.isEmpty(
              'agent_portal.personal_details_primary_phone_required_error'
            ),
            FieldValidator.patternValidator(
              /^[\+]?[(]?[0-9]{3}[)]?[-\s\.]?[0-9]{3}[-\s\.]?[0-9]{4,6}$/im,
              'agent_portal.personal_details_primary_phone_required_error' //need to add in CMS
            ),
            Validators.minLength(10)
          ]
        ],
        email: [
          '',
          [
            FieldValidator.isEmpty(
              'agent_portal.personal_details_email_required_error'
            ),
            FieldValidator.patternValidator(
              /^[a-zA-Z]{1}(([^<>()\[\]\\.,;:\s@']+(\.[^<>()\[\]\\.,;:\s@']+)*)|('.+'))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/,
              'agent_portal.personal_details_email_required_error'
            )
          ]
        ],
        confirm_email: [
          '',
          [
            FieldValidator.isEmpty(
              'agent_portal.personal_details_email_required_error'
            ),
            FieldValidator.patternValidator(
              /^[a-zA-Z]{1}(([^<>()\[\]\\.,;:\s@']+(\.[^<>()\[\]\\.,;:\s@']+)*)|('.+'))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/,
              'agent_portal.personal_details_email_required_error'
            )
          ]
        ],
        electronic_delivery: [false, FieldValidator.isEmpty]
      },
      {
        validator: FieldValidator.mustMatch(
          'email',
          'confirm_email',
          'agent_portal.personal_details_email_match_error'
        )
      }
    );
  }

  formMyinfoEventHander($event: any) {
    this.isShowAddress = $event;
  }

  formAddressEventHander($event: any) {
    this.isShowContact = $event;
    if (
      (this.userType === 'new' || this.userType === 'anonymous') &&
      !this.isShowContinue
    )
      this.personalInfoService.isShowContactForm.next(true);
    // if (this.isShowContact)
    //   this.personalInfoService.buttonVisibleStatus.next(true);
  }

  formContactEventHandler($event: any) {
    this.isShowContinue = $event;
  }

  formUpdateCustomerEventHandler($event: any) {
    this.personalInfoService.addUserDependentData($event, this.route);
  }

  savePersonalDetails() {
    if (this.personalInfoService.isFormValid.value) {
      if (aflac_eic) {
        aflac_eic.aflac_eic_form('aflac_eic_prefs');
      }
      const requestHeader = {
        hdimPayload: (window as any).aflac_eic_prefs.value,
        jscPayload: (window as any).user_prefs2.value
      };

      const personalInfoData = {
        formData: this.personalInfoService.formateDataOnFormSubmit(
          this.myInfoForm,
          this.addressForm,
          this.contactForm,
          this.personalDetailsData,
          requestHeader
        ),
        customerId: this.personalDetailsData.customerNumber
      };

      personalInfoData.formData['bundleId'] =
        this.bundleData && this.bundleData[0].bundleId;
      personalInfoData.formData[
        'quotes'
      ] = this.personalInfoService.updatePersonalQuotes(
        this.bundleData,
        this.contactForm.value,
        this.myInfoForm.value
      );
      personalInfoData.formData[
        'deleteQuoteList'
      ] = this.fetchDeleteQuoteListData();

      //console.log('personalInfoData 11 : ', JSON.stringify(personalInfoData));

      if (this.userType === 'new' || this.userType === 'anonymous')
        this.saveUserPersonalInfo(personalInfoData);
      else this.updateUserPersonalInfo(personalInfoData);
    }
  }

  saveUserPersonalInfo(personalInfoData) {
    this.store.dispatch(
      savePersonalDetails({ PersonalDetailsFormData: personalInfoData })
    );
    const actionStatus = this.store
      .pipe(select(personalDataSaveStatus))
      .subscribe(res => {
        if (res && res.status === true) {
          const pdClone = Object.assign({}, personalInfoData.formData);
          pdClone['customerNumber'] = res.data.customerNumber;
          personalInfoData = { formData: pdClone };
          this.addPersonalDataToStore(personalInfoData);
        }
      });
  }

  updateUserPersonalInfo(personalInfoData) {
    this.store.dispatch(updatePersonalData({ myInfoData: personalInfoData }));
    const actionStatus = this.store
      .pipe(select(personalDataUpdateStatus))
      .subscribe(res => {
        if (res && res.status === true) {
          this.addPersonalDataToStore(personalInfoData);
        }
      });
  }

  addPersonalDataToStore(personalInfoData) {
    this.personalInfoService.addUserDependentData(
      personalInfoData.formData,
      this.route
    );
    //bundle update
    //this.buyFlowService.setBundleDataAction(this.bundleId);
    this.personalInfoService.isShowContactForm.next(false);
    this.personalInfoService.isContactFormView.next(true);
    if (this.userType !== 'member' && urlConfig && urlConfig.enableIDV) {
      this.checkIdentity(personalInfoData);
    } else {
      const subscribeRedirect = this.buyFlowService.completeCurrentStepAndMoveToNext(
        this.route
      );
      this.subscriptions.add(subscribeRedirect);
    }
  }

  //Check user identity
  checkIdentity(personalInfoData) {
    const requestData = this.personalInfoService.formatDataOnIdValidation(
      personalInfoData.formData
    );
    this.store.dispatch(
      validateUserIdentity({ PersonalDetailsFormData: requestData })
    );
    const idValidationStatus = this.store
      .pipe(select(idValidationStatusSelector))
      .subscribe(res => {
        if (res && res.success) {
          const subscribeRedirect = this.buyFlowService.completeCurrentStepAndMoveToNext(
            this.route
          );
          this.subscriptions.add(subscribeRedirect);
        } else {
          this.router.navigateByUrl('identity-error');
        }
      });
  }

  fetchDeleteQuoteListData() {
    const fdqsub = this.personalInfoService
      .getDeletedQuoteListData()
      .subscribe(delData => {
        this.deleteQuoteListData = delData;
      });
    this.subscriptions.add(fdqsub);
    return this.deleteQuoteListData;
  }

  ngOnDestroy() {
    this.subscriptions.unsubscribe();
    this.personalInfoService.isContactFormView.next(true);
  }
}
