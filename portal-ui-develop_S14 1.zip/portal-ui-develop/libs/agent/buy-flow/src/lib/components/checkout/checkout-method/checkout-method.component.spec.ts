import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import {
  MatTableModule,
  MatFormFieldModule,
  MatInputModule
} from '@angular/material';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { MatRadioModule } from '@angular/material/radio';
import { CheckoutMethodComponent } from './checkout-method.component';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { TranslateModule } from '@ngx-translate/core';
import { StoreModule, Store, MemoizedSelector } from '@ngrx/store';
import { saveYourQuoteReducer } from '@aflac/agent/shared';
import { provideMockStore, MockStore } from '@ngrx/store/testing';
import { SaveYourQuoteState, ProductState } from '@aflac/agent/shared'; //stores
import { agentESign, selectedProduct } from '@aflac/agent/shared'; //selectors
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { RouterTestingModule } from '@angular/router/testing';

describe('CheckoutMethodComponent', () => {
  let component: CheckoutMethodComponent;
  let fixture: ComponentFixture<CheckoutMethodComponent>;
  let mockStore: MockStore<SaveYourQuoteState>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [CheckoutMethodComponent],
      imports: [
        MatTableModule,
        MatFormFieldModule,
        MatInputModule,
        ReactiveFormsModule,
        FormsModule,
        MatRadioModule,
        TranslateModule.forRoot(),
        HttpClientTestingModule,
        RouterTestingModule
      ],
      providers: [provideMockStore({})],
      schemas: [CUSTOM_ELEMENTS_SCHEMA]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CheckoutMethodComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
    mockStore = TestBed.get(Store);
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should execute showIp', () => {
    component.showIp();
    expect(component.showTextBox).toBeTruthy();
  });
  it('should execute watchOptionSelected', () => {
    component.watchOptionSelected({
      text: 'Voice Signature',
      value: 'v',
      checked: false,
      type: 'voice-sign'
    });
    expect(component.redirector).toEqual('voice-sign');
  });
  it('should execute OnBlurCaptureInput', () => {
    component.OnBlurCaptureInput('test');
    expect(component.capturedAgentSign).toEqual('test');
    expect(component.signatureInd).toBeTruthy();
  });

  it('should execute handleSubmit', () => {
    spyOn(component, 'handlePostReq').and.returnValue(true);
    component.redirector = 'e-sign';
    component.handleSubmit();
    expect(component.handlePostReq).toHaveBeenCalled();
  });
});
