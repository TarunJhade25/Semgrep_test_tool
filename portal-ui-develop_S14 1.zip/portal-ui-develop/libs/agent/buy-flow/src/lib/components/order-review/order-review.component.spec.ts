import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { TranslateModule } from '@ngx-translate/core';
import { RouterTestingModule } from '@angular/router/testing';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { Router } from '@angular/router';
import { provideMockStore, MockStore } from '@ngrx/store/testing';
import { StoreModule, Store, MemoizedSelector } from '@ngrx/store';
import { of } from 'rxjs';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { BehaviorSubject, Observable } from 'rxjs';

import { OrderReviewComponent } from './order-review.component';
import * as fromProduct from '@aflac/agent/shared';
import { ProductState, AgentSharedService } from '@aflac/agent/shared';
import { BuyFlowService } from '../../services/buy-flow.service';
import * as fromMockSaveYourQuoteSelector from '@aflac/agent/shared';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { BrowserDynamicTestingModule } from '@angular/platform-browser-dynamic/testing';
import { AgeChangeInPremiumComponent } from '../personal-details/personal-details-modal/age-validation-modal/age-change-in-premium/age-change-in-premium.component';
import { AgeNotEligibleForProductComponent } from '../personal-details/personal-details-modal/age-validation-modal/age-not-eligible-for-product/age-not-eligible-for-product.component';
import { DependentIneligibilityModalComponent } from '../dependent-ineligibility-modal/dependent-ineligibility-modal.component';
import {
  MatDialogRef,
  MatDialogModule,
  MAT_DIALOG_DATA,
  MatDialog
} from '@angular/material/dialog';
import * as fromAgentSaveQuote from '@aflac/agent/shared';
import { AnimationDriver } from '@angular/animations/browser';

const orderReviewInfo = {
  quotes: [
    {
      freeLookPeriod: 30
    }
  ]
};
const selectedPlans = {
  key: 'from-list',
  value: [
    {
      productId: 'PREC-IC',
      productName: 'Accident',
      plan: {
        id: 123,
        price: '100',
        description: 'These are the benefits',
        name: 'Lorem ipsum',
        states: ['AL', 'CT'],
        title: 'Standard Plan',
        benefits: [
          {
            id: 333,
            name: 'test',
            price: 123
          }
        ]
      },
      coverage: 'ind',
      selected: true,
      availableInCart: true,
      selectedRiders: [
        {
          rider: { title: 'title1', price: '100' },
          selected: true,
          availableInCart: true,
          plan: { id: 'id1' }
        },
        {
          rider: { title: 'title2', price: '200' },
          selected: true,
          availableInCart: true,
          plan: { id: 'id1' }
        }
      ]
    }
  ]
};
const dependentObject = {
  'PREC-IA': {
    spouse: {
      firstName: 'spousef',
      lastName: 'spousel',
      middleName: '',
      suffix: null,
      dateOfBirth: '12/12/1980',
      ssn: '637935789',
      gender: 'male',
      addresses: []
    },
    children: [
      {
        firstName: 'cf',
        lastName: 'cl'
      }
    ]
  }
};
const personalInformationObject = {
  firstName: 'primaryfirst',
  lastName: 'primarylast',
  dateOfBirth: '01/01/2000'
};

const buyFlowElements = [
  {
    completed: true,
    data: {},
    disabled: false,
    header: 'Quote',
    inactive: false,
    link: '/review',
    required: true,
    title: 'Quote'
  },
  {
    completed: false,
    data: dependentObject,
    disabled: false,
    header: 'Dependents Information',
    inactive: false,
    link: '/dependents',
    required: true,
    title: 'Dependents Information'
  },
  {
    completed: false,
    data: {},
    disabled: false,
    header: 'Eligibility',
    inactive: false,
    link: '/eligibility',
    required: true,
    title: 'Eligibility'
  },
  {
    completed: false,
    data: personalInformationObject,
    disabled: false,
    header: 'Personal Information',
    inactive: false,
    link: '/my-details',
    required: true,
    title: 'Personal Information'
  }
];

// class RouterStub {
//   navigateByUrl(url: string) {
//     return url;
//   }
// }

const agePayload = {
  ageEligibilityDetails: [
    {
      productId: 'PREC-IA',
      productName: 'Accident Insurance',
      currentPremium: 28.05,
      riders: []
    },
    {
      productId: 'PREC-IC',
      productName: 'Cancer Insurance',
      currentPremium: 209.87,
      riders: []
    }
  ],
  ageInEligibilityDetails: [],
  agePremiumChangeDetails: [
    {
      productId: 'PREC-IA',
      productName: 'Accident Insurance',
      dateOfBirth: '01/01/2000',
      currentPremium: 28.05,
      prevPremium: 25.1,
      riders: []
    },
    {
      productId: 'PREC-IC',
      productName: 'Cancer Insurance',
      dateOfBirth: '01/01/2000',
      currentPremium: 209.87,
      prevPremium: 25.5,
      riders: []
    }
  ]
};

const ageValData = {
  status: true,
  data: [
    {
      PRECIA: {
        data: {
          planTypeCd: 'Low',
          monthlyPremium: 28.05,
          monthPremium: 28.05,
          coverageTierCd: 'EC',
          minAge: 20,
          maxAge: 65,
          riders: [],
          productCd: 'PREC-IA'
        },
        message: 'Success'
      }
    },
    {
      PRECIC: {
        data: {
          planTypeCd: 'plan07',
          monthlyPremium: 209.87,
          monthPremium: 201.3,
          coverageTierCd: 'EF',
          minAge: 20,
          maxAge: 40,
          riders: [],
          productCd: 'PREC-IC'
        },
        message: 'Success'
      }
    }
  ]
};
const ageValidationResponse = {
  status: true,
  data: [
    {
      PRECIA: {
        data: {
          planTypeCd: 'High',
          monthlyPremium: 69.24,
          monthPremium: 62.29,
          coverageTierCd: 'EC',
          rds: [
            {
              riderNameCd: 'Additional Accidental-Death Benefit Rider',
              isIncludedInd: true,
              monthlyPremium: 6.95
            }
          ],
          riders: [
            {
              riderNameCd: 'Additional Accidental-Death Benefit Rider',
              isIncludedInd: true,
              monthlyPremium: 6.95
            }
          ],
          insured: [
            {
              minAge: 20,
              maxAge: 65,
              relationshipToPrimaryInsuredCd: 'SELF',
              disabilityInd: false,
              newInd: true,
              primaryInsuredInd: true
            },
            {
              minAge: 20,
              maxAge: 65,
              relationshipToPrimaryInsuredCd: '1',
              disabilityInd: false,
              newInd: false,
              primaryInsuredInd: false
            },
            {
              minAge: 20,
              maxAge: 65,
              relationshipToPrimaryInsuredCd: '2',
              disabilityInd: false,
              newInd: false,
              primaryInsuredInd: false
            }
          ],
          productCd: 'PREC-IA',
          notEligibleInsureds: [
            {
              referenceNumber: '1234',
              customerNumber: '50002',
              relationshipToPrimaryInsuredCd: '1',
              dateOfBirth: '2006-04-21',
              disabilityInd: false,
              newInd: false,
              primaryInsuredInd: false
            }
          ]
        },
        message: 'Success'
      }
    }
  ]
};
const depValInfo = [
  {
    relationshipToPrimaryInsuredCd: '1'
  }
];
const modalPayload = {
  totalMonthycost: {
    old: 143.5,
    new: 330.54
  },
  productDetails: [
    {
      productId: 'PREC-IC',
      productName: 'Cancer Insurance',
      coverage: {
        old: 'ind_sps',
        new: 'ind'
      },
      nonEligibleDependents: [
        {
          name: 'cv c',
          relation: '1',
          dob: '09/09/1930'
        }
      ],
      monthlyPremium: {
        old: 35.19,
        new: 224.68
      }
    },
    {
      productId: 'PREC-ICI',
      productName: 'Critical Illness Insurance',
      coverage: {
        old: 'ind_sps',
        new: 'ind'
      },
      nonEligibleDependents: [
        {
          name: 'cv c',
          relation: '1',
          dob: '09/09/1930'
        }
      ],
      monthlyPremium: {
        old: 80.1,
        new: 43.57
      }
    },
    {
      productId: 'PREC-IA',
      productName: 'Accident Insurance',
      coverage: {
        old: 'ind',
        new: 'ind'
      },
      nonEligibleDependents: [],
      monthlyPremium: {
        old: 28.21,
        new: 62.29
      }
    }
  ],
  editLink: '',
  continuelink: ''
};
const riderValue = [
  {
    rider: {
      price: 200
    }
  }
];
const cartPlans = {
  key: 'from-list',
  value: [
    {
      productId: 'PREC-IC',
      productName: 'Accident',
      plan: {
        id: 123,
        price: '100',
        description: 'These are the benefits',
        name: 'Lorem ipsum',
        states: ['AL', 'CT'],
        title: 'Standard Plan',
        benefits: [
          {
            id: 333,
            name: 'test',
            price: 123
          }
        ]
      },
      coverage: 'ind',
      selected: true,
      availableInCart: true,
      selectedRiders: [
        {
          rider: { title: 'title1', price: '100' },
          selected: true,
          availableInCart: true,
          plan: { id: 'id1' }
        },
        {
          rider: { title: 'title2', price: '200' },
          selected: true,
          availableInCart: true,
          plan: { id: 'id1' }
        }
      ]
    }
  ]
};

describe('OrderReviewComponent', () => {
  let component: OrderReviewComponent;
  let fixture: ComponentFixture<OrderReviewComponent>;
  let mockStore: MockStore<any>;
  let store: Store<ProductState>;
  let mockSelectedPlanSelector: MemoizedSelector<any, any>;
  let mockSavedQuoteSelector: MemoizedSelector<any, any>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [
        OrderReviewComponent,
        AgeChangeInPremiumComponent,
        AgeNotEligibleForProductComponent,
        DependentIneligibilityModalComponent
      ],
      imports: [
        TranslateModule.forRoot(),
        RouterTestingModule,
        BrowserAnimationsModule,
        FormsModule,
        ReactiveFormsModule,
        RouterTestingModule,
        RouterModule,
        MatDialogModule,
        BrowserAnimationsModule,
        HttpClientTestingModule
      ],
      providers: [
        provideMockStore({}),
        // { provide: Router, useClass: RouterStub }
        { provide: BuyFlowService, useClass: MockBuyflowService },
        { provide: AgentSharedService, useClass: MockAgentSharedService },
        {
          provide: MAT_DIALOG_DATA,
          useValue: {}
        },
        {
          provide: MatDialogRef,
          useClass: DialogMock
        }
      ],

      schemas: [CUSTOM_ELEMENTS_SCHEMA]
    })
      .overrideModule(BrowserDynamicTestingModule, {
        set: {
          entryComponents: [
            AgeChangeInPremiumComponent,
            AgeNotEligibleForProductComponent,
            AgeChangeInPremiumComponent
          ]
        }
      })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OrderReviewComponent);
    mockStore = TestBed.get(Store);
    store = TestBed.get(Store);
    mockSelectedPlanSelector = mockStore.overrideSelector(
      fromProduct.selectedPlans,
      selectedPlans
    );
    mockStore.overrideSelector(
      fromMockSaveYourQuoteSelector.buyFlowElementsSelector,
      buyFlowElements
    );
    mockSavedQuoteSelector = mockStore.overrideSelector(
      fromAgentSaveQuote.orderReviewInfoSelector,
      orderReviewInfo
    );
    mockSavedQuoteSelector = mockStore.overrideSelector(
      fromAgentSaveQuote.primaryInsuredAgeValidationDetailsSelector,
      ageValData
    );
    component = fixture.componentInstance;
    spyOn(component, 'getDependentsDetails').and.returnValue(dependentObject);
    spyOn(component, 'getPersonalDetails').and.returnValue(
      personalInformationObject
    );
    fixture.detectChanges();
  });

  it('should create', () => {
    component.totalMonthlyPayment = 0;
    expect(component).toBeTruthy();
  });

  it('should check applyAgeValidation function is called', () => {
    component.applyAgeValidation();
    expect(component.applyAgeValidation).toBeDefined();
  });

  it('should check openAgeNotEligibleModel function is called', () => {
    component.openAgeNotEligibleModel(agePayload);
    expect(component.openAgeNotEligibleModel).toBeDefined();
  });
  it('should check ageValidationFlow function is called', () => {
    component.ageValidationFlow(ageValData);
    expect(component.ageValidationFlow).toBeDefined();
  });

  // it('should call convertDOB function and return date in yyyy-mm-dd format', () => {
  //   const formattedDate = component.convertDOB('01/01/2000', 'yyyy-mm-dd');
  //   expect(formattedDate).toEqual('2000-01-01');
  // });
  // it('should call convertDOB function and return date in mm/dd/yyyy format', () => {
  //   const formattedDate = component.convertDOB('2000-01-01', 'mm/dd/yyyy');
  //   expect(formattedDate).toEqual('01/01/2000');
  // });
  it('should convert DOB to required format', () => {
    const dob1 = component.convertDOB('09/09/1990', 'request-payload');
    const dob2 = component.convertDOB('1990-09-09', 'modal-payload');
    expect(dob1).toEqual('1990-09-09');
    expect(dob2).toEqual('09/09/1990');
  });
  it('should convert single digit number to 2 digit', () => {
    const twodigitnumber = component._to2digit(1);
    expect(twodigitnumber).toEqual('01');
  });
  it('should set effective date', () => {
    component.setEffectiveDate('01/01/2000');
    expect(component.effectiveDate).toEqual('01/01/2000');
  });

  it('should check checkDependentEligibility function is called', () => {
    component.checkDependentEligibility();
    expect(component.checkDependentEligibility).toBeDefined();
  });

  it('should check nonEligibleDependentsOfSelectedProduct function is called', () => {
    component.dependentsDetails = dependentObject;
    component.nonEligibleDependentsOfSelectedProduct(depValInfo, 'PREC-IA');
    expect(component.nonEligibleDependentsOfSelectedProduct).toBeDefined();
  });

  it('should check updateDependentDetailsBasedOnEligibility function is called', () => {
    const inputData = {
      productDetails: [
        {
          nonEligibleDependents: [{}],
          coverage: {
            new: 'ind'
          },
          monthlyPremium: {
            new: '123'
          }
        }
      ]
    };

    component.updateDependentDetailsBasedOnEligibility(inputData);
    expect(component.updateDependentDetailsBasedOnEligibility).toBeDefined();
  });

  it('should call updateBuyFlowElements', () => {
    component.updateBuyFlowElements();
    expect(component.updateBuyFlowElements).toBeDefined();
  });
  it('should update DependentDetails Based On Eligibility', () => {
    spyOn(component, 'updateBuyFlowElements').and.returnValue(true);
    component.orderedProducts = selectedPlans.value;
    component.updateDependentDetailsBasedOnEligibility(modalPayload);
    expect(component.updateBuyFlowElements).toHaveBeenCalled();
  });

  it('should update dependent store on navigation', () => {
    spyOn(component, 'updateBuyFlowElements').and.returnValue(true);
    expect(component.updateBuyFlowElements).toBeDefined();
  });

  it('should return formatted benefit amount', () => {
    const result = component.getBenefitAmount(10000);
    expect(result).toEqual('$10K');
  });

  it('should call applyAgeValidation from proceedToCheckout function', () => {
    spyOn(mockStore, 'dispatch').and.returnValue(true);
    spyOn(component, 'initAgeValidationResponseOfDependents').and.returnValue(
      true
    );
    spyOn(component, 'applyAgeValidation').and.returnValue(true);
    // spyOn(component, 'convertDOBOfPrimaryInsured').and.returnValue(true);
    component.effectiveDate = new Date();
    component.cartDetailsModified = [];
    component.orderedProducts = selectedPlans.value;
    component.proceedToCheckout();
    expect(component.applyAgeValidation).toHaveBeenCalled();
  });

  it('should call updateBuyFlowElements from updateDependentsDetailStore function', () => {
    spyOn(component, 'updateBuyFlowElements').and.returnValue(true);
    component.dependentsDetails = dependentObject;
    component.updateDependentsDetailStore();
    expect(component.updateBuyFlowElements).toHaveBeenCalled();
  });

  it('should open DependentIneligibilityModalComponent from showDependentIneligibilityPopup function', () => {
    spyOn(component.dialog, 'open').and.returnValue({
      afterClosed: () => of(true)
    });
    spyOn(
      component,
      'updateDependentDetailsBasedOnEligibility'
    ).and.returnValue(true);
    spyOn(component, 'updateDependentsDetailStore').and.returnValue(true);
    const data = {};
    component.showDependentIneligibilityPopup(data);
    expect(component.dialog.open).toHaveBeenCalled();
  });

  it('should open AgeChangeInPremiumComponent modal from openAgeChangeInPremiumModel function', () => {
    spyOn(component.dialog, 'open').and.returnValue({
      afterClosed: () => of(true)
    });
    const data = {};
    component.openAgeChangeInPremiumModel(data);
    expect(component.dialog.open).toHaveBeenCalled();
  });

  class MockBuyflowService {
    enableStepperByRoute(route) {
      return of(true);
    }
    completeCurrentStepAndMoveToNext(route) {
      return of(true);
    }
    ageEligibilityCheck(): Observable<any> {
      return of(ageValData);
    }
    getDependentAgeValidation(): Observable<any> {
      return of(ageValidationResponse);
    }
    addItemsToCart(data) {
      return data;
    }
    calculateMonthlyPayment() {
      return 200;
    }
    getNumeric() {
      return 200;
    }
    updateShoppingCartPrice() {
      return of(true);
    }
    convertDOBOfPrimaryInsured() {
      return of(true);
    }

    getAgentSearchQuote() {
      return of(true);
    }
    convertDOB() {
      return of(true);
    }
    createUpdateQuoteReqParams(data) {
      return data;
    }
  }

  class MockAgentSharedService {
    createUpdateQuoteReqParams(inputdata) {
      return inputdata;
    }
  }
  class DialogMock {
    _containerInstance = { _config: { width: '380px' } };
    updatePosition() {}
    close() {}
  }
});
