import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CheckoutSuccessComponent } from './checkout-success.component';
import { StoreModule, Store } from '@ngrx/store';
import { provideMockStore, MockStore } from '@ngrx/store/testing';
import { BuyFlowService } from '../../../services/buy-flow.service';
import { BehaviorSubject } from 'rxjs';
import { TranslateModule } from '@ngx-translate/core';
import { RouterModule } from '@angular/router';
import { effectiveDate, SaveYourQuoteState } from '@aflac/agent/shared';
const mockEffectiveDate =
  'Wed Mar 25 2015 05:30:00 GMT+0530 (India Standard Time)';
describe('CheckoutSuccessComponent', () => {
  let component: CheckoutSuccessComponent;
  let fixture: ComponentFixture<CheckoutSuccessComponent>;
  let mockStore: MockStore<SaveYourQuoteState>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [CheckoutSuccessComponent],
      imports: [
        TranslateModule.forRoot(),
        StoreModule.forRoot({}),
        RouterModule.forRoot([])
      ],
      providers: [
        provideMockStore({}),
        { provide: BuyFlowService, useClass: MockBuyflowService }
      ]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CheckoutSuccessComponent);
    mockStore = TestBed.get(Store);
    mockStore.overrideSelector(effectiveDate, mockEffectiveDate);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
  class MockBuyflowService {
    isStepper = new BehaviorSubject(false);
  }
});
