import { selectCustomerInfo } from '@aflac/sales/shared';
import { Location } from '@angular/common';
import {
  Component,
  ElementRef,
  HostListener,
  OnInit,
  ViewChild
} from '@angular/core';
import { DomSanitizer, SafeResourceUrl } from '@angular/platform-browser';
import { ActivatedRoute, Router } from '@angular/router';
import { Store } from '@ngrx/store';
import { Subscription } from 'rxjs';
import { PersonalDetailsService } from '../personal-details/services/personal-details.service';
import { BuyFlowService } from '../../services/buy-flow.service';
import { PaymentService } from './services/payment.service';
import { DatePipe } from '@angular/common';

const enum sessionState {
  submit = 'submit',
  addAccount = 'addAccount',
  cancel = 'cancel'
}
@Component({
  selector: 'aflac-payment-checkout',
  templateUrl: './payment-checkout.component.html',
  styleUrls: ['./payment-checkout.component.scss']
})
export class PaymentCheckoutComponent implements OnInit {
  payload = null;
  route = '/check-out-payment-details';
  sessionUrl: SafeResourceUrl = null;
  appRoutes: any;
  session = {
    started: true,
    cancelled: false,
    submitted: false,
    startIframe: false
  };
  addCardResponse = false;
  isFrameLoaded: boolean;
  loaderService$: Subscription;
  submittedAccountId: string;
  submittedAccount: any;
  submittedAccountType: string; //Refactor above three;
  paymentAccounts: any; // PaymentMethod[] = [];
  customerInfo: any;
  userType: any;
  customerNumber: any;
  existingMembers = false;
  editFlow = false;
  firstName: any;
  lastName: any;
  streetAddress1: any;
  state: any;
  zip5: any;
  city: any;
  domesticPhoneNumber: any;
  email: any;
  @ViewChild('jpmcframe', { static: false }) iframe: ElementRef;

  constructor(
    public buyFlowService: BuyFlowService,
    public domSanitizer: DomSanitizer,
    public activeRoute: ActivatedRoute,
    private store: Store<{ QuoteState }>,
    private personalDetailsService: PersonalDetailsService,
    private location: Location,
    private router: Router,
    private paymentService: PaymentService,
    private datePipe: DatePipe
  ) {
    //   //The below is the sample response we are getting as the query params
    //   /*
    //   {accountId: 1018, returnSessionId: "1594303857580", DLFunction: "addAccount", DLAction: "cancel", paymentMethod: "CC"}
    //   */
    // });
  }

  ngOnInit() {
    // to be changed from content document
    this.route = this.router.url;
    this.buyFlowService.enableStepperByRoute(this.route);

    this.manipulateCustomerType();
    //this.getPaymentAccounts();
    //this.proceedToPayment();
    //this.getPersonalDetails();
    //this.location.subscribe(r => console.log(r, '7777'));
  }

  manipulateCustomerType() {
    this.buyFlowService.getBundleDataFromBundleId().subscribe(bundleData => {
      //console.log('bundleData : ', bundleData);
      if (
        bundleData &&
        bundleData.status === true &&
        bundleData.data &&
        bundleData.data.quotes &&
        bundleData.data.quotes.length > 0
      ) {
        this.customerNumber = bundleData.data.quotes[0].customerNumber;
        this.userType = this.buyFlowService.checkCustomerType(
          this.customerNumber,
          bundleData.data.isAnonymous
        );
        this.paymentService.userType.next(this.userType);
        console.log('this.userType : ', this.userType);
        this.session.started = true;

        if (this.userType === 'member') {
          this.getMemberPaymentAccounts();
        }
      }
    });
  }

  private getMemberPaymentAccounts() {
    this.paymentService
      .getPaymentMethods(this.customerNumber)
      .subscribe((accounts: any) => {
        //console.log('accounts : ', accounts);
        if (accounts && accounts.data && accounts.data.length > 0) {
          this.manipulateAccounts(accounts.data);
        }
      });
  }

  manipulateAccounts(accountData) {
    const accountsMod = [];
    if (accountData) {
      accountData.map(item => {
        if (item) {
          //console.log('item : ', item);
          const itemClone = Object.assign({}, item);
          itemClone['nickname'] = item.nickName;
          if (item.type === 'eft') {
            itemClone['accountNumberLast4'] = item.accountNumber.slice(-4);
            accountsMod.push({ accountId: item.id, achAccount: itemClone });
          }
          if (item.type === 'pciCreditCard') {
            itemClone['creditCardNumberLast4'] = item.number;
            itemClone['creditCardExpirationDate'] = this.datePipe.transform(
              item.expirationDate,
              'MM/yyyy'
            );
            accountsMod.push({ accountId: item.id, ccAccount: itemClone });
          }
        }
      });
      accountsMod.length > 1
        ? (this.existingMembers = true)
        : (this.existingMembers = false);
      this.paymentAccounts = accountsMod;
    }
  }

  public getPersonalDetails() {
    this.store.select(selectCustomerInfo).subscribe(customerInfo => {
      console.log(customerInfo, 'Here you go -------------->');
    });
  }

  loadJPMCFrame(evt) {
    if (evt.target.src !== '') {
      this.isFrameLoaded = true;
      console.log('Frame loading completed now--->');
    }
  }

  savePayment() {
    const subscribeRedirect = this.buyFlowService.completeCurrentStepAndMoveToNext(
      this.route
    );
  }

  @HostListener('window:message', ['$event'])
  onMessage(event) {
    this.receiveMessage(event);
  }

  receiveMessage(e) {
    const receivedData = e.data;
    if (this.isValidURL(receivedData)) {
      const remainUrl = receivedData.slice(5);
      const paramArray = remainUrl.split('&');
      const keyValues = [];
      let action;
      for (let i = 0; i < paramArray.length; i++) {
        const pair = paramArray[i].split('=');
        if (pair[0] === 'DLAction') {
          action = pair[1];
        }
        keyValues.push({
          key: pair[0],
          value: pair[1]
        });
      }

      if (action) {
        this.sessionUrl = null;
        this.resetSession();
        this.session.cancelled = action === sessionState.cancel;
        this.session.submitted =
          action === sessionState.submit ||
          action === sessionState.addAccount ||
          action === 'editAccount';
        if (this.session.submitted) {
          this.submittedAccountId = keyValues.find(
            it => it.key === 'accountId'
          ).value;

          this.paymentService
            .getPaymentAuthorization({
              userId: 'POLICYNUMBER1', // Mandatory
              accountId: this.submittedAccountId // Mandatory
            })
            .subscribe(); //Only works in production according to Rama! What to do with this!
          this.getPaymentAccounts();
        } else {
          this.resetSession();
          this.session.started = true;
        }
      }
    }
  }

  isValidURL(val) {
    if (typeof val === 'string' && val.indexOf('JPMC-') === 0) {
      return true;
    }
    return false;
  }

  /**
   * Invoked to to fetch the jpmc url and load it inside the Iframe.
   */
  addPaymentMethod(data) {
    this.resetSession();
    this.session.startIframe = true;
    this.isFrameLoaded = false;
    //Sampple payload until the api is ready.
    console.log('Retrieved customerInfo,', this.customerInfo);
    this.buyFlowService.getBundleDataFromBundleId().subscribe(bundleData => {
      if (
        bundleData &&
        bundleData.status === true &&
        bundleData.data &&
        bundleData.data.quotes &&
        bundleData.data.quotes.length > 0 &&
        bundleData.data.quotes[0].insureds &&
        bundleData.data.quotes[0].insureds.length > 0
      ) {
        this.customerNumber =
          bundleData.data.quotes[0].insureds[0].customerNumber;

        this.firstName = bundleData.data.quotes[0].insureds[0].firstName;
        this.lastName = bundleData.data.quotes[0].insureds[0].lastName;
      }
      if (
        bundleData &&
        bundleData.status === true &&
        bundleData.data &&
        bundleData.data.quotes &&
        bundleData.data.quotes.length > 0 &&
        bundleData.data.quotes[0].insureds &&
        bundleData.data.quotes[0].insureds.length > 0 &&
        bundleData.data.quotes[0].insureds[0].address
      ) {
        this.streetAddress1 =
          bundleData.data.quotes[0].insureds[0].address.addressLine1;
        this.city = bundleData.data.quotes[0].insureds[0].address.city;
        this.state = bundleData.data.quotes[0].insureds[0].address.stateProvCd;
        this.zip5 = bundleData.data.quotes[0].insureds[0].address.postalCode;
      }
      if (
        bundleData &&
        bundleData.status === true &&
        bundleData.data &&
        bundleData.data.quotes &&
        bundleData.data.quotes.length > 0 &&
        bundleData.data.quotes[0].insureds &&
        bundleData.data.quotes[0].insureds.length > 0 &&
        bundleData.data.quotes[0].insureds[0].phones &&
        bundleData.data.quotes[0].insureds[0].phones.length > 0
      ) {
        this.domesticPhoneNumber =
          bundleData.data.quotes[0].insureds[0].phones[0].phone;
      }
      if (
        bundleData &&
        bundleData.status === true &&
        bundleData.data &&
        bundleData.data.quotes &&
        bundleData.data.quotes.length > 0 &&
        bundleData.data.quotes[0].insureds &&
        bundleData.data.quotes[0].insureds.length > 0 &&
        bundleData.data.quotes[0].insureds[0].emails &&
        bundleData.data.quotes[0].insureds[0].emails.length > 0
      ) {
        this.email = bundleData.data.quotes[0].insureds[0].emails[0].email;
      }
    });
    if (this.customerInfo && this.customerInfo.firstName) {
      this.payload = {
        type: data.type, // Account type mandatory field CC/ACH
        profile: {
          userId: 'POLICYNUMBER1', // Mandatory
          firstName: this.customerInfo.firstName,
          streetAddress1: '',
          city: '',
          state: '',
          zip5: '',
          domesticPhoneNumber: '',
          email: '', // Mandatory
          achEnableDisable: 'E'
        },

        returnUrl: window.location.href
      };
      if (
        this.customerInfo.addresses &&
        this.customerInfo.addresses.length > 0
      ) {
        this.payload.profile.addressLine1 = this.customerInfo.addresses[0].addressLine1;
        this.payload.profile.city = this.customerInfo.addresses[0].city;
        this.payload.profile.state = this.customerInfo.addresses[0].stateProvCd;
        this.payload.profile.zip5 = this.customerInfo.addresses[0].zipCode;
      }
      if (this.customerInfo.phones && this.customerInfo.phones.length > 0) {
        this.payload.profile.domesticPhoneNumber = this.customerInfo.phones[0].phone;
      }
      if (this.customerInfo.emails && this.customerInfo.emails.length > 0) {
        this.payload.profile.email = this.customerInfo.emails[0].email;
      }
    } else {
      this.payload = {
        type: data.type, // Account type mandatory field CC/ACH
        profile: {
          userId: this.customerNumber || '20000000213', // Mandatory
          firstName: this.firstName,
          lastName: this.lastName,
          streetAddress1: this.streetAddress1,
          city: this.city,
          state: this.state,
          zip5: this.zip5,
          domesticPhoneNumber: this.domesticPhoneNumber || '3232323232',
          email: this.email, // Mandatory
          achEnableDisable: 'E'
        },

        returnUrl: window.location.href
      };
    }
    this.getJPMCSessionTransferURL(this.payload);
  }

  /**
   * Gets the url of the page to be loaded inside the Iframe.
   * @param payload Customer info created from personal details
   */
  private getJPMCSessionTransferURL(payload) {
    //this.isFrameLoaded = false;
    this.paymentService.getJPMCSessionUrl(payload).subscribe(
      (result: any) => {
        this.sessionUrl = this.domSanitizer.bypassSecurityTrustResourceUrl(
          result.sessionTransferUrl
        );
      },
      failure => {
        console.log('Error retrieving the iframe url');
      }
    );
  }

  /**
   * Gets all the accouts based on the customer id provided
   */
  private getPaymentAccounts() {
    //const policyno = this.editFlow ? this.customerNumber : 'POLICYNUMBER1';
    const policyno = this.customerNumber || '20000000213';
    this.paymentService.getPaymentAccount(policyno).subscribe((r: any) => {
      console.log('r : ', r);
      console.log(r.accounts);
      //this.paymentAccounts = r.accounts;
      this.getAddedAccount(r.accounts);
    });
  }

  /**
   * To get the added account based on the returned 4 digit account ID.
   * @param accounts The accounts associated with the customer
   */
  private getAddedAccount(accounts: Array<any>) {
    const foundSubmittedOne = accounts.find(
      f => f.accountId === this.submittedAccountId
    );
    if (foundSubmittedOne) {
      if (foundSubmittedOne.ccAccount) {
        this.submittedAccount = foundSubmittedOne.ccAccount;
        this.submittedAccountType = 'CC';
      } else {
        this.submittedAccount = foundSubmittedOne.achAccount;
        this.submittedAccountType = 'ACH';
      }
    }
    console.log(this.submittedAccount);
  }

  showAccountBlock(accountId) {
    this.submittedAccountId = accountId;
    this.session.started = false;
    this.session.submitted = true;
    this.getAddedAccount(this.paymentAccounts);
  }

  changePaymentMethod() {
    this.session.started = true;
    this.session.submitted = false;
    this.session.cancelled = false;
  }

  addPaymentCard(data) {
    this.editFlow = false;
    this.addPaymentMethod(data);
  }

  resetSession() {
    this.session = {
      started: false,
      cancelled: false,
      submitted: false,
      startIframe: false
    };
  }

  editPaymentMethod(data) {
    this.resetSession();
    this.session.startIframe = true;
    this.editFlow = true;
    const payload = {
      userId: this.customerNumber,
      accountId: data.accountId.toString(),
      returnUrl: location.href,
      achEnableDisable: 'E'
    };
    this.isFrameLoaded = false;
    this.session.started = false;
    this.paymentService.getUpdateAccountUrl(payload).subscribe(
      (result: any) => {
        this.sessionUrl = this.domSanitizer.bypassSecurityTrustResourceUrl(
          result.sessionTransferUrl
        );
      },
      failure => {
        console.log('Error retrieving the iframe url');
      }
    );
  }
}
