import { SharedMaterialModule } from '@aflac/shared/material';
import { FieldValidator } from '@aflac/shared/validators';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import {
  FormBuilder,
  FormsModule,
  ReactiveFormsModule,
  Validators
} from '@angular/forms';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { StoreModule, MemoizedSelector, Store } from '@ngrx/store';
import { TranslateModule } from '@ngx-translate/core';
import { MaskApplierService, NgxMaskModule } from 'ngx-mask';
import { saveYourQuoteReducer } from '@aflac/agent/shared';
import { PersonalDetailsContactInfoComponent } from './personal-details-contact-info.component';
import { MockStore, provideMockStore } from '@ngrx/store/testing';
import { of, BehaviorSubject, Observable } from 'rxjs';
import { PersonalDetailsService } from '../services/personal-details.service';

describe('PersonalDetailsContactInfoComponent', () => {
  let component: PersonalDetailsContactInfoComponent;
  let mockStore: MockStore<any>;
  let fixture: ComponentFixture<PersonalDetailsContactInfoComponent>;
  const fb: FormBuilder = new FormBuilder();
  const contactForm = fb.group(
    {
      phone_number: [
        '1111111111',
        [Validators.required, Validators.minLength(10)]
      ],
      email: [
        'a@gmail.com',
        [
          Validators.required,
          FieldValidator.patternValidator(
            /^[a-zA-Z.]+@[a-zA-Z_]+?\.[a-zA-Z]{2,3}$/
          )
        ]
      ],
      confirm_email: [
        'a@gmail.com',
        [
          Validators.required,
          FieldValidator.patternValidator(
            /^[a-zA-Z.]+@[a-zA-Z_]+?\.[a-zA-Z]{2,3}$/
          )
        ]
      ],
      electronic_delivery: [false, FieldValidator.isEmpty]
    },
    {
      validator: +FieldValidator.mustMatch('email', 'confirm_email')
    }
  );

  const personalData = {
    emails: [
      {
        email: 'a@gmail.com'
      }
    ],
    phones: [
      {
        phone: '1234567892'
      }
    ],
    customerNumber: '1212'
  };
  const userDetails = {
    age: '54',
    consentStatus: 'GRANTED',
    customerNumber: '510001',
    email: 'johnsmith@gmail.com',
    firstName: 'Johnson',
    lastName: 'S',
    quotes: [
      {
        caseId: 'QWESR2314 WE',
        coverageTypeCd: 'ind_sps',
        packageCd: 'plan07',
        productCd: 'PREC-IC',
        productName: 'Cancer Insurance',
        riders: [],
        riskStateCd: 'AL',
        series: 'test',
        sfrId: '',
        totalPremium: '16.93'
      }
    ]
  };

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [PersonalDetailsContactInfoComponent],
      imports: [
        TranslateModule.forRoot(),
        ReactiveFormsModule,
        NgxMaskModule.forRoot(),
        BrowserAnimationsModule,
        FormsModule,
        HttpClientTestingModule,
        SharedMaterialModule,
        StoreModule.forRoot(saveYourQuoteReducer)
      ],
      providers: [
        provideMockStore({}),
        MaskApplierService,
        { provide: FormBuilder, useValue: fb },
        {
          provide: PersonalDetailsService,
          useClass: MockPersonalDetailsService
        }
      ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PersonalDetailsContactInfoComponent);
    component = fixture.componentInstance;
    mockStore = TestBed.get(Store);
    component.contactForm = contactForm;

    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should check for new prospect', () => {
    component.ngOnInit();
  });

  it('form change event', () => {
    component.formChangeEvent();
    expect(component.formChangeEvent).toBeDefined();
  });

  it('key press event', () => {
    const mockEvent = {
      target: {
        value: '123456789'
      },
      charCode: 49
    };
    component.keyPress(mockEvent);
  });

  it('should check saveDataOnContactSuccess function is called', () => {
    const personalInfoData = {
      formData: personalData,
      customerId: '111111',
      statusOnComplete: 'contact-success'
    };
    component.saveDataOnContactSuccess(personalInfoData);
    expect(component.saveDataOnContactSuccess).toBeDefined();
  });

  it('set form data event ', () => {
    component.data = {
      emails: [
        {
          email: 'a@gmail.com'
        }
      ],
      phones: [
        {
          phone: '1234567891'
        }
      ]
    };
    component.setContactFormData();
  });

  it('should check for toggleViewMode ', () => {
    component.toggleViewMode();
    expect(component.toggleViewMode).toBeDefined();
  });

  it('should check for setContactFormData ', () => {
    component.setContactFormData();
    expect(component.setContactFormData).toBeDefined();
  });

  it('should check for onSubmit ', () => {
    const personalInfoData = {
      formData: personalData,
      customerId: '111111',
      statusOnComplete: 'contact-success'
    };
    component.onSubmit();
    expect(component.onSubmit).toBeDefined();
  });

  class MockPersonalDetailsService {
    public isFormValid = new BehaviorSubject(false);
    public confirmNewAddress = new BehaviorSubject(false);
    public isMyInfoFormStatus = new BehaviorSubject(true);
    public isAddressFormStatus = new BehaviorSubject(true);
    public isShowContactForm = new BehaviorSubject(true);
    public isContactFormView = new BehaviorSubject(true);
    public buttonVisibleStatus = new BehaviorSubject(false);
    public userType = new BehaviorSubject('new');
    public isContactFormStatus = new BehaviorSubject(true);

    getPersonalData(route): Observable<any> {
      return of(personalData);
    }
    getUserDataFomSaveQuoteResponse(): Observable<any> {
      return of(userDetails);
    }
    formateDataOnFormSubmit() {
      return of(true);
    }
    addUserDependentData() {
      return of(true);
    }
  }
});
