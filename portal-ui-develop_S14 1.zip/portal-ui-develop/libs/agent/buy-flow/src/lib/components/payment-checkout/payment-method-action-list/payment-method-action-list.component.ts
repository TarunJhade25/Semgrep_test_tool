import {
  Component,
  OnInit,
  Input,
  EventEmitter,
  Output,
  OnChanges
} from '@angular/core';
import { PaymentService } from '../services/payment.service';

@Component({
  selector: 'aflac-payment-method-action-list',
  templateUrl: './payment-method-action-list.component.html',
  styleUrls: ['./payment-method-action-list.component.scss']
})
export class PaymentMethodActionListComponent implements OnInit, OnChanges {
  constructor(public paymentService: PaymentService) {}
  @Input()
  paymentAccounts;
  @Output() addPaymentCard = new EventEmitter();
  @Output() selectPayment = new EventEmitter();
  @Output() editPaymentMethod = new EventEmitter();
  existingMembers = false;
  paymentActionAdd = 'ADD';
  showAddBankDetails = true;
  ngOnInit() {}

  ngOnChanges() {
    console.log('paymentAccounts change : ', this.paymentAccounts);
    this.checkBackDetalisLoaded();
  }
  checkBackDetalisLoaded() {
    this.showAddBankDetails = true;
    if (this.paymentAccounts && this.paymentAccounts.length > 0) {
      this.existingMembers = true;
      this.paymentAccounts.forEach(element => {
        if (element.achAccount) {
          this.showAddBankDetails = false;
        }
      });
    } else {
      this.existingMembers = false;
    }
  }
  gotoadd(data) {
    this.addPaymentCard.emit(data);
  }

  gotoesign(data) {
    this.selectPayment.emit(data);
  }

  gotoedit(data) {
    this.editPaymentMethod.emit(data);
  }
}
