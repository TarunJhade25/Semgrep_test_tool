import { Component, OnInit } from '@angular/core';
import { Store, select } from '@ngrx/store';
import { SaveYourQuoteState } from '@aflac/agent/shared';
import { dependentDataByRouteSelector } from '@aflac/agent/shared'; // Selectors

@Component({
  selector: 'aflac-checkout-email-success',
  templateUrl: './checkout-email-success.component.html',
  styleUrls: ['./checkout-email-success.component.scss']
})
export class CheckoutEmailSuccessComponent implements OnInit {
  constructor(private store: Store<SaveYourQuoteState>) {}
  fetchedEmail: string;
  ngOnInit() {
    this.store
      .pipe(select(dependentDataByRouteSelector, '/my-details'))
      .subscribe(personalInfo => {
        if (personalInfo && personalInfo.emails) {
          this.fetchedEmail = personalInfo.emails[0].email || '';
        }
      });
  }
}
