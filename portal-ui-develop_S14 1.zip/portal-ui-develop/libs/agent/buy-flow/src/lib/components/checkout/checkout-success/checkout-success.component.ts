import { Component, OnInit, OnDestroy, AfterViewInit } from '@angular/core';
import { BuyFlowService } from '../../../services/buy-flow.service';
import { Store, select } from '@ngrx/store';
import { SaveYourQuoteState } from '@aflac/agent/shared'; //stores
import { effectiveDate } from '@aflac/agent/shared'; //selectors
import { Router } from '@angular/router';
import { dependentDataByRouteSelector } from '@aflac/agent/shared';
@Component({
  selector: 'aflac-checkout-success',
  templateUrl: './checkout-success.component.html',
  styleUrls: ['./checkout-success.component.scss']
})
export class CheckoutSuccessComponent implements OnInit, AfterViewInit {
  effectiveDate: string;
  fetchedEmail: string;
  constructor(
    public buyFlowService: BuyFlowService,
    private store: Store<SaveYourQuoteState>,
    public _router: Router
  ) {}

  ngOnInit() {
    this.store.select(effectiveDate).subscribe(effDate => {
      if (effDate) this.effectiveDate = this.showFormattedDate(effDate);
    });
    this.store
      .pipe(select(dependentDataByRouteSelector, '/my-details'))
      .subscribe(personalInfo => {
        if (personalInfo && personalInfo.emails) {
          this.fetchedEmail = personalInfo.emails[0].email || '';
        }
      });
  }
  ngAfterViewInit() {
    this.buyFlowService.isStepper.next(false);
  }
  redirectHome() {
    this._router.navigateByUrl('home');
  }
  showFormattedDate(date) {
    const today = new Date(date);
    let formattedDate = '';
    const dd = today.getDate();
    let ddStr = dd.toString();
    const mm = today.getMonth() + 1;
    let mmStr = mm.toString();
    const yyyy = today.getFullYear();
    const yyyyStr = yyyy.toString();
    if (dd < 10) {
      ddStr = `0${ddStr}`;
    }

    if (mm < 10) {
      mmStr = `0${mmStr}`;
    }
    formattedDate = mmStr + '/' + ddStr + '/' + yyyyStr;
    return formattedDate;
  }
}
