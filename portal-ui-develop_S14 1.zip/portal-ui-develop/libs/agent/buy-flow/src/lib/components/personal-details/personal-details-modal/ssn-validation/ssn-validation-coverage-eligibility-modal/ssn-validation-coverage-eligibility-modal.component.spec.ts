import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { SsnValidationCoverageEligibilityModalComponent } from './ssn-validation-coverage-eligibility-modal.component';
import { TranslateModule } from '@ngx-translate/core';
import {
  MatDialogModule,
  MatDialogRef,
  MatDialog,
  MAT_DIALOG_DATA
} from '@angular/material/dialog';
import { StoreModule, Store, MemoizedSelector } from '@ngrx/store';
import { saveYourQuoteReducer } from '@aflac/agent/shared';
import { RouterTestingModule } from '@angular/router/testing';
import { NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { SharedMaterialModule } from '@aflac/shared/material';
import { PersonalDetailsService } from '../../../services/personal-details.service';
import { AgentSharedService } from '@aflac/agent/shared';
import { of, Observable } from 'rxjs';
import { StateEntityService } from '@aflac/shared/data-model';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { provideMockStore, MockStore } from '@ngrx/store/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { Router } from '@angular/router';

describe('SsnValidationCoverageEligibilityModalComponent', () => {
  let component: SsnValidationCoverageEligibilityModalComponent;
  let fixture: ComponentFixture<SsnValidationCoverageEligibilityModalComponent>;
  let dialog: MatDialog;
  let router: Router;
  let mockStore: MockStore<any>;

  const bundleData = {
    data: {
      quotes: [
        {
          bundleId: '000',
          policyNumber: 'a1b2',
          effectiveDate: '01/02/2019',
          expirationDate: '01/06/2019',
          transactionEffectiveDate: '03/02/2019',
          policyStatusCd: 'dummy',
          productCode: 'PREC-IC',
          lobCd: 'dummy',
          totalPremium: 1234,
          currencyCode: 'ind',
          producerCd: 'dummy',
          subProducerCd: 'd',
          quoteNumber: '111',
          customerNumber: '111'
        }
      ]
    }
  };

  const ssnData = {
    firstName: 'John',
    lastName: 'Doe',
    gender: 'M',
    ssn: '123456789',
    middleInitials: 'A',
    suffix: 'Jr.',
    dateOfBirth: '1985-07-13',
    aflacUserGuid: 'adskjk2764sdsd-sfsf',
    addresses: [
      {
        addressLine1: '11',
        addressLine2: 'a',
        city: 'Maa',
        stateProvCd: 'AL',
        zipCode: 12345
      }
    ],
    emails: [
      {
        email: 'a@gmail.com'
      }
    ],
    phones: [
      {
        phone: '1234567892'
      }
    ],
    customerNumber: '1212',
    availableProducts: [
      {
        productCd: 'PREC-IA'
      },
      {
        productCd: 'PREC-IC'
      }
    ]
  };

  const payloadData = {
    payload: {
      customerName: 'Johnson S',
      eligiblePlans: [
        {
          planId: 'plan07',
          planTitle: 'Standard Plan',
          productId: 'PREC-IC',
          productName: 'Cancer Insurance'
        }
      ],
      inEligiblePlans: [
        {
          productId: 'PREC-IA',
          productName: 'Accident Insurance',
          planId: 'Low',
          planTitle: 'Standard Plan'
        }
      ],
      purchasedProducts: [
        { productId: 'PREC-IA', productName: 'Accident Insurance' }
      ],
      updatedCartItems: [
        {
          availableInCart: true,
          coverage: 'ind',
          plan: {
            id: 'plan07',
            name: 'Lorem ipsum dolor sit',
            title: 'Standard Plan',
            description: 'These are the benefits that you cash.',
            states: []
          },
          productId: 'PREC-IC',
          productName: 'Cancer Insurance',
          selected: true,
          selectedRiders: [],
          startingPrice: '16.93'
        }
      ],
      ssnData: ssnData
    }
  };

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [SsnValidationCoverageEligibilityModalComponent],
      imports: [
        MatDialogModule,
        RouterTestingModule,
        SharedMaterialModule,
        TranslateModule.forRoot(),
        StoreModule.forRoot(saveYourQuoteReducer),
        BrowserAnimationsModule,
        HttpClientTestingModule
      ],
      schemas: [NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA],
      providers: [
        provideMockStore({}),
        { provide: MAT_DIALOG_DATA, useValue: ssnData },
        { provide: MatDialogRef, useClass: DialogMock },
        { provide: Router, useClass: RouterStub },
        { provide: StateEntityService, useClass: MockStateEntityService },
        {
          provide: PersonalDetailsService,
          useClass: MockPersonalDetailsService
        },
        {
          provide: AgentSharedService,
          useClass: MockAgentSharedService
        }
      ]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(
      SsnValidationCoverageEligibilityModalComponent
    );
    mockStore = TestBed.get(Store);
    component = fixture.componentInstance;
    dialog = TestBed.get(MatDialog);
    router = TestBed.get(Router);
    component.data = payloadData;
    component.selectedProfile = payloadData.payload;
    component.ssnDetails = ssnData;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('check for ngOnInit', () => {
    component.ngOnInit();
    expect(component.ngOnInit).toBeDefined();
  });

  it('check for goBackAndEdit', () => {
    component.goBackAndEdit();
    expect(component.goBackAndEdit).toBeDefined();
  });

  it('check for goToQuote', () => {
    component.goToQuote();
    expect(component.goToQuote).toBeDefined();
  });

  it('check for updateCartWithEligibleQuote', () => {
    component.updateCartWithEligibleQuote();
    expect(component.updateCartWithEligibleQuote).toBeDefined();
  });

  //Mock class
  class MockStateEntityService {
    entities$ = of([{ states: [{ code: 'AL', name: 'Alabama' }] }]);
  }

  class MockPersonalDetailsService {
    calculateAgeFromDOB() {
      return of(true);
    }
  }

  class MockAgentSharedService {
    getStateNameFromStateProvCode() {
      return of(true);
    }
    updateSearchQuote() {
      return of(true);
    }
    updateExistingCustomerInfo() {
      return of(true);
    }
    /*
    updateRetrieveQuote() {
      return of(true);
    } */
    updateCartWithEligibleQuote() {
      return of(true);
    }
  }

  class RouterStub {
    navigateByUrl(url: string) {
      return url;
    }
  }
  class DialogMock {
    close() {}
  }
});
