import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { ESignatureComponent } from './e-signature.component';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { MatDialogModule } from '@angular/material';
import { TranslateModule } from '@ngx-translate/core';
import { StoreModule, Store, MemoizedSelector } from '@ngrx/store';
import { saveYourQuoteReducer } from '@aflac/agent/shared';
import { provideMockStore, MockStore } from '@ngrx/store/testing';
import { SaveYourQuoteState, ProductState } from '@aflac/agent/shared'; //stores
import { RouterModule } from '@angular/router';
import {
  agentESign,
  selectedProduct,
  effectiveDate
} from '@aflac/agent/shared'; //selectors

import { BrowserDynamicTestingModule } from '@angular/platform-browser-dynamic/testing';
import { CheckoutEmailSuccessComponent } from '../../checkout-email-success/checkout-email-success.component';
const constName = {};
const constStoreName = {};
const mockEffectiveDate =
  'Wed Mar 25 2015 05:30:00 GMT+0530 (India Standard Time)';

describe('ESignatureComponent', () => {
  let component: ESignatureComponent;
  let fixture: ComponentFixture<ESignatureComponent>;
  let mockStore: MockStore<SaveYourQuoteState>;
  let mockProdStore: MockStore<ProductState>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ESignatureComponent, CheckoutEmailSuccessComponent],
      imports: [
        MatDialogModule,
        TranslateModule.forRoot(),
        StoreModule.forRoot(saveYourQuoteReducer),
        BrowserAnimationsModule,
        RouterModule.forRoot([])
      ],
      providers: [provideMockStore({})],
      schemas: [CUSTOM_ELEMENTS_SCHEMA]
    })
      .overrideModule(BrowserDynamicTestingModule, {
        set: {
          entryComponents: [CheckoutEmailSuccessComponent]
        }
      })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ESignatureComponent);
    mockStore = TestBed.get(Store);
    mockProdStore = TestBed.get(Store);
    mockStore.overrideSelector(agentESign, constStoreName);
    mockStore.overrideSelector(effectiveDate, mockEffectiveDate);
    mockProdStore.overrideSelector(selectedProduct, constName);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
