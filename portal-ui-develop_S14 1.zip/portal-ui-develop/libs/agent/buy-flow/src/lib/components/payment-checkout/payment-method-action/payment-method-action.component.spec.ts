import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PaymentMethodActionComponent } from './payment-method-action.component';
import { TranslateModule } from '@ngx-translate/core';

describe('PaymentMethodActionComponent', () => {
  let component: PaymentMethodActionComponent;
  let fixture: ComponentFixture<PaymentMethodActionComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [PaymentMethodActionComponent],
      imports: [TranslateModule.forRoot()]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PaymentMethodActionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should check for selection to be enabled', () => {
    component.selectAction();
    expect(component.enableActions).toBeTruthy();
  });

  it('should check for and set expiry on init of component', () => {
    const monthIn = (new Date().getMonth() + 1).toString();
    component.data = {
      creditCardExpirationDate: `${monthIn}/2020`
    };
    component.checkExpiryOfCreditCards();
    expect(component.isToExpireSoon).toBeTruthy();
  });

  it('should check for and set expiry on init of component', () => {
    component.data = {
      creditCardExpirationDate: '06/2020'
    };
    component.checkExpiryOfCreditCards();
    expect(component.isExpired).toBeTruthy();
  });

  it('should check for and set expiry on init of component', () => {
    const monthIn = (new Date().getMonth() + 2).toString();
    component.data = {
      creditCardExpirationDate: `${monthIn}/2020`
    };
    component.checkExpiryOfCreditCards();
    expect(component.isExpired).toBeFalsy();
    expect(component.isToExpireSoon).toBeFalsy();
  });

  it('should check for and set expiry on init of component', () => {
    const yearIn = (new Date().getFullYear() + 1).toString();
    component.data = {
      creditCardExpirationDate: `06/${yearIn}`
    };
    component.checkExpiryOfCreditCards();
    expect(component.isExpired).toBeFalsy();
    expect(component.isToExpireSoon).toBeFalsy();
  });
});
