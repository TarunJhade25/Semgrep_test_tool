export interface CheckOutPostSignModel {
  policyNumber: string;
  productCode: string;
  signatureInd: boolean;
  signatureTypeCd: string;
  dateTimestamp: string;
  signedName: string;
  ipNumber: string;
  voiceRRNum: any;
}
