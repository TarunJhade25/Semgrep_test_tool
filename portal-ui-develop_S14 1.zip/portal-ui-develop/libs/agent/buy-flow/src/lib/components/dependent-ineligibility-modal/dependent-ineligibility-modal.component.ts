import { Component, OnInit, Inject, ChangeDetectorRef } from '@angular/core';
import { PerfectScrollbarConfigInterface } from 'ngx-perfect-scrollbar';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { CmsService } from '@aflac/shared/cms';
import { Store, select } from '@ngrx/store';
import { SaveYourQuoteState, dependentsEditAction } from '@aflac/agent/shared';
import { BuyFlowService } from '../../services/buy-flow.service';
import { DependentService } from '../dependents/services/dependent.service';

@Component({
  selector: 'aflac-dependent-ineligibility-modal',
  templateUrl: './dependent-ineligibility-modal.component.html',
  styleUrls: ['./dependent-ineligibility-modal.component.scss']
})
export class DependentIneligibilityModalComponent implements OnInit {
  public config: PerfectScrollbarConfigInterface = {
    scrollingThreshold: 0,
    minScrollbarLength: 148,
    maxScrollbarLength: 148,
    wheelSpeed: 0.6
  };
  nonEligibleDependents: any;
  coverageTypes: any;
  totalMonthlyCost: any;
  route: any;
  isUWR = false;
  constructor(
    @Inject(MAT_DIALOG_DATA) public data: any,
    public cmsService: CmsService,
    public buyFlowService: BuyFlowService,
    public dependentService: DependentService,
    private store: Store<SaveYourQuoteState>,
    private cdr: ChangeDetectorRef,
    public dialogRef: MatDialogRef<DependentIneligibilityModalComponent>
  ) {}

  ngOnInit() {
    this.coverageTypes = {};
    this.getCoverageTypes();
    this.isUWR = false;
    if (this.data && this.data.payload) {
      this.isUWR = this.data.payload.isUWR ? this.data.payload.isUWR : false;
      const _productDetails = this.data.payload.productDetails;
      this.route = this.data.payload.currentRoute;
      if (this.data.payload.dependentsNotEligible) {
        this.nonEligibleDependents = _productDetails.filter(
          e => e.nonEligibleDependents.length > 0
        );
      } else {
        this.nonEligibleDependents = _productDetails;
      }
      this.totalMonthlyCost = this.data.payload.totalMonthycost;
    }
    this.calculateScrollHeight();
  }
  calculateScrollHeight() {
    setTimeout(() => {
      const offsetHeight = document.getElementsByClassName('ps-content')[0]
        .clientHeight;
      if (offsetHeight < 336) {
        document
          .getElementById('dynamic-height-container')
          .classList.add('no-scroll-content');
        document
          .getElementById('ineligibility-modal-header')
          .classList.add('borderless-title');
        Array.from(document.getElementsByName('product-list-item')).forEach(
          item => {
            item.classList.add('item-with-border');
          }
        );
        document
          .getElementById('dependent-modal-scrollbar')
          .classList.add('scrollbar-no-scroll-content');
        this.cdr.detectChanges();
      }
    }, 200);
  }

  getCoverageTypes() {
    this.cmsService.getKey('agent_portal').subscribe(agentCMSData => {
      const _coverageTypes = agentCMSData && agentCMSData.coverage_types;
      _coverageTypes.forEach(element => {
        const key = element.code;
        const data = { [key]: element.default_value };
        this.coverageTypes = Object.assign(this.coverageTypes, data);
      });
    });
  }

  editDependent() {
    const payload = { edited: true };
    this.store.dispatch(dependentsEditAction({ payload }));
  }
  acceptAndContinue() {
    this.dialogRef.close('continue');
  }
}
