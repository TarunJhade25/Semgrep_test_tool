import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PaymentMethodActionListComponent } from './payment-method-action-list.component';
import { TranslateModule } from '@ngx-translate/core';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { HttpClientTestingModule } from '@angular/common/http/testing';

describe('PaymentMethodActionListComponent', () => {
  let component: PaymentMethodActionListComponent;
  let fixture: ComponentFixture<PaymentMethodActionListComponent>;
  const goToAddData = { type: 'CC' };
  const editData = {
    payload: {
      customerNumber: '400029',
      id: 1400,
      description: 'MasterCard ****4444 expiring 09/20',
      type: 'pciCreditCard',
      profileId: '1325',
      number: '4444',
      expirationDate: '2020-09-08',
      creditCardType: 'MasterCard',
      nickName: 'Ethan',
      nickname: 'Ethan',
      creditCardNumberLast4: '4444',
      creditCardExpirationDate: '09/2020'
    },
    accountId: 1400,
    type: 'CC'
  };
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [PaymentMethodActionListComponent],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
      imports: [HttpClientTestingModule, TranslateModule.forRoot()]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PaymentMethodActionListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
  it('should call checkBackDetalisLoaded funtion', () => {
    component.checkBackDetalisLoaded();
    expect(component as any).toBeDefined();
  });
  it('should call gotoadd funtion', () => {
    component.gotoadd(goToAddData);
    expect(component as any).toBeDefined();
  });
  it('should call gotoedit funtion', () => {
    component.gotoedit(editData);
    expect(component as any).toBeDefined();
  });
});
