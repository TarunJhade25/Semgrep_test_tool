import { Component, OnInit, OnDestroy } from '@angular/core';
import { Store, select } from '@ngrx/store';
import { Router } from '@angular/router';
import {
  SaveYourQuoteState,
  getIneligibleDependentDetails,
  getIneligibleDependentDetailsSuccess,
  checkDependentEdited,
  dependentsEditAction,
  ShoppingCartService,
  selectStateVariationObject,
  AgentSharedService
} from '@aflac/agent/shared';
import { Observable, combineLatest, Subscription } from 'rxjs';
import * as _ from 'lodash';
import { first, take } from 'rxjs/operators';
import { DependentService } from './services/dependent.service';
import { BuyFlowService } from '../../services/buy-flow.service';
import { CmsService } from '@aflac/shared/cms';
import {
  updateBuyFlowElements,
  buyFlowElementsSelector,
  getDependentRelationshipsSuccess,
  updateQuote,
  quoteDataUpdateStatus,
  getQuoteDataFromBundleId
} from '@aflac/agent/shared';
import { MatDialog } from '@angular/material/dialog';
import { DependentIneligibilityModalComponent } from '../dependent-ineligibility-modal/dependent-ineligibility-modal.component';
import { object } from 'prop-types';
import { ConsentModalComponent } from './consent-modal/consent-modal.component';
import { SaveStateVariationData } from '@aflac/shared/ui';

@Component({
  selector: 'aflac-dependents',
  templateUrl: './dependents.component.html',
  styleUrls: ['./dependents.component.scss']
})
export class DependentsComponent implements OnInit, OnDestroy {
  private subscriptions = new Subscription();
  private bundleSubscriptions = new Subscription();

  selectedQuoteData: any = [];
  coverageTypes: any = [];
  coverageTitle: string;
  dependentData$: Observable<any>;
  dependentDataArray: any;
  allowChildren = [];
  showNextProduct = false;
  productCounter = 1;
  hideChildForm = [];
  childButtonShow = [];
  showContinue = false;
  disableContinue = false;
  coverageArray = [];
  max: any = 1;
  route = '/dependents';
  ProductsInCart: any;
  customerBundleInfo: any;
  ageValidationSubscription = new Subscription();
  dependentEdited: any;
  customerNumber: any;
  userType: any = 'new';
  cartData: any;
  bundleData: any;
  depDataArray: any;
  modalDisplayed = false;
  dependentRelationshipData: any;
  depRelationshipTypes: any;
  userDataFlag = false;
  stateVariationData: any;
  stateVariationDataArray: any;

  constructor(
    public dependentService: DependentService,
    public buyFlowService: BuyFlowService,
    private store: Store<SaveYourQuoteState>,
    private cmsService: CmsService,
    private router: Router,
    public dialog: MatDialog,
    private shoppingCartService: ShoppingCartService,
    private agentSharedService: AgentSharedService
  ) {}

  ngOnInit() {
    this.route = this.router.url;
    this.getStateVariationData();
    this.buyFlowService.enableStepperByRoute(this.route);
    this.store.dispatch(
      getDependentRelationshipsSuccess({ payload: undefined })
    );
    this.dependentData$ = this.dependentService.getDependentData(this.route);
    this.subscriptions = this.dependentData$.subscribe(dependent => {
      this.depDataArray = dependent ? dependent : {};
    });
    this.manipulateQuoteData();
    this.initAgeValidationResponseOfDependents();
    this.getProductsInCart();
    this.getDependentAgeValidationResponse();
    this.checkDependentEdited();
  }

  getStateVariationData() {
    const subp = this.store
      .pipe(select(selectStateVariationObject))
      .subscribe(data => {
        if (!_.isEmpty(data)) {
          this.stateVariationDataArray = data;
        }
      });
    this.subscriptions.add(subp);
  }

  checkDependentEdited() {
    const subp = this.buyFlowService.checkDependentEdited().subscribe(res => {
      if (res) this.dependentEdited = res;
    });
    this.subscriptions.add(subp);
  }

  initAgeValidationResponseOfDependents() {
    this.store.dispatch(
      getIneligibleDependentDetailsSuccess({ payload: undefined })
    );
    this.store.dispatch(dependentsEditAction({ payload: undefined }));
  }

  getProductsInCart() {
    const subp = this.buyFlowService.getCartData().subscribe(data => {
      this.ProductsInCart = data && data.value;
    });
    this.subscriptions.add(subp);
  }

  getDependentAgeValidationResponse() {
    this.ageValidationSubscription = this.buyFlowService
      .getDependentAgeValidation()
      .subscribe(res => {
        //console.log('age res : ', res);
        if (res && res.data && res.data.length) {
          const products = [];
          let nonEligibleDependents = 0;
          let totalMonthlyCostOld = 0;
          let totalMonthlyCostNew = 0;
          const insuredDetails = res.data;
          this.ProductsInCart.forEach(element => {
            const monthlyPremium = Number(
              this.getMonthlyPremiumFromCart(element)
            );
            totalMonthlyCostOld = totalMonthlyCostOld + monthlyPremium;
            let _insuredDetails: any;
            insuredDetails.forEach(item => {
              if (
                Object.keys(item).includes(element.productId.replace(/-/g, ''))
              ) {
                _insuredDetails =
                  item[element.productId.replace(/-/g, '')].data;
              }
            });
            if (_insuredDetails) {
              totalMonthlyCostNew =
                totalMonthlyCostNew + Number(_insuredDetails.monthlyPremium);
              const payloadItem = {
                productId: element.productId,
                productName: element.productName,
                coverage: {
                  old: element.coverage,
                  new: _insuredDetails && _insuredDetails.coverageTierCd
                },
                nonEligibleDependents: this.nonEligibleDependentsOfSelectedProduct(
                  _insuredDetails.notEligibleInsureds,
                  element.productId
                ),
                monthlyPremium: {
                  old: monthlyPremium.toFixed(2),
                  new: Number(_insuredDetails.monthlyPremium).toFixed(2)
                }
              };
              products.push(payloadItem);
              if (
                payloadItem.nonEligibleDependents &&
                payloadItem.nonEligibleDependents.length > 0
              )
                nonEligibleDependents++;
            }
          });
          const cartPayload = {
            price: totalMonthlyCostNew.toFixed(2),
            count: this.ProductsInCart && this.ProductsInCart.length
          };
          const payload = {
            totalMonthycost: {
              old: Number(totalMonthlyCostOld).toFixed(2),
              new: Number(totalMonthlyCostNew).toFixed(2)
            },
            productDetails: this.sortProducts(products),
            currentRoute: this.route,
            dependentsNotEligible: nonEligibleDependents > 0 ? true : false,
            bundleData: this.bundleData,
            selectedQuoteData: this.selectedQuoteData,
            dependentDataArray: this.dependentDataArray
          };
          if (nonEligibleDependents > 0 || this.dependentEdited) {
            this.showDependentIneligibilityPopup(payload);
            this.shoppingCartService.updateShoppingCartPrice(cartPayload);
          } else {
            this.updateDependentQuote(
              this.bundleData,
              this.selectedQuoteData,
              this.dependentDataArray
            );
          }
        }
      });
  }

  updateDependentQuote(bundleData, cartData, depDataArray) {
    const updateQuoteInputParams = this.agentSharedService.createUpdateQuoteReqParams(
      {
        bundleId: bundleData && bundleData[0].bundleId,
        selectedPlans: cartData,
        dependentsList: this.dependentService.createDependentArrayWithQuoteNumber(
          depDataArray,
          bundleData
        )
      }
    );
    //console.log('updateQuoteInputParams : ', updateQuoteInputParams);
    this.store.dispatch(
      updateQuote({ payload: updateQuoteInputParams, isValidateRequired: 'N' })
    );
    const qusub = this.store
      .pipe(select(quoteDataUpdateStatus))
      .subscribe(res => {
        if (res && res.status === true) {
          this.store.dispatch(
            getQuoteDataFromBundleId({
              bundleId: updateQuoteInputParams.bundleId
            })
          );
          this.buyFlowService.completeCurrentStepAndMoveToNext(this.route);
        }
      });
    this.subscriptions.add(qusub);
  }

  sortProducts(products) {
    const sortedProducts = [];
    if (this.selectedQuoteData && this.selectedQuoteData.length) {
      this.selectedQuoteData.forEach(element => {
        const currentProduct = products.filter(
          e => e.productId === element.productId
        );
        if (currentProduct && currentProduct.length)
          sortedProducts.push(currentProduct[0]);
      });
    }
    if (sortedProducts.length !== products.length) {
      products.forEach(element => {
        const isPresent = sortedProducts.filter(
          e => e.productId === element.productId
        );
        if (!isPresent.length) sortedProducts.push(element);
      });
    }
    return sortedProducts;
  }

  updateDependentsDetailStore() {
    const products = Object.keys(this.dependentDataArray);
    const iteratedDependents = {};
    products.forEach(item => {
      let _selectedProduct = {};
      const dependents = this.dependentDataArray[item];
      if (dependents['spouse'] && dependents['spouse'].selected) {
        _selectedProduct = {
          ..._selectedProduct,
          spouse: dependents['spouse']
        };
      }
      if (dependents['children'] && dependents['children'].length) {
        const children = [];
        dependents['children'].forEach(child => {
          if (child.selected) children.push(child);
        });
        if (children.length) {
          _selectedProduct = { ..._selectedProduct, children: children };
        }
      }
      if (Object.keys(_selectedProduct).length > 0)
        iteratedDependents[item] = _selectedProduct;
    });
    this.dependentDataArray = iteratedDependents;
    this.updateBuyFlowElements();
  }

  getMonthlyPremiumFromCart(element) {
    let sum = 0;
    sum = sum + Number(element.plan.price);
    if (element.selectedRiders && element.selectedRiders.length) {
      element.selectedRiders.forEach(item => {
        sum = sum + item.rider.price;
      });
    }
    return Number(sum).toFixed(2);
  }

  nonEligibleDependentsOfSelectedProduct(info, productId) {
    //info: non eligible dependents array of selected productID
    const selectedProduct = this.dependentDataArray[productId];
    const _nonEligibleDependents = [];
    if (info && info.length) {
      info.forEach(element => {
        if (
          element.relationshipToPrimaryInsuredCd === '1' ||
          element.relationshipToPrimaryInsuredCd === 'Spouse'
        ) {
          const _data = {
            name:
              selectedProduct['spouse'].firstName +
              ' ' +
              selectedProduct['spouse'].lastName,
            relation: element.relationshipToPrimaryInsuredCd,
            dob: this.convertDOB(
              selectedProduct['spouse'].dateOfBirth,
              'modal-payload'
            ),
            oid: selectedProduct['spouse'].oid
          };
          _nonEligibleDependents.push(_data);
        } else if (
          element.relationshipToPrimaryInsuredCd === '2' ||
          element.relationshipToPrimaryInsuredCd === 'Child'
        ) {
          selectedProduct['children'].forEach(childInfo => {
            if (childInfo.oid === element.referenceNumber) {
              const _data = {
                name: childInfo.firstName + ' ' + childInfo.lastName,
                relation: element.relationshipToPrimaryInsuredCd,
                dob: this.convertDOB(childInfo.dateOfBirth, 'modal-payload'),
                oid: childInfo.oid
              };
              _nonEligibleDependents.push(_data);
            }
          });
        }
      });
      return _nonEligibleDependents;
    } else return [];
  }

  prepopulateDependentData() {
    this.max = this.selectedQuoteData && this.selectedQuoteData.length;
    this.selectedQuoteData.forEach((element, i) => {
      this.productCounter = i + 1;
      this._manipulateFlags();
    });
  }

  manipulateQuoteData() {
    this.bundleSubscriptions = combineLatest(
      this.buyFlowService.getCartData(),
      this.buyFlowService.getBundleDataFromBundleId()
    ).subscribe(([cartData, bundleData]) => {
      //console.log('bundleData : ', bundleData);
      //console.log('cartData : ', cartData);
      if (
        bundleData &&
        bundleData.status === true &&
        bundleData.data &&
        bundleData.data.quotes &&
        bundleData.data.quotes.length > 0 &&
        cartData &&
        cartData.value &&
        cartData.value.length > 0 &&
        !this.modalDisplayed
      ) {
        this.customerNumber = bundleData.data.quotes[0].customerNumber;
        if (this.customerNumber)
          this.dependentService.setPersonalData(this.customerNumber);
        //console.log('customerNumber : ', this.customerNumber);
        this.cartData = cartData.value;
        this.bundleData = bundleData.data.quotes;
        this.manipulateSelectedProducts(this.bundleData, this.cartData);
        this.manipulateCustomerType(bundleData.data.isAnonymous);
      }
    });
  }

  manipulateSelectedProducts(bundleData, cartData) {
    if (bundleData && cartData) {
      const res = cartData.map(val => {
        return Object.assign(
          {},
          val,
          bundleData.filter(v => v.productCode === val.productId)[0]
        );
      });
      if (res && res.length) {
        this.coverageArray = [];
        // Filter out all individual products
        this.selectedQuoteData = res
          .filter(item => item.coverage !== 'ind')
          .map(sQuoteData => {
            this.coverageArray.push(sQuoteData.coverage);
            return {
              ...sQuoteData,
              coverageTitle: this._setCoverageTypeTitle(sQuoteData.coverage)
            };
          });
        // Sort products based on heavy coverage type
        this._sortSelectedQuoteData();
        sessionStorage.setItem(
          'state-selected-agent-quote-data',
          JSON.stringify(this.selectedQuoteData)
        );
      }
    } else {
      this.selectedQuoteData = JSON.parse(
        sessionStorage.getItem('state-selected-agent-quote-data')
      );
    }
    //console.log('this.selectedQuoteData : ', this.selectedQuoteData);
  }

  manipulateCustomerType(isAnonymous) {
    if (this.customerNumber) {
      const pdsub = combineLatest(
        this.buyFlowService.getPersonalDataFromCustomerNumber(),
        this.buyFlowService.getUserDataFomSaveQuoteResponse()
      ).subscribe(([pData, uData]) => {
        //console.log('pData : ', pData);
        if (pData && pData.status === true && pData.data) {
          const personalData = pData.data;
          this.userType = this.buyFlowService.checkCustomerIsProspectOrMember(
            personalData,
            isAnonymous
          );
          this.dependentService.userType.next(this.userType);
        }
        //console.log('userType : ', this.userType);

        // To check whether edited the quote & navigated
        this.userDataFlag =
          uData && Object.keys(uData).length > 0 ? true : false;

        if (
          (this.userType === 'member' ||
            (this.userType === 'prospect' && !this.userDataFlag)) &&
          Object.keys(this.depDataArray).length === 0
        ) {
          this.manipulateExistingDependentData();
        } else if (this.userType === 'anonymous') {
          this.manipulateDependentDataFromBundle();
          this.getDependent();
        } else {
          this.getDependent();
        }
      });
      this.subscriptions.add(pdsub);
    }
  }

  manipulateExistingDependentData() {
    this.dependentService.setDependentRelationshipData(this.customerNumber);
    const depSub = this.dependentService
      .getDependentRelationshipData()
      .subscribe(depRelationData => {
        //console.log('depRelationData : ', depRelationData);
        if (
          depRelationData &&
          depRelationData.status === true &&
          depRelationData.data &&
          depRelationData.data.length > 0 &&
          this.selectedQuoteData &&
          this.selectedQuoteData.length > 0
        ) {
          this.dependentRelationshipData = depRelationData.data;
          this.addDependentDataToStore(false, '');
        }
      });
    //console.log('dependentRelationshipData : ', this.dependentRelationshipData);
    if (
      _.isEmpty(this.dependentRelationshipData) ||
      (this.dependentRelationshipData &&
        this.dependentRelationshipData.length === 0)
    )
      this.manipulateDependentDataFromBundle();
    this.getDependent();
    this.subscriptions.add(depSub);
  }

  manipulateDependentDataFromBundle() {
    let insuredMod;

    if (this.bundleData && this.bundleData.length > 0) {
      this.bundleData.forEach(item => {
        const insureds = {};
        const insureCh = [];
        if (item && item.insureds) {
          item.insureds.forEach(ins => {
            const insClone = Object.assign({}, ins);
            if (
              ins.relationshipToPrimaryInsuredCd !== 'SELF' &&
              ins.relationshipToPrimaryInsuredCd !== 'self'
            ) {
              if (insClone.relationshipToPrimaryInsuredCd === '1') {
                insClone['relationshipRole'] = 'SPOUSE';
                insClone['editMode'] = false;
                insClone['gender'] = ins.genderCd;
                insureds['spouse'] = insClone;
              } else if (insClone.relationshipToPrimaryInsuredCd === '2') {
                insClone['relationshipRole'] = 'CHILD';
                insClone['editMode'] = false;
                insClone['selected'] = true;
                insureCh.push(insClone);
                insureds['children'] = insureCh;
              }
            }
          });
          if (!_.isEmpty(insureds)) {
            insuredMod = Object.assign({}, insuredMod, {
              [item.productCode]: insureds
            });
          }
          //console.log('insuredMod : ', insuredMod);
        }
      });
      this.dependentService.addUserDependentDataFromBundle(
        insuredMod,
        this.route
      );
    }
  }

  addDependentDataToStore(spFlag, productId) {
    this.depRelationshipTypes = [];
    this.dependentRelationshipData.map(depReData => {
      this.depRelationshipTypes.push(depReData.relationshipRole);
    });
    this.dependentService.addUserDependentData(
      this.dependentRelationshipData,
      this.route,
      this.selectedQuoteData,
      this.coverageArray,
      this.depRelationshipTypes,
      spFlag,
      productId
    );
  }

  getDependent() {
    const subs = this.dependentData$.subscribe(dependent => {
      this.dependentDataArray = dependent;
      this.showContinue = this.showContinueButton();
      //console.log('dependentDataArray : ', this.dependentDataArray);
      if (this.showContinue) {
        this.prepopulateDependentData();
        this.dependentService.isFormValid.next(false);
      } else {
        this._manipulateFlags();
      }
      this.disableContinue = this.disableContinueButton();
    });
    this.subscriptions.add(subs);
  }

  nextProduct() {
    this.max = this.max + 1;
    this.productCounter++;

    // Copy dependent data to other products
    this._mapDependentDataToOtherProducts();

    // Update cloned data to stepper
    if (this.dependentDataArray) {
      this.updateBuyFlowElements();
    }

    // Manipulate buttons hide/show
    this._manipulateFlags();

    // Show/hide Continue button
    this.showContinue = this.showContinueButton();
  }

  addChildDependent(index, productIndex) {
    this.childButtonShow[productIndex] = false;
    this.hideChildForm[productIndex] = true;
    this.dependentService.isFormValid.next(true);
    this.dependentService.disableNextProduct.next(true);
    const element = document.getElementById('childBlock' + index);
    if (element) {
      this.scrollToPosition(element);
    }
  }

  saveDependent() {
    this.checkDependentEligibility();
    // save dep
  }

  showDependentIneligibilityPopup(data) {
    this.modalDisplayed = true;
    const dialogRef = this.dialog.open(DependentIneligibilityModalComponent, {
      disableClose: true,
      panelClass: 'dependent-ineligibility-modal-cover',
      data: { payload: data }
    });
    this.updateDependentDetailsBasedOnEligibility(data);
    dialogRef.afterClosed().subscribe(res => {
      if (res && res === 'continue') {
        this.updateDependentsDetailStore();
        this.updateDependentQuote(
          this.bundleData,
          this.selectedQuoteData,
          this.dependentDataArray
        );
      }
    });
  }

  /* Update Cart and dependentArray details based on eligibility */
  updateDependentDetailsBasedOnEligibility(data) {
    const productDetails = data.productDetails;
    const _dependentDataArray = Object.assign({}, this.dependentDataArray);
    productDetails.forEach(element => {
      if (
        (element.nonEligibleDependents &&
          element.nonEligibleDependents.length) ||
        this.dependentEdited
      ) {
        const cloneCartProduct = Object.assign(
          {},
          this.ProductsInCart.filter(e => e.productId === element.productId)[0]
        );
        const clonePlan = Object.assign({}, cloneCartProduct.plan);
        cloneCartProduct.coverage = element.coverage.new;
        const updatedPlanPrice =
          cloneCartProduct &&
          cloneCartProduct.selectedRiders &&
          cloneCartProduct.selectedRiders.length
            ? this.eliminateRiderPriceFromPremium(
                element.monthlyPremium.new,
                cloneCartProduct.selectedRiders
              )
            : element.monthlyPremium.new;
        clonePlan.price = updatedPlanPrice;
        cloneCartProduct.plan = clonePlan;
        const dataToDispatch = { key: 'from-list', value: cloneCartProduct };
        this.buyFlowService.addItemsToCart(dataToDispatch);
        this.selectedQuoteData.forEach((item, index) => {
          if (item.productId === element.productId) {
            const cloneSelectedQuote = item;
            cloneSelectedQuote.coverageTypeCd = cloneCartProduct.coverage;
            cloneSelectedQuote.coverage = cloneCartProduct.coverage;
            cloneSelectedQuote.coverageTitle = this._setCoverageTypeTitle(
              cloneCartProduct.coverage
            );
            cloneSelectedQuote.plan = clonePlan;
            this.selectedQuoteData[index] = cloneSelectedQuote;
          }
        });
        if (
          element.nonEligibleDependents &&
          element.nonEligibleDependents.length
        ) {
          const updateDependent = Object.assign(
            {},
            _dependentDataArray[element.productId]
          );
          element.nonEligibleDependents.forEach(dependent => {
            if (dependent.relation === '1') {
              const spouse = Object.assign({}, updateDependent['spouse']);
              spouse.selected = false;
              spouse.available = true;
              spouse.invalid = true;
              updateDependent['spouse'] = spouse;
            } else if (dependent.relation === '2') {
              const childArray = Object.assign([], updateDependent['children']);
              childArray.forEach((child, index) => {
                if (dependent.oid === child.oid) {
                  const noneligiblechild = Object.assign({}, child);
                  noneligiblechild.selected = false;
                  noneligiblechild.available = true;
                  noneligiblechild.invalid = true;
                  childArray[index] = noneligiblechild;
                }
              });
              updateDependent['children'] = childArray;
            }
          });
          _dependentDataArray[element.productId] = updateDependent;
        }
      }
    });
    this.dependentDataArray = _dependentDataArray;
    this.updateBuyFlowElements();
    sessionStorage.setItem(
      'state-selected-agent-quote-data',
      JSON.stringify(this.selectedQuoteData)
    );
  }

  eliminateRiderPriceFromPremium(price, rider) {
    let updatedPrice: number = price;
    let ridersum = 0;
    rider.forEach(item => {
      ridersum = ridersum + item.rider.price;
    });
    updatedPrice = updatedPrice - ridersum;
    return Number(updatedPrice).toFixed(2);
  }

  childInfoModal(productId) {
    this.stateVariationData = this.stateVariationDataArray[productId];
    if (this.stateVariationData) {
      const initialState = {
        dependent_info: this.stateVariationData.dependent_info || '',
        title: this.cmsService.getKey(
          'sales_portal.consent_modal_child_info_header'
        ),
        closeBtnName: this.cmsService.getKey(
          'sales_portal.consent_modal_close_button_text'
        )
      };
      this.dialog.open(ConsentModalComponent, {
        data: {
          initialState
        },
        panelClass: 'child-info-modal-resizer',
        ariaLabelledBy: 'mat-consent-dialog-title'
      });
    }
  }

  updateFlag(dataObj) {
    if (
      dataObj.mode === 'submit' &&
      dataObj.type === 'spouse' &&
      !dataObj.editMode &&
      (this.userType === 'member' ||
        (this.userType === 'prospect' && !this.userDataFlag))
    ) {
      this.addDependentDataToStore(true, dataObj.parentIndex);
    }
    if (this.userType === 'member' || dataObj.type === 'child') {
      const childBFlag = dataObj.mode === 'edit' ? false : true;
      this.childButtonShow[dataObj.parentIndex] = childBFlag;
      this.hideChildForm[dataObj.parentIndex] = false;
      // Show/hide Continue button
      this.showContinue = this.showContinueButton();
    }
  }

  _setCoverageTypeTitle(coverage) {
    this.cmsService.getKey('agent_portal').subscribe(agentCMSData => {
      this.coverageTypes = agentCMSData.coverage_types;
      if (this.coverageTypes && this.coverageTypes.length > 0) {
        this.coverageTitle = this.coverageTypes.filter(
          data => data.code === coverage
        )[0].default_value;
      }
    });
    return this.coverageTitle;
  }

  _sortSelectedQuoteData() {
    const coverageEquals = this.coverageArray.every((v, i, a) => v === a[0]);
    const ordering = {};
    const sortOrder = ['ind_fml', 'ind_sps', 'ind_chd'];
    for (let i = 0; i < sortOrder.length; i++) ordering[sortOrder[i]] = i;
    this.selectedQuoteData.sort((a, b) => {
      if (coverageEquals) {
        return parseFloat(a.startingPrice) - parseFloat(b.startingPrice);
      } else {
        return (
          ordering[a.coverage] - ordering[b.coverage] ||
          parseFloat(a.startingPrice) - parseFloat(b.startingPrice)
        );
      }
    });
  }

  _manipulateFlags() {
    if (this.selectedQuoteData && this.selectedQuoteData.length) {
      const productId = this.selectedQuoteData[this.productCounter - 1][
        'productId'
      ];
      const coverage = this.selectedQuoteData[this.productCounter - 1][
        'coverage'
      ];
      this.childButtonShow[productId] = true;

      if (coverage === 'ind_fml') {
        if (
          this.dependentDataArray &&
          this.dependentDataArray[productId] &&
          this.dependentDataArray[productId].spouse &&
          !this.dependentDataArray[productId].children
        ) {
          this.allowChildren[productId] = true;
          this.hideChildForm[productId] = true;
        } else if (
          this.dependentDataArray &&
          this.dependentDataArray[productId] &&
          this.dependentDataArray[productId].spouse &&
          this.dependentDataArray[productId].children
        ) {
          this.allowChildren[productId] = true;
          this.showNextProduct = this.showNextProductButton();
        }
      }
      if (
        coverage === 'ind_sps' &&
        this.dependentDataArray &&
        this.dependentDataArray[productId] &&
        this.dependentDataArray[productId].spouse
      ) {
        this.showNextProduct = this.showNextProductButton();
      }
      if (coverage === 'ind_chd') {
        this.allowChildren[productId] = true;
        if (
          this.dependentDataArray &&
          this.dependentDataArray[productId] &&
          this.dependentDataArray[productId].children
        ) {
          this.hideChildForm[productId] = false;
          this.showNextProduct = this.showNextProductButton();
        } else {
          this.hideChildForm[productId] = true;
          this.showNextProduct = false;
        }
      }
    }
  }

  _mapDependentDataToOtherProducts() {
    const productIndex = this.productCounter - 2;
    const productId = this.selectedQuoteData[productIndex]['productId'];
    const prevProductId =
      productIndex > 0
        ? this.selectedQuoteData[productIndex - 1]['productId']
        : '';
    const quoteObj = this.selectedQuoteData[productIndex + 1];

    if (this.dependentDataArray && this.dependentDataArray[productId]) {
      const cloneObj = this.dependentDataArray
        ? Object.assign({}, this.dependentDataArray[productId])
        : {};

      let cloneChildObj = [],
        childObjFiltered = [];
      if (quoteObj.coverage !== 'ind_sps') {
        if (
          prevProductId &&
          this.dependentDataArray[productId] &&
          this.dependentDataArray[productId].children &&
          this.dependentDataArray[prevProductId] &&
          this.dependentDataArray[prevProductId].children
        ) {
          cloneChildObj = [
            ...this.dependentDataArray[productId].children,
            ...this.dependentDataArray[prevProductId].children
          ];
        } else if (
          prevProductId &&
          this.dependentDataArray[prevProductId] &&
          this.dependentDataArray[prevProductId].children
        ) {
          cloneChildObj = this.dependentDataArray[prevProductId].children;
        } else {
          cloneChildObj = this.dependentDataArray[productId].children;
        }

        if (cloneChildObj && cloneChildObj.length > 0) {
          cloneChildObj = cloneChildObj.map(childObj => {
            const childObjMap = Object.assign({}, childObj);
            childObjMap.selected = true;
            return childObjMap;
          });
          // Filter unique child
          childObjFiltered = cloneChildObj.filter(
            (v, i) => cloneChildObj.findIndex(item => item.oid === v.oid) === i
          );
          // Sort based on added order
          childObjFiltered.sort((a, b) => {
            return a.addedDate - b.addedDate;
          });
        }
      }

      if (!this.dependentDataArray[quoteObj.productId]) {
        this.dependentDataArray = Object.assign({}, this.dependentDataArray, {
          [quoteObj.productId]: {}
        });
        // Update existing data if member/prospect
        if (
          this.userType === 'member' ||
          (this.userType === 'prospect' && !this.userDataFlag)
        ) {
          this.addDependentDataToStore(true, quoteObj.productId);
        }

        if (cloneObj && childObjFiltered && childObjFiltered.length > 0)
          cloneObj.children = childObjFiltered;

        this.dependentDataArray = Object.assign({}, this.dependentDataArray);

        if (quoteObj.coverage === 'ind_fml') {
          this.dependentDataArray[quoteObj.productId] = cloneObj;
        } else if (quoteObj.coverage === 'ind_sps' && cloneObj.spouse) {
          this.dependentDataArray[quoteObj.productId] = {
            spouse: cloneObj.spouse
          };
        } else {
          if (cloneObj.children) {
            this.dependentDataArray[quoteObj.productId] = {
              children: cloneObj.children
            };
          }
        }
      }
    }
  }

  showNextProductButton() {
    return this.selectedQuoteData.length ===
      (this.dependentDataArray && Object.keys(this.dependentDataArray).length)
      ? false
      : true;
  }

  showContinueButton() {
    //console.log('selectedQuoteData : ', this.selectedQuoteData);
    //console.log('dependentDataArray : ', this.dependentDataArray);
    let showCB = false,
      validData;
    if (
      this.dependentDataArray &&
      Object.keys(this.dependentDataArray).length > 0 &&
      this.selectedQuoteData &&
      this.selectedQuoteData.length &&
      !this.modalDisplayed
    ) {
      Object.keys(this.dependentDataArray).forEach(k => {
        const coverage = this.selectedQuoteData.filter(
          sp => sp.productId === k
        )[0].coverage;
        if (Object.keys(this.dependentDataArray[k]).length > 0) {
          if (coverage === 'ind_fml') {
            validData =
              this.dependentDataArray[k].spouse &&
              Object.keys(this.dependentDataArray[k].spouse).length > 0 &&
              this.dependentDataArray[k].children &&
              Object.keys(this.dependentDataArray[k].children).length > 0
                ? true
                : false;
          } else if (coverage === 'ind_sps') {
            validData =
              this.dependentDataArray[k].spouse &&
              Object.keys(this.dependentDataArray[k].spouse).length > 0
                ? true
                : false;
          } else {
            validData =
              this.dependentDataArray[k].children &&
              Object.keys(this.dependentDataArray[k].children).length > 0
                ? true
                : false;
          }
        }
      });
      showCB =
        this.selectedQuoteData.length ===
          Object.keys(this.dependentDataArray).length && validData
          ? true
          : false;
    } else if (this.modalDisplayed) {
      showCB = true;
    }
    return showCB;
  }

  disableContinueButton() {
    let disableCB = false;
    const disableCBArray = [];
    if (
      this.dependentDataArray &&
      Object.keys(this.dependentDataArray).length > 0 &&
      !this.modalDisplayed
    ) {
      Object.keys(this.dependentDataArray).forEach(k => {
        if (Object.keys(this.dependentDataArray[k]).length > 0) {
          if (this.dependentDataArray[k].children) {
            disableCBArray[k] = this.dependentDataArray[k].children.some(
              childSelected => childSelected.selected === true
            )
              ? false
              : true;
          }
        }
      });
      if (
        Object.keys(disableCBArray) &&
        Object.keys(disableCBArray).length > 0
      ) {
        disableCB = Object.keys(disableCBArray).every(
          el => disableCBArray[el] === false
        )
          ? false
          : true;
      }
    } else if (this.modalDisplayed) {
      disableCB = false;
    }
    return disableCB;
  }

  updateBuyFlowElements() {
    const subsBFElements = this.store
      .pipe(
        select(buyFlowElementsSelector),
        first()
      )
      .subscribe(data => {
        const buySteps = JSON.parse(JSON.stringify(data));
        buySteps.forEach((value, index) => {
          if (value.link === this.route) {
            buySteps[index].data = this.dependentDataArray;
          }
        });
        this.store.dispatch(updateBuyFlowElements({ payload: buySteps }));
      });
    this.subscriptions.add(subsBFElements);
  }

  /*  Request structure for age validation check */
  checkDependentEligibility() {
    const products = [];
    this.ProductsInCart.forEach(element => {
      const productDetails = {
        productCd: element.productId,
        packageCd: element.plan.id,
        agencyId: this.bundleData[0] && this.bundleData[0].producerCd,
        originalIssueState:
          this.bundleData[0] && this.bundleData[0].originalIssueState,
        intDiagnosisBenefitAmount: Number(element.benefitAmount),
        tobaccoInd: element.tobaccoInd,
        riders: this.getRiderDetails(element.selectedRiders),
        insureds: this.getInsuredDetails(element.productId)
      };
      products.push(productDetails);
    });
    const payload = {
      effectiveDate: new Date().toISOString(),
      products: products
    };
    this.store.dispatch(getIneligibleDependentDetails({ payload }));
  }

  getRiderDetails(item) {
    const riders = [];
    if (item) {
      item.forEach(riderItem => {
        const riderPayload = { riderNameCd: riderItem.rider.riderNameCd };
        riders.push(riderPayload);
      });
    }
    return riders;
  }

  getInsuredDetails(productId) {
    const insured = [];
    if (this.dependentDataArray) {
      const selectedProduct = this.dependentDataArray[productId];
      if (
        selectedProduct &&
        selectedProduct['spouse'] &&
        selectedProduct['spouse'].selected
      ) {
        insured.push(this.getInsuredArray(selectedProduct['spouse'], '1'));
      }
      if (selectedProduct && selectedProduct['children']) {
        selectedProduct['children'].forEach(item => {
          if (item.selected) insured.push(this.getInsuredArray(item, '2'));
        });
      }
    }
    const selfData = {
      customerNumber: this.customerNumber,
      dateOfBirth: this.getSelfDOB(),
      disabilityInd: false,
      newInd: true,
      primaryInsuredInd: true,
      referenceNumber: '0',
      relationshipToPrimaryInsuredCd: 'SELF'
    };

    insured.push(selfData);
    return insured;
  }

  getSelfDOB() {
    if (
      this.bundleData &&
      this.bundleData.length > 0 &&
      this.bundleData[0].insureds
    ) {
      const selfData = this.bundleData[0].insureds.filter(
        item =>
          item.relationshipToPrimaryInsuredCd === 'SELF' ||
          item.relationshipToPrimaryInsuredCd === 'self'
      );
      return selfData && selfData.length && selfData[0].dateOfBirth;
    }
  }

  getInsuredArray(data, dependentCode) {
    const details = {
      referenceNumber: data.oid,
      customerNumber: this.customerNumber,
      relationshipToPrimaryInsuredCd: dependentCode,
      dateOfBirth: this.convertDOB(data.dateOfBirth, 'request-payload'),
      disabilityInd: false,
      newInd: data.customerNumber ? false : true,
      primaryInsuredInd: false
    };
    return details;
  }

  scrollToPosition(e) {
    setTimeout(() => {
      window.scroll({
        behavior: 'smooth',
        left: 0,
        top: e.offsetTop
      });
    }, 100);
  }

  /* To check DOB format matches mm/dd/yyy. For API request convert to yyyy-mm-dd format, 
  for modal input convert to mm/dd/yyy format */
  convertDOB(date, payload) {
    const regex = /^[0-9]{2}[\/][0-9]{2}[\/][0-9]{4}$/g;
    const matchRequiredFormat = regex.test(date);
    if (payload === 'request-payload') {
      if (matchRequiredFormat) {
        //change to yyyy-mm-dd
        const datearray = date.split('/');
        return datearray[2] + '-' + datearray[0] + '-' + datearray[1];
      } else return date;
    } else if (payload === 'modal-payload') {
      if (!matchRequiredFormat) {
        //change to mm/dd/yyyy
        const datearray = date.split('-');
        return datearray[1] + '/' + datearray[2] + '/' + datearray[0];
      } else return date;
    }
  }

  ngOnDestroy() {
    this.store.dispatch(
      getIneligibleDependentDetailsSuccess({ payload: undefined })
    );
    if (this.subscriptions !== undefined) this.subscriptions.unsubscribe();
    if (this.bundleSubscriptions !== undefined)
      this.bundleSubscriptions.unsubscribe();
    this.ageValidationSubscription.unsubscribe();
  }

  checkDisabledStatus() {
    const disabledStatus =
      this.disableContinue || this.dependentService.isFormValid.value === true;
    //console.log('disabledStatus : ', disabledStatus);
    if (!disabledStatus) {
      const payload = {
        disabled: false,
        shoppingCarModalWrapper: 'enabled-cart'
      };
      this.buyFlowService.updateHeaderShoppingCartparams({ payload });
    }
    return disabledStatus;
  }
}
