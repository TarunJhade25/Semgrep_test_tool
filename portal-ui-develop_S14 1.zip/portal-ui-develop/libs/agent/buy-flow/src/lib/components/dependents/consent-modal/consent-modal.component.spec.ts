import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ConsentModalComponent } from './consent-modal.component';
import { TranslateModule } from '@ngx-translate/core';
import {
  MatDialogRef,
  MatDialogModule,
  MAT_DIALOG_DATA
} from '@angular/material/dialog';

import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';

describe('ConsentModalComponent', () => {
  let component: ConsentModalComponent;
  let fixture: ComponentFixture<ConsentModalComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [TranslateModule.forRoot(), MatDialogModule],
      declarations: [ConsentModalComponent],
      providers: [
        { provide: MAT_DIALOG_DATA, useValue: { initialState: 'test' } },
        { provide: MatDialogRef, useClass: DialogMock }
      ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ConsentModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
  it('should call close function on hidding the dialog box ', () => {
    const spyObj = spyOn(component.dialogRef, 'close').and.callThrough();
    component.hideModal();
    expect(spyObj).toHaveBeenCalled();
  });
});

//MockClass
class DialogMock {
  close() {}
}
