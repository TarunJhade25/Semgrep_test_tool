import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'aflac-quote-review',
  templateUrl: './quote-review.component.html',
  styleUrls: ['./quote-review.component.scss']
})
export class QuoteReviewComponent implements OnInit {
  constructor() {}

  ngOnInit() {}
}
