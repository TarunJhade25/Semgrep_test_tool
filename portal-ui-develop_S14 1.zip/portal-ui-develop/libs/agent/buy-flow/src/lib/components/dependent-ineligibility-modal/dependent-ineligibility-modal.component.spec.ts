import {
  async,
  ComponentFixture,
  TestBed,
  fakeAsync,
  tick
} from '@angular/core/testing';
import { CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA } from '@angular/core';
import {
  MatDialogRef,
  MatDialogModule,
  MAT_DIALOG_DATA
} from '@angular/material/dialog';
import { StoreModule, MemoizedSelector, Store } from '@ngrx/store';
import { TranslateModule } from '@ngx-translate/core';
import { MockStore, provideMockStore } from '@ngrx/store/testing';
import {
  saveYourQuoteReducer,
  SaveYourQuoteState,
  AgentSharedService
} from '@aflac/agent/shared';
import { CmsService } from '@aflac/shared/cms';
import { DependentIneligibilityModalComponent } from './dependent-ineligibility-modal.component';
import { BehaviorSubject, Observable, of } from 'rxjs';
import { BuyFlowService } from '../../services/buy-flow.service';
import { RouterTestingModule } from '@angular/router/testing';
import { DependentService } from '../dependents/services/dependent.service';
import * as fromMockSaveYourQuoteSelector from '@aflac/agent/shared';

const modalPayload = {
  totalMonthycost: {
    old: 143.5,
    new: 330.54
  },
  productDetails: [
    {
      productId: 'PREC-IC',
      productName: 'Cancer Insurance',
      coverage: {
        old: 'ind_sps',
        new: 'ind'
      },
      nonEligibleDependents: [
        {
          name: 'cv c',
          relation: '1',
          dob: '09/09/1930'
        }
      ],
      monthlyPremium: {
        old: 35.19,
        new: 224.68
      }
    },
    {
      productId: 'PREC-ICI',
      productName: 'Critical Illness Insurance',
      coverage: {
        old: 'ind_sps',
        new: 'ind'
      },
      nonEligibleDependents: [
        {
          name: 'cv c',
          relation: '1',
          dob: '09/09/1930'
        }
      ],
      monthlyPremium: {
        old: 80.1,
        new: 43.57
      }
    },
    {
      productId: 'PREC-IA',
      productName: 'Accident Insurance',
      coverage: {
        old: 'ind',
        new: 'ind'
      },
      nonEligibleDependents: [],
      monthlyPremium: {
        old: 28.21,
        new: 62.29
      }
    }
  ],
  editLink: '',
  continuelink: ''
};

const cmsData = {
  coverage_types: [
    { key: 'ind', default_value: 'you' },
    { key: 'ind-sps', default_value: 'you and wife' },
    { key: 'ind-fml', default_value: 'complete family' }
  ]
};

class MockBuyflowService {
  completeCurrentStepAndMoveToNext(route) {
    return of(true);
  }
}

class MockCmsService {
  getKey(any): Observable<any> {
    const data = cmsData;
    return of(data);
  }
}

class DialogMock {
  close() {
    return true;
  }
  afterAll() {
    return true;
  }
}

class MockDependentService {
  public isFormValid = new BehaviorSubject(false);
  public disableNextProduct = new BehaviorSubject(false);
  getDependentData(route): Observable<any> {
    return of(true);
  }
  getDependentRelationshipData(): Observable<any> {
    return of(true);
  }
  setDependentRelationshipData() {
    return of(true);
  }
  addUserDependentData() {
    return of(true);
  }
  createDependentArrayWithQuoteNumber() {
    return true;
  }
}

class MockAgentSharedService {
  createUpdateQuoteReqParams() {
    return true;
  }
}

describe('DependentIneligibilityModalComponent', () => {
  let component: DependentIneligibilityModalComponent;
  let fixture: ComponentFixture<DependentIneligibilityModalComponent>;
  let mockStore: MockStore<SaveYourQuoteState>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        MatDialogModule,
        TranslateModule.forRoot(),
        StoreModule.forRoot(saveYourQuoteReducer),
        RouterTestingModule
      ],
      declarations: [DependentIneligibilityModalComponent],
      schemas: [CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA],
      providers: [
        provideMockStore({}),
        { provide: MatDialogRef, useClass: DialogMock },
        { provide: BuyFlowService, useClass: MockBuyflowService },
        { provide: MAT_DIALOG_DATA, useValue: { payload: modalPayload } },
        { provide: CmsService, useClass: MockCmsService },
        { provide: DependentService, useClass: MockDependentService },
        { provide: AgentSharedService, useClass: MockAgentSharedService }
      ]
    }).compileComponents();
  }));

  beforeEach(async(() => {
    fixture = TestBed.createComponent(DependentIneligibilityModalComponent);
    mockStore = TestBed.get(Store);
    mockStore.overrideSelector(
      fromMockSaveYourQuoteSelector.quoteDataUpdateStatus,
      true
    );
    component = fixture.componentInstance;
    const dummyElement = document.createElement('div');
    document.getElementById = jasmine
      .createSpy('HTML Element')
      .and.returnValues([dummyElement]);
    spyOn(component, 'calculateScrollHeight').and.returnValue(true);
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should fetch coverage types from CMS', () => {
    component.getCoverageTypes();
    expect(component.coverageTypes).toBeDefined();
  });

  it('should edit dependent', () => {
    component.editDependent();
    expect(component as any).toBeDefined();
  });

  it('should move to next step on clicking continue', () => {
    component.acceptAndContinue();
    expect(component as any).toBeDefined();
  });

  /*   it('should calculate scroll height and dynamically add class', fakeAsync(() => {
      component.calculateScrollHeight();
      tick(500);
      fixture.detectChanges();
      expect(component as any).toBeDefined();
    })); */
});
