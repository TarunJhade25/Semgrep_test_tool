import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'aflac-agent-order-review-free-lookup-period',
  templateUrl: './agent-order-review-free-lookup-period.component.html',
  styleUrls: ['./agent-order-review-free-lookup-period.component.scss']
})
export class AgentOrderReviewFreeLookupPeriodComponent implements OnInit {
  @Input() freeLookPeriod;
  constructor() {}

  ngOnInit() {}
}
