import { BrowserModule } from '@angular/platform-browser';
import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';

import { EligibilityComponent } from './eligibility.component';
import { UwrReactComponentWrapper } from '../uwr-react-component/UwrReactComponentWrapper';

@NgModule({
  declarations: [EligibilityComponent, UwrReactComponentWrapper],
  imports: [BrowserModule],
  providers: [],
  bootstrap: [EligibilityComponent],
  schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class AppModule {}
