import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { urlConfig } from '@aflac/shared/data-model';
import { CheckOutPostSignModel as Model } from '../model/checkoutPostSign.model';

@Injectable({
  providedIn: 'root'
})
export class CheckoutService {
  public endpoint: string = urlConfig.eisMicroServiceBaseUrl;
  constructor(private http: HttpClient) {}
  getSignMethodAvl(): Observable<any> {
    return this.http.get(`${this.endpoint}agent/v1/profile`);
  }
  postPolicyList$(policyListObj): Observable<any> {
    console.log(policyListObj);
    return this.http.post(`${this.endpoint}agent/v1/policyList`, policyListObj);
  }
  postSignInfo$(postSignObj: Model) {
    return this.http.post(`${this.endpoint}agent/v1/policy/sign`, {
      policyNumber: postSignObj.policyNumber,
      productCode: postSignObj.productCode,
      signatureInd: postSignObj.signatureInd,
      signatureTypeCd: postSignObj.signatureTypeCd,
      dateTimestamp: postSignObj.dateTimestamp,
      signedName: postSignObj.signedName,
      ipNumber: postSignObj.ipNumber,
      voiceRRNum: postSignObj.voiceRRNum
    });
  }
}
