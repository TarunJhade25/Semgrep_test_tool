import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'aflac-payment-card-details',
  templateUrl: './payment-card-details.component.html',
  styleUrls: ['./payment-card-details.component.scss']
})
export class PaymentCardDetailsComponent implements OnInit {
  @Input() data: any;
  @Input() type: string;
  constructor() {}

  ngOnInit() {}
}
