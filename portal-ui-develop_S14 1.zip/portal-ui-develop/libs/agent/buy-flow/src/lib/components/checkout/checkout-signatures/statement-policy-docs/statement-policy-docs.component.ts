import { Component, OnInit } from '@angular/core';
import { Statements } from '../../mock-statement';
import { Docs } from '../../mock-doc';

import { BuyFlowService } from '../../../../services/buy-flow.service';
import { CheckoutService } from '../../services/checkout.service';
import { Store } from '@ngrx/store';
import { SaveYourQuoteState } from '@aflac/agent/shared'; //stores
import { selectUserDetailsFromAgent } from '@aflac/agent/shared';

@Component({
  selector: 'aflac-statement-policy-docs',
  templateUrl: './statement-policy-docs.component.html',
  styleUrls: ['./statement-policy-docs.component.scss']
})
export class StatementPolicyDocsComponent implements OnInit {
  docs: any = Docs;
  statements: any = Statements;
  statementsFromCart: Array<{ type: string; body: string }> = [];
  docsFromCart: Array<{ type: string; docs: Array<string> }> = [];
  selData: any;
  cartData: any;
  postSelected: Array<{ policyNumber: string; productCode: string }> = [];
  obj: {} = {};
  key = 'productDetails';

  constructor(
    public buyFlowService: BuyFlowService,
    private checkoutService: CheckoutService,
    private store: Store<SaveYourQuoteState>
  ) {}

  ngOnInit() {
    //this.subscribePostPolicyList(); //=> TO DO
    // this.postSelected = [
    //   {
    //     policyNumber: 'T5000000031',
    //     productCode: 'PREC-ICI'
    //   },
    //   {
    //     policyNumber: 'T50000000032',
    //     productCode: 'PREC-IA'
    //   }
    // ];
    this.store
      .select(selectUserDetailsFromAgent)
      .subscribe(sel => (this.selData = sel));
    // console.log('selData-1', this.selData);

    this.buyFlowService.getCartData().subscribe(cart => {
      if (cart) this.cartData = cart.value;
    });
    //console.log('cartData', this.cartData);

    // this.selData = this.selData.quoteDetails.filter(el => {
    //   return this.cartData.some(f => {
    //     return f.productId === el.productCd;
    //   });
    // });
    this.selData =
      this.selData && this.selData.quoteDetails
        ? this.selData.quoteDetails.filter(el => {
            return this.cartData.some(f => {
              return f.productId === el.productCd;
            });
          })
        : '';
    //console.log('selData-2', this.selData);

    this.postSelected = this.selData
      ? this.selData.map(body => ({
          policyNumber: body.quoteNumber,
          productCode: body.productCd
        }))
      : [];
    // console.log('postSelected', this.postSelected);

    this.statementsFromCart = this.cartData
      ? this.cartData.map(tempCart => ({
          type: tempCart.productName,
          body: tempCart.productId
        }))
      : [];
    this.statementsFromCart = this.statementsFromCart
      ? this.statementsFromCart.map(state => {
          return { ...state, shouldShow: false };
        })
      : [];

    this.docsFromCart = this.cartData
      ? this.cartData.map(tempCart => ({
          type: tempCart.productName,
          docs: ['doc1', 'doc2', 'doc3']
        }))
      : [];

    //sorted statement & docs

    this.statementsFromCart = this.statementsFromCart.sort(this.compare);
    this.docsFromCart = this.docsFromCart.sort(this.compare);

    // this.statements = this.statements.map(state => {
    //   return { ...state, shouldShow: false };
    // });
    this.obj[this.key] = this.postSelected;
    // console.log('obj', this.obj);
  }

  //Placeholder created for handling PolicyList
  // subscribePostPolicyList() {
  //   console.log(this.obj);
  //   this.checkoutService
  //     .postPolicyList$(this.obj)
  //     .subscribe(res => console.log(res));
  // }

  showDetails(stat) {
    stat.shouldShow = !stat.shouldShow;
  }
  //sort
  compare(a, b) {
    const typeA = a.type.toUpperCase();
    const typeB = b.type.toUpperCase();

    let comparison = 0;
    if (typeA > typeB) {
      comparison = 1;
    } else if (typeA < typeB) {
      comparison = -1;
    }
    return comparison;
  }
}
