import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { PersonalDetailsComponent } from './personal-details.component';
import { FieldValidator } from '@aflac/shared/validators';
import { FormBuilder, ReactiveFormsModule, FormsModule } from '@angular/forms';
import { PersonalDetailsMyInfoComponent } from './personal-details-my-info/personal-details-my-info.component';
import { PersonalDetailsHomeAddressComponent } from './personal-details-home-address/personal-details-home-address.component';
import { PersonalDetailsContactInfoComponent } from './personal-details-contact-info/personal-details-contact-info.component';
import { TranslateModule } from '@ngx-translate/core';
import { ObjectToKeysPipe } from '@aflac/shared/validators';
import { MaskInputPipe } from './pipes/mask-input.pipe';
import { NgxMaskModule } from 'ngx-mask';
import { StoreModule, Store, MemoizedSelector } from '@ngrx/store';
import { saveYourQuoteReducer } from '@aflac/agent/shared';
import { RouterTestingModule } from '@angular/router/testing';
import { DatePipe } from '@angular/common';
import { NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { SharedMaterialModule } from '@aflac/shared/material';
import { PersonalDetailsService } from './services/personal-details.service';
import { of, BehaviorSubject, Observable } from 'rxjs';
import { BuyFlowService } from '../../services/buy-flow.service';
import { StateEntityService } from '@aflac/shared/data-model';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { provideMockStore, MockStore } from '@ngrx/store/testing';
import { CmsService } from '@aflac/shared/cms';

import {
  personalDetailsSelectorProspect,
  dependentDataByRouteSelector,
  SaveYourQuoteState,
  personalDataSaveStatus,
  personalDataUpdateStatus,
  buyFlowElementsSelector,
  idValidationStatusSelector
} from '@aflac/agent/shared';
import { FormErrorsComponent } from '@aflac/shared/validators';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { Router } from '@angular/router';

describe('PersonalDetailsComponent', () => {
  let component: PersonalDetailsComponent;
  let fixture: ComponentFixture<PersonalDetailsComponent>;
  const fb: FormBuilder = new FormBuilder();
  let personalStoreService;
  let router: Router;
  let mockStore: MockStore<SaveYourQuoteState>;

  const myInfoForm = fb.group({
    firstName: 'aa',
    lastName: 'a',
    gender: 'M',
    dateOfBirth: '1976-06-01',
    middleInitials: 'm',
    taxId: '123456789',
    suffix: ''
  });
  const addressForm = fb.group({
    addressLine1: 'aa',
    addressLine2: 'a',
    city: 'Maa',
    stateProvCd: 'AL',
    zipCode: 12345
  });
  const contactForm = fb.group({
    phone_number: 'aa',
    email: 'a',
    confirm_email: 'M',
    electronic_delivery: true
  });
  const personalData = {
    firstName: 'John',
    lastName: 'Doe',
    gender: 'M',
    taxId: '123456789',
    middleInitials: 'A',
    suffix: 'Jr.',
    dateOfBirth: '1985-07-13',
    aflacUserGuid: 'adskjk2764sdsd-sfsf',
    addresses: [
      {
        addressLine1: '11',
        addressLine2: 'a',
        city: 'Maa',
        stateProvCd: 'AL',
        zipCode: 12345
      }
    ],
    emails: [
      {
        email: 'a@gmail.com'
      }
    ],
    phones: [
      {
        phone: '1234567892'
      }
    ],
    customerNumber: '1212',
    requestHeader: {
      jscPayload: 'test',
      hdimayload: 'test'
    },
    isAnonymous: false
  };

  const userDetails = {
    age: '54',
    consentStatus: 'GRANTED',
    customerNumber: '510001',
    email: 'johnsmith@gmail.com',
    firstName: 'Johnson',
    lastName: 'S',
    quotes: [
      {
        caseId: 'QWESR2314 WE',
        coverageTypeCd: 'ind_sps',
        packageCd: 'plan07',
        productCd: 'PREC-IC',
        productName: 'Cancer Insurance',
        riders: [],
        riskStateCd: 'AL',
        series: 'test',
        sfrId: '',
        totalPremium: '16.93'
      }
    ]
  };

  const buyFlowElements = [
    {
      completed: true,
      data: {},
      disabled: false,
      header: 'Quote',
      inactive: false,
      link: '/review',
      required: true,
      title: 'Quote'
    },
    {
      completed: false,
      data: {},
      disabled: false,
      header: 'Dependents Information',
      inactive: false,
      link: '/dependents',
      required: true,
      title: 'Dependents Information'
    },
    {
      completed: false,
      data: {},
      disabled: false,
      header: 'Personal Information',
      inactive: false,
      link: '/my-details',
      required: true,
      title: 'Personal Information'
    }
  ];

  const customerNumber = '111111';
  const urlRoute = '/my-details';

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [
        PersonalDetailsComponent,
        ObjectToKeysPipe,
        MaskInputPipe,
        FormErrorsComponent,
        PersonalDetailsMyInfoComponent,
        PersonalDetailsHomeAddressComponent,
        PersonalDetailsContactInfoComponent
      ],
      imports: [
        FormsModule,
        ReactiveFormsModule,
        RouterTestingModule,
        SharedMaterialModule,
        TranslateModule.forRoot(),
        NgxMaskModule.forRoot(),
        StoreModule.forRoot(saveYourQuoteReducer),
        BrowserAnimationsModule,
        HttpClientTestingModule
      ],
      schemas: [NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA],
      providers: [
        provideMockStore({}),
        DatePipe,
        { provide: StateEntityService, useClass: MockStateEntityService },
        { provide: BuyFlowService, useClass: MockBuyflowService },
        {
          provide: PersonalDetailsService,
          useClass: MockPersonalDetailsService
        }
      ]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PersonalDetailsComponent);
    mockStore = TestBed.get(Store);
    mockStore.overrideSelector(personalDetailsSelectorProspect, customerNumber);
    mockStore.overrideSelector(personalDataUpdateStatus, 'complete');
    mockStore.overrideSelector(personalDataSaveStatus, 'complete');
    mockStore.overrideSelector(buyFlowElementsSelector, buyFlowElements);
    mockStore.overrideSelector(dependentDataByRouteSelector, {});
    mockStore.overrideSelector(idValidationStatusSelector, {});
    component = fixture.componentInstance;
    personalStoreService = TestBed.get(PersonalDetailsService);
    const buyflowService = TestBed.get(BuyFlowService);
    spyOn(buyflowService, 'enableStepperByRoute');

    component.myInfoForm = myInfoForm;
    component.addressForm = addressForm;
    component.contactForm = contactForm;
    component.customerNumber = customerNumber;
    component.personalDetailsData = personalData;
    router = TestBed.get(Router);
    (window as any).aflac_eic = null;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
  it('checking if condition when data null', () => {
    spyOn(personalStoreService, 'getPersonalData').and.returnValue(of({}));
    spyOn(component, 'getCustomerNumber').and.returnValue('111111');
    spyOn(component, 'manipulateCustomerType').and.returnValue('');
    component.ngOnInit();
  });

  it('should get customer number', () => {
    spyOn(personalStoreService, 'addUserDependentData').and.returnValue('');
    component.getCustomerNumber();
    expect(component.getCustomerNumber).toBeDefined();
  });

  it('check for customer manipulatation', () => {
    spyOn(component, 'checkCustomerIsProspectOrMember').and.returnValue(true);
    component.manipulateCustomerType();
    expect(component.manipulateCustomerType).toBeDefined();
  });

  it('check user type prospect or member', () => {
    component.checkCustomerIsProspectOrMember(personalData);
    expect(component.checkCustomerIsProspectOrMember).toBeDefined();
  });

  it('mock form  my info event handler', () => {
    component.formMyinfoEventHander(true);
  });

  it('mock form address event handler', () => {
    component.formAddressEventHander(true);
  });

  it('mock form contact event handler', () => {
    component.formContactEventHandler(true);
  });

  it('mock form update customer event handler', () => {
    component.formUpdateCustomerEventHandler(true);
  });

  it('check savePersonalDetails to be called', () => {
    component.savePersonalDetails();
    expect(component.savePersonalDetails).toBeDefined();
  });

  it('check addPersonalDataToStore to be called', () => {
    component.addPersonalDataToStore(personalData);
    expect(component.addPersonalDataToStore).toBeDefined();
  });

  it('check updateUserPersonalInfo to be called', () => {
    component.updateUserPersonalInfo(personalData);
    expect(component.updateUserPersonalInfo).toBeDefined();
  });

  it('check saveUserPersonalInfo to be called', () => {
    component.saveUserPersonalInfo(personalData);
    expect(component.saveUserPersonalInfo).toBeDefined();
  });

  it('check checkIdentity to be called', () => {
    component.checkIdentity(personalData);
    expect(component.checkIdentity).toBeDefined();
  });

  //Mock class
  class MockStateEntityService {
    entities$ = of([{ us_states: [{ code: 'AL', name: 'Alabama' }] }]);
  }

  class MockBuyflowService {
    enableStepperByRoute(route) {
      return of(true);
    }
    completeCurrentStepAndMoveToNext(route) {
      return of(true);
    }
    getBundleDataFromBundleId() {
      return of(true);
    }
    checkCustomerIsProspectOrMember() {
      return of(true);
    }
    setBundleDataAction() {
      return of(true);
    }
  }

  class MockPersonalDetailsService {
    public isFormValid = new BehaviorSubject(false);
    public confirmNewAddress = new BehaviorSubject(false);
    public isMyInfoFormStatus = new BehaviorSubject(true);
    public isAddressFormStatus = new BehaviorSubject(true);
    public isShowContactForm = new BehaviorSubject(true);
    public isContactFormView = new BehaviorSubject(true);
    public buttonVisibleStatus = new BehaviorSubject(false);
    public userType = new BehaviorSubject('new');

    getPersonalData(route): Observable<any> {
      return of(personalData);
    }
    setCustomerNumber() {
      return of(true);
    }
    getCustomerNumber() {
      return of(true);
    }
    getUserDataFomSaveQuoteResponse(): Observable<any> {
      return of(userDetails);
    }
    addUserDependentData() {
      return of(true);
    }
    setPersonalDataProspect() {
      return of(true);
    }
    setSSNValue() {
      return of(true);
    }
    formateDataOnFormSubmit() {
      return of(true);
    }
    formatDataOnIdValidation() {
      return of(true);
    }
  }
});
