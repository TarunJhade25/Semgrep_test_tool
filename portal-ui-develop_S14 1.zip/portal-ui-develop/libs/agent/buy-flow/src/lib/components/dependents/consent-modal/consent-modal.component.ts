import { Component, OnInit, Inject } from '@angular/core';
import { PerfectScrollbarConfigInterface } from 'ngx-perfect-scrollbar';
import { Subject } from 'rxjs';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';

@Component({
  selector: 'aflac-consent-modal',
  templateUrl: './consent-modal.component.html',
  styleUrls: ['./consent-modal.component.scss']
})
export class ConsentModalComponent implements OnInit {
  title: string;
  closeBtnName: string;
  public config: PerfectScrollbarConfigInterface = {
    minScrollbarLength: 148,
    maxScrollbarLength: 148,
    wheelSpeed: 0.6,
    scrollYMarginOffset: 389
  };
  contentTitleOne: string;
  contentDataOne: string;
  contentTitleTwo: string;
  contentDataTwoParaOne: string;
  contentDataTwoParaTwo: string;
  public onClose: Subject<boolean>;

  constructor(
    public dialogRef: MatDialogRef<ConsentModalComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) {}

  ngOnInit() {}

  hideModal() {
    this.dialogRef.close(true);
  }
}
