import {
  Component,
  OnInit,
  Input,
  Output,
  EventEmitter,
  OnDestroy,
  ViewChild,
  ElementRef
} from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { CmsService } from '@aflac/shared/cms';
import { Store, select, ActionsSubject } from '@ngrx/store';
import { DatePipe } from '@angular/common';
import { SaveYourQuoteState } from '@aflac/agent/shared';
import {
  validateCustomerSSN,
  resetCustomerSSNData,
  validateCustomerAge,
  resetCustomerAgeData,
  validateCustomerSSNSuccess,
  validateCustomerAgeSuccess
} from '@aflac/agent/shared'; // Actions
import { ssnValidationDetailsSelector } from '@aflac/agent/shared'; // Selectors
import { PersonalDetailsService } from '../services/personal-details.service';
import { Observable, Subscription, forkJoin, combineLatest } from 'rxjs';
import { first, map } from 'rxjs/operators';
import { Router } from '@angular/router';
import { SsnValidationCustomerListModalComponent } from '../personal-details-modal/ssn-validation/ssn-validation-customer-list-modal/ssn-validation-customer-list-modal.component';
import { SsnValidationCoverageEligibilityModalComponent } from '../personal-details-modal/ssn-validation/ssn-validation-coverage-eligibility-modal/ssn-validation-coverage-eligibility-modal.component';
import { SsnValidationCoverageChangeModalComponent } from '../personal-details-modal/ssn-validation/ssn-validation-coverage-change-modal/ssn-validation-coverage-change-modal.component';
import { AgeChangeInPremiumComponent } from '../personal-details-modal/age-validation-modal/age-change-in-premium/age-change-in-premium.component';
import { AgeNotEligibleForProductComponent } from '../personal-details-modal/age-validation-modal/age-not-eligible-for-product/age-not-eligible-for-product.component';
import { SsnInfoModalComponent } from '../personal-details-modal/ssn-info-modal/ssn-info-modal.component';
import { BuyFlowService } from '../../../services/buy-flow.service';
import * as _ from 'lodash';

@Component({
  selector: 'aflac-personal-details-my-info',
  templateUrl: './personal-details-my-info.component.html',
  styleUrls: [
    './personal-details-my-info.component.scss',
    '../personal-details.component.scss'
  ]
})
export class PersonalDetailsMyInfoComponent implements OnInit, OnDestroy {
  @Input() myInfoForm;
  @Input() isFromMemberPortal;
  @Input() userType;
  @Input() bundleData;
  @Output() formEvent = new EventEmitter<boolean>();
  @Output() formUpdateCustomerEvent = new EventEmitter<boolean>();
  @ViewChild('inputRef', { static: false }) inputRef;
  @ViewChild('ssnPlaceHolder', { static: false }) ssnPlaceHolder: ElementRef;

  matErrorSpacing: number;
  hide = false;
  pattern = {
    Y: { pattern: new RegExp('\\d'), symbol: 'X' },
    0: { pattern: new RegExp('\\d') }
  };
  maskPattern = 'YYY-YY-0000';

  isValid = false;
  toggleViewData: any = {};
  buttonText: any = this.cmsService.getKey('lookup.personal_details_next_btn');
  middleInitialsData: any[] = [];
  isEdit = false;
  updatedData: any;
  route = '/my-details';
  previousSsnValue: any = 0;
  errorStatus = true;
  errorText: any =
    'Lorem ipsum dolor sit amet, consetetur. Sadipscing elitr, sed diam.';
  userData: any;
  private subscriptions = new Subscription();
  private popupSubscription = new Subscription();
  private agePopupSubscription = new Subscription();
  personalData: Observable<any>;
  data: any;
  genderData: any[];
  hoiddenInputValue: any;
  newdigit: any = '';
  formValueEvent: any;
  ssnChange: any;
  appRoutes: any;
  currentRoute: string;
  ssnDetails: any;
  cartDetails: any = [];
  cartDetailsModified: any = [];
  ageValidationData: any;
  ssnValidationData: any;
  myInfoFormData: any;
  openDropdownFlag = false;
  editingSSN: any = false;

  constructor(
    private fb: FormBuilder,
    private datePipe: DatePipe,
    private cmsService: CmsService,
    private store: Store<SaveYourQuoteState>,
    public dialog: MatDialog,
    public personalInfoService: PersonalDetailsService,
    private actionsSubject$: ActionsSubject,
    private router: Router,
    public buyFlowService: BuyFlowService
  ) {}

  ngOnInit() {
    this.currentRoute = this.router.url;
    this.cmsService.getKey('lookup.suffix').subscribe(res => {
      if (res instanceof Array) this.middleInitialsData = res;
    });
    this.cmsService
      .getKey('lookup.personal_details_gender_options')
      .subscribe(res => {
        if (res instanceof Array) this.genderData = res;
      });

    this.personalData = this.personalInfoService.getPersonalData(this.route);
    this.subscriptions = this.personalData.subscribe(data => {
      if (!(this.data && this.data.firstName)) {
        this.data = data;
        if (JSON.stringify(data) === '{}' || !data) {
          // value setting for new prospect
          this.isEdit = true;
          this.userData = this.personalInfoService.getPrevCustomerData();
          if (!_.isEmpty(this.userData)) {
            this.setFormDataForNewUser(this.userData);
          }
        } else {
          /* value setting for returning customer/prospect*/
          this.isEdit = false;
          this.setMyInfoFormData(this.data);
          this.getDataForToggleView(this.data);
        }
      } else {
        if (this.personalInfoService.buttonVisibleStatus.value) {
          if (this.myInfoForm.dirty && this.isEdit) {
            this.personalInfoService.isFormValid.next(false);
          }
        }
      }
    });
    this.myInfoForm.markAsPristine();
    // this.getDataForToggleView(this.personalData);
    // this.trackFirstValueChange()
    // this.checkSsnFieldChange();
  }

  hideValue() {
    this.hide = !this.hide;
    this.ssnChange = this.myInfoForm.controls['taxId'].valueChanges
      .pipe(first())
      .subscribe(val => {
        if (val === this.data.taxId)
          this.myInfoForm.controls['taxId'].markAsPristine();
      });
    // this.myInfoForm.controls['ssn'].markAsPristine();
  }

  setFormDataForNewUser(data) {
    const { firstName, lastName } = data;
    const controls = this.myInfoForm.controls;
    controls['firstName'].setValue(firstName);
    controls['lastName'].setValue(lastName);
  }

  setMyInfoFormData(formData) {
    const {
      firstName,
      lastName,
      suffix,
      gender,
      taxId,
      dateOfBirth,
      middleName
    } = formData;
    const controls = this.myInfoForm.controls;
    controls['firstName'].setValue(firstName);
    controls['lastName'].setValue(lastName);
    controls['suffix'].setValue(suffix);
    controls['gender'].setValue(gender);
    if (taxId) controls['taxId'].setValue(taxId);
    if (dateOfBirth) {
      const dateVal = this.datePipe.transform(dateOfBirth, 'MM/dd/yyyy');
      controls['dateOfBirth'].setValue(dateVal);
    }
    if (this.data.taxId) {
      this.hide = true;
    }
    if (middleName) {
      const val = middleName.length;
      let middleInitial;
      middleInitial = middleName;
      if (val > 1) {
        middleInitial = middleName.slice(0, 1);
      }
      controls['middleInitials'].setValue(middleInitial);
    }
  }

  getDataForToggleView(data) {
    this.toggleViewData.date = this.datePipe.transform(
      data.dateOfBirth,
      'MM/dd/yyyy'
    );
    if (data && data.suffix) {
      this.middleInitialsData.forEach(i => {
        if (i.key === data.suffix) {
          this.toggleViewData.suffix = i.value;
        }
      });
    }

    const taxIdMask = data.taxId.replace(/\d(?=\d{4})/g, 'X');
    this.toggleViewData.taxId = taxIdMask.replace(
      /(\D{3})(\D{2})(\d+)/,
      '$1-$2-$3'
    );
  }

  ageSSNResetAction() {
    [resetCustomerSSNData(), resetCustomerAgeData()].forEach(a =>
      this.store.dispatch(a)
    );
  }

  ageSSNValidationAction() {
    const sqObj = this.buyFlowService.getAgentSearchQuote();
    //console.log('sqObj : ', sqObj);
    let cartData = [];
    this.cartDetailsModified = [];
    let ageParams;
    const cartSub = this.personalInfoService.getCartData().subscribe(res => {
      if (res !== undefined && res.value && res.value.length > 0) {
        this.cartDetails = res.value;
        this.cartDetails.map(item => {
          const riders = [];
          if (item.selectedRiders && item.selectedRiders.length > 0) {
            item.selectedRiders.map(ridetItem => {
              if (ridetItem.productId === item.productId)
                riders.push({ riderNameCd: ridetItem.rider.riderNameCd });
            });
          }
          cartData = Object.assign([], cartData);
          cartData.push({
            productCd: item.productId,
            packageCd: item.plan.id,
            coverageType: item.coverage,
            originalIssueStateCd: sqObj.stateProvCd,
            caseId: sqObj.caseId,
            agencyId: sqObj.partnerId,
            initialDiagnosisAmount: item.benefitAmount,
            tobaccoUseInd: item.tobaccoInd,
            addCancerCoverageInd: item.cancerCoverage,
            rider: riders
          });
          this.cartDetailsModified.push({
            productId: item.productId,
            productName: item.productName,
            monthlyPremium: item.plan.price,
            riders: item.selectedRiders
          });
        });
      }
    });
    const dateOfBirth = this.myInfoForm.value.dateOfBirth;
    ageParams = {
      dob: dateOfBirth
        ? this.buyFlowService.convertDOB(dateOfBirth, 'req')
        : '',
      effectiveDate: '',
      products: cartData
    };
    this.subscriptions.add(cartSub);

    [
      validateCustomerSSN({ ssn: this.myInfoForm.value.taxId }),
      validateCustomerAge({ ageParams: ageParams })
    ].forEach(a => this.store.dispatch(a));
  }

  setDeleteQuoteList(payload) {
    if (
      payload &&
      payload.ageInEligibilityDetails &&
      payload.ageInEligibilityDetails.length > 0
    )
      this.personalInfoService.setDeleteQuoteList(
        payload.ageInEligibilityDetails,
        this.bundleData
      );
  }

  ageValidationFlow(ageValData) {
    const payload = this.buyFlowService.ageEligibilityCheck(
      ageValData,
      this.cartDetails,
      this.myInfoForm.value.dateOfBirth
    );
    this.setDeleteQuoteList(payload);
    if (
      (payload &&
        payload.ageInEligibilityDetails &&
        payload.ageInEligibilityDetails.length) ===
      (this.cartDetails && this.cartDetails.length)
    ) {
      payload['mode'] = 'Exit';
      payload['purchasedProducts'] = this.cartDetailsModified;
      this.openAgeNotEligibleModel(payload);
      return false;
    } else if (
      payload &&
      payload.ageEligibilityDetails &&
      payload.ageEligibilityDetails.length > 0 &&
      payload.ageInEligibilityDetails &&
      payload.ageInEligibilityDetails.length > 0
    ) {
      payload['mode'] = 'Hope';
      payload['cartProducts'] = this.cartDetailsModified;
      this.openAgeNotEligibleModel(payload);
      return false;
    } else if (
      payload &&
      payload.agePremiumChangeDetails &&
      payload.agePremiumChangeDetails.length > 0
    ) {
      this.openAgeChangeInPremiumModel(payload);
      return false;
    } else {
      this.saveMyInfoFormData();
    }
  }

  saveMyInfoFormData() {
    this.saveMyinfoDataOnSuccess(this.myInfoFormData);
  }

  applyAgeValidation() {
    this.agePopupSubscription = this.personalInfoService
      .getAgeValidationData()
      .subscribe(ageData => {
        if (
          ageData &&
          ageData.status === true &&
          ageData.data &&
          ageData.data.length > 0
        ) {
          this.ageValidationFlow(ageData);
        } else {
          this.saveMyInfoFormData();
        }
      });
  }

  onSubmit() {
    if (this.myInfoForm.valid) {
      // Reset Age SSN data
      this.ageSSNResetAction();
      this.personalInfoService.setMyInfoForm(this.myInfoForm.value);
      let customerNumber;
      if (this.data && this.data.customerNumber) {
        customerNumber = this.data.customerNumber;
      } else if (this.personalInfoService.getCustomerNumber()) {
        customerNumber = this.personalInfoService.getCustomerNumber();
      }
      this.data = Object.assign({}, this.data, {
        customerNumber: customerNumber
      });

      // Validate Age SSN
      this.ageSSNValidationAction();

      const myInfoFormData = {
        statusOnComplete: 'myinfo-succcess',
        formData: this.personalInfoService.formateDataOnFormSubmit(
          this.myInfoForm,
          null,
          null,
          this.data
        ),
        customerId: customerNumber
      };
      this.myInfoFormData = myInfoFormData;

      this.popupSubscription = this.actionsSubject$.subscribe((action: any) => {
        if (action.type === validateCustomerSSNSuccess.type) {
          const ssnData = action.payload;
          if (
            ssnData &&
            ssnData.status === true &&
            ssnData.data &&
            ssnData.data.length > 0
          ) {
            this.ssnValidationData = ssnData;
            this.isEdit = true;
            this.openSsnCustomerModal(ssnData.data);
          } else {
            this.applyAgeValidation();
          }
        }
      });
    }
  }

  saveMyinfoDataOnSuccess(myInfoFormData) {
    if (
      this.personalInfoService.buttonVisibleStatus.value &&
      this.personalInfoService.isAddressFormStatus.value &&
      this.personalInfoService.isContactFormStatus.value
    ) {
      this.personalInfoService.isFormValid.next(true);
    }

    this.isEdit = false;
    this.personalInfoService.isMyInfoFormStatus.next(true);
    this.personalInfoService.addUserDependentData(
      myInfoFormData.formData,
      this.currentRoute
    );
    this.formEvent.emit(true);
    this.hide = true;
    this.data = myInfoFormData.formData;
    this.getDataForToggleView(this.data);
    if (this.formValueEvent) this.formValueEvent.unsubscribe();
  }

  openSsnCustomerModal(ssnData) {
    const dialogRef = this.dialog.open(
      SsnValidationCustomerListModalComponent,
      {
        width: '747px',
        disableClose: true,
        panelClass: 'customer-search-result-modal-cover',
        data: { ssnData }
      }
    );

    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        this.isEdit = true;
        /*
        if (result !== 'close' && result !== 'goback') {
          this.formUpdateCustomerEvent.emit(ssnData);
        } */
        if (
          result === 'close' ||
          result === 'goback' ||
          result === 'navigate'
        ) {
          if (this.popupSubscription !== undefined)
            this.popupSubscription.unsubscribe();
          this.formEvent.emit(false);
        } else if (result.mode === 'continue') {
          result['cartData'] = this.cartDetailsModified;
          this.openSsnCoverageChangePopup(result);
        } else {
          this.openCoverageEligiblePopup(result);
        }
      }
    });
  }

  openCoverageEligiblePopup(payload) {
    const ssnDialogRef = this.dialog.open(
      SsnValidationCoverageEligibilityModalComponent,
      {
        disableClose: true,
        panelClass: 'product-eligibility-modal-cover',
        data: { payload }
      }
    );
    ssnDialogRef.afterClosed().subscribe(result => {
      if (result && (result === 'goback' || result === 'continue')) {
        if (this.popupSubscription !== undefined)
          this.popupSubscription.unsubscribe();
      }
    });
  }

  openSsnCoverageChangePopup(payload) {
    const ssnCoverageDialogRef = this.dialog.open(
      SsnValidationCoverageChangeModalComponent,
      {
        disableClose: true,
        panelClass: 'product-eligibility-modal-cover',
        data: { payload }
      }
    );
    ssnCoverageDialogRef.afterClosed().subscribe(result => {
      if (result && (result === 'goback' || result === 'continue')) {
        if (this.popupSubscription !== undefined)
          this.popupSubscription.unsubscribe();
      }
    });
  }

  openAgeChangeInPremiumModel(dataObj) {
    const payload = dataObj;
    const ageDialogRef = this.dialog.open(AgeChangeInPremiumComponent, {
      width: '747px',
      disableClose: true,
      panelClass: 'age-change-in-Premium-modal-wrapper',
      data: { payload }
    });

    ageDialogRef.afterClosed().subscribe(result => {
      //console.log('age Validation premium : ', result);
      if (result) {
        if (this.agePopupSubscription !== undefined)
          this.agePopupSubscription.unsubscribe();
        if (this.popupSubscription !== undefined)
          this.popupSubscription.unsubscribe();
        this.ageSSNResetAction();
        if (result === 'goback') {
          this.isEdit = true;
          this.formEvent.emit(false);
        } else if (result === 'continue') {
          this.isEdit = false;
          this.saveMyInfoFormData();
          if (this.userType !== 'new')
            this.personalInfoService.isFormValid.next(true);
        }
      }
    });
  }

  openAgeNotEligibleModel(dataObj) {
    const payload = dataObj;
    const dialogRef = this.dialog.open(AgeNotEligibleForProductComponent, {
      width: '747px',
      disableClose: true,
      panelClass: 'age-not-eligible-for-productmodal-wrapper',
      data: { payload }
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        if (this.agePopupSubscription !== undefined)
          this.agePopupSubscription.unsubscribe();
        if (this.popupSubscription !== undefined)
          this.popupSubscription.unsubscribe();
        this.ageSSNResetAction();
        if (result && result === 'goback') {
          this.formEvent.emit(false);
          this.isEdit = true;
        } else {
          this.isEdit = false;
          if (
            result.agePremiumChangeDetails &&
            result.agePremiumChangeDetails.length > 0
          ) {
            result['mode'] = 'notEligible';
            this.openAgeChangeInPremiumModel(result);
            return false;
          } else {
            this.saveMyInfoFormData();
            if (this.userType !== 'new')
              this.personalInfoService.isFormValid.next(true);
          }
        }
      }
    });
  }

  toggleViewMode() {
    this.isEdit = !this.isEdit;
    this.buttonText = this.cmsService.getKey(
      'lookup.find_plans_update_button_text'
    );
    this.maskPattern = 'YYY-YY-0000';
    this.editingSSN = true;
    this.setMyInfoFormData(this.data);
    this.myInfoForm.markAsPristine();
    this.personalInfoService.isFormValid.next(false);
    this.personalInfoService.isMyInfoFormStatus.next(false);
    this.trackFirstValueChange();
  }

  trackFirstValueChange() {
    this.formValueEvent = this.myInfoForm.valueChanges.subscribe(val => {
      if (this.personalInfoService.buttonVisibleStatus.value) {
        if (this.myInfoForm.dirty && this.isEdit) {
          this.personalInfoService.isFormValid.next(false);
          this.personalInfoService.isMyInfoFormStatus.next(false);
        }
      }
    });
  }

  get f() {
    if (this.myInfoForm) {
      return this.myInfoForm.controls;
    }
  }

  openSsnInfoModal(event) {
    event.stopPropagation();
    const initialState = {
      title: this.cmsService.getKey(
        'sales_portal.personal_details_ssn_info_title'
      ),
      contentDataOne: this.cmsService.getKey('agent_portal.ssn_info_message'),
      closeBtnName: this.cmsService.getKey(
        'sales_portal.consent_modal_close_button_text'
      )
    };
    this.dialog.open(SsnInfoModalComponent, {
      data: {
        initialState
      },
      panelClass: 'child-info-modal-resizer',
      ariaLabelledBy: 'mat-consent-dialog-title'
    });
  }

  public changeMaskPattern(inputRef) {
    if (inputRef && inputRef.value) {
      this.maskPattern = 'YYY-YY-YYYY';
      if (
        this.myInfoForm.controls['taxId'].value.length >
          this.previousSsnValue.length ||
        this.myInfoForm.controls['taxId'].value.length === 1
      ) {
        this.showSSNLastChar();
        setTimeout(() => {
          this.showMaskedSSN();
        }, 500);
      }
      if (this.editingSSN) {
        this.editingSSN = false;
      }
      this.previousSsnValue = this.myInfoForm.controls['taxId'].value;
    }
  }

  public showSSNLastChar() {
    this.ssnPlaceHolder.nativeElement.style.display = 'block';
  }

  public showMaskedSSN() {
    this.ssnPlaceHolder.nativeElement.style.display = 'none';
  }

  public replaceLastChar(val) {
    return val.replace(/.(?=.{1,}$)/g, 'X');
  }

  resetMaskPattern() {
    this.myInfoForm.controls['taxId'].setValue('');
    this.maskPattern = 'YYY-YY-YYYY';
  }

  setMaskPattern() {
    this.maskPattern = 'YYY-YY-0000';
  }

  ngOnDestroy() {
    this.subscriptions.unsubscribe();
    if (this.popupSubscription !== undefined)
      this.popupSubscription.unsubscribe();
    if (this.agePopupSubscription !== undefined)
      this.agePopupSubscription.unsubscribe();
  }
}
