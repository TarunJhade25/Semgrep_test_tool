import { Component, OnInit, OnDestroy, Inject } from '@angular/core';
import { SelectionModel } from '@angular/cdk/collections';
import {
  MatDialogRef,
  MAT_DIALOG_DATA,
  MatDialog
} from '@angular/material/dialog';
import { Router } from '@angular/router';
import { Store, select } from '@ngrx/store';
import { Subscription } from 'rxjs';
import { PersonalDetailsService } from '../../../services/personal-details.service';
import { AgentSharedService } from '@aflac/agent/shared';
import { BuyFlowService } from '../../../../../services/buy-flow.service';

export interface PeriodicElement {
  id: number;
  name: string;
  state: string;
  dob: string;
}
@Component({
  selector: 'aflac-ssn-validation-customer-list-modal',
  templateUrl: './ssn-validation-customer-list-modal.component.html',
  styleUrls: ['./ssn-validation-customer-list-modal.component.scss']
})
export class SsnValidationCustomerListModalComponent
  implements OnInit, OnDestroy {
  displayedColumns: string[] = ['select', 'name', 'state', 'dob'];
  dataSource;
  selection = new SelectionModel<PeriodicElement>(true, []);
  stateProvCd: string;
  subscription = new Subscription();
  selectedCustomer: any;
  customerDetailsArray = [];
  storeDetailsArray: any;
  ssnDetailsArray: any;
  ssnDetails: any;
  productsAlreadyPurchased: any;
  inEligiblePlans = [];
  eligiblePlans = [];
  updatedcart: any[];
  productsByStateArray = [];
  productsByStateFilteredArray = [];
  bundleData: any;

  constructor(
    private store: Store<any>,
    private router: Router,
    private personalInfoService: PersonalDetailsService,
    private agentSharedService: AgentSharedService,
    public buyFlowService: BuyFlowService,
    private dialogRef: MatDialogRef<SsnValidationCustomerListModalComponent>,
    public dialog: MatDialog,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) {}

  ngOnInit() {
    this.ssnDetailsArray = this.data && this.data.ssnData;
    //console.log('this.ssnDetailsArray : ', this.ssnDetailsArray);
    this.setSSNValidationDetails();
    this.getStoreDetails();
    this.getProductByStateDetails();
  }

  setSSNValidationDetails() {
    if (this.ssnDetailsArray) {
      this.createCustomerDetailsArray(this.ssnDetailsArray);
      this.dataSource = this.customerDetailsArray;
    }
  }

  getStoreDetails() {
    this.subscription = this.personalInfoService
      .getCartData()
      .subscribe(res => {
        if (res !== undefined && res.value && res.value.length > 0) {
          this.storeDetailsArray = res.value;
        }
      });
  }

  getProductByStateDetails() {
    const psSub = this.personalInfoService
      .getProductsByStateData()
      .subscribe(res => {
        if (res && res.length > 0) {
          this.productsByStateArray = res;
          sessionStorage.setItem(
            'state-agent-product-details',
            JSON.stringify(res)
          );
        } else {
          this.productsByStateArray = JSON.parse(
            sessionStorage.getItem('state-agent-product-details')
          );
        }
      });
    this.subscription.add(psSub);
  }

  createCustomerDetailsArray(selectedCustomerDetails) {
    for (const item of selectedCustomerDetails) {
      const name = item.firstName + ' ' + item.lastName;
      const state = this.agentSharedService.getStateNameFromStateProvCode(
        item.addresses[0].stateProvCd
      );
      this.customerDetailsArray.push({
        customerNumber: item.customerNumber,
        name: name,
        state: state,
        dateOfBirth: this.buyFlowService.convertDOB(item.dateOfBirth, 'res')
      });
    }
  }

  // The label for the checkbox on the passed row
  checkboxLabel(row?: PeriodicElement): string {
    return `${this.selection.isSelected(row) ? 'deselect' : 'select'} row ${
      row.name
    }`;
  }

  goBackAndEdit() {
    this.dialogRef.close('goback');
    this.router.navigateByUrl('my-details');
  }

  closePopUp() {
    this.dialogRef.close('close');
  }

  onSubmit() {
    this.ssnDetails = this.ssnDetailsArray.filter(
      e => e.customerNumber === this.selectedCustomer
    )[0];
    const payload = this.productEligibilityCheck();
    //console.log('payload SSNCL : ', payload);
    const isAgentEligibleForState = this.agentSharedService.checkAgentEligibilityForState(
      this.ssnDetails.addresses[0].stateProvCd
    );
    if (
      this.ssnDetails &&
      this.ssnDetails.availableProducts &&
      this.ssnDetails.availableProducts.length > 0
    ) {
      payload['customerName'] =
        this.ssnDetails.firstName + ' ' + this.ssnDetails.lastName;
      payload['purchasedProducts'] = this.manipulatePurchasedArray();
      payload['ssnData'] = this.ssnDetails;

      if (!isAgentEligibleForState) {
        payload['mode'] = 'AgentIneligible';
        this.dialogRef.close(payload);
      } else {
        // If the customer purchased all the 3 products
        this.filterProductStateArray();
        if (
          this.productsByStateFilteredArray &&
          this.productsByStateFilteredArray.length === 0
        ) {
          payload['mode'] = 'Exit';
          this.dialogRef.close(payload);
        } else if (
          payload &&
          payload.eligiblePlans.length > 0 &&
          payload.inEligiblePlans.length > 0
        ) {
          payload['mode'] = 'continue';
          this.dialogRef.close(payload);
        } else if (
          payload &&
          payload.eligiblePlans.length > 0 &&
          payload.inEligiblePlans.length === 0
        ) {
          this.dialogRef.close('navigate');
          this.agentSharedService.updateSearchQuote('ssn', this.ssnDetails);
          this.agentSharedService.updateExistingCustomerInfo(
            'ssn',
            this.ssnDetails
          );
          //this.agentSharedService.updateRetrieveQuote();
          this.router.navigateByUrl('quotes');
        } else {
          payload['mode'] = 'Hope';
          this.dialogRef.close(payload);
        }
      }
    }
  }

  filterProductStateArray() {
    if (this.productsByStateArray && this.productsByStateArray.length > 0) {
      this.productsByStateFilteredArray = this.productsByStateArray.filter(
        ({ id: id1 }) =>
          !this.ssnDetails.availableProducts.some(
            ({ productCd: id2 }) => id2 === id1
          )
      );
    }
  }

  manipulatePurchasedArray() {
    const purchasedProductArray = [];
    this.productsByStateArray.map(item => {
      this.ssnDetails.availableProducts.map(e => {
        if (item.id === e.productCd) {
          purchasedProductArray.push({
            productId: item.id,
            productName: item.name
          });
        }
      });
    });
    return purchasedProductArray;
  }

  productEligibilityCheck() {
    this.updatedcart = [];
    this.productsAlreadyPurchased = this.ssnDetails.availableProducts;
    this.storeDetailsArray.map(item => {
      let alreadyPurchased = false;
      this.productsAlreadyPurchased.map(e => {
        if (item.productId === e.productCd) {
          alreadyPurchased = true;
          this.inEligiblePlans.push({
            productId: item.productId,
            productName: item.productName,
            planId: item.plan.id,
            planTitle: item.plan.title
          });
        }
      });
      if (!alreadyPurchased) {
        this.eligiblePlans.push({
          productId: item.productId,
          productName: item.productName,
          planId: item.plan.id,
          planTitle: item.plan.title,
          monthlyPremium: item.plan.price,
          riders: item.selectedRiders
        });
        this.updatedcart.push(item);
      }
    });
    return {
      eligiblePlans: this.eligiblePlans,
      inEligiblePlans: this.inEligiblePlans,
      updatedCartItems: this.updatedcart
    };
  }

  ngOnDestroy() {
    if (this.subscription !== undefined) this.subscription.unsubscribe();
  }
}
