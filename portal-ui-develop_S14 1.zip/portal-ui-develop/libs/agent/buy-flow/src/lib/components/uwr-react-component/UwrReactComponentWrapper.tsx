import { CmsService } from '@aflac/shared/cms';
import {
  AfterViewInit,
  Component,
  ElementRef,
  EventEmitter,
  OnChanges,
  OnDestroy,
  OnInit,
  Output,
  ViewChild
} from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { Router } from '@angular/router';
import { select, Store, UPDATE } from '@ngrx/store';
import * as _ from 'lodash';
import * as React from 'react';
import * as ReactDOM from 'react-dom';
const UwQuestionnaire = window['UwQuestionnaire'];
import { BuyFlowService } from '../../services/buy-flow.service';
import {
  buyFlowElementsSelector,
  dependentDataByRouteSelector,
  getIneligibleDependentDetails,
  getIneligibleDependentDetailsSuccess,
  getQuoteDataFromBundleId,
  getQuoteDataWithBundle,
  quoteDataUpdateStatus,
  ShoppingCartService,
  updateBuyFlowElements,
  updateQuote
} from '@aflac/agent/shared';
import { Observable, Subscription } from 'rxjs';
import { DependentService } from '../dependents/services/dependent.service';
import { DependentIneligibilityModalComponent } from '../dependent-ineligibility-modal/dependent-ineligibility-modal.component';
import { first } from 'rxjs/operators';
window['React'] = React;

const containerElementName = 'uwrReactComponentContainer';

// @ts-ignore
@Component({
  selector: 'aflac-uwr-component',
  template: `
    <span #${containerElementName}></span>
  `
})
export class UwrReactComponentWrapper
  implements OnDestroy, AfterViewInit, OnChanges, OnInit {
  private subscriptions = new Subscription();
  appRoutes = [];
  theme$: any;
  productCode: string;
  insured: any;
  getQuoteData: any;
  stepId: string;
  isGetQuoteDataAvailable: boolean;
  reviewQuoteIndex: string;
  previousUrl: string;
  policyNumber: string;
  ageValidationSub;
  canUpdate: boolean;
  updateQuoteSub;
  ineligibleInsureds: any;
  eligibleInsureds: any[];
  dialogRef: any;
  nextUrl = '/eligibility';
  route: any;
  ProductsInCart: any;
  bundleData: any;
  dependentDataArray: any;
  dependentData$: Observable<any>;
  modalDisplayed = false;

  // previousUrl ="/quotes/save-your-progress"
  @ViewChild(containerElementName, { static: false }) containerRef: ElementRef;
  @Output() UWRSuccess = new EventEmitter();
  policy: { policyNumber: string; insureds: any }[];
  constructor(
    public buyFlowService: BuyFlowService,
    public dependentService: DependentService,
    private store: Store<any>,
    private router: Router,
    private cmsService: CmsService,
    public dialog: MatDialog,
    private shoppingCartService: ShoppingCartService
  ) 
  {
    this.attachUWRAgentListener();
  }

  ngOnInit() {
    this.getStoreData();
  }

  ngOnChanges() {
    this.getStoreData();
  }

  ngAfterViewInit() {
    this.render();
  }

  ngOnDestroy() {
    // if (this.theme$) {
    //   this.theme$.unsubscribe();
    // }
    // if (this.ageValidationSub) {
    //   this.ageValidationSub.unsubscribe();
    // }
    if (this.subscriptions) this.subscriptions.unsubscribe();

    ReactDOM.unmountComponentAtNode(this.containerRef.nativeElement);
  }

  /***
   * Attaches listeners to the web-component from portal
   */
  attachUWRAgentListener() {
    const CustomEvent = function() {
      let subscriptions = [];
      this.on = function(event, handler) {
        subscriptions.push({ event, handler });
      };
      this.emit = function(event, args) {
        subscriptions
          .filter(subscriber => subscriber.event === event)
          .forEach(({ handler }) => {
            handler(args);
          });
      };
      this.off = function(subscribedEvent, subscribersHandle) {
        subscriptions = subscriptions.filter(
          ({ event, handler }) =>
            handler !== subscribersHandle && event !== subscribedEvent
        );
      };
    };

    window['udwrEventEmitter'] = new CustomEvent();

    /* Listen to Start Quote link event */
    window['udwrEventEmitter'].on('startQuote', () => {
      this.router.navigateByUrl('');
      /* Add in logic to clear the session & store values */
    });

    /* If user selects Yes to Cancel pop-up navigate back to previous step */
    window['udwrEventEmitter'].on('processCancel', () => {
      this.buyFlowService.enableStepperByRoute(this.previousUrl);
    });

    /* Listen to the success event */
    window['udwrEventEmitter'].on('udwrStatus', udwrResult => {
      if (udwrResult && udwrResult.uwrqComplete) {
        /* save UWRQ response to eligibility data obj */
        this.processUWResponse(udwrResult);
      }
    });
  }

  /***
   * Initialize the UWRQ component
   * */
  renderDetails() {
    const questionnaireService = '/agent/v1';
    const policyPersonalService = '/agent/v1';
    // tslint:disable-next-line:one-variable-per-declaration
    const productServices = {
      default: '/agent/v1'
    };
    const policyDetails = {
      channel: 'Agent Portal',
      transactionType: 'New Business',
      policy: this.policy
    };

    if (this.containerRef && this.containerRef.nativeElement) {
      ReactDOM.render(
        <div className={'i-am-classy'}>
          <UwQuestionnaire
            questionnaireService={questionnaireService}
            policyPersonalService={policyPersonalService}
            policyDetails={policyDetails}
            productServices={productServices}
          />
        </div>,
        this.containerRef.nativeElement
      );
    }
  }

  /***
   * Fetch the getQuoteData
   * */
  getDataForUWR() {
    const subsBFElements = this.store
      .pipe(select(getQuoteDataWithBundle))
      .subscribe(
        quoteData => {
          if (quoteData && quoteData.status) {
            console.log(quoteData);
            this.bundleData = quoteData.data.quotes;
            this.prepareInsuredDataForUWR(quoteData.data);
            this.renderDetails();
          }
        },
        err => {
          console.log(err);
        }
      );
    this.subscriptions.add(subsBFElements);
  }

  /***
   * Get insured data from getQuote for UWRQ
   * @param data: map the portal insureds data to create UWRQ insureds array
   * */
  prepareInsuredDataForUWR(data) {
    const policyData = [];
    data.quotes.forEach(element => {
      const insuredData = [];
      if (data) {
        _.each(element.insureds, insured => {
          const obj = {};
          obj['oid'] = insured.oid;
          obj['insuredType'] = this.getInsuredType(
            insured.relationshipToPrimaryInsuredCd
          );
          obj['firstName'] = insured.firstName;
          obj['lastName'] = insured.lastName;
          obj['dateOfBirth'] = insured.dateOfBirth;
          obj['primaryInsured'] = insured.primaryInsuredInd;
          insuredData.push(obj);
        });
      }
      const objdata = {};
      objdata['policyNumber'] = element.quoteNumber;
      objdata['insureds'] = insuredData;

      policyData.push(objdata);
    });
    this.policy = policyData;
  }

  /***
   * Map the portal relationship to UWRQ insured
   * @param relation: portal relationship status
   * */
  getInsuredType(relation): string {
    if (relation === 'SELF') {
      return 'Named Insured';
    } else if (relation === '1') {
      return 'Spouse';
    } else if (relation === '2') {
      return 'Child';
    }
  }
  /***
   * React render method
   * */
  private render() {
    this.getDataForUWR();
  }

  /***
   * Decide how to proceed further based on the response from UWR
   * @param response: UWRQ response with status and ineligible insureds
   * */
  processUWResponse(response) {
    const ineligibleInsuredsArray = [];
    let emitflag = false;
    const quoteData = this.bundleData;
    if (response) {
      response.policies.forEach(element => {
        //  if (policyData && policyData.length > 0) {
        /* using index 0, since for SP always one policy will be returned */
        const finalDecision = element.finalUWCode;
        //setting the productCode
        const ineligiblesdata = quoteData.filter(
          data => data.quoteNumber === element.policyNumber
        )[0];
        console.log('ineligiblesdata', ineligiblesdata);
        element.productCode = ineligiblesdata.productCode;

        if (finalDecision === 'ACC') {
          if (this.canUpdate) {
            // this.prepareAndDispatchUpdateQuote(null);
          } else {
            emitflag = true;
            //  this.UWRSuccess.emit();
          }
        } else if (finalDecision === 'DCL') {
          /* Portal will not be handling the DCL status as per requirement */
          console.log('DCL Status');
        } else if (finalDecision === 'RERATE') {
          ineligibleInsuredsArray.push(element);
          //this.checkDependentEligibility(policyData[0].ineligibleInsureds);
        }
        // }
      });
      if (ineligibleInsuredsArray && ineligibleInsuredsArray.length > 0) {
        this.checkDependentEligibility(ineligibleInsuredsArray);

        //this.checkDependentEligibility(response.policies[0].ineligibleInsureds);
      } else if (emitflag) {
        this.UWRSuccess.emit();
      }
    }
  }

  getProductsInCart() {
    const subsBFElements = this.buyFlowService.getCartData().subscribe(data => {
      this.ProductsInCart = data && data.value;
    });
    this.subscriptions.add(subsBFElements);
  }
  getDependent() {
    const subsBFElements = this.store
      .pipe(select(dependentDataByRouteSelector, '/dependents'))
      .subscribe(dependententsObj => {
        if (dependententsObj) {
          this.dependentDataArray = dependententsObj;
        }
      });
    this.subscriptions.add(subsBFElements);
  }
  /*  Request structure for age validation check */
  checkDependentEligibility(ineligibles) {
    this.ineligibleInsureds = _.clone(ineligibles);
    const products = [];
    this.ProductsInCart.forEach(element => {
      const productDetails = {
        productCd: element.productId,
        packageCd: element.plan.id,
        agencyId: this.bundleData[0] && this.bundleData[0].producerCd,
        originalIssueState:
          this.bundleData[0] && this.bundleData[0].originalIssueState,
        intDiagnosisBenefitAmount: Number(element.benefitAmount),
        tobaccoInd: element.tobaccoInd,
        riders: this.getRiderDetails(element.selectedRiders),
        insureds: this.getEligibleInsureds(ineligibles, element.productId)
      };
      products.push(productDetails);
    });
    const payload = {
      effectiveDate: new Date().toISOString(),
      products: products
    };
    console.log('checkDependentEligibility  payload : ', payload);
    this.store.dispatch(getIneligibleDependentDetails({ payload }));
  }
  /***
   * Create data for age validation API to get the updated coverage type and rate
   * @param ineligibles: array of ineligible insureds from UW
   */
  getEligibleInsureds(ineligibles, productId) {
    const eligibleInsureds = [];
    const quoteDataSet = this.bundleData;
    //  const quoteData = this.bundleData;
    const quoteData = [];
    this.bundleData.forEach(element => {
      if (element.productCode === productId) {
        quoteData.push(element);
      }
    });
    const ineligiblesdata = ineligibles.filter(
      data => data.productCode === productId
    )[0];
    const ineligibleInsureds = ineligiblesdata
      ? ineligiblesdata.ineligibleInsureds
      : [];
    const eligibleDetails = _.differenceWith(
      quoteData[0].insureds,
      ineligibleInsureds,
      function(allInsureds, ineligible) {
        return (
          allInsureds.oid === ineligible.oid ||
          allInsureds.relationshipToPrimaryInsuredCd === 'SELF'
        );
      }
    );
    /***
     * @property newInd: is set to false, because eligibility for dependents comes only after the age validation
     * from the dependents page
     * @property referenceNumber: is any random number, set to 0 for self, & index+20 for dependents
     */
    const insuredObjSelf = {
      referenceNumber: '0',
      customerNumber: quoteData[0].customerNumber,
      disabilityInd: false,

      primaryInsuredInd: true,
      newInd: true,
      relationshipToPrimaryInsuredCd: 'SELF',
      dateOfBirth: this.getSelfDOB()
    };
    /* prepare the eligible insured data for next step(self) */
    this.eligibleInsureds = quoteData[0].insureds.filter(
      el => el.relationshipToPrimaryInsuredCd === 'SELF'
    );
    eligibleInsureds.push(insuredObjSelf);
    if (eligibleInsureds.length > 0) {
      _.each(eligibleDetails, (eligible, index) => {
        if (eligible.relationshipToPrimaryInsuredCd !== 'SELF') {
          const data = {};
          data['customerNumber'] = quoteDataSet[0]['customerNumber'];
          data['dateOfBirth'] = eligible['dateOfBirth'];
          data['disabilityInd'] = eligible['disabilityInd'];
          data['newInd'] = false;
          data['primaryInsuredInd'] = eligible['primaryInsuredInd'];
          data['referenceNumber'] = index + 20 + '0';
          data['relationshipToPrimaryInsuredCd'] =
            eligible['relationshipToPrimaryInsuredCd'];
          eligibleInsureds.push(data);
          /* push the eligible dependent data into arr */
          this.eligibleInsureds.push(
            _.find(quoteDataSet[0].insureds, ['oid', eligible.oid])
          );
        }
      });
    }
    return eligibleInsureds;
  }
  getRiderDetails(item) {
    const riders = [];
    if (item) {
      item.forEach(riderItem => {
        const riderPayload = { riderNameCd: riderItem.rider.riderNameCd };
        riders.push(riderPayload);
      });
    }
    return riders;
  }

  getInsuredArray(data, dependentCode) {
    const details = {
      referenceNumber: data.oid,
      customerNumber: this.bundleData[0].customerNumber,
      relationshipToPrimaryInsuredCd: dependentCode,
      dateOfBirth: this.convertDOB(
        data.dateOfBirth,
        'request-payload'
      ),
      disabilityInd: false,
      newInd: data.customerNumber ? false : true,
      primaryInsuredInd: false
    };
    return details;
  }

  getSelfDOB() {
    if (
      this.bundleData &&
      this.bundleData.length > 0 &&
      this.bundleData[0].insureds
    ) {
      const selfData = this.bundleData[0].insureds.filter(
        item =>
          item.relationshipToPrimaryInsuredCd === 'SELF' ||
          item.relationshipToPrimaryInsuredCd === 'self'
      );
      return selfData && selfData.length && selfData[0].dateOfBirth;
    }
  }

  getDependentAgeValidationResponse() {
    const subsBFElements = this.buyFlowService
      .getDependentAgeValidation()
      .subscribe(res => {
        console.log('age res : ', res);
        if (res && res.data && res.data.length) {
          const products = [];
          let nonEligibleDependents = 0;
          let totalMonthlyCostOld = 0;
          let totalMonthlyCostNew = 0;
          const insuredDetails = res.data;
          this.ProductsInCart.forEach(element => {
            const monthlyPremium = Number(
              this.getMonthlyPremiumFromCart(element)
            );
            totalMonthlyCostOld = totalMonthlyCostOld + monthlyPremium;
            let _insuredDetails: any;
            insuredDetails.forEach(item => {
              if (
                Object.keys(item).includes(element.productId.replace(/-/g, ''))
              ) {
                _insuredDetails =
                  item[element.productId.replace(/-/g, '')].data;
              }
            });
            if (_insuredDetails) {
              totalMonthlyCostNew =
                totalMonthlyCostNew + Number(_insuredDetails.monthlyPremium);
              const payloadItem = {
                productId: element.productId,
                productName: element.productName,
                coverage: {
                  old: element.coverage,
                  new: _insuredDetails && _insuredDetails.coverageTierCd
                },
                nonEligibleDependents: this.nonEligibleDependentsOfSelectedProduct(
                  this.ineligibleInsureds,
                  element.productId
                ),
                monthlyPremium: {
                  old: monthlyPremium.toFixed(2),
                  new: Number(_insuredDetails.monthlyPremium).toFixed(2)
                }
              };
              products.push(payloadItem);
              if (
                payloadItem.nonEligibleDependents &&
                payloadItem.nonEligibleDependents.length > 0
              )
                nonEligibleDependents++;
            }
          });
          const cartPayload = {
            price: totalMonthlyCostNew.toFixed(2),
            count: this.ProductsInCart && this.ProductsInCart.length
          };
          const payload = {
            isUWR: true,
            totalMonthycost: {
              old: Number(totalMonthlyCostOld).toFixed(2),
              new: Number(totalMonthlyCostNew).toFixed(2)
            },
            productDetails: products,
            currentRoute: this.route,
            dependentsNotEligible: nonEligibleDependents > 0 ? true : false,
            bundleData: this.bundleData,
            // selectedQuoteData: this.selectedQuoteData,
            dependentDataArray: this.dependentDataArray
          };
          console.log('showDependentIneligibilityPopup payload ', payload);
          // if (nonEligibleDependents > 0 || true) {
          this.showDependentIneligibilityPopup(payload);
          this.shoppingCartService.updateShoppingCartPrice(cartPayload);
          // } else {
          //   // this.updateDependentQuote(
          //   //   this.bundleData,
          //   //   this.selectedQuoteData,
          //   //   this.dependentDataArray
          //   // );
          // }
        }
      });
    this.subscriptions.add(subsBFElements);
  }
  /***
   * Fetch policy number, product code & getQuoteData from store
   * */
  getStoreData() {
    this.store.dispatch(
      getIneligibleDependentDetailsSuccess({ payload: undefined })
    );
    this.getProductsInCart();
    this.getDependentAgeValidationResponse();
    this.route = this.router.url;
    this.dependentData$ = this.dependentService.getDependentData(this.route);
    this.getDependent();
  }
  getMonthlyPremiumFromCart(element) {
    let sum = 0;
    sum = sum + Number(element.plan.price);
    if (element.selectedRiders && element.selectedRiders.length) {
      element.selectedRiders.forEach(item => {
        sum = sum + item.rider.price;
      });
    }
    return Number(sum).toFixed(2);
  }
  nonEligibleDependentsOfSelectedProduct(info, productId) {
    //info: non eligible dependents array of selected productID
    const selectedProduct = this.dependentDataArray[productId];
    let quoteData;
    info.forEach(element => {
      if (element.productCode === productId) {
        // quoteData.push(element);
        quoteData = element.ineligibleInsureds;
      }
    });
    const _nonEligibleDependents = [];
    if (quoteData && quoteData.length) {
      quoteData.forEach(element => {
        if (element.insuredType === '1' || element.insuredType === 'Spouse') {
          const _data = {
            name:
              selectedProduct['spouse'].firstName +
              ' ' +
              selectedProduct['spouse'].lastName,
            relation: element.insuredType,
            dob: this.convertDOB(
              selectedProduct['spouse'].dateOfBirth,
              'modal-payload'
            ),
            oid: selectedProduct['spouse'].oid
          };
          _nonEligibleDependents.push(_data);
        } else if (
          element.insuredType === '2' ||
          element.insuredType === 'Child'
        ) {
          selectedProduct['children'].forEach(childInfo => {
            //if (childInfo.oid === element.oid) {
            const formatdob = this.convertDOB(
              element.dateOfBirth.split('T')[0],
              'modal-payload'
            );
            if (
              childInfo.firstName === element.firstName &&
              childInfo.lastName === element.lastName &&
              childInfo.dateOfBirth === formatdob
            ) {
              const _data = {
                name: childInfo.firstName + ' ' + childInfo.lastName,
                relation: element.insuredType,
                dob: this.convertDOB(
                  childInfo.dateOfBirth,
                  'modal-payload'
                ),
                oid: childInfo.oid
              };
              _nonEligibleDependents.push(_data);
            }
          });
        }
      });
      return _nonEligibleDependents;
    } else return [];
  }

  showDependentIneligibilityPopup(data) {
    this.modalDisplayed = true;
    const dialogRef = this.dialog.open(DependentIneligibilityModalComponent, {
      disableClose: true,
      panelClass: 'dependent-ineligibility-modal-cover',
      data: { payload: data }
    });
    this.updateDependentDetailsBasedOnEligibility(data);
    dialogRef.afterClosed().subscribe(res => {
      if (res && res === 'continue') {
        this.updateDependentsDetailStore();
        this.buyFlowService.completeCurrentStepAndMoveToNext(this.route);
      }
    });
  }
  updateDependentsDetailStore() {
    const products = Object.keys(this.dependentDataArray);
    const iteratedDependents = {};
    products.forEach(item => {
      let _selectedProduct = {};
      const dependents = this.dependentDataArray[item];
      if (dependents['spouse'] && dependents['spouse'].selected) {
        _selectedProduct = {
          ..._selectedProduct,
          spouse: dependents['spouse']
        };
      }
      if (dependents['children'] && dependents['children'].length) {
        const children = [];
        dependents['children'].forEach(child => {
          if (child.selected) children.push(child);
        });
        if (children.length) {
          _selectedProduct = { ..._selectedProduct, children: children };
        }
      }
      if (Object.keys(_selectedProduct).length > 0)
        iteratedDependents[item] = _selectedProduct;
    });
    this.dependentDataArray = iteratedDependents;
    this.updateBuyFlowElements();
  }
  eliminateRiderPriceFromPremium(price, rider) {
    let updatedPrice: number = price;
    let ridersum = 0;
    rider.forEach(item => {
      ridersum = ridersum + item.rider.price;
    });
    updatedPrice = updatedPrice - ridersum;
    return Number(updatedPrice).toFixed(2);
  }
  /* Update Cart and dependentArray details based on eligibility */
  updateDependentDetailsBasedOnEligibility(data) {
    const productDetails = data.productDetails;
    const _dependentDataArray = Object.assign({}, this.dependentDataArray);
    productDetails.forEach(element => {
      if (
        element.nonEligibleDependents &&
        element.nonEligibleDependents.length
      ) {
        const cloneCartProduct = Object.assign(
          {},
          this.ProductsInCart.filter(e => e.productId === element.productId)[0]
        );
        const clonePlan = Object.assign({}, cloneCartProduct.plan);
        cloneCartProduct.coverage = element.coverage.new;
        const updatedPlanPrice =
          cloneCartProduct &&
          cloneCartProduct.selectedRiders &&
          cloneCartProduct.selectedRiders.length
            ? this.eliminateRiderPriceFromPremium(
                element.monthlyPremium.new,
                cloneCartProduct.selectedRiders
              )
            : element.monthlyPremium.new;
        clonePlan.price = updatedPlanPrice;
        cloneCartProduct.plan = clonePlan;
        const dataToDispatch = { key: 'from-list', value: cloneCartProduct };
        this.buyFlowService.addItemsToCart(dataToDispatch);

        if (
          element.nonEligibleDependents &&
          element.nonEligibleDependents.length
        ) {
          const updateDependent = Object.assign(
            {},
            _dependentDataArray[element.productId]
          );
          element.nonEligibleDependents.forEach(dependent => {
            if (dependent.relation === '1' || dependent.relation === 'spouse') {
              const spouse = Object.assign({}, updateDependent['spouse']);
              spouse.selected = false;
              spouse.available = true;
              spouse.invalid = true;
              updateDependent['spouse'] = spouse;
            } else if (
              dependent.relation === '2' ||
              dependent.relation === 'children'
            ) {
              const childArray = Object.assign([], updateDependent['children']);
              childArray.forEach((child, index) => {
                if (dependent.oid === child.oid) {
                  const noneligiblechild = Object.assign({}, child);
                  noneligiblechild.selected = false;
                  noneligiblechild.available = true;
                  noneligiblechild.invalid = true;
                  childArray[index] = noneligiblechild;
                }
              });
              updateDependent['children'] = childArray;
            }
          });
          _dependentDataArray[element.productId] = updateDependent;
        }
      }
    });
    this.dependentDataArray = _dependentDataArray;
    this.updateBuyFlowElements();
  }
  /* To check DOB format matches mm/dd/yyy. For API request convert to yyyy-mm-dd format, 
  for modal input convert to mm/dd/yyy format */
  convertDOB(date, payload) {
    const regex = /^[0-9]{2}[\/][0-9]{2}[\/][0-9]{4}$/g;
    const matchRequiredFormat = regex.test(date);
    if (payload === 'request-payload') {
      if (matchRequiredFormat) {
        //change to yyyy-mm-dd
        const datearray = date.split('/');
        return datearray[2] + '-' + datearray[0] + '-' + datearray[1];
      } else return date;
    } else if (payload === 'modal-payload') {
      if (!matchRequiredFormat) {
        //change to mm/dd/yyyy
        const datearray = date.split('-');
        return datearray[1] + '/' + datearray[2] + '/' + datearray[0];
      } else return date;
    }
  }
  updateBuyFlowElements() {
    const subsBFElements = this.store
      .pipe(
        select(buyFlowElementsSelector),
        first()
      )
      .subscribe(data => {
        const buySteps = JSON.parse(JSON.stringify(data));
        buySteps.forEach((value, index) => {
          if (value.link === this.route) {
            buySteps[index].data = this.dependentDataArray;
          }
        });
        this.store.dispatch(updateBuyFlowElements({ payload: buySteps }));
      });
    this.subscriptions.add(subsBFElements);
  }
}
