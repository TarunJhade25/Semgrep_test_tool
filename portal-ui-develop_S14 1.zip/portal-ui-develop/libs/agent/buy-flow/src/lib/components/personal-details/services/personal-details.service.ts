import { Injectable } from '@angular/core';
import {
  buyFlowElementsSelector,
  updateBuyFlowElements,
  dependentDataByRouteSelector,
  getSavedUserDetails,
  selectUserDetailsFromAgent,
  getQuoteDataWithBundle,
  ssnValidationDetailsSelector,
  ageValidationDetailsSelector,
  deletedQuoteList,
  deletedQuoteListSelector
} from '@aflac/agent/shared'; // Selectors
import {
  ProductState,
  selectedPlans,
  fetchProductsByState
} from '@aflac/agent/shared';
import { select, Store } from '@ngrx/store';
import { first } from 'rxjs/operators';
import { SaveYourQuoteState } from '@aflac/agent/shared';
import { getPersonalDetails } from '@aflac/agent/shared'; // Actions
import { BehaviorSubject, Observable } from 'rxjs';
import { AddressValidationObj } from '@aflac/agent/shared';
import { HttpClient } from '@angular/common/http';
import { urlConfig } from '@aflac/shared/data-model';
import { BuyFlowService } from '../../../services/buy-flow.service';
import * as _ from 'lodash';

@Injectable({
  providedIn: 'root'
})
export class PersonalDetailsService {
  public isFormValid = new BehaviorSubject(false);
  public confirmNewAddress = new BehaviorSubject(false);
  public isMyInfoFormStatus = new BehaviorSubject(true);
  public isAddressFormStatus = new BehaviorSubject(true);
  public isShowContactForm = new BehaviorSubject(true);
  public isContactFormView = new BehaviorSubject(true);
  public endpoint: string = urlConfig.eisMicroServiceBaseUrl;
  public buttonVisibleStatus = new BehaviorSubject(false);
  public userType = new BehaviorSubject('new');
  public isContactFormStatus = new BehaviorSubject(true);
  custNumber: any;
  ssn: any;
  addressFormData: any;
  myInfoForm: any;
  ageValidationData: any;
  bundleData: any;
  userDataObj: any;
  constructor(
    private store: Store<SaveYourQuoteState>,
    private productStore: Store<ProductState>,
    private http: HttpClient,
    public buyFlowService: BuyFlowService
  ) {}

  addUserDependentData(userData, route) {
    this.store
      .pipe(
        select(buyFlowElementsSelector),
        first()
      )
      .subscribe(data => {
        const buySteps = JSON.parse(JSON.stringify(data));
        buySteps.forEach((value, index) => {
          if (value.link === route && userData) {
            buySteps[index].data = userData;
          }
        });
        this.store.dispatch(updateBuyFlowElements({ payload: buySteps }));
      });
  }

  setBundleData(data) {
    this.bundleData = data;
  }

  getPersonalData(route) {
    return this.store.select(dependentDataByRouteSelector, route);
  }
  getUserDataFomSaveQuote() {
    return this.store.select(selectUserDetailsFromAgent);
  }

  getUserDataFomSaveQuoteResponse() {
    return this.store.select(getSavedUserDetails);
  }

  getSSNValidationData() {
    return this.store.pipe(select(ssnValidationDetailsSelector));
  }

  getAgeValidationData() {
    return this.store.pipe(select(ageValidationDetailsSelector));
  }

  getCartData() {
    return this.productStore.pipe(select(selectedPlans));
  }

  getProductsByStateData() {
    return this.productStore.pipe(select(fetchProductsByState));
  }

  setPersonalDataProspect(custNumber) {
    this.store.dispatch(getPersonalDetails({ customerId: custNumber }));
  }

  setCustomerNumber(custNumber) {
    this.custNumber = custNumber;
  }

  getCustomerNumber() {
    return this.custNumber;
  }

  setAgeValData(ageValidationData) {
    this.ageValidationData = ageValidationData;
  }

  getAgeValData() {
    return this.ageValidationData;
  }

  formateDataOnFormSubmit(
    myInfoForm,
    addressForm,
    contactForm,
    personalData,
    requestHeader?
  ) {
    // My Info data
    let customerNumber, aflacUserGuid, hdim;
    const serviceCommunicationsInd = true;
    const otherCommunicationsInd = true;
    const bData = this.bundleData;
    //console.log('PS bData : ', bData);
    let {
      firstName,
      lastName,
      middleName,
      suffix,
      dateOfBirth,
      taxId,
      gender,
      addresses,
      emails,
      phones,
      isElectronicCopy,
      isPaperCopy
    } = personalData;
    if (personalData.customerNumber) {
      customerNumber = personalData.customerNumber;
    }
    if (personalData.aflacUserGuid) {
      aflacUserGuid = personalData.aflacUserGuid;
    }
    if (personalData.hdim) {
      hdim = personalData.hdim;
    }
    // const fullData = Object.assign({}, personalDetailsData);
    if (myInfoForm) {
      firstName = myInfoForm.getRawValue().firstName.trim();
      lastName = myInfoForm.getRawValue().lastName.trim();
      middleName = myInfoForm.getRawValue().middleInitials;
      suffix = myInfoForm.getRawValue().suffix;
      dateOfBirth = requestHeader
        ? this.buyFlowService.convertDOB(
            myInfoForm.getRawValue().dateOfBirth,
            'req'
          )
        : myInfoForm.getRawValue().dateOfBirth;
      taxId = myInfoForm.getRawValue().taxId;
      gender = myInfoForm.getRawValue().gender;
    }

    // Home Address Data
    if (addressForm) {
      addresses = [];
      let {
        addressLine1,
        addressLine2,
        city,
        stateProvCd,
        zipCode,
        countryCd,
        addressTypeCd,
        addressValidated
      } = addressForm.value;
      addressLine1 = addressForm.getRawValue().addressLine1.trim();
      addressLine2 = addressForm.getRawValue().addressLine2.trim();
      city = addressForm.getRawValue().city.trim();
      zipCode = addressForm.getRawValue().zipCode;
      if (!stateProvCd) stateProvCd = addressForm.getRawValue().stateProvCd;
      if (
        bData &&
        bData.length > 0 &&
        bData[0].insureds &&
        bData[0].insureds.length > 0
      ) {
        countryCd = bData[0].insureds[0].address.countryCd;
        addressTypeCd = bData[0].insureds[0].address.addressTypeCd;
      }
      addressValidated = true;
      addresses.push({
        addressLine1,
        addressLine2,
        city,
        stateProvCd,
        zipCode,
        countryCd,
        addressTypeCd,
        addressValidated
      });
    }

    // Contact Info data
    if (contactForm) {
      emails = [];
      phones = [];
      const date = new Date();
      const isoDate = date.toISOString();
      const today = isoDate.split('T')[0];
      const emailInfo = {
        email: contactForm.getRawValue().confirm_email
          ? contactForm.getRawValue().confirm_email.trim()
          : contactForm.getRawValue().email.trim(),
        consentStatus: 'GRANTED',
        consentDate: today
      };
      emails.push(emailInfo);

      const phoneInfo = {
        phone: contactForm.getRawValue().phone_number
      };
      phones.push(phoneInfo);
      if (contactForm.getRawValue().electronic_delivery) {
        isElectronicCopy = true;
        isPaperCopy = false;
      } else {
        isElectronicCopy = false;
        isPaperCopy = true;
      }
    }

    const data = {
      customerNumber,
      firstName,
      lastName,
      middleName,
      suffix,
      dateOfBirth,
      taxId,
      gender,
      addresses,
      emails,
      phones,
      isElectronicCopy,
      isPaperCopy,
      requestHeader,
      aflacUserGuid,
      serviceCommunicationsInd,
      otherCommunicationsInd
    };
    return data;
  }

  setSSNValue(ssn) {
    this.ssn = ssn;
  }

  getSSNValue() {
    return this.ssn;
  }

  PostAddressForValidation$(addressObj: AddressValidationObj): Observable<any> {
    return this.http.post(
      `${this.endpoint}afl-address-rs/v1/address/validate`,
      {
        street: addressObj.street,
        street2: addressObj.street2,
        zip: addressObj.zip,
        state: addressObj.state,
        city: addressObj.city
      }
    );
  }

  returnAddressValidation(data) {
    let ctaStatus, errorStatus;
    const errorSts = ['0', '1', '16', '17'];
    const ctaSts = ['2', '3', '4', '6', '7', '11'];
    if (data) {
      errorStatus = errorSts.includes(data); // get  error status =true
      ctaStatus = !ctaSts.includes(data); // get ctastatus = false
    }

    return {
      errorStatus,
      ctaStatus
    };
  }
  setAddressFormData(data) {
    this.addressFormData = data;
  }
  getAddressFormData() {
    return this.addressFormData;
  }
  setMyInfoForm(data) {
    this.myInfoForm = data;
  }
  getMyInfoForm() {
    return this.myInfoForm;
  }

  formatDataOnIdValidation(formData) {
    const data = {
      sourceSystem: 'EIS', // Default value
      systemFlowCode: 'APPLICANT_REGISTRATION', // Default value
      aflacUserGUID: formData.aflacUserGuid,
      eisCustomerNumber: formData.customerNumber.toString(), //formData.customerNumber, //1212, 510001- ID valiation success, 333 - ID valiation failure
      firstName: formData.firstName,
      middleName: formData.middleName,
      lastName: formData.lastName,
      dateOfBirth: formData.dateOfBirth,
      emailAddress: formData.emails[0].email,
      phoneNumber: formData.phones[0].phone,
      phoneIdentifier: 'MOBILE', //Default Value
      address1: formData.addresses[0].addressLine1,
      address2: formData.addresses[0].addressLine2,
      city: formData.addresses[0].city,
      state: formData.addresses[0].stateProvCd,
      zip: formData.addresses[0].zipCode,
      documentNumber: formData.taxId,
      documentType: 'SSN',
      requestDeviceData: {
        headers: [],
        userIdentityCookies: [],
        jsc: formData.requestHeader.jscPayload,
        hdim: formData.requestHeader.hdimPayload
      }
    };
    return data;
  }

  getNumeric(stringVal) {
    if (isNaN(stringVal)) stringVal = stringVal.replace(/,/g, '');
    return Number(stringVal);
  }

  fetchUpdatedSum(quote) {
    let updatedCartSum = 0;
    if (quote && quote.length > 0) {
      quote.forEach(element => {
        updatedCartSum = updatedCartSum + this.getNumeric(element.plan.price);
        if (element.selectedRiders && element.selectedRiders.length > 0) {
          element.selectedRiders.forEach(item => {
            updatedCartSum = updatedCartSum + this.getNumeric(item.rider.price);
          });
        }
      });
    }
    return updatedCartSum.toFixed(2);
  }

  calculateAgeFromDOB(dateOfBirth) {
    const today = new Date();
    const birthDate = new Date(dateOfBirth);
    let age = today.getFullYear() - birthDate.getFullYear();
    const m = today.getMonth() - birthDate.getMonth();

    if (m < 0 || (m === 0 && today.getDate() < birthDate.getDate())) {
      age--;
    }
    return age;
  }

  setDeleteQuoteList(filteredQuoteObject, bundleData) {
    let deletedList;
    const deletedListFiltered = [];
    if (bundleData && bundleData.length > 0) {
      deletedList = bundleData.filter(({ productCode: id1 }) =>
        filteredQuoteObject.some(({ productId: id2 }) => id2 === id1)
      );
    }
    if (deletedList && deletedList.length > 0) {
      deletedList.map(item => {
        deletedListFiltered.push({ policyNumber: item.quoteNumber });
      });
    }
    //console.log('deletedListFiltered : ', deletedListFiltered);
    this.store.dispatch(
      deletedQuoteList({ deletedQuote: deletedListFiltered })
    );
  }

  getDeletedQuoteListData() {
    return this.store.pipe(select(deletedQuoteListSelector));
  }

  updatePersonalQuotes(bundleData, contactFormData, myInfoFormData) {
    const today = new Date();
    const bDataMod = [];
    if (bundleData && bundleData.length > 0) {
      bundleData.map(item => {
        /*
        let insuredArray = [];
        if (!_.isEmpty(item.insureds)) {
          item.insureds.map(insItem => {
            const insItemClone = Object.assign({}, insItem);
            if (insItem.relationshipToPrimaryInsuredCd === 'SELF') {
              insItemClone['dateOfBirth'] = this.buyFlowService.convertDOB(
                myInfoFormData.dateOfBirth,
                'req'
              );
            }
            insuredArray.push(insItemClone);
          });
        }
        console.log('item.insured : ', insuredArray);
*/
        bDataMod.push({
          productCd: item.productCode,
          packageCd: item.packageCd,
          coverageTypeCd: item.coverageTypeCd,
          quoteNumber: item.quoteNumber,
          electronicPolicyDelivery: contactFormData.electronic_delivery,
          electronicDateTimestamp: today.toISOString(),
          insureds: item.insureds
        });
      });
    }
    return bDataMod;
  }

  getPrevCustomerData() {
    const userData = this.getUserDataFomSaveQuoteResponse();
    if (userData) {
      userData.subscribe(uData => {
        if (!_.isEmpty(uData)) {
          this.userDataObj = uData;
        } else {
          if (this.bundleData && this.bundleData.length > 0) {
            this.userDataObj = this.bundleData[0].insureds.filter(
              item => item.relationshipToPrimaryInsuredCd === 'SELF'
            )[0];
          }
        }
      });
    }
    return this.userDataObj;
  }
}
