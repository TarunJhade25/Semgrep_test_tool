import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PersonalDetailsHomeAddressComponent } from './personal-details-home-address.component';
import { TranslateModule } from '@ngx-translate/core';
import { NotificationComponent } from '@aflac/shared/ui';
import {
  FormsModule,
  ReactiveFormsModule,
  FormBuilder,
  Validators
} from '@angular/forms';
import { SharedMaterialModule } from '@aflac/shared/material';
import { StoreModule, Store, MemoizedSelector } from '@ngrx/store';
import { saveYourQuoteReducer } from '@aflac/agent/shared';
import { PersonalDetailsService } from '../services/personal-details.service';
import { MockStore, provideMockStore } from '@ngrx/store/testing';
import {
  agentSelectedQuote,
  buyFlowElementsSelector
} from '@aflac/agent/shared';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { of, Observable, Observer } from 'rxjs';
import { StateEntityService } from '@aflac/shared/data-model';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { NgxMaskModule } from 'ngx-mask';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { CmsService } from '@aflac/shared/cms';
import { Router } from '@angular/router';
import { RouterTestingModule } from '@angular/router/testing';

describe('PersonalDetailsHomeAddressComponent', () => {
  let component: PersonalDetailsHomeAddressComponent;
  let fixture: ComponentFixture<PersonalDetailsHomeAddressComponent>;
  let mockStore: MockStore<any>;
  let router: Router;
  const initialState = { statusOnComplete: 'address-success' };
  const fb: FormBuilder = new FormBuilder();
  const addressForm = fb.group({
    addressLine1: ['', [Validators.required]],
    addressLine2: ['', []],
    city: ['', [Validators.required]],
    stateProvCd: ['', [Validators.required]],
    zipCode: ['', [Validators.required, Validators.minLength(5)]]
  });
  const data = {
    addresses: {
      addressLine1: 'AA',
      addressLine2: 'ab',
      city: 'asa',
      stateProvCd: 'CA',
      zipCode: '12345'
    }
  };
  const addressInfo = {
    addressLine1: 'AA',
    addressLine2: 'ab',
    city: 'asa',
    stateProvCd: 'CA',
    zipCode: '12345',
    street: 'sdsd'
  };
  const prefilledData = {
    addresses: [
      {
        addressLine1: '36 Florida strret',
        addressLine2: '10 flor',
        city: 'San francisco',
        stateProvCd: 'AL',
        zipCode: 12323
      }
    ],
    customerNumber: '1212'
  };
  const fakeSpinner = {
    spinnerState: of({ code: 'AL', name: 'Alabama' })
  };
  const buyFlowElements = [];
  const agentSearchQuote = {
    state: 'Alabama',
    stateProvCd: 'AL',
    caseId: 'AEDJHDYU',
    age: 24,
    partnerId: '1'
  };
  let mockBuyFlowSelector: MemoizedSelector<any, any>;
  let mockAgentQuoteSelector: MemoizedSelector<any, any>;
  // const personalInfoService: PersonalDetailsService;
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [
        PersonalDetailsHomeAddressComponent,
        NotificationComponent
      ],
      imports: [
        TranslateModule.forRoot(),
        ReactiveFormsModule,
        BrowserAnimationsModule,
        FormsModule,
        SharedMaterialModule,
        StoreModule.forRoot(saveYourQuoteReducer),
        NgxMaskModule.forRoot(),
        HttpClientTestingModule,
        RouterTestingModule
      ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
      providers: [
        provideMockStore({}),
        { provide: StateEntityService, useClass: MockStateEntityService },
        PersonalDetailsService,
        CmsService
      ]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PersonalDetailsHomeAddressComponent);
    mockStore = TestBed.get(Store);
    mockBuyFlowSelector = mockStore.overrideSelector(
      buyFlowElementsSelector,
      buyFlowElements
    );
    mockAgentQuoteSelector = mockStore.overrideSelector(
      agentSelectedQuote,
      agentSearchQuote
    );
    component = fixture.componentInstance;
    router = TestBed.get(Router);
    const cmsService = TestBed.get(CmsService);
    const mockStates = {
      us_states: [
        {
          code: 'AL',
          name: 'Alabama'
        }
      ]
    };
    spyOn(cmsService, 'getKey').and.returnValue(of(mockStates));
    component.addressForm = addressForm;
    component.data = null;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
  it('key press event', () => {
    const mockEvent = {
      target: {
        value: '1231'
      },
      charCode: 49
    };
    component.keyPress(mockEvent);
  });

  it('should set data for new prospect', () => {
    const personalStoreService = TestBed.get(PersonalDetailsService);
    const mockQouteData = {
      state: 'Alabama'
    };
    const qouteSpy = spyOn(
      personalStoreService,
      'getUserDataFomSaveQuoteResponse'
    ).and.returnValue(of([mockQouteData]));
    component.setFormDataForNewProspect();
    expect(qouteSpy).toHaveBeenCalled();
  });
  it('on submit  event', () => {
    component.addressForm.setValue({
      addressLine1: 'aaaqw',
      addressLine2: 'Johnes',
      city: 'sad',
      stateProvCd: 'AL',
      zipCode: 12323
    });
    component.addressInfo = addressInfo;
    spyOn(component, 'checkAfterAddressValidation').and.returnValue(of(true));
    component.onSubmit();
  });
  it('toggle mode event', () => {
    component.data = {
      addresses: [
        {
          addressLine1: '36 Florida strret',
          addressLine2: '10 flor',
          city: 'San francisco',
          stateProvCd: 'AL',
          zipCode: 12323
        }
      ]
    };
    component.selectedState = [{ code: 'Al', name: 'Alabama' }];
    component.toggleViewMode();
  });
  it('get selected state mock event ', () => {
    const newUser = false;
    component.data = {
      addresses: [
        {
          addressLine1: '36 Florida strret',
          addressLine2: '10 flor',
          city: 'San francisco',
          stateProvCd: 'AL',
          zipCode: 12323
        }
      ]
    };
    component.us_states = [{ code: 'AL', name: 'Alabama' }];
    component.getSelectedState(component.data, newUser);
  });
  it('after address validation event', () => {
    component.data = {
      addresses: [
        {
          addressLine1: '36 Florida strret',
          addressLine2: '10 flor',
          city: 'San francisco',
          stateProvCd: 'AL',
          zipCode: 12323
        }
      ],
      customerNumber: '1212'
    };
    component.checkAfterAddressValidation();
  });
  it('pre filled data event', () => {
    component.us_states = [{ code: 'AL', name: 'Alabama' }];
    component.data = {
      addresses: [
        {
          addressLine1: '36 Florida strret',
          addressLine2: '10 flor',
          city: 'San francisco',
          stateProvCd: 'AL',
          zipCode: 12323
        }
      ],
      customerNumber: '1212'
    };
    component.ngOnInit();
  });
  it('save data address event', () => {
    const mockJson = {
      formData: addressInfo
    };
    const personalStoreService = TestBed.get(PersonalDetailsService);
    spyOn(personalStoreService, 'addUserDependentData');
    component.saveDataOnAddressSuccess(mockJson);
  });
  it('form change event', () => {
    const age = component.addressForm.controls['addressLine1'];
    age.setValue('aaa');
    component.isEdit = true;
    component.trackFirstValueChange();
  });
  it('should show saved data event', () => {
    const personalStoreService = TestBed.get(PersonalDetailsService);
    const dataSpy = spyOn(
      personalStoreService,
      'getPersonalData'
    ).and.returnValue(of(prefilledData));
    component.ngOnInit();
    expect(dataSpy).toHaveBeenCalled();
  });

  it('should check callSuccessFunction function is called', () => {
    component.callSuccessFunction();
    expect(component.callSuccessFunction).toBeDefined();
  });

  it('should check getAddressStr function is called', () => {
    component.us_states = [{ code: 'AL', name: 'Alabama' }];
    const addData = {
      addressLine1: 'AA',
      addressLine2: 'ab',
      city: 'asa',
      state: 'AL',
      zipCode: '12345',
      street: 'sdsd'
    };
    component.getAddressStr(addData);
    expect(component.getAddressStr).toBeDefined();
  });

  // Mock Class
  class MockStateEntityService {
    entities$ = of([{ us_states: [{ code: 'AL', name: 'Alabama' }] }]);
  }
});
