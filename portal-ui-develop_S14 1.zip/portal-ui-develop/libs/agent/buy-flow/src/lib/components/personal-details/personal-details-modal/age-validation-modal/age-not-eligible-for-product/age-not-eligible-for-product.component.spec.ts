import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { AgeNotEligibleForProductComponent } from './age-not-eligible-for-product.component';
import { TranslateModule } from '@ngx-translate/core';
import {
  MatDialogModule,
  MatDialogRef,
  MatDialog,
  MAT_DIALOG_DATA
} from '@angular/material/dialog';
import { StoreModule, Store, MemoizedSelector } from '@ngrx/store';
import { saveYourQuoteReducer } from '@aflac/agent/shared';
import { RouterTestingModule } from '@angular/router/testing';
import { NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { SharedMaterialModule } from '@aflac/shared/material';
import { PersonalDetailsService } from '../../../services/personal-details.service';
import { of, Observable } from 'rxjs';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { provideMockStore, MockStore } from '@ngrx/store/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { Router } from '@angular/router';

describe('AgeNotEligibleForProductComponent', () => {
  let component: AgeNotEligibleForProductComponent;
  let fixture: ComponentFixture<AgeNotEligibleForProductComponent>;
  let dialog: MatDialog;
  let router: Router;
  let mockStore: MockStore<any>;

  const cartData = {
    key: 'from-list',
    value: [
      {
        productId: 'PREC-IC',
        productName: 'Accident',
        plan: {
          id: 123,
          price: '100',
          description: 'These are the benefits',
          name: 'Lorem ipsum',
          states: ['AL', 'CT'],
          title: 'Standard Plan',
          benefits: [
            {
              id: 333,
              name: 'test',
              price: 123
            }
          ]
        },
        coverage: 'ind',
        selected: true,
        availableInCart: true,
        selectedRiders: [
          {
            rider: { title: 'title1', price: '100' },
            selected: true,
            availableInCart: true,
            plan: { id: 'id1' }
          },
          {
            rider: { title: 'title2', price: '200' },
            selected: true,
            availableInCart: true,
            plan: { id: 'id1' }
          }
        ]
      }
    ]
  };

  const payloadData = {
    payload: {
      ageEligibilityDetails: [
        {
          productId: 'PREC-IA',
          productName: 'Accident Insurance',
          currentPremium: 28.05,
          riders: []
        },
        {
          productId: 'PREC-IC',
          productName: 'Cancer Insurance',
          currentPremium: 209.87,
          riders: []
        }
      ],
      ageInEligibilityDetails: [],
      agePremiumChangeDetails: [
        {
          currentPremium: 209.87,
          dateOfBirth: '01/01/2000',
          prevPremium: 27.33,
          productId: 'PREC-IC',
          productName: 'Cancer Insurance',
          riders: []
        }
      ],
      cartProducts: cartData.value,
      mode: 'Exit'
    }
  };

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [AgeNotEligibleForProductComponent],
      imports: [
        MatDialogModule,
        RouterTestingModule,
        SharedMaterialModule,
        TranslateModule.forRoot(),
        StoreModule.forRoot(saveYourQuoteReducer),
        BrowserAnimationsModule,
        HttpClientTestingModule
      ],
      schemas: [NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA],
      providers: [
        provideMockStore({}),
        { provide: MAT_DIALOG_DATA, useValue: payloadData.payload },
        { provide: MatDialogRef, useClass: DialogMock },
        {
          provide: PersonalDetailsService,
          useClass: MockPersonalDetailsService
        }
      ]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AgeNotEligibleForProductComponent);
    mockStore = TestBed.get(Store);
    component = fixture.componentInstance;
    dialog = TestBed.get(MatDialog);
    router = TestBed.get(Router);
    component.data = payloadData;
    component.ageEligibilityData = payloadData.payload;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('check for ngOnInit', () => {
    component.ngOnInit();
    expect(component.ngOnInit).toBeDefined();
  });

  it('check for goBackAndEdit', () => {
    component.goBackAndEdit();
    expect(component.goBackAndEdit).toBeDefined();
  });

  it('check for getStoreDetails', () => {
    component.getStoreDetails();
    expect(component.getStoreDetails).toBeDefined();
  });

  it('check for getProductPremiumChange', () => {
    component.getProductPremiumChange();
    expect(component.getProductPremiumChange).toBeDefined();
  });

  it('check for filterProductInEligible', () => {
    component.filterProductInEligible();
    expect(component.filterProductInEligible).toBeDefined();
  });

  it('check for updateCartPremium', () => {
    component.updateCartPremium();
    expect(component.updateCartPremium).toBeDefined();
  });

  it('check for onSubmit', () => {
    component.onSubmit();
    expect(component.onSubmit).toBeDefined();
  });

  it('check for updateCartWithEligibleQuote', () => {
    component.updateCartWithEligibleQuote('');
    expect(component.updateCartWithEligibleQuote).toBeDefined();
  });

  //Mock class
  class MockPersonalDetailsService {
    getCartData(): Observable<any> {
      return of(cartData);
    }
    fetchUpdatedSum() {
      return of(true);
    }
  }
  class DialogMock {
    close() {}
  }
});
