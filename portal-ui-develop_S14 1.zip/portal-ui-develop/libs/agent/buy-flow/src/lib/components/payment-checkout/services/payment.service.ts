import { urlConfig } from '@aflac/shared/data-model';
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class PaymentService {
  public userType = new BehaviorSubject('new');
  prefix = urlConfig.eisMicroServiceBaseUrl + 'jpmc/';

  // prefix =
  //   `http://devportalalb-74324206.us-east-1.elb.amazonaws.com:8080/` + 'jpmc/';
  prefixEIS = urlConfig.eisMicroServiceBaseUrl;

  constructor(private http: HttpClient) {
    if (this.prefix.indexOf('localhost') > 0) {
      this.prefix = urlConfig.securityServiceBaseUrl + 'jpmc/';
    }
  }
  getJPMCSessionUrl(payload) {
    return this.http.post(this.prefix + 'v1/initiate', payload);
  }

  getUpdateAccountUrl(payload) {
    return this.http.post(this.prefix + 'v1/update/account', payload);
  }

  getPaymentAccount(custId) {
    const timestamp = new Date().valueOf();
    return this.http.get(
      this.prefix + `v1/accounts/${custId}?time=${timestamp}`
    );
  }

  makeSinglePayment(paymentReq) {
    return this.http.post(this.prefix + 'v1/payment', paymentReq);
  }

  refundSinglePayment(refundReq) {
    return this.http.post(this.prefix + 'v1/refund', refundReq);
  }

  getPaymentAuthorization(payload) {
    return this.http.post(this.prefix + 'v1/authorize', payload);
  }

  getPaymentCardUpdate(payload) {
    return this.http.post(this.prefix + 'v1/account/update/cc', payload);
  }

  getPaymentBankUpdate(payload) {
    return this.http.post(this.prefix + 'v1/account/update/ach', payload);
  }

  //eis api mock?
  getPaymentMethods(custId) {
    return this.http.get(
      this.prefixEIS +
        `agent/v1/billing-customers/` +
        custId +
        `/payment-methods`
    );
  }

  //eis api mock?
  addPaymentMethod(payload) {
    return this.http.post(
      this.prefixEIS + `customer/member/v1/billing/payment-methods`,
      payload
    );
  }

  //eis api mock?
  updatePaymentMethod(payload, paymentId) {
    return this.http.put(
      this.prefixEIS +
        `customer/member/v1/billing/payment-methods/${paymentId}`,
      payload
    );
  }
}
