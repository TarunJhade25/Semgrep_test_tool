import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';
import { MatDatepickerInputEvent } from '@angular/material/datepicker';
import { SaveYourQuoteState, getEffectiveDate } from '@aflac/agent/shared'; //stores
import { Store, select } from '@ngrx/store';
@Component({
  selector: 'aflac-agent-order-review-effective-date',
  templateUrl: './agent-order-review-effective-date.component.html',
  styleUrls: ['./agent-order-review-effective-date.component.scss']
})
export class AgentOrderReviewEffectiveDateComponent implements OnInit {
  effectiveDateForm: FormGroup;
  minDate: Date;
  maxDate: Date;
  @Output() dateSelected: EventEmitter<any> = new EventEmitter<any>();

  constructor(private savedQuoteStore: Store<SaveYourQuoteState>) {}

  ngOnInit() {
    this.effectiveDateForm = new FormGroup({
      effectiveDate: new FormControl('')
    });

    //Set min and max date of effective date as
    //current day+1 and current day+7
    this.minDate = new Date();
    this.minDate.setDate(this.minDate.getDate() + 1);

    this.maxDate = new Date();
    this.maxDate.setDate(this.maxDate.getDate() + 30);
  }

  onDateSelection($event) {
    this.dateSelected.emit($event.value);
    this.savedQuoteStore.dispatch(getEffectiveDate({ payload: $event.value }));
  }
}
