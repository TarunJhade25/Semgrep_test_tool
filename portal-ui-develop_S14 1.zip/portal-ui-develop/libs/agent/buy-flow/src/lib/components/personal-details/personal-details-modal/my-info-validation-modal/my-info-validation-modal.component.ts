import { Component, OnInit, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';

@Component({
  selector: 'aflac-my-info-validation-modal',
  templateUrl: './my-info-validation-modal.component.html',
  styleUrls: ['./my-info-validation-modal.component.scss']
})
export class MyInfoValidationModalComponent implements OnInit {
  constructor(
    public dialogRef: MatDialogRef<MyInfoValidationModalComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) {}

  ngOnInit() {}
  closeModal(checkClose) {
    this.dialogRef.close(checkClose);
  }
}
