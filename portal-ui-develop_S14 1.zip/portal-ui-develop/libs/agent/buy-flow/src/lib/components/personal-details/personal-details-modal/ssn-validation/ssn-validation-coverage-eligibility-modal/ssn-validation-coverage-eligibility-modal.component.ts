import { Component, OnInit, Inject, OnDestroy } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { Router } from '@angular/router';
import { Store, select } from '@ngrx/store';
import { Subscription } from 'rxjs';
import { AgentSharedService } from '@aflac/agent/shared';
import { ProductState, ResetRetrieveCart } from '@aflac/agent/shared';

@Component({
  selector: 'aflac-ssn-validation-coverage-eligibility-modal',
  templateUrl: './ssn-validation-coverage-eligibility-modal.component.html',
  styleUrls: ['./ssn-validation-coverage-eligibility-modal.component.scss']
})
export class SsnValidationCoverageEligibilityModalComponent
  implements OnInit, OnDestroy {
  subscription = new Subscription();
  modalExpanded: any;
  selectedProfile: any;
  ssnDetails: any;

  constructor(
    @Inject(MAT_DIALOG_DATA) public data: any,
    private router: Router,
    private store: Store<any>,
    private agentSharedService: AgentSharedService,
    private productStore: Store<ProductState>,
    private dialogRef: MatDialogRef<
      SsnValidationCoverageEligibilityModalComponent
    >
  ) {}

  ngOnInit() {
    let modalType;
    this.selectedProfile = this.data && this.data.payload;
    //console.log('SSN Coverage selected profile : ', this.selectedProfile);
    this.ssnDetails = this.selectedProfile.ssnData;
    if (this.selectedProfile) {
      if (this.selectedProfile.mode === 'AgentIneligible') modalType = 'ai';
      else if (this.selectedProfile.mode === 'Exit') modalType = 'exit';
      else modalType = 'hope';
      this.modalExpanded = modalType;
    }
  }

  goBackAndEdit() {
    this.dialogRef.close('goback');
    this.router.navigateByUrl('my-details');
  }

  goToQuote() {
    this.dialogRef.close('continue');
    this.updateCartWithEligibleQuote();
    this.agentSharedService.updateSearchQuote('ssn', this.ssnDetails);
    this.agentSharedService.updateExistingCustomerInfo('ssn', this.ssnDetails);
    //this.agentSharedService.updateRetrieveQuote(); // Need to check
    this.router.navigateByUrl('quotes');
  }

  updateCartWithEligibleQuote() {
    const cartPayload = {
      key: undefined,
      value: undefined
    };
    const headerPayload = {
      price: 0,
      count: 0
    };
    this.productStore.dispatch(ResetRetrieveCart());
    sessionStorage.removeItem('state-agent-cart-details');
    this.agentSharedService.updateCartWithEligibleQuote(
      cartPayload,
      headerPayload
    );
  }

  ngOnDestroy() {
    if (this.subscription !== undefined) this.subscription.unsubscribe();
  }
}
