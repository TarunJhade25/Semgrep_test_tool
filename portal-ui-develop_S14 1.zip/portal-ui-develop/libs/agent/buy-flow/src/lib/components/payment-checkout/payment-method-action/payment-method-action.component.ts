import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';

@Component({
  selector: 'aflac-payment-method-action',
  templateUrl: './payment-method-action.component.html',
  styleUrls: ['./payment-method-action.component.scss']
})
export class PaymentMethodActionComponent implements OnInit {
  constructor() {}
  @Input() data;
  @Input() action;
  @Input() accountId;
  @Input() type;
  @Input() existingMembers;
  @Output() gotoesign = new EventEmitter();
  @Output() gotoedit = new EventEmitter();
  @Output() gotoadd = new EventEmitter();
  enableActions = false;
  isExpired = false;
  isToExpireSoon = false;
  ngOnInit() {
    this.checkExpiryOfCreditCards();
  }

  selectCard() {
    this.enableActions = false;
    this.gotoesign.emit(this.accountId);
  }

  editAccount() {
    this.enableActions = false;
    this.gotoedit.emit({
      payload: this.data,
      accountId: this.accountId,
      type: this.type
    });
  }

  addAccount() {
    this.gotoadd.emit({ type: this.type });
  }

  selectAction() {
    this.enableActions = true;
  }

  checkExpiryOfCreditCards() {
    if (this.data && this.data.creditCardExpirationDate) {
      const expArray = this.data.creditCardExpirationDate.split('/');
      const expMonth = parseInt(expArray[0], 10);
      const expYear = parseInt(expArray[1], 10);

      const currentMonth = new Date().getMonth() + 1;
      const currentYear = new Date().getFullYear();

      if (expYear === currentYear) {
        if (expMonth === currentMonth) {
          this.isToExpireSoon = true;
        } else if (expMonth < currentMonth) {
          this.isExpired = true;
        } else {
          this.isExpired = false;
          this.isToExpireSoon = false;
        }
      } else if (expYear < currentYear) {
        this.isExpired = true;
      }
    }
  }
}
