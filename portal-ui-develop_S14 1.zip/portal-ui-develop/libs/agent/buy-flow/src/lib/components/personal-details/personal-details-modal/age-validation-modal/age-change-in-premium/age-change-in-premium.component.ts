import { Component, OnInit, Inject } from '@angular/core';
import {
  MatDialogRef,
  MAT_DIALOG_DATA,
  MatDialog
} from '@angular/material/dialog';
import { Router } from '@angular/router';
import { Subscription } from 'rxjs';
import { Store } from '@ngrx/store';
import { ProductState, UpdateCartOnQuoteSave } from '@aflac/agent/shared';
import { PersonalDetailsService } from '../../../services/personal-details.service';
import { ShoppingCartService } from '@aflac/agent/shared';

@Component({
  selector: 'aflac-age-change-in-premium',
  templateUrl: './age-change-in-premium.component.html',
  styleUrls: ['./age-change-in-premium.component.scss']
})
export class AgeChangeInPremiumComponent implements OnInit {
  subscription = new Subscription();
  ageValidationDetails: any;
  totalPrevPremium: any = 0;
  totalCurrentPremium: any = 0;
  storeDetailsArray: any;
  storeDetailsFilteredArray: any = [];

  constructor(
    private router: Router,
    private productStore: Store<ProductState>,
    private personalInfoService: PersonalDetailsService,
    private shoppingCartService: ShoppingCartService,
    private dialogRef: MatDialogRef<AgeChangeInPremiumComponent>,
    public dialog: MatDialog,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) {}

  ngOnInit() {
    this.getStoreDetails();
    this.ageValidationDetails = this.data.payload;
    //console.log('Age Premium Payload : ', this.ageValidationDetails);
    if (
      this.ageValidationDetails &&
      this.ageValidationDetails.ageEligibilityDetails &&
      this.ageValidationDetails.ageEligibilityDetails.length > 0
    ) {
      this.ageValidationDetails.ageEligibilityDetails.map(item => {
        this.totalPrevPremium += parseFloat(item.prevPremium);
        this.totalCurrentPremium += parseFloat(item.currentPremium);
      });
    }
  }

  getStoreDetails() {
    this.subscription = this.personalInfoService
      .getCartData()
      .subscribe(res => {
        if (res !== undefined && res.value && res.value.length > 0) {
          this.storeDetailsArray = res.value;
        }
      });
  }

  updateCartPremium() {
    let planPremium = 0;
    if (this.storeDetailsArray && this.storeDetailsArray.length > 0) {
      this.storeDetailsArray.map(cartItem => {
        const cloneCartItem = Object.assign({}, cartItem);
        const cloneCartPlanItem = Object.assign({}, cartItem.plan);
        if (
          this.ageValidationDetails.agePremiumChangeDetails &&
          this.ageValidationDetails.agePremiumChangeDetails.length > 0
        ) {
          this.ageValidationDetails.agePremiumChangeDetails.map(premiumItem => {
            if (cartItem.productId === premiumItem.productId) {
              let newRiderPremium = 0;
              if (
                cartItem.selectedRiders &&
                cartItem.selectedRiders.length > 0
              ) {
                cloneCartItem['selectedRiders'] = [];
                cartItem.selectedRiders.forEach(cartRiderItem => {
                  const cloneCartSelectedRiderItem = Object.assign(
                    {},
                    cartRiderItem
                  );
                  const cloneCartRiderItem = Object.assign(
                    {},
                    cartRiderItem.rider
                  );
                  if (premiumItem.riders && premiumItem.riders.length > 0) {
                    const premiumRiderItemObj = premiumItem.riders.find(
                      premiumRiderItem =>
                        premiumRiderItem.riderNameCd ===
                        cartRiderItem.rider.title
                    );
                    if (premiumRiderItemObj) {
                      cloneCartRiderItem['price'] =
                        premiumRiderItemObj.monthlyPremium;
                    }
                    cloneCartSelectedRiderItem['rider'] = cloneCartRiderItem;
                    cloneCartItem['selectedRiders'].push(
                      cloneCartSelectedRiderItem
                    );
                  }
                });
                newRiderPremium = premiumItem.riders.reduce(
                  (a, b) => a + b.monthlyPremium,
                  0
                );
              }
              planPremium =
                premiumItem.currentPremium >= newRiderPremium
                  ? premiumItem.currentPremium - newRiderPremium
                  : premiumItem.currentPremium;

              cloneCartPlanItem.price = planPremium.toFixed(2);
              cloneCartItem['plan'] = cloneCartPlanItem;
              cartItem = cloneCartItem;
              //console.log('cartItem : ', cartItem);
            }
          });
        }
        this.storeDetailsFilteredArray.push(cartItem);
      });
    }
  }

  updateCartWithEligibleQuote(quote) {
    const cartSum = this.personalInfoService.fetchUpdatedSum(quote);
    //console.log('cartSum : ', cartSum);
    //console.log('quote : ', quote);
    const cartPayload = {
      key: 'from-list',
      value: quote
    };
    const headerPayload = {
      price: cartSum,
      count: quote.length
    };
    this.productStore.dispatch(UpdateCartOnQuoteSave({ payload: cartPayload }));
    this.shoppingCartService.updateShoppingCartPrice(headerPayload);
  }

  onSubmit() {
    this.dialogRef.close('continue');
    if (this.ageValidationDetails.mode !== 'notEligible') {
      this.updateCartPremium();
      this.updateCartWithEligibleQuote(this.storeDetailsFilteredArray);
    }
  }

  goBackAndEdit() {
    this.dialogRef.close('goback');
  }
}
