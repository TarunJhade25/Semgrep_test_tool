import { Component, OnInit, Inject, OnDestroy } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { Router } from '@angular/router';
import { Store, select } from '@ngrx/store';
import { Subscription } from 'rxjs';
import { AgentSharedService } from '@aflac/agent/shared';
import { PersonalDetailsService } from '../../../services/personal-details.service';

@Component({
  selector: 'aflac-ssn-validation-coverage-change-modal',
  templateUrl: './ssn-validation-coverage-change-modal.component.html',
  styleUrls: ['./ssn-validation-coverage-change-modal.component.scss']
})
export class SsnValidationCoverageChangeModalComponent
  implements OnInit, OnDestroy {
  subscription = new Subscription();
  modalExpanded: boolean;
  payloadData: any;
  cartPremium: any = 0;
  currentPremium: any = 0;
  ssnDetails: any;
  bundleData: any;

  constructor(
    @Inject(MAT_DIALOG_DATA) public data: any,
    private router: Router,
    private store: Store<any>,
    private agentSharedService: AgentSharedService,
    private personalInfoService: PersonalDetailsService,
    private dialogRef: MatDialogRef<SsnValidationCoverageChangeModalComponent>
  ) {}

  ngOnInit() {
    this.payloadData = this.data && this.data.payload;
    //console.log('SSN Coverage change selected profile : ', this.payloadData);
    this.ssnDetails = this.payloadData.ssnData;
    this.getProductPremiumChange();
  }

  getProductPremiumChange() {
    if (this.payloadData) {
      if (this.payloadData.cartData && this.payloadData.cartData.length > 0) {
        let cartRiderPremium = 0,
          cartProductTotalPremium = 0;
        this.payloadData.cartData.map(cartItem => {
          // Sum cart total premium plan+riders
          cartRiderPremium = this.getRiderSum(cartItem);
          cartProductTotalPremium =
            Number(cartRiderPremium) + Number(cartItem.monthlyPremium);
          // Sum cart total premium plan+riders end
          this.cartPremium += cartProductTotalPremium;
        });
      }
      if (
        this.payloadData.eligiblePlans &&
        this.payloadData.eligiblePlans.length > 0
      ) {
        let cartEligRiderPremium = 0,
          cartEligProductTotalPremium = 0;
        this.payloadData.eligiblePlans.map(item => {
          // Sum cart total premium plan+riders
          cartEligRiderPremium = this.getRiderSum(item);
          cartEligProductTotalPremium =
            Number(cartEligRiderPremium) + Number(item.monthlyPremium);
          // Sum cart total premium plan+riders end
          this.currentPremium += cartEligProductTotalPremium;
        });
      }
    }
  }

  getRiderSum(cartItem) {
    let cartRiderPremium = 0;
    if (cartItem.riders && cartItem.riders.length > 0) {
      cartRiderPremium = cartItem.riders.reduce((a, b) => a + b.rider.price, 0);
      //console.log('riderSum : ', cartRiderPremium);
    }
    return cartRiderPremium;
  }

  goToQuote() {
    this.dialogRef.close('continue');
    this.updateCartWithEligibleQuote(this.payloadData.updatedCartItems);
    this.agentSharedService.updateSearchQuote('ssn', this.ssnDetails);
    this.agentSharedService.updateExistingCustomerInfo('ssn', this.ssnDetails);
    //this.agentSharedService.updateRetrieveQuote(); // Need to check
    this.router.navigateByUrl('quotes');
  }

  updateCartWithEligibleQuote(quote) {
    const updatedCartSum = this.personalInfoService.fetchUpdatedSum(quote);
    const cartPayload = {
      key: 'from-list',
      value: quote
    };
    const headerPayload = {
      price: updatedCartSum,
      count: quote.length
    };
    this.agentSharedService.updateCartWithEligibleQuote(
      cartPayload,
      headerPayload
    );
  }

  ngOnDestroy() {
    if (this.subscription !== undefined) this.subscription.unsubscribe();
  }
}
