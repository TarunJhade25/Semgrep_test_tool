import { Component, OnInit } from '@angular/core';
import { BuyFlowService } from '../../services/buy-flow.service';
import { Router } from '@angular/router';

@Component({
  selector: 'aflac-checkout',
  templateUrl: './checkout.component.html',
  styleUrls: ['./checkout.component.scss']
})
export class CheckoutComponent implements OnInit {
  route = '/checkout';
  signatureTemp: any;
  hideMethod: any;
  constructor(public buyFlowService: BuyFlowService, private router: Router) {}

  ngOnInit() {
    this.route = this.router.url;
    this.buyFlowService.enableStepperByRoute(this.route);
  }
  signatureTypeReceiver(e) {
    this.signatureTemp = e;
    this.hideMethod = true;
  }
}
