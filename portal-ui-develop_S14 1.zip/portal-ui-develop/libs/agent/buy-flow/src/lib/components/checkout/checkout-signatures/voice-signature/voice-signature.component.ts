import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material';
import { CheckoutEmailSuccessComponent } from '../../checkout-email-success/checkout-email-success.component';
import { Store } from '@ngrx/store';
import { SaveYourQuoteState, getVoiceSignId } from '@aflac/agent/shared'; //stores
@Component({
  selector: 'aflac-voice-signature',
  templateUrl: './voice-signature.component.html',
  styleUrls: ['./voice-signature.component.scss']
})
export class VoiceSignatureComponent implements OnInit {
  showTextBox = false;
  terms: any = [];
  purchaseClicked: boolean;
  signatureDone: boolean;
  capturedVoiceSign: string;
  sum = 0;
  emailClicked: boolean;
  isFilled: any;
  constructor(
    public checkoutEmailSuccessDialog: MatDialog,
    private store: Store<SaveYourQuoteState>
  ) {}

  ngOnInit() {
    this.terms = [
      {
        checked: false,
        desc: `By checking this box, I hereby agree to the above Applicant’s Statements
        and Agreements.`,
        rider1: ``,
        rider2: ``,
        rider3: ``
      },
      {
        checked: false,
        desc: `By checking this box I hereby agree that I have reviewed the benefits
        and premium of the insurance policy [and/or rider(s)] that I am applying for and agree to the
        following.`,
        rider1: `I understand the impact that the premium for this coverage has on my
        paycheck/income;`,
        rider2: `I understand the impact that the total Tier One premium for this coverage
        and any other Tier One coverage has on my paycheck/income and believe it
        to be appropriate for me; and`,
        rider3: `I have considered all of my existing health insurance coverage, with
        Tier one and/or with other carriers, and believe this additional
        coverage is appropriate for my insurance needs. I further understand
        that I can contact Tier One and/or other insurance carriers to assist in
        evaluating the suitability of insurance coverage for me.`
      }
    ];
  }
  onCheckBoxChange(term: any, index) {
    if (term.checked) {
      this.sum = this.sum + 1;
    } else {
      this.sum = this.sum - 1;
    }
  }
  OnBlurCaptureInput(capturedInput: string) {
    this.capturedVoiceSign = capturedInput;
    if (capturedInput) {
      this.signatureDone = true;
    } else {
      this.signatureDone = false;
    }
  }
  showEmailSuccessPopup() {
    if (!this.emailClicked) {
      this.emailClicked = !this.emailClicked;
    }
    const dialogRef = this.checkoutEmailSuccessDialog.open(
      CheckoutEmailSuccessComponent,
      {
        width: '315px',
        panelClass: 'agent-checkout-email-success-modal',
        disableClose: true,
        backdropClass: 'agent-checkout-email-success-backdrop'
      }
    );
    setTimeout(function() {
      dialogRef.close();
    }, 3000);
  }
  showIp() {
    this.showTextBox = true;
  }
  openSuccessPage() {
    this.purchaseClicked = !this.purchaseClicked;
    this.store.dispatch(getVoiceSignId({ payload: this.capturedVoiceSign })); // set voice Sign id to store
  }
  /*** Only AlphaNumeric ***/
  allowOnlyAlphaNum(event) {
    const inp = String.fromCharCode(event.keyCode);
    if (/[a-zA-Z0-9]/.test(inp)) {
      return true;
    } else {
      event.preventDefault();
      return false;
    }
  }
}
