import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'aflac-checkout-signatures',
  templateUrl: './checkout-signatures.component.html',
  styleUrls: ['./checkout-signatures.component.scss']
})
export class CheckoutSignaturesComponent implements OnInit {
  @Input() sigType: any;
  constructor() {}

  ngOnInit() {}
}
