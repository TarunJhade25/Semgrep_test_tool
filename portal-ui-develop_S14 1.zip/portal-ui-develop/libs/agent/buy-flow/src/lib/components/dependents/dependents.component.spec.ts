import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { RouterModule } from '@angular/router';
import { StoreModule, MemoizedSelector, Store } from '@ngrx/store';
import { TranslateModule } from '@ngx-translate/core';
import { RouterTestingModule } from '@angular/router/testing';
import { of, BehaviorSubject, Observable } from 'rxjs';
import { MatDialogModule } from '@angular/material/dialog';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import {
  saveYourQuoteReducer,
  SaveYourQuoteState,
  AgentSharedService
} from '@aflac/agent/shared';
import { MockStore, provideMockStore } from '@ngrx/store/testing';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import * as fromMockSaveYourQuoteSelector from '@aflac/agent/shared';
import { CmsService } from '@aflac/shared/cms';
import { BuyFlowService } from '../../services/buy-flow.service';
import { DependentService } from './services/dependent.service';
import { DependentsComponent } from './dependents.component';

describe('DependentsComponent', () => {
  let component: DependentsComponent;
  let fixture: ComponentFixture<DependentsComponent>;
  let mockStore: MockStore<SaveYourQuoteState>;
  let mockProductsSelector: MemoizedSelector<any, any>;
  let mockSaveQuoteSelector: MemoizedSelector<any, any>;
  let mockQuoteDataSelector: MemoizedSelector<any, any>;

  const quoteProductData = {
    age: '23',
    consentStatus: 'GRANTED',
    customerNumber: '',
    email: 'ddfs@dff.com',
    firstName: 'sdfs',
    lastName: 'sds',
    quotes: [
      {
        caseId: 'test',
        coverageTypeCd: 'ind_fml',
        packageCd: 'plan07',
        productCd: 'PREC-IC',
        productId: 'PREC-IC',
        productName: 'Cancer Insurance',
        riders: [],
        riskStateCd: 'AL',
        series: 'test',
        sfrId: 'test',
        totalPremium: '16.93'
      },
      {
        caseId: 'test',
        coverageTypeCd: 'ind_sps',
        packageCd: 'low',
        productCd: 'PREC-IA',
        productId: 'PREC-IA',
        productName: 'Accident Insurance',
        riders: [],
        riskStateCd: 'AL',
        series: 'test',
        sfrId: 'test',
        totalPremium: '19.93'
      }
    ]
  };

  const quoteData = {
    customerDetails: [],
    quoteDetails: [
      {
        productCd: 'PREC-IC',
        productId: 'PREC-IC',
        quoteNumber: 193
      },
      {
        productCd: 'PREC-ICI',
        productId: 'PREC-ICI',
        quoteNumber: 198
      }
    ]
  };

  const selectedQuoteData = [
    {
      caseId: 'test',
      coverageTypeCd: 'ind_fml',
      packageCd: 'plan07',
      productCd: 'PREC-IC',
      productId: 'PREC-IC',
      productName: 'Cancer Insurance',
      riders: [],
      riskStateCd: 'AL',
      series: 'test',
      sfrId: 'test',
      totalPremium: '16.93',
      quoteNumber: 193
    },
    {
      caseId: 'test',
      coverageTypeCd: 'ind_sps',
      packageCd: 'low',
      productCd: 'PREC-IA',
      productId: 'PREC-IA',
      productName: 'Accident Insurance',
      riders: [],
      riskStateCd: 'AL',
      series: 'test',
      sfrId: 'test',
      totalPremium: '19.93',
      quoteNumber: 195
    },
    {
      caseId: 'test',
      coverageTypeCd: 'ind_sps',
      packageCd: 'low',
      productId: 'PREC-ICI',
      productName: 'Critical Illness Insurance',
      riders: [],
      riskStateCd: 'AL',
      series: 'test',
      sfrId: 'test',
      totalPremium: '25.93',
      quoteNumber: 198
    }
  ];

  const buyFlowElements = [
    {
      completed: true,
      data: {},
      disabled: false,
      header: 'Quote',
      inactive: false,
      link: '/review',
      required: true,
      title: 'Quote'
    },
    {
      completed: false,
      data: {},
      disabled: false,
      header: 'Dependents Information',
      inactive: false,
      link: '/dependents',
      required: true,
      title: 'Dependents Information'
    },
    {
      completed: false,
      data: {},
      disabled: false,
      header: 'Eligibility',
      inactive: false,
      link: '/eligibility',
      required: true,
      title: 'Eligibility'
    }
  ];
  const coverageTypeArray = ['ind_fml', 'ind_sps', 'ind_chd'];

  const coverageTypes = [
    {
      code: 'ind',
      default_value: 'You'
    },
    {
      code: 'ind_sps',
      default_value: 'You & Your Spouse'
    }
  ];

  const dependentDataArray = {
    'PREC-IC': {
      spouse: {
        firstName: 'Ryan',
        lastName: 'John',
        dateOfBirth: '01/01/1990',
        gender: 'M',
        editMode: false
      },
      children: [
        {
          firstName: 'Joan',
          lastName: 'Keit',
          dateOfBirth: '01/01/1990',
          gender: '',
          editMode: false
        }
      ]
    },
    'PREC-IA': {
      spouse: {
        firstName: 'Ryan',
        lastName: 'John',
        dateOfBirth: '01/01/1990',
        gender: 'M',
        editMode: false
      },
      children: [
        {
          firstName: 'Joan',
          lastName: 'Keit',
          dateOfBirth: '01/01/1990',
          gender: '',
          editMode: false
        }
      ]
    }
  };

  const cartData = {
    key: 'from-list',
    value: [
      {
        productId: 'PREC-IC',
        productName: 'Accident',
        plan: {
          id: 123,
          price: '100',
          description: 'These are the benefits',
          name: 'Lorem ipsum',
          states: ['AL', 'CT'],
          title: 'Standard Plan',
          benefits: [
            {
              id: 333,
              name: 'test',
              price: 123
            }
          ]
        },
        coverage: 'ind',
        selected: true,
        availableInCart: true,
        selectedRiders: [
          {
            rider: { title: 'title1', price: '100' },
            selected: true,
            availableInCart: true,
            plan: { id: 'id1' }
          },
          {
            rider: { title: 'title2', price: '200' },
            selected: true,
            availableInCart: true,
            plan: { id: 'id1' }
          }
        ]
      }
    ]
  };

  const bundleData = {
    data: {
      quotes: [
        {
          bundleId: '000',
          policyNumber: 'a1b2',
          effectiveDate: '01/02/2019',
          expirationDate: '01/06/2019',
          transactionEffectiveDate: '03/02/2019',
          policyStatusCd: 'dummy',
          productCode: 'PREC-IC',
          lobCd: 'dummy',
          totalPremium: 1234,
          currencyCode: 'ind',
          producerCd: 'dummy',
          subProducerCd: 'd',
          quoteNumber: '111',
          customerNumber: '111'
        }
      ]
    }
  };

  const personalData = {
    firstName: 'John',
    lastName: 'Doe',
    gender: 'M',
    ssn: '123456789',
    middleInitials: 'A',
    suffix: 'Jr.',
    dateOfBirth: '1985-07-13',
    aflacUserGuid: 'adskjk2764sdsd-sfsf',
    addresses: [
      {
        addressLine1: '11',
        addressLine2: 'a',
        city: 'Maa',
        stateProvCd: 'AL',
        zipCode: 12345
      }
    ],
    emails: [
      {
        email: 'a@gmail.com'
      }
    ],
    phones: [
      {
        phone: '1234567892'
      }
    ],
    customerNumber: '1212',
    requestHeader: {
      jscPayload: 'test',
      hdimayload: 'test'
    },
    availableProducts: {}
  };

  const depRelationData = {
    status: true,
    data: [
      {
        customerNumber: '800008',
        relationshipRole: 'CHILD',
        firstName: 'Aldo',
        lastName: 'dsouza',
        middleName: '',
        suffix: '',
        gender: 'Male',
        dateOfBirth: '1984-07-13',
        taxId: '123456789',
        serviceCommunicationsInd: true,
        otherCommunicationsInd: true,
        aflacUserGuid: 'b480d9fc-8558-4507-92cb-772325011677',
        addresses: [
          {
            id: 0,
            addressLine1: '714 N. Yukon St.',
            addressLine2: '15 flr',
            addressLine3: ' ',
            city: 'Ridgecrest',
            county: 'Ridgecrest',
            zipCode: '93555',
            stateProvCd: 'CA',
            countryCd: 'US',
            addressTypeCd: 'mailing'
          }
        ],
        phones: [{ id: 0, phone: '1234567890', phoneTypeCd: 'WORK' }],
        emails: [{ id: 0, email: 'john@email.com' }],
        agencies: [{ agencyCode: 'QAG' }]
      },
      {
        customerNumber: '800009',
        relationshipRole: 'SPOUSE',
        firstName: 'Mary',
        lastName: 'Jane',
        middleName: '',
        suffix: '',
        gender: 'Male',
        dateOfBirth: '1984-07-13',
        taxId: '123456789',
        serviceCommunicationsInd: true,
        otherCommunicationsInd: true,
        aflacUserGuid: 'b480d9fc-8558-4507-92cb-772325011677',
        addresses: [
          {
            id: 0,
            addressLine1: '714 N. Yukon St.',
            addressLine2: '15 flr',
            addressLine3: ' ',
            city: 'Ridgecrest',
            county: 'Ridgecrest',
            zipCode: '93555',
            stateProvCd: 'CA',
            countryCd: 'US',
            addressTypeCd: 'mailing'
          }
        ],
        phones: [{ id: 0, phone: '1234567890', phoneTypeCd: 'WORK' }],
        emails: [{ id: 0, email: 'john@email.com' }],
        agencies: [{ agencyCode: 'QAG' }]
      }
    ],
    message: 'Success'
  };

  const ageValidationResponse = {
    status: true,
    data: [
      {
        PRECIA: {
          data: {
            planTypeCd: 'High',
            monthlyPremium: 69.24,
            monthPremium: 62.29,
            coverageTierCd: 'EC',
            rds: [
              {
                riderNameCd: 'Additional Accidental-Death Benefit Rider',
                isIncludedInd: true,
                monthlyPremium: 6.95
              }
            ],
            riders: [
              {
                riderNameCd: 'Additional Accidental-Death Benefit Rider',
                isIncludedInd: true,
                monthlyPremium: 6.95
              }
            ],
            insured: [
              {
                minAge: 20,
                maxAge: 65,
                relationshipToPrimaryInsuredCd: 'SELF',
                disabilityInd: false,
                newInd: true,
                primaryInsuredInd: true
              },
              {
                minAge: 20,
                maxAge: 65,
                relationshipToPrimaryInsuredCd: '1',
                disabilityInd: false,
                newInd: false,
                primaryInsuredInd: false
              },
              {
                minAge: 20,
                maxAge: 65,
                relationshipToPrimaryInsuredCd: '2',
                disabilityInd: false,
                newInd: false,
                primaryInsuredInd: false
              }
            ],
            productCd: 'PREC-IA',
            notEligibleInsureds: [
              {
                referenceNumber: '1234',
                customerNumber: '50002',
                relationshipToPrimaryInsuredCd: '1',
                dateOfBirth: '2006-04-21',
                disabilityInd: false,
                newInd: false,
                primaryInsuredInd: false
              }
            ]
          },
          message: 'Success'
        }
      }
    ]
  };

  const modalPayload = {
    totalMonthycost: {
      old: 143.5,
      new: 330.54
    },
    productDetails: [
      {
        productId: 'PREC-IC',
        productName: 'Cancer Insurance',
        coverage: {
          old: 'ind_sps',
          new: 'ind'
        },
        nonEligibleDependents: [
          {
            name: 'cv c',
            relation: '1',
            dob: '09/09/1930'
          }
        ],
        monthlyPremium: {
          old: 35.19,
          new: 224.68
        }
      },
      {
        productId: 'PREC-ICI',
        productName: 'Critical Illness Insurance',
        coverage: {
          old: 'ind_sps',
          new: 'ind'
        },
        nonEligibleDependents: [
          {
            name: 'cv c',
            relation: '1',
            dob: '09/09/1930'
          }
        ],
        monthlyPremium: {
          old: 80.1,
          new: 43.57
        }
      },
      {
        productId: 'PREC-IA',
        productName: 'Accident Insurance',
        coverage: {
          old: 'ind',
          new: 'ind'
        },
        nonEligibleDependents: [],
        monthlyPremium: {
          old: 28.21,
          new: 62.29
        }
      }
    ],
    editLink: '',
    continuelink: ''
  };

  const urlRoute = '/dependents';
  const coverage = 'ind-fml';

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        TranslateModule.forRoot(),
        StoreModule.forRoot(saveYourQuoteReducer),
        RouterModule,
        RouterTestingModule,
        ReactiveFormsModule,
        FormsModule,
        MatDialogModule
      ],
      declarations: [DependentsComponent],
      providers: [
        provideMockStore({}),
        { provide: CmsService, useClass: MockCmsService },
        { provide: BuyFlowService, useClass: MockBuyflowService },
        { provide: DependentService, useClass: MockDependentService },
        { provide: AgentSharedService, useClass: MockAgentSharedService }
      ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DependentsComponent);
    mockStore = TestBed.get(Store);

    mockQuoteDataSelector = mockStore.overrideSelector(
      fromMockSaveYourQuoteSelector.selectUserDetailsFromAgent,
      quoteData
    );
    mockProductsSelector = mockStore.overrideSelector(
      fromMockSaveYourQuoteSelector.getSavedUserDetails,
      quoteProductData
    );

    mockSaveQuoteSelector = mockStore.overrideSelector(
      fromMockSaveYourQuoteSelector.buyFlowElementsSelector,
      buyFlowElements
    );
    mockStore.overrideSelector(
      fromMockSaveYourQuoteSelector.quoteDataUpdateStatus,
      true
    );

    component = fixture.componentInstance;
    component.cartData = cartData.value;
    component.bundleData = bundleData.data.quotes;
    component.dependentRelationshipData = depRelationData.data;
    component.selectedQuoteData = selectedQuoteData;
    component.dependentDataArray = dependentDataArray;
    component.coverageTypes = coverageTypes;
    component.productCounter = 2;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should subscribe to quote data by calling manipulateQuoteData() on component init', () => {
    spyOn(component, 'manipulateQuoteData').and.callThrough();
    component.manipulateQuoteData();
    expect(component.manipulateQuoteData).toBeDefined();
  });

  it('should manipulate quote data by calling manipulateSelectedProducts() ', () => {
    spyOn(component, 'manipulateSelectedProducts').and.callThrough();
    component.manipulateSelectedProducts(
      component.bundleData,
      component.cartData
    );
    expect(component.manipulateSelectedProducts).toBeDefined();
  });

  it('should call manipulateCustomerType', () => {
    component.manipulateCustomerType(true);
    expect(component.manipulateCustomerType).toBeDefined();
  });

  it('should call manipulateExistingDependentData', () => {
    component.manipulateExistingDependentData();
    expect(component.manipulateExistingDependentData).toBeDefined();
  });

  it('should call prepopulateDependentData', () => {
    component.prepopulateDependentData();
    expect(component.prepopulateDependentData).toBeDefined();
  });

  it('should call addDependentDataToStore', () => {
    component.depRelationshipTypes = ['spouse', 'child'];
    component.dependentRelationshipData = component.addDependentDataToStore(
      true,
      'PREC-IA'
    );
    expect(component.addDependentDataToStore).toBeDefined();
  });

  it('should subscribe to dependent data by calling getDependent() funtion', () => {
    spyOn(component, 'getDependent').and.callThrough();
    component.getDependent();
    expect(Object.keys(dependentDataArray)).toContain('PREC-IC');
    expect(component as any).toBeDefined();
  });

  it('should call _setCoverageTypeTitle', () => {
    component._setCoverageTypeTitle(coverage);
    expect(component._setCoverageTypeTitle).toBeDefined();
  });

  it('should call _sortSelectedQuoteData', () => {
    component._sortSelectedQuoteData();
    expect(component._sortSelectedQuoteData).toBeDefined();
  });

  it('should call nextProduct', () => {
    spyOn(component, '_mapDependentDataToOtherProducts').and.returnValue(true);
    spyOn(component, '_manipulateFlags').and.returnValue(true);
    component.nextProduct();
    expect(component.nextProduct).toBeDefined();
  });

  it('should call _manipulateFlags', () => {
    component._manipulateFlags();
    expect(component._manipulateFlags).toBeDefined();
  });

  it('should call _mapDependentDataToOtherProducts', () => {
    component._mapDependentDataToOtherProducts();
    expect(component._mapDependentDataToOtherProducts).toBeDefined();
  });

  it('should call showContinueButton', () => {
    component.showContinueButton();
    expect(component.showContinueButton).toBeDefined();
  });

  it('should call showNextProductButton', () => {
    component.showNextProductButton();
    expect(component.showNextProductButton).toBeDefined();
  });

  it('should call updateBuyFlowElements', () => {
    component.updateBuyFlowElements();
    expect(component.updateBuyFlowElements).toBeDefined();
  });

  it('should call updateFlag', () => {
    const dataObj = { mode: 'edit' };
    component.updateFlag(dataObj);
    expect(component.updateFlag).toBeDefined();
  });

  it('should call saveDependent', () => {
    component.saveDependent();
    expect(component.saveDependent).toBeDefined();
  });

  it('should call addChildDependent', () => {
    component.addChildDependent(0, 'PREC-IA');
    expect(component.addChildDependent).toBeDefined();
  });

  it('should update DependentDetails Based On Eligibility', () => {
    spyOn(component, 'updateBuyFlowElements').and.returnValue(true);
    component.ProductsInCart = cartData.value;
    component.updateDependentDetailsBasedOnEligibility(modalPayload);
    expect(component.updateBuyFlowElements).toHaveBeenCalled();
  });

  it('should update dependent store on navigation', () => {
    spyOn(component, 'updateBuyFlowElements').and.returnValue(true);
    component.updateDependentsDetailStore();
    expect(component.updateBuyFlowElements).toHaveBeenCalled();
  });

  it('should convert DOB to required format', () => {
    const dob1 = component.convertDOB('09/09/1990', 'request-payload');
    const dob2 = component.convertDOB('1990-09-09', 'modal-payload');
    expect(dob1).toEqual('1990-09-09');
    expect(dob2).toEqual('09/09/1990');
  });
  class MockCmsService {
    getKey(key: string | Array<string>, interpolateParams?: Object): any {
      const data = { coverageTypes: coverageTypes };
      return of(data);
    }
  }

  class MockBuyflowService {
    enableStepperByRoute(route) {
      return of(true);
    }
    completeCurrentStepAndMoveToNext(route) {
      return of(true);
    }
    getCartData(): Observable<any> {
      return of(cartData);
    }
    getBundleDataFromBundleId(): Observable<any> {
      return of(bundleData);
    }
    getPersonalDataFromCustomerNumber(): Observable<any> {
      return of(personalData);
    }
    getUserDataFomSaveQuoteResponse(): Observable<any> {
      return of(quoteProductData);
    }
    getDependentAgeValidation(): Observable<any> {
      return of(ageValidationResponse);
    }
    checkDependentEdited(): Observable<any> {
      return of(true);
    }
    addItemsToCart(data) {
      return data;
    }
  }

  class MockDependentService {
    public isFormValid = new BehaviorSubject(false);
    public disableNextProduct = new BehaviorSubject(false);
    getDependentData(route): Observable<any> {
      return of(dependentDataArray);
    }
    getDependentRelationshipData(): Observable<any> {
      return of(depRelationData);
    }
    setDependentRelationshipData() {
      return of(true);
    }
    addUserDependentData() {
      return of(true);
    }
    createDependentArrayWithQuoteNumber() {
      return true;
    }
  }

  class MockAgentSharedService {
    createUpdateQuoteReqParams() {
      return true;
    }
  }
});
