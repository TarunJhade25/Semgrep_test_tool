import { Component, OnInit, OnDestroy, ChangeDetectorRef } from '@angular/core';
import { BuyFlowService } from '../../services/buy-flow.service';
import { Router } from '@angular/router';
import { Store, select } from '@ngrx/store';
import { Subscription } from 'rxjs';
import { first } from 'rxjs/operators';
import { CmsService } from '@aflac/shared/cms';
import { selectedPlans, ProductState } from '@aflac/agent/shared';
import {
  dependentDataByRouteSelector,
  SaveYourQuoteState,
  getOrderReviewInfo,
  orderReviewInfoSelector,
  validatePrimaryInsuredAge,
  primaryInsuredAgeValidationDetailsSelector,
  resePrimaryInsuredAgeData,
  getIneligibleDependentDetails,
  getIneligibleDependentDetailsSuccess,
  ShoppingCartService,
  updateBuyFlowElements,
  buyFlowElementsSelector,
  selectUserDetailsFromAgent,
  updateQuote,
  AgentSharedService
} from '@aflac/agent/shared';
import { AgeChangeInPremiumComponent } from '../personal-details/personal-details-modal/age-validation-modal/age-change-in-premium/age-change-in-premium.component';
import { AgeNotEligibleForProductComponent } from '../personal-details/personal-details-modal/age-validation-modal/age-not-eligible-for-product/age-not-eligible-for-product.component';
import { MatDialog } from '@angular/material/dialog';
import { DependentIneligibilityModalComponent } from '../dependent-ineligibility-modal/dependent-ineligibility-modal.component';

@Component({
  selector: 'aflac-order-review',
  templateUrl: './order-review.component.html',
  styleUrls: ['./order-review.component.scss']
})
export class OrderReviewComponent implements OnInit, OnDestroy {
  route = '/order-review';
  cartSubscription: Subscription;
  dependentsSubsciption: Subscription;
  personalInfoSubsciption: Subscription;
  orderedProducts;
  dependentsDetails;
  orderReviewData = [];
  totalMonthlyPayment = 0;
  diagnosisBenefitAmount = '$10K';
  primaryInsuredName;
  effectiveDate;
  coverageArray = [];
  orderReviewInfoSubscription: Subscription;
  freeLookPeriod;
  cartDetailsModified: any = [];
  primaryInsuredDOB;
  agePopupSubscription = new Subscription();
  customerNumber;
  effDateFormatted;
  ageValidationSubscription = new Subscription();
  modalDisplayed = false;
  coverageTypes: any = [];
  coverageTitle: string;
  bundleId;
  bundleDetails;
  buyFlowElementSubscription = new Subscription();
  updateCartPayload;
  bundleIdSubscription: Subscription;
  deletedListFiltered = [];
  constructor(
    public buyFlowService: BuyFlowService,
    private router: Router,
    private productStore: Store<ProductState>,
    private savedQuoteStore: Store<SaveYourQuoteState>,
    public dialog: MatDialog,
    private shoppingCartService: ShoppingCartService,
    private cmsService: CmsService,
    private cdr: ChangeDetectorRef,
    private agentSharedService: AgentSharedService
  ) {}

  ngOnInit() {
    this.route = this.router.url;
    this.buyFlowService.enableStepperByRoute(this.route);
    this.fetchBundleId();
    this.getSelectedPlansFromCart();
    this.getPersonalDetails();
    // this.getFreeLookPeriod();
    this.getOrderReviewBundleData();
    this.initAgeValidationResponseOfDependents();
    this.getDependentAgeValidationResponse();
  }
  getBenefitAmount(benefitAmount) {
    return '$' + benefitAmount / 1000 + 'K';
  }
  fetchBundleId() {
    this.bundleIdSubscription = this.savedQuoteStore
      .pipe(select(selectUserDetailsFromAgent))
      .subscribe(qouteData => {
        if (
          qouteData &&
          qouteData.quoteDetails &&
          qouteData.quoteDetails.length > 0
        ) {
          this.bundleId = qouteData.quoteDetails[0].bundleId;
        } else {
          this.bundleId = sessionStorage.getItem('state-agent-bundleId');
        }
      });
  }
  initAgeValidationResponseOfDependents() {
    this.savedQuoteStore.dispatch(
      getIneligibleDependentDetailsSuccess({ payload: undefined })
    );
  }
  getOrderReviewBundleData() {
    //this.fetchBundleId();
    if (this.bundleId) {
      this.savedQuoteStore.dispatch(
        getOrderReviewInfo({
          bundleId: this.bundleId
        })
      );
    }
    this.orderReviewInfoSubscription = this.savedQuoteStore
      .select(orderReviewInfoSelector)
      .subscribe(res => {
        if (res && res.quotes && res.quotes.length) {
          this.bundleDetails = res;
          this.setBundleDetailsToSession(this.bundleDetails);
        } else {
          this.bundleDetails = JSON.parse(
            sessionStorage.getItem('state-bundle-details-order-review-agent')
          );
        }
        this.freeLookPeriod =
          this.bundleDetails &&
          this.bundleDetails.quotes.length &&
          this.bundleDetails.quotes[0].freeLookPeriod
            ? this.bundleDetails.quotes[0].freeLookPeriod
            : '';
        this.customerNumber =
          this.bundleDetails &&
          this.bundleDetails.quotes.length &&
          this.bundleDetails.quotes[0].customerNumber
            ? this.bundleDetails.quotes[0].customerNumber
            : '';
        //this.getPrimaryInsuredDOB(res.quotes[0].insureds); need to take dob like this for real integration
      });
  }
  setBundleDetailsToSession(bundleDetails) {
    sessionStorage.setItem(
      'state-bundle-details-order-review-agent',
      JSON.stringify(bundleDetails)
    );
  }
  getSelectedPlansFromCart() {
    this.cartSubscription = this.productStore
      .select(selectedPlans)
      .subscribe(res => {
        if (res !== undefined && res.value) {
          this.orderedProducts = res.value.map(sQuoteData => {
            this.coverageArray.push(sQuoteData.coverage);
            return {
              ...sQuoteData,
              totalPremium: this.buyFlowService.calculateMonthlyPayment(
                sQuoteData.plan.price,
                sQuoteData.selectedRiders
              )
            };
          });
          // Sort products based on heavy coverage type
          this._sortSelectedQuoteData();
          this.setSelectedPlansToSession(this.orderedProducts);
        } else {
          this.orderedProducts = JSON.parse(
            sessionStorage.getItem('state-selectedPlans-agent')
          );
        }
        this.getDependentsDetails();
        this.getOrderReviewData();
        this.cdr.detectChanges();
      });
  }

  _sortSelectedQuoteData() {
    const coverageEquals = this.coverageArray.every((v, i, a) => v === a[0]);
    const ordering = {};
    const sortOrder = ['ind_fml', 'ind_sps', 'ind_chd', 'ind'];
    for (let i = 0; i < sortOrder.length; i++) ordering[sortOrder[i]] = i;
    this.orderedProducts.sort((a, b) => {
      if (coverageEquals) {
        return parseFloat(a.totalPremium) - parseFloat(b.totalPremium);
      } else {
        return (
          ordering[a.coverage] - ordering[b.coverage] ||
          parseFloat(a.totalPremium) - parseFloat(b.totalPremium)
        );
      }
    });
  }

  setSelectedPlansToSession(selPlans) {
    sessionStorage.setItem(
      'state-selectedPlans-agent',
      JSON.stringify(selPlans)
    );
  }

  getDependentsDetails() {
    this.dependentsSubsciption = this.savedQuoteStore
      .pipe(select(dependentDataByRouteSelector, '/dependents'))
      .subscribe(dependententsObj => {
        if (dependententsObj) {
          this.dependentsDetails = dependententsObj;
        }
      });
  }
  getPersonalDetails() {
    this.personalInfoSubsciption = this.savedQuoteStore
      .pipe(select(dependentDataByRouteSelector, '/my-details'))
      .subscribe(personalInfo => {
        if (
          personalInfo &&
          personalInfo.firstName &&
          personalInfo.lastName &&
          personalInfo.dateOfBirth
        ) {
          this.primaryInsuredName =
            personalInfo.firstName + ' ' + personalInfo.lastName;
          this.primaryInsuredDOB = personalInfo.dateOfBirth;
        }
      });
  }
  getOrderReviewData() {
    this.totalMonthlyPayment = 0;
    this.orderReviewData = [];
    this.orderedProducts.map(item => {
      const detailsObject = {
        productName: item.productName,
        productId: item.productId,
        planName: item.plan.title,
        price: item.plan.price,
        selectedRiders: item.selectedRiders
      };
      if (item.benefitAmount) {
        detailsObject['benefitAmount'] = item.benefitAmount;
      }
      const selectedProduct = detailsObject.productId;
      if (
        this.dependentsDetails !== undefined &&
        this.dependentsDetails !== null
      ) {
        const dependents = this.dependentsDetails[selectedProduct];
        detailsObject['dependents'] = dependents;
      }
      const monthlyPayment = this.buyFlowService.calculateMonthlyPayment(
        detailsObject.price,
        detailsObject.selectedRiders
      );
      detailsObject['monthlyPayment'] = monthlyPayment;
      let totalPayment = 0;
      totalPayment =
        this.totalMonthlyPayment +
        this.buyFlowService.getNumeric(monthlyPayment);
      this.totalMonthlyPayment = this.buyFlowService.getNumeric(
        totalPayment.toFixed(2)
      );
      this.orderReviewData.push(detailsObject);
      if (this.dependentsSubsciption) {
        this.dependentsSubsciption.unsubscribe();
      }
    });
  }
  _to2digit(n: number) {
    return ('00' + n).slice(-2);
  }
  /* dependent age validation start */
  updateBuyFlowElements() {
    this.buyFlowElementSubscription = this.savedQuoteStore
      .pipe(
        select(buyFlowElementsSelector),
        first()
      )
      .subscribe(data => {
        const buySteps = JSON.parse(JSON.stringify(data));
        //updating dependents details alone
        buySteps[1].data = this.dependentsDetails;
        this.savedQuoteStore.dispatch(
          updateBuyFlowElements({ payload: buySteps })
        );
      });
  }

  getMonthlyPremiumFromCart(element) {
    let sum = 0;
    sum = sum + Number(element.plan.price);
    if (element.selectedRiders && element.selectedRiders.length) {
      element.selectedRiders.forEach(item => {
        sum = sum + item.rider.price;
      });
    }
    return Number(sum).toFixed(2);
  }

  nonEligibleDependentsOfSelectedProduct(info, productId) {
    const selectedProduct = this.dependentsDetails[productId];
    const _nonEligibleDependents = [];
    if (info && info.length) {
      info.forEach(element => {
        if (element.relationshipToPrimaryInsuredCd === '1') {
          const _data = {
            name:
              selectedProduct['spouse'].firstName +
              ' ' +
              selectedProduct['spouse'].lastName,
            relation: element.relationshipToPrimaryInsuredCd,
            dob: this.convertDOB(
              selectedProduct['spouse'].dateOfBirth,
              'modal-payload'
            ),
            oid: selectedProduct['spouse'].oid
          };
          _nonEligibleDependents.push(_data);
        } else if (element.relationshipToPrimaryInsuredCd === '2') {
          selectedProduct['children'].forEach(childInfo => {
            if (childInfo.oid === element.referenceNumber) {
              const _data = {
                name: childInfo.firstName + ' ' + childInfo.lastName,
                relation: element.relationshipToPrimaryInsuredCd,
                dob: this.convertDOB(childInfo.dateOfBirth, 'modal-payload'),
                oid: childInfo.oid
              };
              _nonEligibleDependents.push(_data);
            }
          });
        }
      });
      return _nonEligibleDependents;
    } else return [];
  }

  _setCoverageTypeTitle(coverage) {
    this.cmsService.getKey('agent_portal').subscribe(agentCMSData => {
      this.coverageTypes = agentCMSData.coverage_types;
      if (this.coverageTypes && this.coverageTypes.length > 0) {
        this.coverageTitle = this.coverageTypes.filter(
          data => data.code === coverage
        )[0].default_value;
      }
    });
    return this.coverageTitle;
  }

  eliminateRiderPriceFromPremium(price, rider) {
    let updatedPrice: number = price;
    let ridersum = 0;
    rider.forEach(item => {
      ridersum = ridersum + item.rider.price;
    });
    updatedPrice = updatedPrice - ridersum;
    return Number(updatedPrice).toFixed(2);
  }
  /* Update Cart and dependentArray details based on eligibility */
  updateDependentDetailsBasedOnEligibility(data) {
    const productDetails = data.productDetails;
    const _dependentDataArray = Object.assign({}, this.dependentsDetails);
    productDetails.forEach(element => {
      if (
        element.nonEligibleDependents &&
        element.nonEligibleDependents.length
      ) {
        const cloneCartProduct = Object.assign(
          {},
          this.orderedProducts.filter(e => e.productId === element.productId)[0]
        );
        const clonePlan = Object.assign({}, cloneCartProduct.plan);
        cloneCartProduct.coverage = element.coverage.new;
        const updatedPlanPrice =
          cloneCartProduct &&
          cloneCartProduct.selectedRiders &&
          cloneCartProduct.selectedRiders.length
            ? this.eliminateRiderPriceFromPremium(
                element.monthlyPremium.new,
                cloneCartProduct.selectedRiders
              )
            : element.monthlyPremium.new;
        clonePlan.price = updatedPlanPrice;
        cloneCartProduct.plan = clonePlan;
        const dataToDispatch = { key: 'from-list', value: cloneCartProduct };
        this.buyFlowService.addItemsToCart(dataToDispatch);

        if (
          element.nonEligibleDependents &&
          element.nonEligibleDependents.length
        ) {
          const updateDependent = Object.assign(
            {},
            _dependentDataArray[element.productId]
          );
          element.nonEligibleDependents.forEach(dependent => {
            if (dependent.relation === '1') {
              const spouse = Object.assign({}, updateDependent['spouse']);
              spouse.selected = false;
              spouse.available = true;
              spouse.invalid = true;
              updateDependent['spouse'] = spouse;
            } else if (dependent.relation === '2') {
              const childArray = Object.assign([], updateDependent['children']);
              childArray.forEach((child, index) => {
                if (dependent.oid === child.oid) {
                  const noneligiblechild = Object.assign({}, child);
                  noneligiblechild.selected = false;
                  noneligiblechild.available = true;
                  noneligiblechild.invalid = true;
                  childArray[index] = noneligiblechild;
                }
              });
              updateDependent['children'] = childArray;
            }
          });
          _dependentDataArray[element.productId] = updateDependent;
        }
      }
    });
    this.dependentsDetails = _dependentDataArray;
    this.updateBuyFlowElements();
  }
  updateDependentsDetailStore() {
    const products = Object.keys(this.dependentsDetails);
    const iteratedDependents = {};
    products.forEach(item => {
      let _selectedProduct = {};
      const dependents = this.dependentsDetails[item];
      if (dependents['spouse'] && dependents['spouse'].selected) {
        _selectedProduct = {
          ..._selectedProduct,
          spouse: dependents['spouse']
        };
      }
      if (dependents['children'] && dependents['children'].length) {
        const children = [];
        dependents['children'].forEach(child => {
          if (child.selected) children.push(child);
        });
        if (children.length) {
          _selectedProduct = { ..._selectedProduct, children: children };
        }
      }
      if (Object.keys(_selectedProduct).length > 0)
        iteratedDependents[item] = _selectedProduct;
    });
    this.dependentsDetails = iteratedDependents;
    this.updateBuyFlowElements();
  }
  showDependentIneligibilityPopup(data) {
    this.modalDisplayed = true;
    const dialogRef = this.dialog.open(DependentIneligibilityModalComponent, {
      disableClose: true,
      panelClass: 'dependent-ineligibility-modal-cover',
      data: { payload: data }
    });
    dialogRef.afterClosed().subscribe(res => {
      if (res && res === 'continue') {
        //to prevent multiple popups appearing in page
        if (this.ageValidationSubscription) {
          this.ageValidationSubscription.unsubscribe();
        }
        this.shoppingCartService.updateShoppingCartPrice(
          this.updateCartPayload
        );
        this.updateDependentDetailsBasedOnEligibility(data);
        this.updateDependentsDetailStore();
        //update quote
        this.orderedProducts.map(item => {
          this.bundleDetails.quotes.map(element => {
            if (element.productCode === item.productId) {
              item.quoteNumber = element.quoteNumber;
            }
          });
          return item;
        });
        const updateQuoteInputParams = this.agentSharedService.createUpdateQuoteReqParams(
          {
            bundleId: this.bundleDetails.quotes[0].bundleId,
            selectedPlans: this.orderedProducts,
            dependentsList: this.createDependentArrayWithQuoteNumber(
              this.dependentsDetails
            ),
            effectiveDate: this.effDateFormatted,
            //  removedQuotes:['304'] //add quote numbers to be removed as an array like this
            removedQuotes: this.deletedListFiltered
          }
        );
        this.savedQuoteStore.dispatch(
          updateQuote({
            payload: updateQuoteInputParams,
            isValidateRequired: 'y'
          })
        );
        this.buyFlowService.completeCurrentStepAndMoveToNext(this.route);
      }
    });
  }

  getDependentAgeValidationResponse() {
    this.ageValidationSubscription = this.buyFlowService
      .getDependentAgeValidation()
      .subscribe(res => {
        if (res && res.data && res.data.length) {
          const products = [];
          let nonEligibleDependents = 0;
          let totalMonthlyCostOld = 0;
          let totalMonthlyCostNew = 0;
          const insuredDetails = res.data;
          this.orderedProducts.forEach(element => {
            const monthlyPremium = Number(
              this.getMonthlyPremiumFromCart(element)
            );
            totalMonthlyCostOld = totalMonthlyCostOld + monthlyPremium;
            let _insuredDetails: any;
            insuredDetails.forEach(item => {
              if (
                Object.keys(item).includes(element.productId.replace(/-/g, ''))
              ) {
                _insuredDetails =
                  item[element.productId.replace(/-/g, '')].data;
              }
            });
            if (_insuredDetails) {
              totalMonthlyCostNew =
                totalMonthlyCostNew + Number(_insuredDetails.monthlyPremium);
              const payloadItem = {
                productId: element.productId,
                productName: element.productName,
                coverage: {
                  old: element.coverage,
                  new: _insuredDetails && _insuredDetails.coverageTierCd
                },
                nonEligibleDependents: this.nonEligibleDependentsOfSelectedProduct(
                  _insuredDetails.notEligibleInsureds,
                  element.productId
                ),
                monthlyPremium: {
                  old: monthlyPremium.toFixed(2),
                  new: Number(_insuredDetails.monthlyPremium).toFixed(2)
                }
              };
              products.push(payloadItem);
              if (
                payloadItem.nonEligibleDependents &&
                payloadItem.nonEligibleDependents.length > 0
              )
                nonEligibleDependents++;
            }
          });
          this.updateCartPayload = {
            price: totalMonthlyCostNew.toFixed(2),
            count: this.orderedProducts && this.orderedProducts.length
          };
          //  this.shoppingCartService.updateShoppingCartPrice(cartPayload);
          const payload = {
            totalMonthycost: {
              old: Number(totalMonthlyCostOld).toFixed(2),
              new: Number(totalMonthlyCostNew).toFixed(2)
            },
            productDetails: products,
            currentRoute: this.route,
            dependentsNotEligible: nonEligibleDependents > 0 ? true : false
          };
          if (nonEligibleDependents > 0) {
            this.showDependentIneligibilityPopup(payload);
          } else {
            //has dependents and no error
            /*changes for update quote start -  commented as spec is not added*/

            /*updating quote number to selected plans*/
            this.orderedProducts.map(item => {
              this.bundleDetails.quotes.map(element => {
                if (element.productCode === item.productId) {
                  item.quoteNumber = element.quoteNumber;
                  //can update total premium for product and rider form here if needed
                }
              });
              return item;
            });
            const updateQuoteInputParams = this.agentSharedService.createUpdateQuoteReqParams(
              {
                bundleId: this.bundleDetails.quotes[0].bundleId,
                selectedPlans: this.orderedProducts,
                dependentsList: this.createDependentArrayWithQuoteNumber(
                  this.dependentsDetails
                ),
                effectiveDate: this.effDateFormatted,
                removedQuotes: this.deletedListFiltered
                //  removedQuotes:['304'] //add quote numbers to be removed as an array like this
              }
            );
            this.savedQuoteStore.dispatch(
              updateQuote({
                payload: updateQuoteInputParams,
                isValidateRequired: 'y'
              })
            );
            /*changes for update quote end*/

            this.buyFlowService.completeCurrentStepAndMoveToNext(this.route);
          }
        }
      });
  }
  /*Functions required for update quote - commented as spec is not added*/
  createDependentArrayWithQuoteNumber(dependentsDetails) {
    if (dependentsDetails) {
      const modifiedDepArray = [];
      const productKeysArray = Object.keys(dependentsDetails);
      productKeysArray.map(productId => {
        const modifiedDepObj = {
          dependents: this.findDependents(productId, dependentsDetails),
          quoteNumber: this.findQuoteNumber(productId).quoteNumber,
          productCd: this.findQuoteNumber(productId).productCd
        };
        modifiedDepArray.push(modifiedDepObj);
      });
      return modifiedDepArray;
    }
  }

  findDependents(productId, dependentsDetails) {
    return dependentsDetails[productId];
  }
  findQuoteNumber(productId) {
    const currentProduct = this.bundleDetails.quotes.filter(
      e => e.productCode === productId
    );
    const quoteNumber = currentProduct[0].quoteNumber;
    return {
      quoteNumber: quoteNumber,
      productCd: currentProduct[0].productCode
    };
  }
  /*  Request structure for age validation check */
  checkDependentEligibility() {
    const products = [];
    this.orderedProducts.forEach(element => {
      const productDetails = {
        productCd: element.productId,
        packageCd: element.plan.id,
        agencyId: this.bundleDetails && this.bundleDetails.quotes[0].producerCd,
        originalIssueState:
          this.bundleDetails && this.bundleDetails.quotes[0].originalIssueState,
        intDiagnosisBenefitAmount: Number(element.benefitAmount),
        tobaccoInd: element.tobaccoInd,
        riders: this.getRiderDetails(element.selectedRiders),
        insureds: this.getInsuredDetails(element.productId)
      };

      products.push(productDetails);
    });
    const payload = {
      effectiveDate: this.effDateFormatted,
      products: products
    };
    this.savedQuoteStore.dispatch(getIneligibleDependentDetails({ payload }));
  }

  getRiderDetails(item) {
    const riders = [];
    if (item) {
      item.forEach(riderItem => {
        const riderPayload = { riderNameCd: riderItem.rider.riderNameCd };
        riders.push(riderPayload);
      });
    }
    return riders;
  }

  getInsuredDetails(productId) {
    const insured = [];
    if (this.dependentsDetails) {
      const selectedProduct = this.dependentsDetails[productId];
      if (
        selectedProduct &&
        selectedProduct['spouse'] &&
        selectedProduct['spouse'].selected
      ) {
        insured.push(this.getInsuredArray(selectedProduct['spouse'], '1'));
      }
      if (selectedProduct && selectedProduct['children']) {
        selectedProduct['children'].forEach(item => {
          if (item.selected) insured.push(this.getInsuredArray(item, '2'));
        });
      }
    }
    const selfData = {
      customerNumber: this.customerNumber,
      dateOfBirth: this.buyFlowService.convertDOB(
        this.primaryInsuredDOB,
        'req'
      ),
      disabilityInd: false,
      newInd: true,
      primaryInsuredInd: true,
      referenceNumber: '0',
      relationshipToPrimaryInsuredCd: 'SELF'
    };

    insured.push(selfData);
    return insured;
  }

  /* To check DOB format matches mm/dd/yyy. For API request convert to yyyy-mm-dd format, 
  for modal input convert to mm/dd/yyy format */
  convertDOB(date, payload) {
    const regex = /^[0-9]{2}[\/][0-9]{2}[\/][0-9]{4}$/g;
    const matchRequiredFormat = regex.test(date);
    if (payload === 'request-payload') {
      if (matchRequiredFormat) {
        //change to yyyy-mm-dd
        const datearray = date.split('/');
        return datearray[2] + '-' + datearray[0] + '-' + datearray[1];
      } else return date;
    } else if (payload === 'modal-payload') {
      if (!matchRequiredFormat) {
        //change to mm/dd/yyyy
        const datearray = date.split('-');
        return datearray[1] + '/' + datearray[2] + '/' + datearray[0];
      } else return date;
    }
  }

  getInsuredArray(data, dependentCode) {
    const details = {
      referenceNumber: data.oid,
      customerNumber: this.customerNumber,
      relationshipToPrimaryInsuredCd: dependentCode,
      dateOfBirth: this.convertDOB(data.dateOfBirth, 'request-payload'),
      disabilityInd: false,
      newInd: data.customerNumber ? false : true,
      primaryInsuredInd: false
    };
    return details;
  }
  /* dependent age validation end */

  openAgeChangeInPremiumModel(dataObj) {
    const payload = dataObj;
    const ageDialogRef = this.dialog.open(AgeChangeInPremiumComponent, {
      width: '747px',
      disableClose: true,
      panelClass: 'age-change-in-Premium-modal-wrapper',
      data: { payload }
    });

    ageDialogRef.afterClosed().subscribe(result => {
      if (result) {
        if (this.agePopupSubscription !== undefined)
          this.agePopupSubscription.unsubscribe();
        if (result === 'goback') {
        } else if (result === 'continue') {
          if (this.dependentsDetails) {
            this.initAgeValidationResponseOfDependents();
            this.checkDependentEligibility();
          } else {
            //change in premium for primary.. no dependents
            //update quote
            this.orderedProducts.map(item => {
              this.bundleDetails.quotes.map(element => {
                if (element.productCode === item.productId) {
                  item.quoteNumber = element.quoteNumber;
                }
              });
              return item;
            });

            const updateQuoteInputParams = this.agentSharedService.createUpdateQuoteReqParams(
              {
                bundleId: this.bundleDetails.quotes[0].bundleId,
                selectedPlans: this.orderedProducts,
                effectiveDate: this.effDateFormatted,
                removedQuotes: this.deletedListFiltered
                //  removedQuotes:['304'] //add quote numbers to be removed as an array like this
              }
            );
            this.savedQuoteStore.dispatch(
              updateQuote({
                payload: updateQuoteInputParams,
                isValidateRequired: 'y'
              })
            );
            const subscribeRedirect = this.buyFlowService.completeCurrentStepAndMoveToNext(
              this.route
            );
          }
        }
      }
    });
  }

  openAgeNotEligibleModel(dataObj) {
    dataObj['src'] = 'order-review';
    const payload = dataObj;

    const dialogRef = this.dialog.open(AgeNotEligibleForProductComponent, {
      width: '747px',
      disableClose: true,
      panelClass: 'age-not-eligible-for-productmodal-wrapper',
      data: { payload }
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        if (this.agePopupSubscription !== undefined)
          this.agePopupSubscription.unsubscribe();
        if (result && result === 'goback') {
        } else {
          if (
            result.agePremiumChangeDetails &&
            result.agePremiumChangeDetails.length > 0
          ) {
            result['mode'] = 'notEligible';
            this.openAgeChangeInPremiumModel(result);
            return false;
          } else {
            if (this.dependentsDetails) {
              this.initAgeValidationResponseOfDependents();
              this.checkDependentEligibility();
            } else {
              /* not eligible for some prods, and eligible for others and no dependents */
              //update quote
              this.orderedProducts.map(item => {
                this.bundleDetails.quotes.map(element => {
                  if (element.productCode === item.productId) {
                    item.quoteNumber = element.quoteNumber;
                  }
                });
                return item;
              });
              const updateQuoteInputParams = this.agentSharedService.createUpdateQuoteReqParams(
                {
                  bundleId: this.bundleDetails.quotes[0].bundleId,
                  selectedPlans: this.orderedProducts,
                  effectiveDate: this.effDateFormatted,
                  removedQuotes: this.deletedListFiltered
                  //  removedQuotes:['304'] //add quote numbers to be removed as an array like this
                }
              );
              this.savedQuoteStore.dispatch(
                updateQuote({
                  payload: updateQuoteInputParams,
                  isValidateRequired: 'y'
                })
              );

              const subscribeRedirect = this.buyFlowService.completeCurrentStepAndMoveToNext(
                this.route
              );
            }
          }
        }
      }
    });
  }

  setDeleteQuoteListParams(filteredQuoteObject, bundleData) {
    let deletedList;
    this.deletedListFiltered = [];
    if (bundleData && bundleData.length > 0) {
      deletedList = bundleData.filter(({ productCode: id1 }) =>
        filteredQuoteObject.some(({ productId: id2 }) => id2 === id1)
      );
    }
    if (deletedList && deletedList.length > 0) {
      deletedList.map(item => {
        // this.deletedListFiltered.push({ policyNumber: item.quoteNumber });
        this.deletedListFiltered.push(item.quoteNumber);
      });
    }
  }
  setDeleteQuoteList(payload) {
    if (
      payload &&
      payload.ageInEligibilityDetails &&
      payload.ageInEligibilityDetails.length > 0
    )
      this.setDeleteQuoteListParams(
        payload.ageInEligibilityDetails,
        this.bundleDetails
      );
  }

  ageValidationFlow(ageValData) {
    const payload = this.buyFlowService.ageEligibilityCheck(
      ageValData,
      this.orderedProducts,
      this.primaryInsuredDOB //check whether format is correct in retrieve quote flow
    );
    this.setDeleteQuoteList(payload);
    //  console.log('AVF payload: ', payload);
    if (
      (payload &&
        payload.ageInEligibilityDetails &&
        payload.ageInEligibilityDetails.length) ===
      (this.orderedProducts && this.orderedProducts.length)
    ) {
      payload['mode'] = 'Exit';
      payload['purchasedProducts'] = this.cartDetailsModified;
      this.openAgeNotEligibleModel(payload);
      return false;
    } else if (
      payload &&
      payload.ageEligibilityDetails &&
      payload.ageEligibilityDetails.length > 0 &&
      payload.ageInEligibilityDetails &&
      payload.ageInEligibilityDetails.length > 0
    ) {
      payload['mode'] = 'Hope';
      payload['cartProducts'] = this.cartDetailsModified;
      this.openAgeNotEligibleModel(payload);
      return false;
    } else if (
      payload &&
      payload.agePremiumChangeDetails &&
      payload.agePremiumChangeDetails.length > 0
    ) {
      this.openAgeChangeInPremiumModel(payload);
      return false;
    } else {
      if (this.dependentsDetails) {
        //unsubscribing to prevent multiple subscriptions
        if (this.agePopupSubscription !== undefined) {
          this.agePopupSubscription.unsubscribe();
        }
        this.initAgeValidationResponseOfDependents();
        this.checkDependentEligibility();
      } else {
        // console.log('no error no dependents case...');
        /*changes for update quote start*/
        this.orderedProducts.map(item => {
          this.bundleDetails.quotes.map(element => {
            if (element.productCode === item.productId) {
              item.quoteNumber = element.quoteNumber;
              //can update total premium for product and rider form here if needed
            }
          });
          return item;
        });

        const updateQuoteInputParams = this.agentSharedService.createUpdateQuoteReqParams(
          {
            bundleId: this.bundleDetails.quotes[0].bundleId,
            selectedPlans: this.orderedProducts,
            effectiveDate: this.effDateFormatted
          }
        );
        this.savedQuoteStore.dispatch(
          updateQuote({
            payload: updateQuoteInputParams,
            isValidateRequired: 'y'
          })
        );
        /*changes for update quote end*/

        const subscribeRedirect = this.buyFlowService.completeCurrentStepAndMoveToNext(
          this.route
        );
      }
    }
  }

  applyAgeValidation() {
    this.agePopupSubscription = this.savedQuoteStore
      .select(primaryInsuredAgeValidationDetailsSelector)
      .subscribe(ageData => {
        if (
          ageData &&
          ageData.status === true &&
          ageData.data &&
          ageData.data.length > 0
        ) {
          this.ageValidationFlow(ageData);
        }
      });
  }

  proceedToCheckout() {
    this.savedQuoteStore.dispatch(resePrimaryInsuredAgeData());
    this.initAgeValidationResponseOfDependents();
    const day = this.effectiveDate.getDate();
    const month = this.effectiveDate.getMonth() + 1;
    const year = this.effectiveDate.getFullYear();
    const effDateFormatted =
      year + '-' + this._to2digit(month) + '-' + this._to2digit(day);
    this.effDateFormatted = effDateFormatted;
    const sqObj = this.buyFlowService.getAgentSearchQuote();
    this.cartDetailsModified = [];
    const cartData = [];
    this.orderedProducts.map(item => {
      const riders = [];
      if (item.selectedRiders && item.selectedRiders.length > 0) {
        item.selectedRiders.map(ridetItem => {
          if (ridetItem.productId === item.productId)
            riders.push({ riderNameCd: ridetItem.rider.riderNameCd });
        });
      }
      const cartDataItems = {
        productCd: item.productId,
        packageCd: item.plan.id,
        coverageType: item.coverage,
        originalIssueStateCd: sqObj.stateProvCd,
        caseId: sqObj.caseId,
        agencyId: sqObj.partnerId,
        initialDiagnosisAmount: item.benefitAmount,
        tobaccoUseInd: item.tobaccoInd,
        addCancerCoverageInd: item.cancerCoverage,
        rider: riders
      };
      cartData.push(cartDataItems);
      this.cartDetailsModified.push({
        productId: item.productId,
        productName: item.productName,
        monthlyPremium: item.plan.price,
        riders: item.selectedRiders
      });
    });
    const ageParams = {
      dob: this.buyFlowService.convertDOB(this.primaryInsuredDOB, 'req'),
      effectiveDate: effDateFormatted,
      products: cartData
    };
    this.savedQuoteStore.dispatch(
      validatePrimaryInsuredAge({ ageParams: ageParams })
    );
    this.applyAgeValidation();
  }
  setEffectiveDate(date) {
    this.effectiveDate = date;
  }
  ngOnDestroy() {
    if (this.cartSubscription) {
      this.cartSubscription.unsubscribe();
    }
    if (this.dependentsSubsciption) {
      this.dependentsSubsciption.unsubscribe();
    }
    if (this.personalInfoSubsciption) {
      this.personalInfoSubsciption.unsubscribe();
    }
    if (this.agePopupSubscription) {
      this.agePopupSubscription.unsubscribe();
    }
    if (this.orderReviewInfoSubscription) {
      this.orderReviewInfoSubscription.unsubscribe();
    }
    if (this.buyFlowElementSubscription) {
      this.buyFlowElementSubscription.unsubscribe();
    }
    if (this.ageValidationSubscription) {
      this.ageValidationSubscription.unsubscribe();
    }
    if (this.bundleIdSubscription) {
      this.bundleIdSubscription.unsubscribe();
    }
  }
}
