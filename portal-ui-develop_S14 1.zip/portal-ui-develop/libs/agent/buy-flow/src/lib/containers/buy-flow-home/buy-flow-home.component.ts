import {
  Component,
  OnInit,
  OnDestroy,
  ChangeDetectorRef,
  AfterViewInit
} from '@angular/core';
import { Store, select } from '@ngrx/store';
import { Observable, Subscription, of } from 'rxjs';
import { CmsService } from '@aflac/shared/cms';
import { Router } from '@angular/router';
import { ActivatedRoute } from '@angular/router';
import { filter } from 'rxjs/operators';
import { SaveYourQuoteState } from '@aflac/agent/shared';
import { BuyFlowService } from '../../services/buy-flow.service';
import {
  buyFlowElementsSelector,
  getSavedUserDetails,
  selectUserDetailsFromAgent
} from '@aflac/agent/shared'; // Selectors
import {
  updateBuyFlowElements,
  getQuoteDataFromBundleId,
  saveUserDetails
} from '@aflac/agent/shared'; // Actions
import {
  ProductState,
  selectedPlans,
  UpdateCartOnQuoteSave
} from '@aflac/agent/shared';
import { CdkRow } from '@angular/cdk/table';

@Component({
  selector: 'aflac-buy-flow-home',
  templateUrl: './buy-flow-home.component.html',
  styleUrls: ['./buy-flow-home.component.scss']
})
export class BuyFlowHomeComponent implements OnInit, OnDestroy, AfterViewInit {
  buyFlowElements: Observable<any>;
  private subscriptions = new Subscription();
  urlParams: any;
  public routeChange = -1;
  notRequiredSteps = [];
  buyFlowStepsSessionStatus: boolean;
  selectedUserData: any;
  selectedCartData: any;
  bundleId: any;
  bundleData: any;
  isStepper: boolean;

  constructor(
    private store: Store<SaveYourQuoteState>,
    private productStore: Store<ProductState>,
    private cmsService: CmsService,
    private activatedRoute: ActivatedRoute,
    private router: Router,
    public buyFlowService: BuyFlowService,
    private cdr: ChangeDetectorRef
  ) {
    //this.onRouteChange();
  }

  ngOnInit() {
    this.subscriptions = this.activatedRoute.queryParams.subscribe(data => {
      this.urlParams = data;
    });
    if (this.store.pipe(select(buyFlowElementsSelector))) {
      this.buyFlowElements = this.store.pipe(select(buyFlowElementsSelector));
    }
    this.storeToSession('buyFlowElements');
    this.storeToSession('selectedUserData');
    this.storeToSession('selectedCartData');
    // Get bundle ID
    this.storeToSession('bundleId');

    this.setBuyFlowElementsStore();
    this.fetchStateVariationData();
    //console.log('BF bundleId : ', this.bundleId);
    //console.log('BF selectedUserData : ', this.selectedUserData);
  }

  ngAfterViewInit() {
    this.buyFlowService.isStepper.next(true);
    this.cdr.detectChanges();
  }

  fetchStateVariationData() {
    const bfs1 = this.buyFlowService
      .getBundleDataFromBundleId()
      .subscribe(bundleData => {
        if (bundleData && bundleData.data && bundleData.data.quotes) {
          this.buyFlowService.fetchSaveStateVariationData({
            stateCode: bundleData.data.quotes[0].riskStateCd
          });
        }
      });
    this.subscriptions.add(bfs1);
  }

  redirectToFirstStep(buyFlowStepsArray, dependentIndex) {
    const v = buyFlowStepsArray.filter(current => current.required === true);
    if (v && v[dependentIndex]) {
      this.router.navigateByUrl(v[dependentIndex].link);
    }
  }

  setBuyFlowElementsStore() {
    const bfs = this.buyFlowElements.subscribe(buyFlowData => {
      if (
        !(buyFlowData && buyFlowData.length) &&
        this.selectedCartData &&
        this.selectedCartData.length
      ) {
        const coverageTypeArray = [];
        this.selectedCartData.map(item => {
          return coverageTypeArray.push(item.coverage);
        });
        /**CHECK IF SESSSION HAS BREADCRUMB DATA */
        this.setBuyFlowElementsStoreData(coverageTypeArray);
      }
    });
    this.subscriptions.add(bfs);
  }

  sameValues(arr) {
    return arr.every((v, i, a) => v === a[0]);
  }

  public addNotRequiredStep(coverageTypeArray) {
    const allEqual = this.sameValues(coverageTypeArray);
    if (allEqual && coverageTypeArray[0] === 'ind') {
      this.notRequiredSteps.push('/dependents');
    } else {
      this.notRequiredSteps = [];
    }
  }

  setBuyFlowElementsStoreData(coverageTypeArray) {
    const buyFlowStepsArray = [];
    const buyFlowStepsSession = JSON.parse(
      sessionStorage.getItem('state-agent-buy-flow-elements')
    );
    let buyFlowSteps: any;
    this.addNotRequiredStep(coverageTypeArray);

    if (buyFlowStepsSession !== null) {
      /**From Session Storage */
      buyFlowSteps = of(buyFlowStepsSession);
      this.buyFlowStepsSessionStatus = true;
    } else {
      /**From State */
      this.buyFlowStepsSessionStatus = false;
      buyFlowSteps = this.cmsService.getKey('agent_portal.buy_flow_steps');
    }
    this.configureSteps(buyFlowSteps);
  }

  configureSteps(buyFlowSteps: Observable<any>) {
    const buyFlowStepsArray = [];
    if (buyFlowSteps) {
      const subs = buyFlowSteps.subscribe(data => {
        if (this.buyFlowStepsSessionStatus) {
          this.store.dispatch(updateBuyFlowElements({ payload: data }));
        } else {
          if (Array.isArray(data)) {
            data.forEach((element, elementIndex) => {
              buyFlowStepsArray.push({
                title: element.title,
                link: element.link,
                header: element.header,
                inactive: true,
                disabled: false,
                completed: false,
                required: !(this.notRequiredSteps.indexOf(element.link) >= 0),
                data: {}
              });
            });
            buyFlowStepsArray[0].inactive = false;
            buyFlowStepsArray[1].inactive = false;
            this.store.dispatch(
              updateBuyFlowElements({ payload: buyFlowStepsArray })
            );
            this.redirectToFirstStep(buyFlowStepsArray, 1);
          }
        }
      });
      this.subscriptions.add(subs);
    }
  }

  //Save data from store to session storage
  public storeToSession(statename: string) {
    switch (statename) {
      case 'buyFlowElements': {
        const bfls = this.store
          .pipe(select(buyFlowElementsSelector))
          .subscribe(res => {
            if (res && res.length > 0 && this.routeChange > 0) {
              sessionStorage.setItem(
                'state-agent-buy-flow-elements',
                JSON.stringify(res)
              );
            }
          });
        this.subscriptions.add(bfls);
        break;
      }
      case 'selectedUserData': {
        const gsuds = this.store
          .pipe(select(getSavedUserDetails))
          .subscribe(res => {
            if (res && Object.keys(res).length > 0) {
              this.selectedUserData = res;
              sessionStorage.setItem(
                'state-agent-user-details',
                JSON.stringify(res)
              );
            } else {
              this.sessionToStore('selectedUserData');
            }
          });
        this.subscriptions.add(gsuds);
        break;
      }
      case 'selectedCartData': {
        const cartSub = this.productStore
          .pipe(select(selectedPlans))
          .subscribe(res => {
            if (res !== undefined && res.value && res.value.length > 0) {
              this.selectedCartData = res.value;
              sessionStorage.setItem(
                'state-agent-cart-details',
                JSON.stringify(res.value)
              );
            } else {
              this.sessionToStore('selectedCartData');
            }
          });
        this.subscriptions.add(cartSub);
        break;
      }
      case 'bundleId': {
        const bdsub = this.store
          .pipe(select(selectUserDetailsFromAgent))
          .subscribe(qouteData => {
            if (
              qouteData &&
              qouteData.quoteDetails &&
              qouteData.quoteDetails.length > 0
            ) {
              this.bundleId = qouteData.quoteDetails[0].bundleId;
              sessionStorage.setItem(
                'state-agent-bundleId',
                JSON.stringify(this.bundleId)
              );
            } else {
              this.sessionToStore('bundleId');
            }
            //this.bundleId = '1390751';
            if (this.bundleId) {
              this.store.dispatch(
                getQuoteDataFromBundleId({ bundleId: this.bundleId })
              );
            }
          });
        this.subscriptions.add(bdsub);
        break;
      }
      default: {
        break;
      }
    }
  }

  // Save data from session to store
  public sessionToStore(statename: string) {
    switch (statename) {
      case 'buyFlowElements': {
        const data = JSON.parse(
          sessionStorage.getItem('state-agent-buy-flow-elements')
        );
        this.store.dispatch(updateBuyFlowElements({ payload: data }));
        break;
      }
      case 'selectedUserData': {
        this.selectedUserData = JSON.parse(
          sessionStorage.getItem('state-agent-user-details')
        );
        if (this.selectedUserData)
          this.store.dispatch(
            saveUserDetails({ userDetails: this.selectedUserData })
          );
        break;
      }
      case 'selectedCartData': {
        this.selectedCartData = JSON.parse(
          sessionStorage.getItem('state-agent-cart-details')
        );
        if (this.selectedCartData) {
          const cartPayload = {
            key: 'from-list',
            value: this.selectedCartData
          };
          this.productStore.dispatch(
            UpdateCartOnQuoteSave({ payload: cartPayload })
          );
        }

        break;
      }
      case 'bundleId': {
        this.bundleId = JSON.parse(
          sessionStorage.getItem('state-agent-bundleId')
        );
        break;
      }
      default: {
        break;
      }
    }
  }

  ngOnDestroy() {
    this.subscriptions.unsubscribe();
  }
}
