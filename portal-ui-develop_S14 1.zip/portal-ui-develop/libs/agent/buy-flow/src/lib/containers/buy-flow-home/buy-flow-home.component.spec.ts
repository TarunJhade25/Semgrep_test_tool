import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BuyFlowHomeComponent } from './buy-flow-home.component';
import { RouterModule } from '@angular/router';
import { StoreModule, MemoizedSelector, Store } from '@ngrx/store';
import { TranslateModule } from '@ngx-translate/core';
import { RouterTestingModule } from '@angular/router/testing';
import { saveYourQuoteReducer, SaveYourQuoteState } from '@aflac/agent/shared';
import { MockStore, provideMockStore } from '@ngrx/store/testing';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import * as fromMockSaveYourQuoteSelector from '@aflac/agent/shared';
import { CmsService } from '@aflac/shared/cms';
import { of, BehaviorSubject, Observable } from 'rxjs';
import { BuyFlowService } from '../../services/buy-flow.service';
import * as fromProduct from '@aflac/agent/shared';

describe('BuyFlowHomeComponent', () => {
  let component: BuyFlowHomeComponent;
  let fixture: ComponentFixture<BuyFlowHomeComponent>;
  let mockProductsSelector: MemoizedSelector<any, any>;
  let mockSaveQuoteSelector: MemoizedSelector<any, any>;
  let mockStore: MockStore<SaveYourQuoteState>;
  let mockSelectedPlanSelector: MemoizedSelector<any, any>;

  const selectedPlans = {
    key: 'from-list',
    value: [
      {
        productId: 'PREC-IC',
        productName: 'Accident',
        plan: {
          id: 123,
          price: '100',
          description: 'These are the benefits',
          name: 'Lorem ipsum',
          states: ['AL', 'CT'],
          title: 'Standard Plan',
          benefits: [
            {
              id: 333,
              name: 'test',
              price: 123
            }
          ]
        },
        coverage: 'ind',
        selected: true,
        availableInCart: true,
        selectedRiders: [
          {
            rider: { title: 'title1', price: '100' },
            selected: true,
            availableInCart: true,
            plan: { id: 'id1' }
          },
          {
            rider: { title: 'title2', price: '200' },
            selected: true,
            availableInCart: true,
            plan: { id: 'id1' }
          }
        ]
      }
    ]
  };
  const selectedUserDataObj = {
    age: '23',
    consentStatus: 'GRANTED',
    customerNumber: '',
    email: 'ddfs@dff.com',
    firstName: 'sdfs',
    lastName: 'sds',
    quotes: [
      {
        caseId: 'test',
        coverageTypeCd: 'ind_fml',
        packageCd: 'plan07',
        productCd: 'PREC-IC',
        productName: 'Cancer Insurance',
        riders: [],
        riskStateCd: 'AL',
        series: 'test',
        sfrId: 'test',
        totalPremium: '16.93'
      },
      {
        caseId: 'test',
        coverageTypeCd: 'ind_sps',
        packageCd: 'low',
        productCd: 'PREC-IA',
        productName: 'Accident Insurance',
        riders: [],
        riskStateCd: 'AL',
        series: 'test',
        sfrId: 'test',
        totalPremium: '19.93'
      }
    ]
  };
  const selectedUserData = selectedUserDataObj.quotes;
  const buyFlowElements = [
    {
      completed: true,
      data: {},
      disabled: false,
      header: 'Quote',
      inactive: false,
      link: '/review',
      required: true,
      title: 'Quote'
    },
    {
      completed: false,
      data: {},
      disabled: false,
      header: 'Dependents Information',
      inactive: false,
      link: '/dependents',
      required: true,
      title: 'Dependents Information'
    },
    {
      completed: false,
      data: {},
      disabled: false,
      header: 'Eligibility',
      inactive: false,
      link: '/eligibility',
      required: true,
      title: 'Eligibility'
    },
    {
      completed: false,
      data: {},
      disabled: false,
      header: 'Order Review',
      inactive: false,
      link: '/order-review',
      required: true,
      title: 'Order Review'
    }
  ];
  const bundleData = {
    data: {
      quotes: [
        {
          bundleId: '000',
          policyNumber: 'a1b2',
          effectiveDate: '01/02/2019',
          expirationDate: '01/06/2019',
          transactionEffectiveDate: '03/02/2019',
          policyStatusCd: 'dummy',
          productCode: 'PREC-IC',
          lobCd: 'dummy',
          totalPremium: 1234,
          currencyCode: 'ind',
          producerCd: 'dummy',
          subProducerCd: 'd',
          quoteNumber: '111',
          customerNumber: '111'
        }
      ]
    }
  };
  const coverageTypeArray = ['ind-fml', 'ind-sps', 'ind-chd'];

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        TranslateModule.forRoot(),
        StoreModule.forRoot(saveYourQuoteReducer),
        RouterModule,
        RouterTestingModule
      ],
      declarations: [BuyFlowHomeComponent],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
      providers: [
        provideMockStore({}),
        { provide: CmsService, useClass: MockCmsService },
        { provide: BuyFlowService, useClass: MockBuyflowService }
      ]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BuyFlowHomeComponent);
    mockStore = TestBed.get(Store);
    mockSaveQuoteSelector = mockStore.overrideSelector(
      fromMockSaveYourQuoteSelector.buyFlowElementsSelector,
      buyFlowElements
    );
    mockProductsSelector = mockStore.overrideSelector(
      fromMockSaveYourQuoteSelector.getSavedUserDetails,
      selectedUserData
    );
    mockSelectedPlanSelector = mockStore.overrideSelector(
      fromProduct.selectedPlans,
      selectedPlans
    );
    mockSaveQuoteSelector = mockStore.overrideSelector(
      fromMockSaveYourQuoteSelector.buyFlowElementsSelector,
      buyFlowElements
    );
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  afterEach(() => {
    fixture.destroy();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should set setBuyFlowElementsStore ', () => {
    spyOn(component, 'setBuyFlowElementsStore');
    component.setBuyFlowElementsStore();
    expect(component.setBuyFlowElementsStore).toBeDefined();
  });

  it('should set setBuyFlowElementsStoreData ', () => {
    spyOn(component, 'setBuyFlowElementsStoreData');
    component.setBuyFlowElementsStoreData(coverageTypeArray);
    expect(component.setBuyFlowElementsStoreData).toBeDefined();
  });

  it('should dispatch the updateBuyFlowElements', () => {
    const spyObj = spyOn(mockStore, 'dispatch').and.returnValue(of(true));
    component.setBuyFlowElementsStoreData(coverageTypeArray);
    expect(spyObj).toHaveBeenCalled();
  });

  it('should call sameValues', () => {
    component.sameValues(coverageTypeArray);
    expect(component.sameValues).toBeDefined();
  });

  it('should call storeToSession funtion', () => {
    const statename = 'buyFlowElements';
    component.storeToSession(statename);
    expect(component as any).toBeDefined();
  });

  it('should call sessionToStore funtion', () => {
    const statename = 'buyFlowElements';
    component.sessionToStore(statename);
    expect(component as any).toBeDefined();
  });

  class MockCmsService {
    getKey(key: string | Array<string>, interpolateParams?: Object): any {
      return of([
        { inactive: true, completed: false },
        { inactive: true, completed: false }
      ]);
    }
  }
  class MockBuyflowService {
    isStepper = new BehaviorSubject(false);
    getBundleDataFromBundleId(): Observable<any> {
      return of(bundleData);
    }
  }
});
