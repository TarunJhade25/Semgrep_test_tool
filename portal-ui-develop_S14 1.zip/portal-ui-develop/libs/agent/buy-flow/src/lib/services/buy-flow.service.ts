import { Injectable } from '@angular/core';
import { Store, select } from '@ngrx/store';
import {
  SaveYourQuoteState,
  checkDependentEdited,
  SaveStateVariationData
} from '@aflac/agent/shared';
import {
  buyFlowElementsSelector,
  buyFlowAllElementsSelector,
  dependentEligibilityDataSelector,
  getQuoteDataWithBundle,
  personalDetailsSelector,
  getSavedUserDetails
} from '@aflac/agent/shared'; // Selectors
import { first, take } from 'rxjs/operators';
import { BehaviorSubject } from 'rxjs';
import { updateBuyFlowElements, getPersonalDetails } from '@aflac/agent/shared'; // Actions
import { Router } from '@angular/router';
import {
  ProductState,
  selectedPlans,
  addItemToCart,
  SetHeaderShoppingCartParams,
  agentSelectedQuote,
  agentGetQuote,
  Agent,
  getQuoteDataFromBundleId
} from '@aflac/agent/shared';

@Injectable({
  providedIn: 'root'
})
export class BuyFlowService {
  searchQuoteData: any;
  private routeFromSaveQuotePage = false;
  public isStepper = new BehaviorSubject(true);
  constructor(
    private store: Store<SaveYourQuoteState>,
    private productStore: Store<ProductState>,
    private agentStore: Store<Agent>,
    private router: Router
  ) {}
  completeCurrentStepAndMoveToNext(route) {
    return this.store
      .pipe(
        select(buyFlowElementsSelector),
        first()
      )
      .subscribe(data => {
        const buySteps = JSON.parse(JSON.stringify(data));
        const index = buySteps.findIndex(p => p.link.indexOf(route) >= 0);
        buySteps[index].completed = true;
        if (index + 1) {
          buySteps[index + 1].inactive = false;
        }
        this.store.dispatch(updateBuyFlowElements({ payload: buySteps }));
        this.router.navigateByUrl(buySteps[index + 1].link);
      });
  }
  enableStepperByRoute(route) {
    this.store
      .pipe(
        select(buyFlowAllElementsSelector),
        take(2)
      )
      .subscribe(data => {
        if (data && data.length) {
          const buySteps = JSON.parse(JSON.stringify(data));
          const index = buySteps.findIndex(p => p.link === route);
          buySteps[index].inactive = false;
          this.store.dispatch(updateBuyFlowElements({ payload: buySteps }));
        }
      })
      .unsubscribe();
  }

  changeStepperRequiredStatusByRoute(route: string, status: Boolean) {
    this.store
      .pipe(
        select(buyFlowAllElementsSelector),
        first()
      )
      .subscribe(data => {
        if (data && data.length) {
          const buySteps = JSON.parse(JSON.stringify(data));
          const index = buySteps.findIndex(p => p.link === route);
          buySteps[index].required = status;
          this.store.dispatch(updateBuyFlowElements({ payload: buySteps }));
        }
      });
  }

  clearStepperElementData(route: string) {
    this.store
      .pipe(
        select(buyFlowAllElementsSelector),
        first()
      )
      .subscribe(steps => {
        if (steps && steps.length) {
          const buySteps = JSON.parse(JSON.stringify(steps));
          const index = buySteps.findIndex(p => p.link === route);
          buySteps[index].completed = false;
          for (let ind = index + 1; ind < buySteps.length; ind++) {
            buySteps[ind].completed = false;
            buySteps[ind].inactive = true;
            if (buySteps[ind].data) {
              buySteps[ind].data = {};
            }
          }
          this.store.dispatch(updateBuyFlowElements({ payload: buySteps }));
        }
      });
  }
  setRouteFromSaveQuotePage(flag: boolean) {
    this.routeFromSaveQuotePage = flag;
  }
  getRouteFromSaveQuotePage() {
    return this.routeFromSaveQuotePage;
  }

  getCartData() {
    return this.productStore.pipe(select(selectedPlans));
  }
  addItemsToCart(data) {
    return this.productStore.dispatch(addItemToCart({ selectedPlan: data }));
  }

  getDependentAgeValidation() {
    return this.store.pipe(select(dependentEligibilityDataSelector));
  }

  getBundleDataFromBundleId() {
    return this.store.pipe(
      select(getQuoteDataWithBundle),
      take(2)
    );
  }

  getPersonalDataFromCustomerNumber() {
    return this.store.pipe(
      select(personalDetailsSelector),
      take(2)
    );
  }

  setPersonalData(custNumber) {
    this.store.dispatch(getPersonalDetails({ customerId: custNumber }));
  }

  fetchSaveStateVariationData(userStatecode) {
    this.store.dispatch(SaveStateVariationData(userStatecode));
  }

  checkCustomerType(customerNumber, isAnonymous) {
    let uType = 'new';
    if (customerNumber) {
      this.setPersonalData(customerNumber);
      this.getPersonalDataFromCustomerNumber().subscribe(pData => {
        if (pData && pData.status === true && pData.data) {
          uType = this.checkCustomerIsProspectOrMember(pData.data, isAnonymous);
        }
      });
    }
    return uType;
  }

  checkCustomerIsProspectOrMember(personalData, isAnonymous) {
    //console.log('BFS personalData : ', personalData);
    let userType = 'new';
    if (isAnonymous) {
      userType = 'anonymous';
    } else {
      if (personalData) {
        if (
          personalData.availableProducts &&
          personalData.availableProducts.length > 0
        )
          userType = 'member';
        else userType = 'prospect';
      } else userType = 'new';
    }

    return userType;
  }

  checkDependentEdited() {
    return this.store.select(checkDependentEdited);
  }

  getUserDataFomSaveQuoteResponse() {
    return this.store.select(getSavedUserDetails);
  }

  calculateRiderSum(riderData) {
    let riderSum = 0;
    if (riderData && riderData.length > 0) {
      for (const riderItem of riderData) {
        riderSum += Number(riderItem.rider.price);
      }
    }
    return riderSum.toFixed(2);
  }

  ageEligibilityCheck(ageValData, cartDetails, primaryInsuredDOB) {
    //console.log('this.cartDetails :', this.cartDetails);
    const agePremiumChangeDetails = [];
    const ageEligibilityDetails = [];
    const ageInEligibilityDetails = [];
    let cartProductTotalPremium = 0;

    if (ageValData && ageValData !== undefined) {
      if (cartDetails && cartDetails.length > 0) {
        cartDetails.map(cartItem => {
          if (ageValData && ageValData.data && ageValData.data.length > 0) {
            ageValData.data.map(item => {
              if (item && Object.keys(item).length > 0) {
                Object.keys(item).map(k => {
                  const m = k.slice(0, 4) + '-' + k.slice(4);
                  if (m === cartItem.productId) {
                    const cartRiderPremium = this.calculateRiderSum(
                      cartItem.selectedRiders
                    );
                    cartProductTotalPremium =
                      Number(cartRiderPremium) + Number(cartItem.plan.price);
                    if (item[k] && Object.keys(item[k].data).length === 0) {
                      ageInEligibilityDetails.push({
                        productId: cartItem.productId,
                        productName: cartItem.productName,
                        currentPremium: 0,
                        riders: cartItem.selectedRiders
                      });
                    } else {
                      ageEligibilityDetails.push({
                        productId: cartItem.productId,
                        productName: cartItem.productName,
                        currentPremium: item[k].data.monthlyPremium,
                        prevPremium: cartProductTotalPremium,
                        riders: item[k].data.riders
                      });
                      // Premium change
                      if (
                        cartProductTotalPremium !== item[k].data.monthlyPremium
                      ) {
                        agePremiumChangeDetails.push({
                          productId: cartItem.productId,
                          productName: cartItem.productName,
                          dateOfBirth: primaryInsuredDOB,
                          currentPremium: item[k].data.monthlyPremium,
                          prevPremium: cartProductTotalPremium,
                          riders: item[k].data.riders
                        });
                      }
                    }
                  }
                });
              }
            });
          }
        });
      }
    }
    return {
      agePremiumChangeDetails: agePremiumChangeDetails,
      ageEligibilityDetails: ageEligibilityDetails,
      ageInEligibilityDetails: ageInEligibilityDetails
    };
  }
  updateHeaderShoppingCartparams(payload) {
    return this.productStore.dispatch(
      SetHeaderShoppingCartParams({ payload: payload })
    );
  }

  /* update quote start functions start - commented as spec is not added*/
  convertDOB(date, type) {
    const regex = /^[0-9]{2}[\/][0-9]{2}[\/][0-9]{4}$/g;
    const matchRequiredFormat = regex.test(date);
    if (type === 'res' && !matchRequiredFormat) {
      const datearray = date.split('-');
      return datearray[1] + '/' + datearray[2] + '/' + datearray[0];
    } else if (type === 'req' && matchRequiredFormat) {
      const datearray = date.split('/');
      return datearray[2] + '-' + datearray[0] + '-' + datearray[1];
    } else return date;
  }

  getNumeric(stringVal) {
    if (isNaN(stringVal)) stringVal = stringVal.replace(/,/g, '');
    return Number(stringVal);
  }
  calculateMonthlyPayment(planPrice, riders) {
    let monthlyPayment = 0;
    monthlyPayment = this.getNumeric(planPrice);
    riders.map(item => {
      monthlyPayment = monthlyPayment + this.getNumeric(item.rider.price);
    });
    return monthlyPayment.toFixed(2);
  }

  getAgentSearchQuote() {
    this.agentStore.pipe(select(agentSelectedQuote)).subscribe(sqQuote => {
      if (sqQuote && Object.keys(sqQuote).length > 0) {
        this.searchQuoteData = sqQuote;
        sessionStorage.setItem(
          'state-agent-user-age-and-state',
          JSON.stringify(sqQuote)
        );
      } else {
        this.searchQuoteData = JSON.parse(
          sessionStorage.getItem('state-agent-user-age-and-state')
        );
        if (this.searchQuoteData)
          this.agentStore.dispatch(
            agentGetQuote({ agentGetQuote: this.searchQuoteData })
          );
      }
    });
    return this.searchQuoteData;
  }

  setBundleDataAction(bundleId) {
    this.store.dispatch(
      getQuoteDataFromBundleId({
        bundleId: bundleId
      })
    );
  }
}
