import { TestBed } from '@angular/core/testing';

import { BuyFlowService } from './buy-flow.service';
import { StoreModule } from '@ngrx/store';
import { saveYourQuoteReducer } from '@aflac/agent/shared';
import { RouterTestingModule } from '@angular/router/testing';

describe('BuyFlowService', () => {
  beforeEach(() =>
    TestBed.configureTestingModule({
      imports: [StoreModule.forRoot(saveYourQuoteReducer), RouterTestingModule]
    })
  );

  it('should be created', () => {
    const service: BuyFlowService = TestBed.get(BuyFlowService);
    expect(service).toBeTruthy();
  });
});
