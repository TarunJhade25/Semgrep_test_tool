import {
  Component,
  OnInit,
  Output,
  EventEmitter,
  OnDestroy
} from '@angular/core';
import { Subscription } from 'rxjs';
import { MatDialogRef } from '@angular/material';
import { Store } from '@ngrx/store';
import { ShoppingCartService } from '@aflac/agent/shared';
import { ProductState, getHeaderShoppingCartParams } from '@aflac/agent/shared';

@Component({
  selector: 'aflac-agent-shopping-cart-modal',
  templateUrl: './agent-shopping-cart-modal.component.html',
  styleUrls: ['./agent-shopping-cart-modal.component.scss']
})
export class AgentShoppingCartModalComponent implements OnInit, OnDestroy {
  public cartParamsSubscription = new Subscription();
  cartParams;

  @Output() cartUpdated: EventEmitter<any> = new EventEmitter<any>();

  constructor(
    private dialogRef: MatDialogRef<AgentShoppingCartModalComponent>,
    private shoppingCartService: ShoppingCartService,
    private store: Store<ProductState>
  ) {}

  ngOnInit() {
    this.getHeaderCartParams();
  }
  ngOnDestroy() {
    this.cartParamsSubscription.unsubscribe();
  }
  getHeaderCartParams() {
    this.cartParamsSubscription = this.store
      .select(getHeaderShoppingCartParams)
      .subscribe(res => {
        this.cartParams = res;
      });
  }
  closeShoppingCartModal() {
    this.shoppingCartService.hideShoppingCartModal();
  }
}
