import { Component, OnInit, Inject, ChangeDetectorRef } from '@angular/core';
import {
  MatDialogRef,
  MAT_DIALOG_DATA,
  MatDialog
} from '@angular/material/dialog';
import { PerfectScrollbarConfigInterface } from 'ngx-perfect-scrollbar';

@Component({
  selector: 'aflac-agent-header-shopping-cart-confirmation-modal',
  templateUrl: './agent-header-shopping-cart-confirmation-modal.component.html',
  styleUrls: ['./agent-header-shopping-cart-confirmation-modal.component.scss']
})
export class AgentHeaderShoppingCartConfirmationModalComponent
  implements OnInit {
  updatedCartProducts;
  initialCartSubtotal;
  updatedCartSubtotal;
  public config: PerfectScrollbarConfigInterface = {
    scrollingThreshold: 0,
    minScrollbarLength: 148,
    maxScrollbarLength: 148,
    wheelSpeed: 0.6
    // scrollYMarginOffset: 100
  };

  constructor(
    public dialogRef: MatDialogRef<
      AgentHeaderShoppingCartConfirmationModalComponent
    >,
    private cdr: ChangeDetectorRef,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) {}

  ngOnInit() {
    this.updatedCartProducts = this.data.cartProducts;
    this.initialCartSubtotal = this.data.initialCartSubtotal;
    this.updatedCartSubtotal = this.data.updatedCartSubtotal;
    this.calculateScrollHeight();
  }
  calculateScrollHeight() {
    setTimeout(() => {
      if (
        document.getElementsByClassName('ps-content') &&
        document.getElementsByClassName('ps-content').length > 1
      ) {
        const offsetHeight = document.getElementsByClassName('ps-content')[1]
          .clientHeight;
        if (offsetHeight < 249) {
          document
            .getElementById('dynamic-confirmation-height-container')
            .classList.add('no-scroll-content');
          document.getElementsByName('product-list-item').forEach(item => {
            item.classList.add('item-with-border');
          });
          document
            .getElementById('confirm-modal-scrollbar')
            .classList.add('scrollbar-no-scroll-content');
          this.cdr.detectChanges();
        }
      }
    }, 100);
  }
  onSubmit() {
    this.dialogRef.close(true);
  }
  cancelChanges() {
    this.dialogRef.close('cancel');
  }

  getNumeric(stringVal) {
    if (isNaN(stringVal)) stringVal = stringVal.replace(/,/g, '');
    return Number(stringVal);
  }
  closeConfirmationModal() {
    this.dialogRef.close('close');
  }
}
