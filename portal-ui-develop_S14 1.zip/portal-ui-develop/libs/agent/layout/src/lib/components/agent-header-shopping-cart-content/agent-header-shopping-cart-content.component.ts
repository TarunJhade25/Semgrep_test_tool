import {
  Component,
  OnInit,
  OnDestroy,
  Input,
  ChangeDetectorRef,
  AfterViewChecked,
  OnChanges,
  Output,
  EventEmitter
} from '@angular/core';
import { Store, select } from '@ngrx/store';
import { Router } from '@angular/router';
import {
  ProductState,
  selectedPlans,
  UpdateCartOnQuoteSave,
  getHeaderShoppingCartParams,
  updateQuote
} from '@aflac/agent/shared'; // Reducer
import { MatDialog } from '@angular/material';
import { CmsService } from '@aflac/shared/cms';
import { CartProducts, SelectedRiderInCart } from '@aflac/agent/quote';
import { Subscription } from 'rxjs';
import {
  ShoppingCartService,
  SaveYourQuoteState,
  getQuoteDataWithBundle,
  AgentSharedService
} from '@aflac/agent/shared';
//import { ShoppingCartService } from '../../services/shopping-cart.service';
import { AgentHeaderShoppingCartConfirmationModalComponent } from '../agent-header-shopping-cart-confirmation-modal/agent-header-shopping-cart-confirmation-modal.component';
import { PerfectScrollbarConfigInterface } from 'ngx-perfect-scrollbar';
import { ItemsControl } from '@ngu/carousel/lib/ngu-carousel/ngu-carousel';

@Component({
  selector: 'aflac-agent-header-shopping-cart-content',
  templateUrl: './agent-header-shopping-cart-content.component.html',
  styleUrls: ['./agent-header-shopping-cart-content.component.scss']
})
export class AgentHeaderShoppingCartContentComponent
  implements OnInit, AfterViewChecked, OnDestroy {
  public cartProducts: any;
  public shoppingCartProducts: CartProducts[];
  public cartCount: number;
  public checkBoxModal = true;
  public editable = true;
  public cartSum: number;
  public coverageTypes: any;
  public currentState: any;
  public subscription = new Subscription();
  public key: any;
  public benefitAmount: string;
  public initialCartSum;
  public disableUpdateBtn = true;
  public updatedItemsList;
  initialCartSubtotal = 0;
  updatedCartSubtotal = 0;
  disableAllCheckBoxes;
  public cartParamsSubscription = new Subscription();
  cartParams;
  bundleDataSubscriptiom: Subscription;
  bundleDetails;
  deletedListFiltered = [];
  finalcartItems = [];
  filteredQuoteGlobal = [];
  public config: PerfectScrollbarConfigInterface = {
    scrollingThreshold: 0,
    minScrollbarLength: 148,
    maxScrollbarLength: 148,
    wheelSpeed: 0.6
    // scrollYMarginOffset: 100
  };
  @Output() cartUpdated: EventEmitter<any> = new EventEmitter<any>();
  constructor(
    public shoppingCartConfirmationDialog: MatDialog,
    private cdr: ChangeDetectorRef,
    private store: Store<ProductState>,
    private cmsService: CmsService,
    private shoppingCartService: ShoppingCartService,
    private router: Router,
    private savedQuoteStore: Store<SaveYourQuoteState>,
    private agentSharedService: AgentSharedService
  ) {}

  ngOnInit() {
    this.cartProducts = [];
    this.getAgentCMSData();
    this.getCartProducts();
    this.getHeaderCartParams();
    this.initialCartSum = this.CartSubTotal();
    this.disableAllCheckBoxes = true;
    this.calculateScrollHeight();
    this.fetchBundleData();
  }
  calculateScrollHeight() {
    setTimeout(() => {
      if (
        document.getElementsByClassName('ps-content') &&
        document.getElementsByClassName('ps-content').length
      ) {
        const offsetHeight = document.getElementsByClassName('ps-content')[0]
          .clientHeight;
        if (offsetHeight < 306) {
          document
            .getElementById('dynamic-height-container')
            .classList.add('no-scroll-content');
          document.getElementsByName('product-list-item').forEach(item => {
            item.classList.add('item-with-border');
          });
          document
            .getElementById('shopping-modal-scrollbar')
            .classList.add('scrollbar-no-scroll-content');
          this.cdr.detectChanges();
        }
      }
    }, 200);
  }

  fetchBundleData() {
    this.bundleDataSubscriptiom = this.savedQuoteStore
      .pipe(select(getQuoteDataWithBundle))
      .subscribe(bData => {
        this.bundleDetails = bData && bData.data;
      });
  }
  mapBenefitAmount(intDiagnosisBenefitAmount) {
    if (intDiagnosisBenefitAmount) {
      return `$${intDiagnosisBenefitAmount / 1000}K`;
    }
  }
  ngOnDestroy() {
    this.subscription.unsubscribe();
    this.cartParamsSubscription.unsubscribe();
    this.bundleDataSubscriptiom.unsubscribe();
  }
  ngAfterViewChecked() {
    this.cdr.detectChanges();
  }
  getHeaderCartParams() {
    this.cartParamsSubscription = this.store
      .select(getHeaderShoppingCartParams)
      .subscribe(res => {
        this.cartParams = res;
      });
  }
  getCartProducts() {
    this.subscription = this.store.select(selectedPlans).subscribe(res => {
      this.key = res && res.key;
      if (this.key === 'from-list' || this.key === 'from-cart') {
        this.currentState = res.value;
        if (this.currentState && this.currentState.length > 0) {
          this.currentState.forEach(element => {
            const item: CartProducts = {
              productId: element.productId,
              productName: element.productName,
              plan: element.plan.title,
              coverageType: element.coverage,
              price: isNaN(element.plan.price)
                ? Number(element.plan.price.replace('$', '').replace(/,/g, ''))
                : element.plan.price,
              selected: element.selected,
              availableInCart: element.availableInCart,
              currentPlanState: element.plan,
              riders: [],
              benefitAmount: element.benefitAmount,
              tobaccoInd: element.tobaccoInd,
              cancerCoverage: element.cancerCoverage
            };
            if (element.selectedRiders) {
              element.selectedRiders.forEach(riderItem => {
                const rider: SelectedRiderInCart = {
                  name: riderItem.rider.title,
                  price: isNaN(riderItem.rider.price)
                    ? Number(
                        riderItem.rider.price.replace('$', '').replace(/,/g, '')
                      )
                    : riderItem.rider.price,
                  selected: !element.selected ? false : riderItem.selected,
                  availableInCart: riderItem.availableInCart,
                  currentRiderState: riderItem.rider
                };
                item.riders.push(rider);
              });
            }
            const index = this.cartProducts.findIndex(entry => {
              return entry.productId === item.productId;
            });
            if (index < 0) this.cartProducts.push(item);
            else this.cartProducts[index] = item;
          });
        }
        this.cartProducts.forEach(plans => {
          plans.MonthlyPrice = this.monthlyPlanSubTotal(plans);
        });
      } else if (res.key === undefined && res.value === undefined) {
        /* To update cart on changing the search fields */
        this.cartProducts = [];
      }
    });
  }
  /*  To find sum of individual plan and selected riders */
  monthlyPlanSubTotal(plan) {
    let monthlySum = 0;
    monthlySum = plan.selected
      ? monthlySum + this.getNumeric(plan.price)
      : monthlySum;
    if (plan.selected && plan.riders && plan.riders.length > 0) {
      plan.riders.forEach(rider => {
        monthlySum = rider.selected
          ? monthlySum + this.getNumeric(rider.price)
          : monthlySum;
      });
    }
    plan.MonthlyPrice = monthlySum.toFixed(2);
    return monthlySum.toFixed(2);
  }

  getNumeric(stringVal) {
    if (isNaN(stringVal)) stringVal = stringVal.replace(/,/g, '');
    return Number(stringVal);
  }
  /* To get coverage types code and default_value from CMS service*/
  getAgentCMSData() {
    this.coverageTypes = {};
    this.cmsService.getKey('agent_portal').subscribe(agentCMSData => {
      if (agentCMSData.coverage_types) {
        agentCMSData.coverage_types.forEach(element => {
          const data = { [element.code]: element.default_value };
          this.coverageTypes = Object.assign(this.coverageTypes, data);
        });
      }
    });
  }
  /* To find the number of selected products inside cart */
  getCartCount() {
    let cartSum = 0;
    this.cartProducts.forEach(plans => {
      cartSum = plans.selected ? cartSum + 1 : cartSum;
    });
    this.cartCount = cartSum;
    return cartSum;
  }

  /* To find the sum of all products selected inside cart */
  CartSubTotal() {
    let sumVal = 0;
    if (this.cartProducts && this.cartProducts.length > 0) {
      this.cartProducts.forEach(element => {
        sumVal = element.MonthlyPrice
          ? sumVal + Number(this.getNumeric(element.MonthlyPrice).toFixed(2))
          : sumVal;
      });
      return sumVal.toFixed(2);
    }
  }

  /* To update monthly cost based on selection */
  onCheckBoxChange(changedVal) {
    if (!changedVal.product.selected) this.changeRiderStatus(changedVal);
    this.monthlyPlanSubTotal(changedVal.product);
  }

  /* To update rider selection based on plan selection */
  changeRiderStatus(data) {
    const riders = data.product.riders;
    riders.forEach(rider => {
      if (rider.selected) {
        rider.selected = false;
        const dataToDispatch = {
          key: 'rider',
          rider: rider,
          product: data.product
        };
      }
    });
  }

  checkIfRiderUnchecked(ridersArray) {
    const filteredArray = ridersArray.filter(e => e.selected === false);
    if (filteredArray.length > 0) {
      return true;
    }
  }

  calculateInitialTotalMonthlyPremium(productPrice, riders) {
    let monthlyPayment = this.getNumeric(productPrice);
    riders.map(item => {
      monthlyPayment = monthlyPayment + this.getNumeric(item.price);
    });
    return monthlyPayment.toFixed(2);
  }
  calculateUpdatedTotalMonthlyPremium(productPrice, riders, isProductSelected) {
    let monthlyPayment = 0;
    if (isProductSelected) {
      monthlyPayment = this.getNumeric(productPrice);
    }
    riders.map(item => {
      if (item.selected) {
        monthlyPayment = monthlyPayment + this.getNumeric(item.price);
      }
    });
    return monthlyPayment.toFixed(2);
  }
  createUpdatedProductsArray() {
    if (this.cartProducts && this.cartProducts.length) {
      this.initialCartSubtotal = 0;
      this.updatedCartSubtotal = 0;
      this.cartProducts.map(item => {
        const isAnyRiderUnchecked = this.checkIfRiderUnchecked(item.riders);
        if (isAnyRiderUnchecked || !item.selected) {
          item.updated = true;
        } else {
          item.updated = false;
        }
        item.initialTotalPremium = this.calculateInitialTotalMonthlyPremium(
          item.price,
          item.riders
        );
        item.updatedTotalPremium = this.calculateUpdatedTotalMonthlyPremium(
          item.price,
          item.riders,
          item.selected
        );
        this.initialCartSubtotal =
          Number(this.initialCartSubtotal) + Number(item.initialTotalPremium);
        this.updatedCartSubtotal =
          Number(this.updatedCartSubtotal) + Number(item.updatedTotalPremium);
      });
    }
    return this.cartProducts;
  }
  showConfirmationPopup() {
    this.updatedItemsList = this.createUpdatedProductsArray();
    const deletedQuotesArray = [];
    this.updatedItemsList.map(el => {
      if (el.selected === false) {
        deletedQuotesArray.push({ productId: el.productId });
      }
    });
    let deletedList = [];
    this.deletedListFiltered = [];

    // result = firstArray.filter(o => secondArray.some(({id,name}) => o.id === id && o.name === name));
    if (
      this.bundleDetails &&
      this.bundleDetails.quotes &&
      this.bundleDetails.quotes.length
    ) {
      deletedList = this.bundleDetails.quotes.filter(o =>
        deletedQuotesArray.some(({ productId }) => o.productCode === productId)
      );
    }
    if (deletedList && deletedList.length > 0) {
      deletedList.map(item => {
        this.deletedListFiltered.push(item.quoteNumber);
      });
    }

    const dialogRef = this.shoppingCartConfirmationDialog.open(
      AgentHeaderShoppingCartConfirmationModalComponent,
      {
        width: '747px',
        panelClass: 'agent-shopping-cart-confirmation-modal',
        disableClose: true,
        data: {
          cartProducts: this.cartProducts,
          initialCartSubtotal: this.initialCartSubtotal,
          updatedCartSubtotal: this.updatedCartSubtotal
        }
      }
    );
    dialogRef.afterClosed().subscribe(res => {
      if (res === true) {
        //update values to store on clicking continue
        this.filterCartWithSelectedQuotes();
        this.cartUpdated.emit();
        this.shoppingCartService.hideShoppingCartModal();
        if (this.updatedCartSubtotal === 0) {
          this.router.navigateByUrl('/home');
        } else if (this.router.url === 'dependents') {
          //  let productsWithCoverageYou= [];
          let productsWithCoverageYou = 0;
          this.finalcartItems.map(el => {
            if (el.coverage === 'ind') {
              // productsWithCoverageYou.push(el);
              productsWithCoverageYou = productsWithCoverageYou + 1;
            }
          });
          //if all products in cart have coverage You, navigate from dependents to eligibility screen
          if (productsWithCoverageYou === this.finalcartItems.length) {
            this.router.navigateByUrl('/eligibility');
          }
        }
      } else if (res === 'cancel' || res === 'close') {
        //reset cart to initial state on clicking cancel
        this.resetCartToInitialState();
        if (res === 'close') {
          this.shoppingCartService.hideShoppingCartModal();
        }
      }
    });
  }
  resetCartToInitialState() {
    const payload = { key: 'from-list', value: this.currentState };
    this.store.dispatch(UpdateCartOnQuoteSave({ payload }));
  }
  filterCartWithSelectedQuotes() {
    let currentQuote = [];
    const filteredQuote = [];
    if (this.cartProducts && this.cartProducts.length > 0) {
      currentQuote = this.cartProducts.filter(item => item.selected);
      currentQuote.forEach(quote => {
        const ridersArray = [];
        if (quote.riders && quote.riders.length) {
          quote.riders.forEach(riderItem => {
            const riderObj = {
              selected: riderItem.selected,
              availableInCart: riderItem.availableInCart,
              productId: quote.productId,
              rider: riderItem.currentRiderState
            };
            ridersArray.push(riderObj);
          });
        }
        const filterItem = {
          productId: quote.productId,
          productName: quote.productName,
          // plan: quote.plan,
          plan: quote.currentPlanState,
          availableInCart: quote.availableInCart,
          selected: quote.selected,
          coverage: quote.coverageType,
          startingPrice: quote.startingPrice,
          selectedRiders:
            ridersArray && ridersArray.length
              ? ridersArray.filter(rider => rider.selected)
              : [],
          tobaccoInd: quote.tobaccoInd,
          cancerCoverage: quote.cancerCoverage,
          benefitAmount: quote.benefitAmount
        };
        filteredQuote.push(filterItem);
        this.filteredQuoteGlobal.push(filterItem);
      });
    }

    if (
      this.filteredQuoteGlobal &&
      this.filteredQuoteGlobal.length &&
      this.bundleDetails &&
      this.bundleDetails.quotes &&
      this.bundleDetails.quotes.length
    ) {
      this.filteredQuoteGlobal.map(item => {
        this.bundleDetails.quotes.map(element => {
          if (element.productCode === item.productId) {
            item.quoteNumber = element.quoteNumber;
          }
        });
        return item;
      });
    }

    let cartItemsCount = 0;
    filteredQuote.forEach(plans => {
      cartItemsCount = cartItemsCount + 1;
    });
    this.cartCount = cartItemsCount;
    const headerPayload = {
      price: this.updatedCartSubtotal.toFixed(2),
      count: this.cartCount
    };
    this.finalcartItems = filteredQuote;
    this.shoppingCartService.updateShoppingCartPrice(headerPayload);
    const payload = { key: 'from-list', value: filteredQuote };
    this.store.dispatch(UpdateCartOnQuoteSave({ payload }));
    //update quote
    if (
      this.filteredQuoteGlobal &&
      this.filteredQuoteGlobal.length &&
      this.bundleDetails &&
      this.bundleDetails.quotes &&
      this.bundleDetails.quotes.length
    ) {
      const updateQuoteInputParams = this.agentSharedService.createUpdateQuoteReqParams(
        {
          bundleId: this.bundleDetails.quotes[0].bundleId,
          selectedPlans: this.filteredQuoteGlobal,
          removedQuotes: this.deletedListFiltered
        }
      );
      this.savedQuoteStore.dispatch(
        updateQuote({
          payload: updateQuoteInputParams,
          isValidateRequired: 'N'
        })
      );
    }
  }
}
