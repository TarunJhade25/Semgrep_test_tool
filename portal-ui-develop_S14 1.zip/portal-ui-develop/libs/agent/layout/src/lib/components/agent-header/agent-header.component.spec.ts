import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { MockStore } from '@ngrx/store/testing';
import { StoreModule, Store } from '@ngrx/store';
import { RouterModule } from '@angular/router';
import * as fromAgent from '@aflac/agent/shared';
import { Agent, agentReducer } from '@aflac/agent/shared';
import { AgentHeaderComponent } from './agent-header.component';
import { APP_BASE_HREF } from '@angular/common';
import { MatDialogModule } from '@angular/material/dialog';

describe('AgentHeaderComponent', () => {
  let component: AgentHeaderComponent;
  let fixture: ComponentFixture<AgentHeaderComponent>;
  let mockStore: MockStore<any>;
  let agentStore: Store<Agent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [AgentHeaderComponent],
      imports: [
        StoreModule.forRoot({ agentReducer }),
        StoreModule.forFeature(
          fromAgent.agentFeatureKey,
          fromAgent.agentReducer
        ),
        RouterModule.forRoot([]),
        MatDialogModule
      ],
      providers: [{ provide: APP_BASE_HREF, useValue: '/' }]
    }).compileComponents();
  }));

  beforeEach(() => {
    agentStore = TestBed.get(Store);
    mockStore = TestBed.get(Store);
    fixture = TestBed.createComponent(AgentHeaderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create component', () => {
    expect(component).toBeTruthy();
  });

  it('should initialize agentProfile', () => {
    expect(component.agentProfile$).toBeDefined();
  });
  it('should open AgentShoppingCartModalComponent from openShoppingCartDialog function', () => {
    spyOn(component.dialogRef, 'open');
    component.openShoppingCartDialog();
    expect(component.dialogRef.open).toHaveBeenCalled();
  });
});
