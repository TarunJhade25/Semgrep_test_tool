import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { TranslateModule } from '@ngx-translate/core';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { AgentHeaderShoppingCartContentComponent } from './agent-header-shopping-cart-content.component';
import {
  MatDialogModule,
  MatDialogRef,
  MAT_DIALOG_DATA
} from '@angular/material/dialog';
import { provideMockStore, MockStore } from '@ngrx/store/testing';
import { StoreModule, Store, MemoizedSelector } from '@ngrx/store';
import { of } from 'rxjs';
import { RouterTestingModule } from '@angular/router/testing';
import { Router } from '@angular/router';
import { ProductState } from '@aflac/agent/shared';
import * as fromProduct from '@aflac/agent/shared';
import { CmsService } from '@aflac/shared/cms';
const selectedPlans = {
  key: 'from-list',
  value: [
    {
      productId: 'PREC-IC',
      productName: 'Accident',
      plan: {
        id: 123,
        price: '100',
        description: 'These are the benefits',
        name: 'Lorem ipsum',
        states: ['AL', 'CT'],
        title: 'Standard Plan',
        benefits: [
          {
            id: 333,
            name: 'test',
            price: 123
          }
        ]
      },
      coverage: 'ind',
      selected: true,
      availableInCart: true,
      selectedRiders: [
        {
          rider: { title: 'title1', price: '100' },
          selected: true,
          availableInCart: true,
          plan: { id: 'id1' }
        },
        {
          rider: { title: 'title2', price: '200' },
          selected: true,
          availableInCart: true,
          plan: { id: 'id1' }
        }
      ]
    }
  ]
};
const headerCartParams = {
  disabled: true,
  shoppingCarModalWrapper: 'disabled-cart'
};
const coverageTypes = [
  {
    code: 'ind',
    default_value: 'You'
  },
  {
    code: 'ind_sps',
    default_value: 'You & Your Spouse'
  }
];
const updatedRiderVal = {
  key: 'rider',
  product: {
    productId: 'PREC-IC',
    productName: 'Cancer Insurance',
    plan: 'Standard Plan',
    coverageType: 'ind',
    price: 16.93,
    selected: true,
    availableInCart: true
  },
  riders: [],
  benefitAmount: undefined,
  tobaccoInd: undefined,
  cancerCoverage: undefined,
  MonthlyPrice: '516.93'
};

//new
const updatedRiderArray = [
  {
    productId: 'PREC-IC',
    productName: 'Accident',
    plan: {
      id: 123,
      price: '100',
      description: 'These are the benefits',
      name: 'Lorem ipsum',
      states: ['AL', 'CT'],
      title: 'Standard Plan',
      benefits: [
        {
          id: 333,
          name: 'test',
          price: 123
        }
      ]
    },
    updated: true,
    coverage: 'ind',
    initialTotalPremium: '100.00',
    updatedTotalPremium: '90.00',
    selected: true,
    availableInCart: true,
    selectedRiders: [
      {
        rider: { title: 'title1', price: '100' },
        selected: true,
        availableInCart: true,
        plan: { id: 'id1' }
      },
      {
        rider: { title: 'title2', price: '200' },
        selected: true,
        availableInCart: true,
        plan: { id: 'id1' }
      }
    ]
  }
];
const ridersArrayInput = [
  {
    selected: true,
    price: 100
  }
];
class RouterStub {
  navigateByUrl(url: string) {
    return url;
  }
}
// class DialogMock {
//   _containerInstance = { _config: { width: '380px' } };
//   updatePosition() {}
//   close() {}
// }

describe('AgentHeaderShoppingCartContentComponent', () => {
  let component: AgentHeaderShoppingCartContentComponent;
  let fixture: ComponentFixture<AgentHeaderShoppingCartContentComponent>;
  let mockStore: MockStore<any>;
  let store: Store<ProductState>;
  let mockSelectedPlanSelector: MemoizedSelector<any, any>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [AgentHeaderShoppingCartContentComponent],
      imports: [
        TranslateModule.forRoot(),
        MatDialogModule,
        RouterTestingModule
      ],
      providers: [
        provideMockStore({}),
        { provide: CmsService, useClass: MockCmsService },
        { provide: Router, useClass: RouterStub }
        // {
        //   provide: MAT_DIALOG_DATA,
        //   useValue: {}
        // },
        // {
        //   provide: MatDialogRef,
        //   useClass: DialogMock
        // }
      ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AgentHeaderShoppingCartContentComponent);
    mockStore = TestBed.get(Store);
    store = TestBed.get(Store);
    mockSelectedPlanSelector = mockStore.overrideSelector(
      fromProduct.selectedPlans,
      selectedPlans
    );
    mockStore.overrideSelector(
      fromProduct.getHeaderShoppingCartParams,
      headerCartParams
    );

    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should call mapBenefitAmount function and return value', () => {
    const intDiagnosisBenefitAmount = 10000;
    const result = component.mapBenefitAmount(intDiagnosisBenefitAmount);
    expect(result).toEqual('$10K');
  });

  it('should return the cart count', () => {
    component.cartProducts = selectedPlans.value;
    component.getCartCount();
    expect(component.cartCount).toEqual(1);
  });

  it('should update monthlyPlanSubTotal on checkbox change', () => {
    spyOn(component, 'monthlyPlanSubTotal').and.callThrough();
    component.onCheckBoxChange(updatedRiderVal);
    expect(component.monthlyPlanSubTotal).toBeDefined();
  });
  it('should return true if a rider is unchecked', () => {
    const ridersArray = [
      {
        selected: false
      }
    ];
    const result = component.checkIfRiderUnchecked(ridersArray);
    expect(result).toEqual(true);
  });
  it('should return initial total monthly premium', () => {
    const productPrice = 100;
    const riders = [
      {
        price: 10
      }
    ];
    const result = component.calculateInitialTotalMonthlyPremium(
      productPrice,
      riders
    );
    expect(result).toEqual('110.00');
  });
  it('should call filterCartWithSelectedQuotes function', () => {
    component.cartProducts = selectedPlans.value;
    component.cartCount = 1;
    spyOn(component, 'filterCartWithSelectedQuotes').and.callThrough();
    component.filterCartWithSelectedQuotes();
    expect(component.cartCount).toEqual(1);
  });

  it('should create products array with premium details', () => {
    component.cartProducts = selectedPlans.value;
    spyOn(component, 'checkIfRiderUnchecked').and.returnValue(true);
    spyOn(component, 'calculateInitialTotalMonthlyPremium').and.returnValue(
      '100.00'
    );
    spyOn(component, 'calculateUpdatedTotalMonthlyPremium').and.returnValue(
      '90.00'
    );
    const processedArray = component.createUpdatedProductsArray();
    expect(processedArray).toEqual(updatedRiderArray);
  });
  it('should call filterCartWithSelectedQuotes from showConfirmationPopup function', () => {
    component.cartProducts = selectedPlans.value;
    spyOn(component, 'createUpdatedProductsArray').and.returnValue(
      updatedRiderArray
    );
    spyOn(component, 'filterCartWithSelectedQuotes').and.callThrough();
    spyOn(component.shoppingCartConfirmationDialog, 'open').and.returnValue({
      afterClosed: () => of(true)
    });
    component.showConfirmationPopup();
    expect(component.filterCartWithSelectedQuotes).toHaveBeenCalled();
  });
  it('should calculate updated premium from calculateUpdatedTotalMonthlyPremium function', () => {
    spyOn(component, 'getNumeric').and.returnValue(100);
    const result = component.calculateUpdatedTotalMonthlyPremium(
      100,
      ridersArrayInput,
      false
    );
    expect(result).toEqual('100.00');
  });

  class MockCmsService {
    getKey(key: string | Array<string>, interpolateParams?: Object): any {
      const data = { coverageTypes: coverageTypes };
      return of(data);
    }
  }
});
