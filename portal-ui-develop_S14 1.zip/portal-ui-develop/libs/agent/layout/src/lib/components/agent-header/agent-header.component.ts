import {
  Component,
  OnInit,
  ChangeDetectorRef,
  AfterViewChecked
} from '@angular/core';
import { Store, select } from '@ngrx/store';
import { Observable } from 'rxjs';
import { Router, ActivationEnd, NavigationEnd } from '@angular/router';
import {
  ProductState,
  SetHeaderShoppingCartParams,
  getHeaderShoppingCartParams
} from '@aflac/agent/shared';
import { Agent } from '@aflac/agent/shared';
import { getAgentProfile } from '@aflac/agent/shared';
import { AgentProfile } from '../../model/agent-profile.model';
import cssVars from 'css-vars-ponyfill';
import { ColorSchemeService } from '@aflac/shared/ui';
import { ShoppingCartService } from '@aflac/agent/shared';
import { MatDialog } from '@angular/material/dialog';
import { AgentShoppingCartModalComponent } from '../agent-shopping-cart-modal/agent-shopping-cart-modal.component';
import { AgentLogoutComponent } from '@aflac/agent/shared';
@Component({
  selector: 'aflac-agent-header',
  templateUrl: './agent-header.component.html',
  styleUrls: ['./agent-header.component.scss']
})
export class AgentHeaderComponent implements OnInit, AfterViewChecked {
  agentHeaderPathFlag: boolean;
  agentProfile$: Observable<AgentProfile>;
  displayCart: boolean;
  headerCartPrice: any;
  headerCartCount: any;
  showHeader: any;
  headerShoppingCartInput;
  agentInfo: any;
  constructor(
    private agentStore: Store<Agent>,
    public router: Router,
    private colorSvc: ColorSchemeService,
    private shoppingCartService: ShoppingCartService,
    private cdr: ChangeDetectorRef,
    public dialogRef: MatDialog,
    private productStore: Store<ProductState>
  ) {}

  ngOnInit() {
    this.headerCartPrice = Number(0).toFixed(2);
    this.headerCartCount = 0;
    this.showHeader = true;
    this.fetchlatestQuotePrice();
    this.agentProfile$ = this.agentStore.pipe(select(getAgentProfile));
    this.agentProfile$.subscribe(res => {
      if (res) {
        this.agentInfo = res;
        sessionStorage.setItem('agent-information', JSON.stringify(res));
      }
    });
    this.router.events.subscribe(val => {
      if (val instanceof ActivationEnd) {
        this.agentHeaderPathFlag = val.snapshot.data.agentHeaderFlag
          ? val.snapshot.data.agentHeaderFlag
          : undefined;
      }
      // TODO: for shopping cart integration in header
      if (val instanceof NavigationEnd) {
        const routeData = val;
        this.displayCart = false;
        if (
          routeData.url === '/quotes/save-your-progress' ||
          routeData.url === '/dependents' ||
          routeData.url === '/eligibility' ||
          routeData.url === '/my-details' ||
          routeData.url === '/order-review' ||
          routeData.url === '/check-out-payment-details' ||
          routeData.url === '/checkout'
        ) {
          this.displayCart = true;
        }
        if (routeData.url === '/identity-error') {
          this.showHeader = false;
        }
        this.headerShoppingCartInput = {
          disabled: false,
          shoppingCarModalWrapper: 'enabled-cart'
        };

        if (
          routeData.url === '/eligibility' ||
          routeData.url === '/dependents'
        ) {
          this.headerShoppingCartInput = {
            disabled: true,
            shoppingCarModalWrapper: 'temporarily-disabled-cart'
          };
        }
        if (
          routeData.url === '/check-out-payment-details' ||
          routeData.url === '/checkout'
        ) {
          this.headerShoppingCartInput = {
            disabled: true,
            shoppingCarModalWrapper: 'disabled-cart'
          };
        }
        this.productStore.dispatch(
          SetHeaderShoppingCartParams({
            payload: this.headerShoppingCartInput
          })
        );
      }
    });
    cssVars({
      variables: this.colorSvc.getVariableMapping('light'),
      onlyLegacy: false,
      watch: true
    });
    this.getShoppingCartModalVisibilityStatus();
  }

  ngAfterViewChecked() {
    this.cdr.detectChanges();
  }
  getShoppingCartModalVisibilityStatus() {
    this.shoppingCartService.cartUpdateData.subscribe(res => {
      if (res) {
        this.dialogRef.closeAll();
      }
      this.cdr.detectChanges();
    });
  }

  fetchlatestQuotePrice() {
    this.shoppingCartService.data.subscribe(res => {
      //add to session storage
      this.headerCartPrice =
        res && res['price'] !== undefined ? res['price'] : this.headerCartPrice;
      this.headerCartCount =
        res && res['count'] !== undefined ? res['count'] : this.headerCartCount;
      this.cdr.detectChanges();
    });
  }

  /*Shopping cart dialog*/
  openShoppingCartDialog() {
    //open shopping cart only if it is not already opened
    const shoppingCartPopupOverlay = document.getElementsByClassName(
      'agent-shopping-cart-backdrop'
    );
    if (shoppingCartPopupOverlay && shoppingCartPopupOverlay.length === 0) {
      this.dialogRef.open(AgentShoppingCartModalComponent, {
        width: '778px',
        panelClass: 'agent-shopping-cart-modal-wrapper',
        backdropClass: 'agent-shopping-cart-backdrop'
      });
    }
  }
  logout() {
    let agentProfile;
    if (this.agentInfo && Object.keys(this.agentInfo).length) {
      agentProfile = this.agentInfo;
    } else {
      agentProfile = JSON.parse(sessionStorage.getItem('agent-information'));
    }
    this.dialogRef.open(AgentLogoutComponent, {
      width: '600px',
      height: '278px',
      disableClose: true,
      panelClass: 'agent-logout-wrapper',
      data: { payload: agentProfile }
    });
  }
}
