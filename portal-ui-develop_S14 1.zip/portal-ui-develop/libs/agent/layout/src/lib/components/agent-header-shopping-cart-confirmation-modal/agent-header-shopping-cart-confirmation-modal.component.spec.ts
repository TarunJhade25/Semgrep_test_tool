import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { TranslateModule } from '@ngx-translate/core';
import { AgentHeaderShoppingCartConfirmationModalComponent } from './agent-header-shopping-cart-confirmation-modal.component';
import {
  MatDialogModule,
  MatDialogRef,
  MAT_DIALOG_DATA
} from '@angular/material/dialog';
import { CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA } from '@angular/core';

const modalInput = {
  cartProducts: [
    {
      productId: 'PREC-IC',
      productName: 'Cancer Insurance',
      plan: 'Standard Plan',
      coverageType: 'ind',
      price: 16.93,
      selected: false,
      availableInCart: true,
      currentPlanState: {
        id: 'plan07',
        name: 'Lorem ipsum dolor sit',
        title: 'Standard Plan',
        description: 'These are the benefits that you cash.'
      },
      riders: [],
      benefitAmount: undefined,
      tobaccoInd: undefined,
      cancerCoverage: undefined,
      MonthlyPrice: '0.00',
      updated: true,
      initialTotalPremium: '16.93',
      updatedTotalPremium: '0.00'
    }
  ],
  initialCartSubtotal: 16.93,
  updatedCartSubtotal: 0
};
const dialogMock = {
  close: () => {}
};
describe('AgentHeaderShoppingCartConfirmationModalComponent', () => {
  let component: AgentHeaderShoppingCartConfirmationModalComponent;
  let fixture: ComponentFixture<
    AgentHeaderShoppingCartConfirmationModalComponent
  >;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [AgentHeaderShoppingCartConfirmationModalComponent],
      imports: [TranslateModule.forRoot(), MatDialogModule],
      schemas: [CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA],
      providers: [
        {
          provide: MatDialogRef,
          useValue: dialogMock
        },
        { provide: MAT_DIALOG_DATA, useValue: modalInput }
      ]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(
      AgentHeaderShoppingCartConfirmationModalComponent
    );
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
  it('getNumeric function should reurn number value', () => {
    const result = component.getNumeric('100');
    expect(result).toEqual(100);
  });
  it('should close the dialog from onSubmit function', () => {
    spyOn(component.dialogRef, 'close');
    component.onSubmit();
    expect(component.dialogRef.close).toHaveBeenCalledWith(true);
  });
  it('should close the dialog from cancelChanges function', () => {
    spyOn(component.dialogRef, 'close');
    component.cancelChanges();
    expect(component.dialogRef.close).toHaveBeenCalledWith('cancel');
  });
  it('should close the dialog from closeConfirmationModal closeConfirmationModal', () => {
    spyOn(component.dialogRef, 'close');
    component.closeConfirmationModal();
    expect(component.dialogRef.close).toHaveBeenCalledWith('close');
  });
});
