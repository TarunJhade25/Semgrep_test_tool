import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { provideMockStore, MockStore } from '@ngrx/store/testing';
import { StoreModule, Store, MemoizedSelector } from '@ngrx/store';
import { AgentShoppingCartModalComponent } from './agent-shopping-cart-modal.component';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { MatDialogModule, MatDialogRef } from '@angular/material/dialog';
import { ProductState } from '@aflac/agent/shared';
import * as fromProduct from '@aflac/agent/shared';
import { TranslateModule } from '@ngx-translate/core';
const headerCartParams = {
  disabled: true,
  shoppingCarModalWrapper: 'disabled-cart'
};
describe('AgentShoppingCartModalComponent', () => {
  let component: AgentShoppingCartModalComponent;
  let fixture: ComponentFixture<AgentShoppingCartModalComponent>;
  let mockStore: MockStore<any>;
  let store: Store<ProductState>;
  let mockSelectedPlanSelector: MemoizedSelector<any, any>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [MatDialogModule, TranslateModule.forRoot()],
      declarations: [AgentShoppingCartModalComponent],
      providers: [
        provideMockStore({}),
        {
          provide: MatDialogRef,
          useValue: {}
        }
      ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AgentShoppingCartModalComponent);
    mockStore = TestBed.get(Store);
    store = TestBed.get(Store);
    mockSelectedPlanSelector = mockStore.overrideSelector(
      fromProduct.getHeaderShoppingCartParams,
      headerCartParams
    );
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
