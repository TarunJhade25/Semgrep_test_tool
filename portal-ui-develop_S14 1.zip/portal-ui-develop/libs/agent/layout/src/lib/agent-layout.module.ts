import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { StoreModule } from '@ngrx/store';
import { SharedCmsModule } from '@aflac/shared/cms';
import { SharedvalidatorsModule } from '@aflac/shared/validators';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { MatAutocompleteModule } from '@angular/material/autocomplete';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatRadioModule } from '@angular/material/radio';
import { MatCheckboxModule } from '@angular/material/checkbox';
import {
  PerfectScrollbarModule,
  PerfectScrollbarConfigInterface,
  PERFECT_SCROLLBAR_CONFIG
} from 'ngx-perfect-scrollbar';
const DEFAULT_PERFECT_SCROLLBAR_CONFIG: PerfectScrollbarConfigInterface = {
  wheelPropagation: true
};
import { SharedMaterialModule } from '@aflac/shared/material';
import { SharedPipesModule } from '@aflac/shared/pipes';
import { AgentHeaderComponent } from './components/agent-header/agent-header.component';
import { AgentShoppingCartModalComponent } from './components/agent-shopping-cart-modal/agent-shopping-cart-modal.component';
import { AgentHeaderShoppingCartContentComponent } from './components/agent-header-shopping-cart-content/agent-header-shopping-cart-content.component';
import { AgentHeaderShoppingCartConfirmationModalComponent } from './components/agent-header-shopping-cart-confirmation-modal/agent-header-shopping-cart-confirmation-modal.component';

@NgModule({
  imports: [
    CommonModule,
    SharedCmsModule,
    SharedvalidatorsModule,
    MatAutocompleteModule,
    MatFormFieldModule,
    MatInputModule,
    SharedMaterialModule,
    SharedPipesModule,
    MatRadioModule,
    MatCheckboxModule,
    ReactiveFormsModule,
    FormsModule,
    PerfectScrollbarModule
  ],
  providers: [
    {
      provide: PERFECT_SCROLLBAR_CONFIG,
      useValue: DEFAULT_PERFECT_SCROLLBAR_CONFIG
    }
  ],
  declarations: [
    AgentHeaderComponent,
    AgentShoppingCartModalComponent,
    AgentHeaderShoppingCartContentComponent,
    AgentHeaderShoppingCartConfirmationModalComponent
  ],
  exports: [AgentHeaderComponent],
  entryComponents: [
    AgentShoppingCartModalComponent,
    AgentHeaderShoppingCartConfirmationModalComponent
  ]
})
export class AgentLayoutModule {}
