export interface AgentProfile {
  agencyCd: string;
  agencyName: string;
  // agentId: string;
  subProducerCd: string;
  firstName: string;
  middleName: string;
  lastName: string;
  electronicSignature: boolean;
  voiceRecording: boolean;
}
