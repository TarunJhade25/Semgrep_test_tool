import { async, TestBed } from '@angular/core/testing';
import { AgentLayoutModule } from './agent-layout.module';

describe('AgentLayoutModule', () => {
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [AgentLayoutModule]
    }).compileComponents();
  }));

  it('should create', () => {
    expect(AgentLayoutModule).toBeDefined();
  });
});
