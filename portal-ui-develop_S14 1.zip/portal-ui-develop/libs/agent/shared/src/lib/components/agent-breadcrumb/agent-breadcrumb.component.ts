import { Component, OnInit } from '@angular/core';
import { Router, NavigationEnd, ActivatedRoute } from '@angular/router';
import { CmsService } from '@aflac/shared/cms';
import { PageNavigationService } from '../../services/page-navigation.service';

@Component({
  selector: 'aflac-agent-breadcrumb',
  templateUrl: './agent-breadcrumb.component.html',
  styleUrls: ['./agent-breadcrumb.component.scss']
})
export class AgentBreadcrumbComponent implements OnInit {
  public showBreadcrumb = false;
  public backButtonText: string;
  public pageType: string;
  public buttonLabel: any;
  public routeData: any;
  constructor(
    private router: Router,
    private activatedRoute: ActivatedRoute,
    private cmsService: CmsService,
    private navigationService: PageNavigationService
  ) {}

  ngOnInit() {
    this.cmsService.getKey('agent_portal').subscribe(data => {
      this.buttonLabel = data['agent_breadcrumb_button_text'];
      this.backButtonText = this.buttonLabel && this.buttonLabel['start_quote'];
    });
    this.router.events.subscribe(val => {
      if (val instanceof NavigationEnd) {
        this.routeData = val;
        if (val) this.activateBreadcrumb();
      }
    });
    this.subscribeBackButtonEvent();
  }
  activateBreadcrumb() {
    if (this.routeData) {
      if (this.routeData.url.includes('/quotes/compare/')) {
        this.showBreadcrumb = false;
      } else if (
        this.routeData.url.includes('/quotes') ||
        this.routeData.url.includes('/dependents') ||
        this.routeData.url.includes('/eligibility') ||
        this.routeData.url.includes('/my-details') ||
        this.routeData.url.includes('/identity-error') ||
        this.routeData.url.includes('/order-review') ||
        this.routeData.url.includes('/check-out-payment-details') ||
        this.routeData.url.includes('/checkout') ||
        this.routeData.url.includes('/system-error')
      ) {
        this.showBreadcrumb = true;
      } else {
        this.showBreadcrumb = false;
      }
    }
  }
  navigateBack() {
    this.router.navigateByUrl('home');
  }

  subscribeBackButtonEvent() {
    this.navigationService.data.subscribe(data => {
      if (data && data['isButtonClicked'] === true) {
        window.history.back();
        this.checkPage();
      }
    });
  }
  checkPage() {
    setTimeout(() => {
      window.scrollTo(0, 0);
      const span = document.getElementById('plan-close');
      if (span !== null && span !== undefined) span.click();
    }, 100);
  }
}
