import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'aflac-agent-notification',
  templateUrl: './agent-notification.component.html',
  styleUrls: ['./agent-notification.component.scss']
})
export class AgentNotificationComponent implements OnInit {
  constructor() {}
  img;
  alt;
  @Input()
  type;
  @Input()
  content;

  ngOnInit() {
    if (this.type === 'error') {
      this.img = 'assets/images/top_bar_error.svg';
      this.alt = 'error';
    } else if (this.type === 'warning') {
      this.img = 'assets/images/top_bar_warning.svg';
      this.alt = 'warning';
    } else if (this.type === 'success') {
      this.img = 'assets/images/top_bar_success.svg';
      this.alt = 'success';
    }
  }
}
