import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PrivacyAndTermsInfoFooterComponent } from './privacy-and-terms-info-footer.component';
import { TranslateModule } from '@ngx-translate/core';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';

describe('PrivacyAndTermsInfoFooterComponent', () => {
  let component: PrivacyAndTermsInfoFooterComponent;
  let fixture: ComponentFixture<PrivacyAndTermsInfoFooterComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [TranslateModule.forRoot()],
      declarations: [PrivacyAndTermsInfoFooterComponent],
      schemas: [CUSTOM_ELEMENTS_SCHEMA]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PrivacyAndTermsInfoFooterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
