import { Component, OnInit } from '@angular/core';
import { Router, NavigationEnd } from '@angular/router';

@Component({
  selector: 'aflac-agent-footer',
  templateUrl: './agent-footer.component.html',
  styleUrls: ['./agent-footer.component.scss']
})
export class AgentFooterComponent implements OnInit {
  showFooter: any;
  constructor(public router: Router) {
    this.showFooter = true;
  }

  ngOnInit() {
    this.getCurrentPage();
  }
  getCurrentPage() {
    this.router.events.subscribe(val => {
      // TODO: for shopping cart integration in header
      if (val instanceof NavigationEnd) {
        const routeData = val;
        if (routeData.url.includes('identity-error')) {
          this.showFooter = false;
        }
      }
    });
  }
}
