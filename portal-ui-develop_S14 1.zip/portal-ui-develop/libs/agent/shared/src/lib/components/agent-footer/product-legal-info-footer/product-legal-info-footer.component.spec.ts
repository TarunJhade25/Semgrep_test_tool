import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { ProductLegalInfoFooterComponent } from './product-legal-info-footer.component';
import { ReplaySubject } from 'rxjs';
import { RouterEvent, NavigationEnd, Router } from '@angular/router';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { TranslateModule } from '@ngx-translate/core';

describe('ProductLegalInfoFooterComponent', () => {
  let component: ProductLegalInfoFooterComponent;
  const eventSubject = new ReplaySubject<RouterEvent>(1);
  let fixture: ComponentFixture<ProductLegalInfoFooterComponent>;
  const MockRouter = {
    ne: new NavigationEnd(0, '/', '/'),
    events: eventSubject.asObservable(),
    url: ''
  };

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [TranslateModule.forRoot(), BrowserAnimationsModule],

      declarations: [ProductLegalInfoFooterComponent],
      providers: [{ provide: Router, useValue: MockRouter }],
      schemas: [CUSTOM_ELEMENTS_SCHEMA]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ProductLegalInfoFooterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should set showDisclaimer on the url `/`', () => {
    eventSubject.next(new NavigationEnd(0, '/', '/'));
    component.getCurrentPage();
    expect(component.showDisclaimer).toBeTruthy();
  });

  it('should set showDisclaimer on the url `/home`', () => {
    eventSubject.next(new NavigationEnd(0, '/home', '/home'));
    component.getCurrentPage();
    expect(component.showDisclaimer).toBeTruthy();
  });

  it('should set showDisclaimer on the url `/quotes`', () => {
    eventSubject.next(new NavigationEnd(0, '/quotes', '/quotes'));
    component.getCurrentPage();
    expect(component.showDisclaimer).toBeTruthy();
  });

  it('should set showDisclaimer on the url `/compare`', () => {
    eventSubject.next(new NavigationEnd(0, '/compare', '/compare'));
    component.getCurrentPage();
    expect(component.showDisclaimer).toBeTruthy();
  });

  it('should set showDisclaimer on the url `/order-review`', () => {
    eventSubject.next(new NavigationEnd(0, '/order-review', '/order-review'));
    component.getCurrentPage();
    expect(component.showDisclaimer).toBeTruthy();
  });

  it('should set showDisclaimer false on the url `/test`', () => {
    eventSubject.next(new NavigationEnd(0, '/test', '/test'));
    component.getCurrentPage();
    expect(component.showDisclaimer).toBeFalsy();
  });

  it('should set showDisclaimer false on the save your quote  page ', () => {
    eventSubject.next(
      new NavigationEnd(
        0,
        '/products/save-your-quote',
        '/products/save-your-quote'
      )
    );
    component.getCurrentPage();
    expect(component.showDisclaimer).toBeFalsy();
  });
});
