import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { ReplaySubject } from 'rxjs';
import { Router, RouterEvent, NavigationEnd } from '@angular/router';
import { AgentFooterComponent } from './agent-footer.component';
import { RouterTestingModule } from '@angular/router/testing';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';

describe('AgentFooterComponent', () => {
  let component: AgentFooterComponent;
  const eventSubject = new ReplaySubject<RouterEvent>(1);
  let fixture: ComponentFixture<AgentFooterComponent>;
  const MockRouter = {
    ne: new NavigationEnd(0, '/', '/'),
    events: eventSubject.asObservable(),
    url: ''
  };

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [AgentFooterComponent],
      imports: [RouterTestingModule],
      providers: [{ provide: Router, useValue: MockRouter }],
      schemas: [CUSTOM_ELEMENTS_SCHEMA]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AgentFooterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
  it('should hide the footer on the url `/identity-error`', () => {
    eventSubject.next(
      new NavigationEnd(0, '/identity-error', '/identity-error')
    );
    component.getCurrentPage();
    expect(component.showFooter).toBeFalsy();
  });
});
