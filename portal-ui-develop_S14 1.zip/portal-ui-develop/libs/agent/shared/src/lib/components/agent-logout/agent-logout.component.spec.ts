import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import {
  MatDialogRef,
  MatDialogModule,
  MAT_DIALOG_DATA
} from '@angular/material/dialog';

import { AgentLogoutComponent } from './agent-logout.component';

class DialogMock {
  close() {
    return true;
  }
  afterAll() {
    return true;
  }
}
const modalPayload = {
  firstName: 'dummy',
  middleName: '',
  lastName: 'user'
};
describe('AgentLogoutComponent', () => {
  let component: AgentLogoutComponent;
  let fixture: ComponentFixture<AgentLogoutComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [AgentLogoutComponent],
      imports: [MatDialogModule],
      providers: [
        { provide: MatDialogRef, useClass: DialogMock },
        { provide: MAT_DIALOG_DATA, useValue: { payload: modalPayload } }
      ]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AgentLogoutComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
  /*   it('should logout from current session', () => { //Removed because it delays the execution
      component.agentLogout();
      expect(component as any).toBeDefined();
    }); */
});
