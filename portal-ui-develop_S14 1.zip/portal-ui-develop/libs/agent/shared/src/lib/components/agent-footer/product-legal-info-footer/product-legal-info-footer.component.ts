import { CmsService } from '@aflac/shared/cms';
import { Component, OnInit, ViewChild } from '@angular/core';
import { MatExpansionPanel } from '@angular/material/expansion';
import { NavigationEnd, ActivationEnd, Router } from '@angular/router';
import { Store } from '@ngrx/store';
@Component({
  selector: 'aflac-agent-product-legal-info-footer',
  templateUrl: './product-legal-info-footer.component.html',
  styleUrls: ['./product-legal-info-footer.component.scss']
})
export class ProductLegalInfoFooterComponent implements OnInit {
  showDisclaimerText1 = false;
  showDisclaimer;
  isExpanded;

  @ViewChild('accordion', { static: true }) accordion: MatExpansionPanel;
  parterFooterData: any;
  partnerLanding: boolean;

  constructor(public _router: Router) {
    this.urlBasedDisclaimerCheck(this._router.url);
  }
  ngOnInit() {
    this.getCurrentPage();
  }

  /**Check component */
  getCurrentPage() {
    this._router.events.subscribe(val => {
      if (this.isExpanded) {
        this.isExpanded = false;
      }
      if (val instanceof NavigationEnd) {
        this.urlBasedDisclaimerCheck(val['url']);
      }
    });
  }

  /**Method to check for the disclaimer visibility on each pages */
  urlBasedDisclaimerCheck(url) {
    if (
      url === '/' ||
      url === '/quotes' ||
      url.includes('compare') ||
      url.includes('home') ||
      url.includes('order-review')
    ) {
      this.showDisclaimer = true;
    } else {
      this.showDisclaimer = false;
    }
  }
}
