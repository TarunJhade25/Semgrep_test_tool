import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AgentLoaderComponent } from './agent-loader.component';
import { AgentLoaderService } from '../../services/agent-loader.service';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { LoaderService } from '@aflac/shared/layout';
import { BehaviorSubject, of } from 'rxjs';

describe('AgentLoaderComponent', () => {
  let component: AgentLoaderComponent;
  let fixture: ComponentFixture<AgentLoaderComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [AgentLoaderComponent],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
      providers: [{ provide: AgentLoaderService, useClass: MockLoaderService }]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AgentLoaderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

//MockClass
class MockLoaderService {
  private _loader = new BehaviorSubject({ getValue: false });

  setLoader(loaderFlag: boolean) {
    this._loader.next({ getValue: loaderFlag });
  }

  isLoading(): any {
    return of(false);
  }
}
