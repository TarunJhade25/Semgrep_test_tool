import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { RouterModule, NavigationEnd } from '@angular/router';
import { TranslateModule, TranslateLoader } from '@ngx-translate/core';
import { APP_BASE_HREF } from '@angular/common';

import { Router } from '@angular/router';
import { AgentBreadcrumbComponent } from './agent-breadcrumb.component';
import { RouterTestingModule } from '@angular/router/testing';
import { of, Observable } from 'rxjs';

const buttonLabel = {
  compare_plan: 'back',
  start_quote: 'Return to quotes'
};

class RouterStub {
  navigate = new Promise((resolve, reject) => {
    resolve(true);
  });
  navigateByUrl(url: string) {
    return url;
  }
}

describe('AgentBreadcrumbComponent', () => {
  let component: AgentBreadcrumbComponent;
  let fixture: ComponentFixture<AgentBreadcrumbComponent>;
  let router: Router;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [AgentBreadcrumbComponent],
      imports: [
        TranslateModule.forRoot(),
        RouterTestingModule
        //  RouterModule.forRoot([])
      ],
      providers: [{ provide: APP_BASE_HREF, useValue: '/' }]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AgentBreadcrumbComponent);
    component = fixture.componentInstance;
    router = TestBed.get(Router);
    spyOn(router, 'navigateByUrl').and.returnValue(of(true));
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should  not enable back button and change button label for compare plan page', () => {
    component.buttonLabel = buttonLabel;
    component.routeData = { url: 'xxxx/quotes/compare/xxx' };
    expect(component.showBreadcrumb).toBeFalsy();
    component.activateBreadcrumb();
    expect(component.showBreadcrumb).toBeFalsy();
  });

  it('should enable back button and change button label for quotes page', () => {
    component.buttonLabel = buttonLabel;
    component.routeData = { url: 'xxxx/quotes/xxx' };
    expect(component.showBreadcrumb).toBeFalsy();
    component.activateBreadcrumb();
    expect(component.showBreadcrumb).toBeTruthy();
  });

  it('should not enable back button for other pages', () => {
    component.buttonLabel = buttonLabel;
    component.routeData = { url: 'xxxx/yyy/xxx' };
    expect(component.showBreadcrumb).toBeFalsy();
    component.activateBreadcrumb();
    expect(component.showBreadcrumb).toBeFalsy();
  });
});
