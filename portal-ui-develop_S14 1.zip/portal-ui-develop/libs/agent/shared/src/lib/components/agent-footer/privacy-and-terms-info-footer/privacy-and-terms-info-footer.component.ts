import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'aflac-agent-privacy-and-terms-info-footer',
  templateUrl: './privacy-and-terms-info-footer.component.html',
  styleUrls: ['./privacy-and-terms-info-footer.component.scss']
})
export class PrivacyAndTermsInfoFooterComponent implements OnInit {
  constructor() {}

  ngOnInit() {}
}
