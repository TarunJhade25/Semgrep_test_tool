import { Component, OnInit, Inject } from '@angular/core';
import { MatDialogRef } from '@angular/material';
import { MAT_DIALOG_DATA } from '@angular/material/dialog';
import { urlConfig } from '@aflac/shared/data-model';

@Component({
  selector: 'aflac-agent-logout',
  templateUrl: './agent-logout.component.html',
  styleUrls: ['./agent-logout.component.scss']
})
export class AgentLogoutComponent implements OnInit {
  userName: string;
  constructor(
    public dialogRef: MatDialogRef<AgentLogoutComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) {}

  ngOnInit() {
    if (this.data && this.data.payload && this.data.payload.firstName) {
      const firstName = this.data.payload.firstName
        ? this.data.payload.firstName
        : '';
      const middleName = this.data.payload.middleName
        ? this.data.payload.middleName + ' '
        : '';
      const lastName = this.data.payload.lastName
        ? this.data.payload.lastName
        : '';
      this.userName = firstName + ' ' + middleName + lastName;
    } else {
      this.userName = undefined;
    }
  }
  agentLogout() {
    sessionStorage.clear();
    localStorage.removeItem('agentSAMLToken');
    window.location.href = urlConfig.logoutUrl;
  }
}
