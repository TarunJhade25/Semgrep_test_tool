import { Component, OnInit, Input } from '@angular/core';
//import { AgentLoaderService } from '@aflac/agent/shared';
import { Observable } from 'rxjs';
import { AgentLoaderService } from '../../services/agent-loader.service';

@Component({
  selector: 'aflac-agent-loader',
  templateUrl: './agent-loader.component.html',
  styleUrls: ['./agent-loader.component.scss']
})
export class AgentLoaderComponent implements OnInit {
  loader$: Observable<any>;
  isAgentLoading: boolean;

  constructor(private loaderService: AgentLoaderService) {}

  ngOnInit() {
    this.loader$ = this.loaderService.isLoading();
    this.getLoaderValue();
  }

  getLoaderValue() {
    this.loader$.subscribe(data => {
      this.isAgentLoading = data.getValue;
    });
  }
}
