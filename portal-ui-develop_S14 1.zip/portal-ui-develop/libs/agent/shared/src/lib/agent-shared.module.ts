import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { StoreModule } from '@ngrx/store';
import { SharedCmsModule } from '@aflac/shared/cms';
import { SharedvalidatorsModule } from '@aflac/shared/validators';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { MatAutocompleteModule } from '@angular/material/autocomplete';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatRadioModule } from '@angular/material/radio';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { SharedMaterialModule } from '@aflac/shared/material';
import * as fromAgent from './state/agent/reducers';
import { EffectsModule } from '@ngrx/effects';
import { AgentEffects } from './state/agent/agent.effects';
//import { AgentHeaderComponent } from './components/agent-header/agent-header.component';
import { AgentFooterComponent } from './components/agent-footer/agent-footer.component';
import { AgentBreadcrumbComponent } from './components/agent-breadcrumb/agent-breadcrumb.component';
import { NewLinePipe } from './pipes/newline.pipe';
import { AgentStateComponent } from './components/agent-state/agent-state.component';
import { ConfirmModalComponent } from './components/confirm-modal/confirm-modal.component';
import { PrivacyAndTermsInfoFooterComponent } from './components/agent-footer/privacy-and-terms-info-footer/privacy-and-terms-info-footer.component';
import { ProductLegalInfoFooterComponent } from './components/agent-footer/product-legal-info-footer/product-legal-info-footer.component';
import { SharedPipesModule } from '@aflac/shared/pipes';
import { IdentityValidationErrorDisplayComponent } from './components/identity-validation-error-display/identity-validation-error-display.component';
import { AgentLoaderComponent } from './components/agent-loader/agent-loader.component';
import { AgentNotificationComponent } from './components/agent-notification/agent-notification.component';
import { AgentLogoutComponent } from './components/agent-logout/agent-logout.component';
import { ErrorInterceptorModule } from './interceptors/error.interceptor.module';
import { AgentSystemErrorComponent } from './components/agent-system-error/agent-system-error.component';
// import { AgentShoppingCartModalComponent } from './components/agent-shopping-cart-modal/agent-shopping-cart-modal.component';
// import { AgentHeaderShoppingCartContentComponent } from './components/agent-header-shopping-cart-content/agent-header-shopping-cart-content.component';
// import { AgentHeaderShoppingCartConfirmationModalComponent } from './components/agent-header-shopping-cart-confirmation-modal/agent-header-shopping-cart-confirmation-modal.component';
@NgModule({
  imports: [
    CommonModule,
    SharedCmsModule,
    SharedvalidatorsModule,
    MatAutocompleteModule,
    MatFormFieldModule,
    MatInputModule,
    SharedMaterialModule,
    SharedPipesModule,
    MatRadioModule,
    MatCheckboxModule,
    ReactiveFormsModule,
    FormsModule,
    ErrorInterceptorModule,
    StoreModule.forFeature(fromAgent.agentFeatureKey, fromAgent.agentReducer),
    EffectsModule.forFeature([AgentEffects])
  ],
  declarations: [
    //AgentHeaderComponent,
    AgentFooterComponent,
    ProductLegalInfoFooterComponent,
    PrivacyAndTermsInfoFooterComponent,
    AgentBreadcrumbComponent,
    NewLinePipe,
    AgentStateComponent,
    ConfirmModalComponent,
    IdentityValidationErrorDisplayComponent,
    AgentLoaderComponent,
    AgentNotificationComponent,
    AgentLogoutComponent,
    AgentSystemErrorComponent
    // AgentShoppingCartModalComponent,
    // AgentHeaderShoppingCartContentComponent,
    // AgentHeaderShoppingCartConfirmationModalComponent
  ],
  exports: [
    // AgentHeaderComponent,
    AgentFooterComponent,
    PrivacyAndTermsInfoFooterComponent,
    ProductLegalInfoFooterComponent,
    AgentBreadcrumbComponent,
    NewLinePipe,
    AgentStateComponent,
    ConfirmModalComponent,
    AgentLoaderComponent,
    AgentNotificationComponent,
    AgentLogoutComponent
  ],
  entryComponents: [
    ConfirmModalComponent,
    AgentLogoutComponent
    // AgentShoppingCartModalComponent,
    // AgentHeaderShoppingCartConfirmationModalComponent
  ]
})
export class AgentSharedModule {}
