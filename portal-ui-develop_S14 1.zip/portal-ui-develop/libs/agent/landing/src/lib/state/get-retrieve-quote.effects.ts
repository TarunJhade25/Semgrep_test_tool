import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { Action, Store, select } from '@ngrx/store';
import { catchError, map, mergeMap, tap } from 'rxjs/operators';
import { Observable, of } from 'rxjs';
import * as RetrieveQuoteActions from './get-retrieve-quote.actions';
import { HomeState } from './reducers';
import { RetrieveQuoteCustomer } from '../model/retrieve-quote-customer.model';
import { RetrieveQuote } from '../model/retrieve-quote.model';
import { urlConfig } from '@aflac/shared/data-model';

@Injectable()
export class GetRetrieveQuoteEffects {
  constructor(
    private http: HttpClient,
    private action$: Actions,
    private quoteStore: Store<HomeState>
  ) {}

  private endpoint: string = urlConfig.eisMicroServiceBaseUrl;
  private sfcrmBaseUrl: string = urlConfig.sfcrmBaseUrl;

  // getRetrieveQuoteCustomer$ = createEffect(
  //   () =>
  //     this.action$.pipe(
  //       ofType(RetrieveQuoteActions.retrieveQuoteCustomerAction),
  //       tap(action => {
  //         //const data: RetrieveQuoteCustomer[] = []; // No Record
  //         const data: RetrieveQuoteCustomer[] = [
  //           {
  //             name: 'Jane Smith',
  //             state: 'California',
  //             dob: '03/20/1966',
  //             email: 'jane.smith@gmail.com',
  //             products: 'Critical illness,cancer,accident'
  //           },
  //           {
  //             name: 'Jane Smith',
  //             state: 'NewYork',
  //             dob: '03/20/1980',
  //             email: 'jane.smith12@gmail.com',
  //             products: 'Critical illness'
  //           }
  //         ];
  //         this.quoteStore.dispatch(
  //           RetrieveQuoteActions.retrieveQuoteCustomerSuccessAction({
  //             payload: data
  //           })
  //         );
  //       })
  //     ),
  //   { dispatch: false }
  // );

  getRetrieveQuoteCustomer$: Observable<Action> = createEffect(() =>
    this.action$.pipe(
      ofType(RetrieveQuoteActions.retrieveQuoteCustomerAction),
      mergeMap(action =>
        this.http
          .get(
            `${this.endpoint}agent/v1/quotes/search?firstName=${
              action.payload.firstName
            }&lastName=${action.payload.lastName}&email=${
              action.payload.email
            }&cb=${new Date().getTime()}`
          )
          .pipe(
            map((data: any) => {
              return RetrieveQuoteActions.retrieveQuoteCustomerSuccessAction({
                payload: data
              });
            }),
            catchError((error: Error) => {
              return of(
                RetrieveQuoteActions.retrieveQuoteCustomerErrorAction(error)
              );
            })
          )
      )
    )
  );

  getRetrieveQuote$: Observable<Action> = createEffect(() =>
    this.action$.pipe(
      ofType(RetrieveQuoteActions.retrieveQuoteAction),
      mergeMap(action =>
        this.http
          .get(`${this.endpoint}agent/v1/bundle?bundleId=${action.quote}`)
          .pipe(
            map((data: RetrieveQuote) => {
              return RetrieveQuoteActions.retrieveQuoteSuccessAction({
                payload: data
              });
            }),
            catchError((error: Error) => {
              return of(RetrieveQuoteActions.retrieveQuoteErrorAction(error));
            })
          )
      )
    )
  );

  getRetrieveLeadId$: Observable<Action> = createEffect(() =>
    this.action$.pipe(
      ofType(RetrieveQuoteActions.retrieveLeadIDAction),
      mergeMap(action =>
        this.http
          .get(
            `${this.sfcrmBaseUrl}sfcrm/agent/v1/leads?sfRefNumber=${action.quote.leadId}`
          )
          .pipe(
            map((data: any) => {
              return RetrieveQuoteActions.retrieveLeadIDSuccessAction({
                payload: data
              });
            }),
            catchError((error: Error) => {
              return of(RetrieveQuoteActions.retrieveLeadIDErrorAction(error));
            })
          )
      )
    )
  );

  getCaseId$: Observable<Action> = createEffect(() =>
    this.action$.pipe(
      ofType(RetrieveQuoteActions.getCaseIdAction),
      mergeMap(action =>
        this.http
          .get(
            `${this.endpoint}agent/v1/cases?agencyName=${action.payload.agencyName}&issueStateCd=${action.payload.issueStateCd}`,
            {}
          )
          .pipe(
            map((data: any) => {
              return RetrieveQuoteActions.getCaseIdSuccessAction({
                caseIds: data
              });
            }),
            catchError((error: Error) => {
              return of(RetrieveQuoteActions.getCaseIdErrorAction(error));
            })
          )
      )
    )
  );

  getBundleCloneID$: Observable<Action> = createEffect(() =>
    this.action$.pipe(
      ofType(RetrieveQuoteActions.retrieveBundleCloneAction),
      mergeMap(action =>
        this.http
          .post(`${this.endpoint}agent/v1/clone-bundle`, action.payload)
          .pipe(
            map((data: any) => {
              return RetrieveQuoteActions.retrieveBundleCloneSuccessAction({
                quote: data
              });
            }),
            catchError((error: Error) => {
              return of(
                RetrieveQuoteActions.retrieveBundleCloneErrorAction(error)
              );
            })
          )
      )
    )
  );
}
