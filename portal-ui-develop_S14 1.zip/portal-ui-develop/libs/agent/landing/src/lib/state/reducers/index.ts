import { createReducer, on } from '@ngrx/store';
import { RetrieveQuoteCustomer } from '../../model/retrieve-quote-customer.model';
import { RetrieveQuote } from '../../model/retrieve-quote.model';
import * as RetrieveQuoteActions from '../get-retrieve-quote.actions';

export const homeFeatureKey = 'home';

export interface HomeState {
  retrieveQuoteCustomerData: RetrieveQuoteCustomer[];
  retrieveQuoteData: RetrieveQuote;
  getQuoteStyleUpdateFlag: boolean;
  caseId: any;
  retrieveLeadIdData: any;
}

export const initialHomeState: HomeState = {
  retrieveQuoteCustomerData: null,
  retrieveQuoteData: null,
  getQuoteStyleUpdateFlag: null,
  caseId: undefined,
  retrieveLeadIdData: null
};

export const _homeReducer = createReducer(
  initialHomeState,
  on(RetrieveQuoteActions.retrieveQuoteCustomerAction, state => state),
  on(
    RetrieveQuoteActions.retrieveQuoteCustomerSuccessAction,
    (state, action) => {
      return {
        ...state,
        retrieveQuoteCustomerData: action.payload
      };
    }
  ),
  on(RetrieveQuoteActions.initRetrieveQuoteCustomerAction, (state, action) => {
    return {
      ...state,
      retrieveQuoteCustomerData: undefined
    };
  }),
  on(
    RetrieveQuoteActions.retrieveQuoteCustomerErrorAction,
    (state, error: Error) => {
      return {
        ...state,
        retrieveQuoteError: error
      };
    }
  ),
  on(RetrieveQuoteActions.retrieveQuoteAction, state => state),
  on(RetrieveQuoteActions.retrieveQuoteSuccessAction, (state, action) => {
    return {
      ...state,
      retrieveQuoteData: action.payload
    };
  }),
  on(RetrieveQuoteActions.retrieveQuoteErrorAction, (state, error: Error) => {
    return {
      ...state,
      retrieveQuoteError: error
    };
  }),
  on(RetrieveQuoteActions.resetRetrieveQuoteAction, state => {
    return {
      ...state,
      retrieveQuoteData: undefined
    };
  }),

  on(RetrieveQuoteActions.retrieveBundleCloneSuccessAction, (state, action) => {
    const payload = {
      message: action.quote && 'success',
      status: action.quote && true,
      data: action.quote,
      isCloned: true
    };
    return {
      ...state,
      retrieveQuoteData: payload // map data here. replace customer details, bundle ID, quote number etc
    };
  }),
  on(
    RetrieveQuoteActions.retrieveBundleCloneErrorAction,
    (state, error: Error) => {
      return {
        ...state,
        retrieveQuoteData: error
      };
    }
  ),

  on(RetrieveQuoteActions.getCaseIdSuccessAction, (state, action) => {
    return {
      ...state,
      caseId: action.caseIds
    };
  }),
  on(RetrieveQuoteActions.getCaseIdErrorAction, (state, error: Error) => {
    return {
      ...state,
      caseId: undefined
    };
  }),

  on(RetrieveQuoteActions.retrieveLeadIDSuccessAction, (state, action) => {
    return {
      ...state,
      retrieveLeadIdData: action.payload
    };
  }),
  on(RetrieveQuoteActions.retrieveLeadIDErrorAction, (state, error: Error) => {
    return {
      ...state,
      retriveLeadIdError: error
    };
  })
);

export function homeReducer(state, action) {
  return _homeReducer(state, action);
}
