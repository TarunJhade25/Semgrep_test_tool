import { createAction, props } from '@ngrx/store';
import { RetrieveQuoteCustomer } from '../model/retrieve-quote-customer.model';
import { RetrieveQuote } from '../model/retrieve-quote.model';

export const retrieveQuoteCustomerAction = createAction(
  '[Retrieve Quote]  Retrieve Quote Customer',
  props<{ payload: any }>()
);

export const retrieveQuoteCustomerSuccessAction = createAction(
  '[Retrieve Quote] - Retrieve Quote Customer Success',
  props<{ payload: RetrieveQuoteCustomer[] }>()
);
export const initRetrieveQuoteCustomerAction = createAction(
  '[Retrieve Quote] - Initilze  Quote Customer Action'
);

export const retrieveQuoteCustomerErrorAction = createAction(
  '[Retrieve Quote] - Retrieve Quote Customer Error',
  props<Error>()
);

export const retrieveQuoteAction = createAction(
  '[Retrieve Quote]  Retrieve Quote',
  props<{ quote: any }>()
);

export const retrieveQuoteSuccessAction = createAction(
  '[Retrieve Quote] - Retrieve Quote Success',
  props<{ payload: RetrieveQuote }>()
);

export const retrieveQuoteErrorAction = createAction(
  '[Retrieve Quote] - Retrieve Quote Error',
  props<Error>()
);

export const resetRetrieveQuoteAction = createAction(
  '[Retrieve Quote]  Reset Retrieve Quote'
);

export const retrieveBundleCloneAction = createAction(
  '[Retrieve Quote]  Retrieve Bundle Clone Response',
  props<{ payload: any }>()
);
export const retrieveBundleCloneSuccessAction = createAction(
  '[Retrieve Quote]  Retrieve Bundle Clone Response Success',
  props<{ quote: any }>()
);
export const retrieveBundleCloneErrorAction = createAction(
  '[Retrieve Quote]  Retrieve Bundle Clone Response Error',
  props<Error>()
);

export const getCaseIdAction = createAction(
  '[Get Quote] - Get Case ID',
  props<{ payload: any }>()
);

export const getCaseIdSuccessAction = createAction(
  '[Get Quote] - Get Case ID Success',
  props<{ caseIds: any }>()
);
export const getCaseIdErrorAction = createAction(
  '[Get Quote] - Get Case ID Error',
  props<Error>()
);
export const retrieveLeadIDAction = createAction(
  '[Lead ID]  Lead ID',
  props<{ quote: any }>()
);

export const retrieveLeadIDSuccessAction = createAction(
  '[Lead ID] - Lead ID Success',
  props<{ payload: any }>()
);

export const retrieveLeadIDErrorAction = createAction(
  '[Lead ID] -Lead ID Error',
  props<Error>()
);

export const retrieveLeadIDQuoteAction = createAction(
  '[Lead ID]  Reset Lead ID'
);
