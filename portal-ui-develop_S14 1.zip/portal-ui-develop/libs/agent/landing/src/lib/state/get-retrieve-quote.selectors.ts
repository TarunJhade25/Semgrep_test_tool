import { createSelector } from '@ngrx/store';

export const getRetrieveQuoteCustomerData = createSelector(
  state => state['home'],
  home => home.retrieveQuoteCustomerData
);

export const getRetrieveQuoteData = createSelector(
  state => state['home'],
  home => home.retrieveQuoteData
);

export const getCaseIds = createSelector(
  state => state['home'],
  home => home.caseId
);
export const getRetrieveLeadIdData = createSelector(
  state => state['home'],
  home => home.retrieveLeadIdData
);
