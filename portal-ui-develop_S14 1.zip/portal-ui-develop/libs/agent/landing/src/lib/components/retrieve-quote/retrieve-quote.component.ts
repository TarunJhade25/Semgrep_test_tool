import { Component, OnInit, OnDestroy } from '@angular/core';
import { FormBuilder, FormControl, FormGroup } from '@angular/forms';
import { FieldValidator } from '@aflac/shared/validators';
import { select, Store } from '@ngrx/store';
import { Subscription } from 'rxjs';
import { Router } from '@angular/router';
import { getRetrieveQuoteCustomerData } from '../../state/get-retrieve-quote.selectors';
import * as RetrieveQuoteActions from '../../state/get-retrieve-quote.actions';
import { MatDialog } from '@angular/material';
import {
  initCart,
  ResetRetrieveCart,
  SaveAgentCriticalIllnessPlansAction
} from '@aflac/agent/shared'; // Product Actions
import { CustomerSearchResultModalComponent } from '../customer-search-result-modal/customer-search-result-modal.component';
import { resetRetrieveQuoteAction } from '../../state/get-retrieve-quote.actions';
import {
  agentEditedQuoteAction,
  saveQuoteSuccessAction,
  resetBuyFlowElements,
  agentSSNValidatedAction,
  getQuoteDataFromBundleIdSuccess,
  getPersonalDetailsSuccess,
  storeCustomerDetailsAction
} from '@aflac/agent/shared';

import { agentGetQuoteStateAction, agentGetQuote } from '@aflac/agent/shared'; // Actions
import { CmsService } from '@aflac/shared/cms';
import { initRetrieveQuoteCustomerAction } from '../../state/get-retrieve-quote.actions';
@Component({
  selector: 'aflac-retrieve-quote',
  templateUrl: './retrieve-quote.component.html',
  styleUrls: ['./retrieve-quote.component.scss']
})
export class RetrieveQuoteComponent implements OnInit, OnDestroy {
  constructor(
    private formBuilder: FormBuilder,
    private quoteStore: Store<any>,
    private router: Router,
    public dialog: MatDialog,
    private cmsService: CmsService
  ) {}

  retrieveQuoteForm = new FormGroup({
    firstName: new FormControl(),
    lastName: new FormControl(),
    email: new FormControl()
  });
  states: any;
  retrieveQuoteNoDataFlag = false;
  subsription: Subscription;

  ngOnInit() {
    this.getInitData();
    sessionStorage.setItem('state-retrieveQuote', '');
  }
  getInitData() {
    this.setFormControlData();
    this.quoteStore.dispatch(initRetrieveQuoteCustomerAction());
    this.getLookupData();
    this.retrieveQuoteCustomerData();
  }

  retrieveQuoteCustomerData() {
    this.subsription = this.quoteStore
      .pipe(select(getRetrieveQuoteCustomerData))
      .subscribe(res => {
        this.retrieveQuoteNoDataFlag = false;
        if (
          (res && res.status === false) ||
          (res && res.customerInfo.length === 0 && res.bundleInfo.length === 0)
        ) {
          this.retrieveQuoteNoDataFlag = true;
          window.scroll(0, 0);
        } else if (res && res.customerInfo.length > 0) {
          // TODO for popup
          this.showUserModal(res.customerInfo);
          return false;
        } else if (
          res &&
          res.bundleInfo &&
          Object.keys(res.bundleInfo).length > 1
        ) {
          const retrieveQuoteObj = {
            status: true,
            message: 'Success',
            data: res.bundleInfo
          };
          this.quoteStore.dispatch(
            RetrieveQuoteActions.retrieveQuoteSuccessAction({
              payload: retrieveQuoteObj
            })
          );
          this.quoteStore.dispatch(
            storeCustomerDetailsAction({
              payload: this.retrieveQuoteForm.value
            })
          );
          this.storeCustomerDetailsToSession(this.retrieveQuoteForm.value);
          if (res.bundleInfo && res.bundleInfo.quotes.length > 0) {
            const agentInfo = JSON.parse(
              sessionStorage.getItem('agent-information')
            );
            const searchObj = {
              state: this.getStateName(res.bundleInfo.quotes[0].riskStateCd),
              stateProvCd: res.bundleInfo.quotes[0].riskStateCd,
              age: this.ageFromDateOfBirthday(
                res.bundleInfo.quotes[0].insureds[0].dateOfBirth
              ),
              caseId: res.bundleInfo.quotes[0].caseId,
              partnerId: agentInfo.agencyCd
            };
            this.quoteStore.dispatch(initCart());
            this.storeRetrieveQuoteDataToSession(res.bundleInfo.quotes);
            this.quoteStore.dispatch(
              agentGetQuoteStateAction({ payload: false })
            );
            this.quoteStore.dispatch(
              agentGetQuote({ agentGetQuote: searchObj })
            );
            this.router.navigate(['quotes']);
          }
        }
      });
  }

  get f() {
    return this.retrieveQuoteForm.controls;
  }

  // Set Form control data
  public setFormControlData() {
    this.retrieveQuoteForm = this.formBuilder.group({
      firstName: [
        '',
        [
          FieldValidator.isEmpty('lookup.save_your_quote_first_name_required'),
          FieldValidator.patternValidator(
            /^[a-zA-Z `']*$/,
            'agent_portal.save_quote_first_name_required_error'
          )
        ]
      ],
      lastName: [
        '',
        [
          FieldValidator.isEmpty('lookup.save_your_quote_last_name_required'),
          FieldValidator.patternValidator(
            /^[a-zA-Z `']*$/,
            'agent_portal.save_quote_last_name_required_error'
          )
        ]
      ],
      email: [
        '',
        [
          FieldValidator.isEmpty(
            'lookup.save_your_quote_email_address_required'
          ),
          FieldValidator.patternValidator(
            /^[a-zA-Z]{1}(([^<>()\[\]\\.,;:\s@']+(\.[^<>()\[\]\\.,;:\s@']+)*)|('.+'))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/,
            'sales_portal.save_your_quote_email_format_error'
          )
        ]
      ]
    });
  }

  // Get quote button submit
  public onSubmit() {
    this.quoteStore.dispatch(resetRetrieveQuoteAction());
    this.quoteStore.dispatch(ResetRetrieveCart());
    this.quoteStore.dispatch(
      storeCustomerDetailsAction({ payload: undefined })
    );
    this.storeCustomerDetailsToSession(undefined);
    this.quoteStore.dispatch(agentEditedQuoteAction({ payload: undefined }));
    sessionStorage.setItem('state-edit-quote-status', null);
    this.resetStoreAndSessions();
    if (this.retrieveQuoteForm.valid) {
      const formData = this.retrieveQuoteForm.value;
      //this.quoteStore.dispatch(initCart());
      this.quoteStore.dispatch(
        RetrieveQuoteActions.retrieveQuoteCustomerAction({ payload: formData })
      );
    }
  }
  private ageFromDateOfBirthday(dateOfBirth: any): number {
    const today = new Date();
    const birthDate = new Date(dateOfBirth);
    let age = today.getFullYear() - birthDate.getFullYear();
    const m = today.getMonth() - birthDate.getMonth();

    if (m < 0 || (m === 0 && today.getDate() < birthDate.getDate())) {
      age--;
    }
    return age;
  }
  getLookupData() {
    this.cmsService.getKey('lookup').subscribe(lookup => {
      this.states = lookup.us_states;
    });
  }
  public getStateName(stateCode): string {
    let statename: string;
    if (stateCode) {
      statename = '';
      if (this.states && this.states.length > 0) {
        statename = this.states.filter(data => data.code === stateCode)[0].name;
      }
    }
    return statename;
  }
  // Save retrieve quote data from store to session
  public storeRetrieveQuoteDataToSession(quoteData) {
    sessionStorage.setItem('state-retrieveQuote', JSON.stringify(quoteData));
  }
  // Save retrieve quote data from store to session
  public storeCustomerDetailsToSession(data) {
    const payload = data ? JSON.stringify(data) : '';
    sessionStorage.setItem('state-customerDetails', payload);
  }
  // to show user list table
  showUserModal(data: any) {
    const payload = data;
    const dialogRef = this.dialog.open(CustomerSearchResultModalComponent, {
      width: '1046px',
      disableClose: false,
      panelClass: 'customer-search-result-modal-cover',
      data: { payload }
    });
    // dialogRef.afterClosed().subscribe(() => {
    //   if (this.subsription !== undefined) {
    //     this.subsription.unsubscribe();
    //   }
    // });
  }

  resetStoreAndSessions() {
    // Remove all sessions
    sessionStorage.removeItem('state-agent-buy-flow-elements');
    sessionStorage.removeItem('state-agent-user-details');
    sessionStorage.removeItem('state-agent-cart-details');
    sessionStorage.removeItem('state-agent-product-details');
    sessionStorage.removeItem('state-agent-bundleId');
    this.quoteStore.dispatch(agentSSNValidatedAction({ payload: undefined }));
    this.quoteStore.dispatch(saveQuoteSuccessAction({ payload: undefined }));
    this.quoteStore.dispatch(
      getQuoteDataFromBundleIdSuccess({ payload: undefined })
    );
    this.quoteStore.dispatch(resetBuyFlowElements());
    this.quoteStore.dispatch(getPersonalDetailsSuccess({ payload: undefined }));
    this.quoteStore.dispatch(
      SaveAgentCriticalIllnessPlansAction({ data: undefined })
    );
  }

  ngOnDestroy() {
    this.subsription.unsubscribe();
  }
  styleObject(height) {
    //const offset = `${height + 60}px`; // 60px top and bottom padding sum
    const offset = this.retrieveQuoteNoDataFlag
      ? `${height + 110}px`
      : `${height + 60}px`;
    return {
      height: `calc(100% - ${offset})`
    };
  }
}
