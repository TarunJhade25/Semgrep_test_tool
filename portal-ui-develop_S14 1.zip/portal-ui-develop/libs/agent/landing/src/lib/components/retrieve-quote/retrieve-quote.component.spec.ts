import { RetrieveQuoteComponent } from './retrieve-quote.component';
import {
  async,
  ComponentFixture,
  TestBed,
  inject
} from '@angular/core/testing';
import {
  MatDialogModule,
  MatDialogRef,
  MatDialog,
  MAT_DIALOG_DATA
} from '@angular/material/dialog';
import { RouterTestingModule } from '@angular/router/testing';
import { Router } from '@angular/router';
import { TranslateModule } from '@ngx-translate/core';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { MatSelectModule } from '@angular/material/select';
import { MatAutocompleteModule } from '@angular/material/autocomplete';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { provideMockStore, MockStore } from '@ngrx/store/testing';
import { StoreModule, Store, MemoizedSelector } from '@ngrx/store';
import { of } from 'rxjs';
import { By } from '@angular/platform-browser';
import { CUSTOM_ELEMENTS_SCHEMA, DebugElement } from '@angular/core';
import { SharedPipesModule } from '@aflac/shared/pipes';
import { ProductReducer } from '@aflac/agent/shared';
import * as fromAgentSearchQuote from '@aflac/agent/shared';
import * as fromProduct from '@aflac/agent/shared';
import * as fromAgentGetRetrieveQuote from '../../state/get-retrieve-quote.actions'; // Actions
import { ProductState } from '@aflac/agent/shared'; // Reducer
import {
  AgentStateComponent,
  agentEditedQuoteAction
} from '@aflac/agent/shared';
import {
  getRetrieveQuoteCustomerData,
  getRetrieveLeadIdData
} from '../../state/get-retrieve-quote.selectors';
import { CustomerSearchResultModalComponent } from '../customer-search-result-modal/customer-search-result-modal.component';
import { BrowserDynamicTestingModule } from '@angular/platform-browser-dynamic/testing';

class RouterStub {
  navigateByUrl(url: string) {
    console.log('url : ', url);
    return url;
  }
  navigate() {
    return true;
  }
}
const startQuoteObj = {
  state: 'Alabama',
  age: 45,
  leadId: '11111',
  caseId: 'PROMO123'
};

const agentprofile = {
  agencyCd: 'QAG',
  agencyName: 'QA Agency',
  subProducerCd: '1',
  electronicSignature: false,
  firstName: 'John',
  lastName: 'Smith',
  middleName: 'R',
  voiceRecording: false
};
const CustomerData = {
  bundleInfo: {},
  customerInfo: [
    {
      firstName: 'Jane',
      lastName: 'Smith',
      email: 'janesmith@gmail.com',
      state: 'CA',
      dateOfBirth: '06-20-1980',
      bundle: {
        id: 2,
        customerNumber: '20000000003',
        receivedVia: 'FAX',
        submissionDate: '2020-06-17',
        quoteList: [
          {
            quoteNumber: 'T50000000011',
            addedToBundleDate: '2020-06-17',
            productCode: 'PREC-IA'
          }
        ],
        createdOn: '2020-06-17T12:41:46.287Z',
        typeCd: 'COMPREHENSIVE',
        producerCd: 'QAG',
        statusCd: 'CREATED'
      }
    },
    {
      firstName: 'Jane',
      lastName: 'S',
      email: 'janesmith@gmail.com',
      state: 'CA',
      dateOfBirth: '03-20-1980',
      bundle: {
        id: 9,
        customerNumber: '20000000003',
        receivedVia: 'FAX',
        submissionDate: '2020-06-17',
        quoteList: [
          {
            quoteNumber: 'T50000000012',
            addedToBundleDate: '2020-06-17',
            productCode: 'PREC-IC'
          },
          {
            quoteNumber: 'T50000000013',
            addedToBundleDate: '2020-06-17',
            productCode: 'PREC-IA'
          }
        ],
        createdOn: '2020-06-17T12:41:46.287Z',
        typeCd: 'COMPREHENSIVE',
        producerCd: 'QAG',
        statusCd: 'CREATED'
      }
    },
    {
      firstName: 'John',
      lastName: 'Smith',
      email: 'janesmith@gmail.com',
      state: 'CA',
      dateOfBirth: '01-30-1980',
      bundle: {
        id: 3,
        customerNumber: '20000000003',
        receivedVia: 'FAX',
        submissionDate: '2020-06-17',
        quoteList: [
          {
            quoteNumber: 'T50000000015',
            addedToBundleDate: '2020-06-17',
            productCode: 'PREC-ICI'
          },
          {
            quoteNumber: 'T50000000016',
            addedToBundleDate: '2020-06-17',
            productCode: 'PREC-IC'
          }
        ],
        createdOn: '2020-06-17T12:41:46.287Z',
        typeCd: 'COMPREHENSIVE',
        producerCd: 'QAG',
        statusCd: 'CREATED'
      }
    },
    {
      firstName: 'Jack',
      lastName: 'Smith',
      email: 'janesmith@gmail.com',
      state: 'CA',
      dateOfBirth: '06-01-1980',
      bundle: {
        id: 4,
        customerNumber: '20000000003',
        receivedVia: 'FAX',
        submissionDate: '2020-06-17',
        quoteList: [
          {
            quoteNumber: 'T50000000021',
            addedToBundleDate: '2020-06-17',
            productCode: 'PREC-ICI'
          },
          {
            quoteNumber: 'T50000000022',
            addedToBundleDate: '2020-06-17',
            productCode: 'PREC-IA'
          },
          {
            quoteNumber: 'T50000000023',
            addedToBundleDate: '2020-06-17',
            productCode: 'PREC-IC'
          }
        ],
        createdOn: '2020-06-17T12:41:46.287Z',
        typeCd: 'COMPREHENSIVE',
        producerCd: 'QAG',
        statusCd: 'CREATED'
      }
    },
    {
      firstName: 'Jane',
      lastName: 'Smithish',
      email: 'janesmith@gmail.com',
      state: 'CA',
      dateOfBirth: '02-01-1980',
      bundle: {
        id: 5,
        customerNumber: '20000000003',
        receivedVia: 'FAX',
        submissionDate: '2020-06-17',
        quoteList: [
          {
            quoteNumber: 'T50000000030',
            addedToBundleDate: '2020-06-17',
            productCode: 'PREC-IA'
          }
        ],
        createdOn: '2020-06-17T12:41:46.287Z',
        typeCd: 'COMPREHENSIVE',
        producerCd: 'QAG',
        statusCd: 'CREATED'
      }
    },
    {
      firstName: 'Jane',
      lastName: 'Swede',
      email: 'janesmith@gmail.com',
      state: 'CA',
      dateOfBirth: '08-01-1981',
      bundle: {
        id: 6,
        customerNumber: '20000000003',
        receivedVia: 'FAX',
        submissionDate: '2020-06-17',
        quoteList: [
          {
            quoteNumber: 'T50000000031',
            addedToBundleDate: '2020-06-17',
            productCode: 'PREC-IC'
          }
        ],
        createdOn: '2020-06-17T12:41:46.287Z',
        typeCd: 'COMPREHENSIVE',
        producerCd: 'QAG',
        statusCd: 'CREATED'
      }
    }
  ]
};
const product = [
  {
    features: [
      'Accidental Death & Dismemberment',
      'Accidental Injury',
      'Non-Injury hospital admission benefits'
    ],
    id: 1001,
    image: 'assets/images/accident_2.svg',
    productName: 'Accident Insurance',
    riders: [
      { description: '', id: 5001, name: 'Accident Rider 1', value: 14.23 },
      { description: '', id: 5002, name: 'Accident Rider 2', value: 24.23 }
    ],
    startingPrice: 12.32,
    states: ['AK', 'AZ', 'CA'],
    name: 'test'
  },
  {
    features: [
      'Accidental Death & Dismemberment',
      'Accidental Injury',
      'Non-Injury hospital admission benefits'
    ],
    id: 1002,
    image: 'assets/images/cancer_2.svg',
    productName: 'Cancer Insurance',
    riders: [
      { description: '', id: 5001, name: 'Cancer Rider 1', value: 14.23 },
      { description: '', id: 5002, name: 'Cancer Rider 2', value: 24.23 }
    ],
    startingPrice: 17.32,
    states: ['AK', 'AZ', 'CA'],
    name: 'test'
  }
];
const agentInfData = {
  subProducerCd: '1',
  firstName: 'John',
  middleName: 'R',
  lastName: 'Smith',
  agencyCd: 'QAG',
  agencyName: 'QA Agency',
  electronicSignature: false,
  voiceRecording: false
};
const bundleInfo = {
  bundleInfo: {
    id: 1,
    submissionDate: '2020-05-13T12:36:23Z',
    statusCd: 'OPEN',
    quotes: [
      {
        quoteNumber: '195',
        bundleId: 1,
        customerNumber: '1214',
        effectiveDate: '2019-12-12',
        expirationDate: '2020-12-12',
        transactionEffectiveDate: '2020-02-28T12:51:20Z',
        policyStatusCd: 'dataGather',
        transactionTypeCd: 'quote',
        timedPolicyStatusCd: 'dataGather',
        revisionNumber: 0,
        pendingRevisionNumber: 0,
        productCode: 'PREC-IC',
        productVersion: 1,
        lobCd: 'ACCIDENT&HEALTH',
        totalPremium: 0,
        monthlyPremium: 0,
        currencyCode: 'USD',
        coverageTypeCd: 'ind',
        series: 'T37000',
        packageCd: 'plan08',
        countryCd: 'US',
        riskStateCd: 'AL',
        sourceCd: 'New',
        producerCd: 'New',
        subProducerCd: 'New',
        caseId: 'CaseLinkTest',
        sfrId: 'abc123',
        contractTermTypeCd: 'Annual',
        underwriterCd: 'Tier One',
        overrideRateEffectiveDateInd: true,
        rateEffectiveDate: '2019-12-12',
        originalIssueState: 'GA',
        sku: 'T3700050',
        basePremium: 100,
        monthlyBasePremium: 100,
        totalMonthlyPremium: 150,
        electronicPolicyDelivery: false,
        electronicDateTimestamp: '2020-05-27 11:31:05.550',
        isOffTheJobOnlyInd: false,
        enrollmentMetadata: 'String',
        tobaccoUseInd: false,
        initialDiagnosisAmount: {},
        insureds: [
          {
            primaryInsuredInd: true,
            relationshipToPrimaryInsuredCd: 'self',
            disabilityInd: '',
            physician: '',
            natureDisability: '',
            disabledDate: '',
            beneficiaryTypeCd: '',
            title: '',
            firstName: 'Jim',
            lastName: 'John',
            middleName: '',
            suffix: '',
            ssn: '',
            genderCd: 'Male',
            maritalStatusCd: '',
            dateOfBirth: '04-21-1982',
            dateofAdoption: '',
            dateofCustody: '',
            occupation: '',
            taxId: '',
            splitPercentage: '',
            address: [
              {
                addressLine1: '345 California Str',
                addressLine2: '10 flr',
                addressLine3: ' ',
                city: 'San Francisco',
                county: 'San Francisco',
                postalCode: '94104',
                stateProvCd: 'AL',
                countryCd: 'US',
                addressTypeCd: 'mailing',
                sameAsInsuredAddressInd: true,
                addressValidated: ''
              }
            ],
            phones: [
              {
                id: 0,
                phone: '1234567890',
                phoneTypeCd: 'WORK'
              }
            ],
            emails: [
              {
                id: 0,
                email: 'jim@gmail.com',
                emailTypeCd: ''
              }
            ],
            beneficiaries: []
          }
        ],
        riders: [
          {
            riderNameCd: 'Initial Diagnosis Increasing Benefit Rider',
            riderPremium: 0,
            monthlyriderPremium: 140,
            riderBenefitAmount: {
              value: 5000,
              currencyCd: 'USD'
            }
          },
          {
            riderNameCd: 'Specified-Disease Diagnosis Benefit Rider',
            riderPremium: 0,
            monthlyriderPremium: 130,
            riderBenefitAmount: {
              value: 5000,
              currencyCd: 'USD'
            }
          },
          {
            riderNameCd: 'Dependent Child Rider',
            riderPremium: 0,
            monthlyriderPremium: 120,
            riderBenefitAmount: {
              value: 5000,
              currencyCd: 'USD'
            }
          }
        ]
      }
    ]
  },
  customerInfo: []
};
describe('RetrieveQuoteComponent', () => {
  let component: RetrieveQuoteComponent;
  let fixture: ComponentFixture<RetrieveQuoteComponent>;
  let de: DebugElement;
  let el: HTMLElement;
  let mockStore: MockStore<any>;
  let productStore: Store<ProductState>;
  let getRetrieveStore: Store<any>;
  let mockQuoteSelector: MemoizedSelector<any, any>;
  let mockProductSelector: MemoizedSelector<any, any>;
  let mockgetAgentProfile: MemoizedSelector<any, any>;
  let mockretrieveQuoteCustomerData: MemoizedSelector<any, any>;
  let router: Router;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [RetrieveQuoteComponent],
      imports: [
        TranslateModule.forRoot(),
        RouterTestingModule,
        MatSelectModule,
        MatAutocompleteModule,
        MatFormFieldModule,
        MatInputModule,
        BrowserAnimationsModule,
        ReactiveFormsModule,
        FormsModule,
        SharedPipesModule,
        MatDialogModule,
        StoreModule.forRoot(ProductReducer),
        BrowserDynamicTestingModule
      ],
      providers: [
        provideMockStore({}),
        { provide: Router, useClass: RouterStub }
      ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RetrieveQuoteComponent);
    component = fixture.componentInstance;
    router = TestBed.get(Router);
    mockStore = TestBed.get(Store);
    productStore = TestBed.get(Store);
    getRetrieveStore = TestBed.get(Store);

    mockQuoteSelector = mockStore.overrideSelector(
      fromAgentSearchQuote.agentSelectedQuote,
      startQuoteObj
    );
    mockgetAgentProfile = mockStore.overrideSelector(
      fromAgentSearchQuote.getAgentProfile,
      agentprofile
    );
    mockretrieveQuoteCustomerData = mockStore.overrideSelector(
      getRetrieveQuoteCustomerData,
      bundleInfo
    );

    mockProductSelector = mockStore.overrideSelector(
      fromProduct.products,
      product
    );

    de = fixture.debugElement.query(By.css('form'));
    el = de.nativeElement;
    sessionStorage.setItem('agent-information', JSON.stringify(agentInfData));
    spyOn(component, 'showUserModal').and.returnValue(true);
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should call getInitData funtion', () => {
    component.getInitData();
    expect(component as any).toBeDefined();
  });

  it('should call retrieveQuoteCustomerData funtion', () => {
    component.retrieveQuoteCustomerData();
    expect(component as any).toBeDefined();
  });
  it('should call getStateName funtion', () => {
    component.getStateName('AL');
    expect(component as any).toBeDefined();
  });
  it('should return state name', () => {
    const stateProvCd = 'AL';
    component.states = [
      {
        name: 'Alabama',
        code: 'AL'
      }
    ];
    const result = component.getStateName(stateProvCd);
    expect(result).toEqual('Alabama');
  });

  it('form should be invalid ', () => {
    component.retrieveQuoteForm.controls['firstName'].setValue('');
    component.retrieveQuoteForm.controls['lastName'].setValue('');
    component.retrieveQuoteForm.controls['email'].setValue('');
    expect(component.retrieveQuoteForm.valid).toBeFalsy();
  });

  it('form should be Valid ', () => {
    component.retrieveQuoteForm.controls['firstName'].setValue('abc');
    component.retrieveQuoteForm.controls['lastName'].setValue('jhone');
    component.retrieveQuoteForm.controls['email'].setValue('jim@gmail.com');
    expect(component.retrieveQuoteForm.valid).toBeTruthy();
  });
  it('should navigate based on condition on submit', () => {
    spyOn(getRetrieveStore, 'dispatch');
    component.onSubmit();
    expect(getRetrieveStore.dispatch).toHaveBeenCalledWith(
      agentEditedQuoteAction({ payload: undefined })
    );
  });
  it('should manage state when direct match found in search', () => {
    component.retrieveQuoteCustomerData();
    expect(component as any).toBeDefined();
  });
});
class DialogMock {
  _containerInstance = { _config: { width: '1046px' } };
  updatePosition() {}
  close() {}
  open(data) {
    return true;
  }
}
