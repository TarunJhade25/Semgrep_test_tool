import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { CustomerSearchResultModalComponent } from './customer-search-result-modal.component';
import { TranslateModule } from '@ngx-translate/core';
import {
  MatTableModule,
  MatFormFieldModule,
  MatInputModule
} from '@angular/material';
import { provideMockStore, MockStore } from '@ngrx/store/testing';
import { CUSTOM_ELEMENTS_SCHEMA, DebugElement } from '@angular/core';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { SharedvalidatorsModule } from '@aflac/shared/validators';
import { RouterTestingModule } from '@angular/router/testing';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { StoreModule, Store, MemoizedSelector } from '@ngrx/store';
import { ProductState } from '@aflac/agent/shared'; // Reducer
import { Router } from '@angular/router';
import {
  MatDialogModule,
  MatDialogRef,
  MatDialog,
  MAT_DIALOG_DATA
} from '@angular/material/dialog';
import { getRetrieveQuoteData } from '../../state/get-retrieve-quote.selectors';

const dataSource = {
  payload: [
    {
      firstName: 'kezia',
      lastName: 'rose',
      email: 'kezia@gmail.com',
      state: 'AL',
      dateOfBirth: '08/23/1981',
      bundle: {
        id: 7,
        customerNumber: '20000000003',
        receivedVia: 'FAX',
        submissionDate: '2020-06-17',
        quoteList: [
          {
            quoteNumber: 'T50000000033',
            addedToBundleDate: '2020-06-17',
            productCode: 'PREC-ICI',
            productName: 'Critical Illness Insurance'
          }
        ],
        createdOn: '2020-06-17T12:41:46.287Z',
        typeCd: 'COMPREHENSIVE',
        producerCd: 'QAG',
        statusCd: 'CREATED'
      }
    },
    {
      firstName: 'kezia',
      lastName: 'martina',
      email: 'kezia@gmail.com',
      state: 'AL',
      dateOfBirth: '01/30/1981',
      bundle: {
        id: 8,
        customerNumber: '20000000003',
        receivedVia: 'FAX',
        submissionDate: '2020-06-17',
        quoteList: [
          {
            quoteNumber: 'T50000000035',
            addedToBundleDate: '2020-06-17',
            productCode: 'PREC-IA',
            productName: 'Accident Insurance'
          }
        ],
        createdOn: '2020-06-17T12:41:46.287Z',
        typeCd: 'COMPREHENSIVE',
        producerCd: 'QAG',
        statusCd: 'CREATED'
      }
    }
  ]
};
const RetrieveQuote = {
  data: {
    quotes: [
      {
        bundleId: '000',
        policyNumber: 'a1b2',
        effectiveDate: '01/02/2019',
        expirationDate: '01/06/2019',
        transactionEffectiveDate: '03/02/2019',
        policyStatusCd: 'dummy',
        productCode: 'PREC-IC',
        lobCd: 'dummy',
        totalPremium: 1234,
        currencyCode: 'ind',
        producerCd: 'dummy',
        subProducerCd: 'd',
        quoteNumber: '111',
        customerNumber: '111'
      }
    ]
  }
};
describe('CustomerSearchResultModalComponent', () => {
  let component: CustomerSearchResultModalComponent;
  let fixture: ComponentFixture<CustomerSearchResultModalComponent>;
  let store: Store<any>;
  let mockStore: MockStore<any>;
  let mockRetrieveQuoteData: MemoizedSelector<any, any>;
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        TranslateModule.forRoot(),
        ReactiveFormsModule,
        FormsModule,
        SharedvalidatorsModule,
        MatFormFieldModule,
        MatInputModule,
        RouterTestingModule,
        BrowserAnimationsModule,
        MatTableModule,
        MatDialogModule
      ],
      declarations: [CustomerSearchResultModalComponent],
      providers: [
        provideMockStore({}),
        { provide: MAT_DIALOG_DATA, useValue: dataSource },
        { provide: MatDialogRef, useClass: DialogMock },
        { provide: Router, useClass: RouterStub }
      ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CustomerSearchResultModalComponent);
    mockStore = TestBed.get(Store);
    store = TestBed.get(Store);

    mockRetrieveQuoteData = mockStore.overrideSelector(
      getRetrieveQuoteData,
      RetrieveQuote
    );
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should call ngOnInit funtion', () => {
    component.ngOnInit();
    expect(component as any).toBeDefined();
  });
  it('should call retrieveQuoteSub funtion', () => {
    component.retrieveQuoteSub();
    expect(component as any).toBeDefined();
  });
  it('should call getLookupData funtion', () => {
    component.getLookupData();
    expect(component as any).toBeDefined();
  });

  it('should call getStateName funtion', () => {
    component.getStateName('AL');
    expect(component as any).toBeDefined();
  });

  it('should return state name', () => {
    const stateProvCd = 'AL';
    component.states = [
      {
        name: 'Alabama',
        code: 'AL'
      }
    ];
    const result = component.getStateName(stateProvCd);
    expect(result).toEqual('Alabama');
  });

  it('should Get getproductNames', () => {
    const result = component.getproductNames(0);
    expect(result).toEqual('Critical Illness Insurance');
  });
});
class RouterStub {
  navigateByUrl(url: string) {
    return url;
  }
}
class DialogMock {
  close() {}
}
