import {
  Component,
  OnInit,
  OnDestroy,
  ViewChild,
  ElementRef
} from '@angular/core';
import { FormBuilder, FormControl, FormGroup } from '@angular/forms';
import { FieldValidator } from '@aflac/shared/validators';
import { Router } from '@angular/router';
import { Store, ActionsSubject } from '@ngrx/store';
import { CmsService } from '@aflac/shared/cms';
import { States, urlConfig } from '@aflac/shared/data-model';
import { Observable, Subscription } from 'rxjs';
import { map, startWith } from 'rxjs/operators';
import {
  agentGetQuote,
  agentGetQuoteStateAction,
  getAgentProfile,
  getStates,
  agentEditedQuoteAction,
  saveQuoteSuccessAction,
  resetBuyFlowElements,
  filteredStateListAction,
  agentSSNValidatedAction,
  getQuoteDataFromBundleIdSuccess,
  getPersonalDetailsSuccess,
  SetNavigationSource
} from '@aflac/agent/shared'; // Actions
import {
  resetRetrieveQuoteAction,
  retrieveLeadIDAction,
  getCaseIdAction,
  retrieveLeadIDSuccessAction
} from '../../state/get-retrieve-quote.actions'; // Actions
import {
  findProductsAction,
  SuccessFindProductsAction,
  initCart,
  ResetRetrieveCart,
  SaveAgentCriticalIllnessPlansAction,
  storeCustomerDetailsAction
} from '@aflac/agent/shared'; // Product Actions
import { ProductState } from '@aflac/agent/shared'; // Reducer
import { HomeState } from '../../state/reducers';
import { getRetrieveLeadIdData } from '../../state/get-retrieve-quote.selectors';
import { Agent } from '@aflac/agent/shared'; // Reducer
import { getCaseIds } from '../../state/get-retrieve-quote.selectors';
import { forEach } from 'lodash';

@Component({
  selector: 'aflac-get-quote',
  templateUrl: './get-quote.component.html',
  styleUrls: ['./get-quote.component.scss']
})
export class GetQuoteComponent implements OnInit, OnDestroy {
  @ViewChild('stateRef', { static: false }) stateField: ElementRef;
  subsc = new Subscription();
  states: any;
  statesList: any;
  invalidLeadID = false;
  case_ids: any[];
  minAgeValue = 18;
  maxAgeValue = 99;
  getQuoteNoDataFlag = false;
  LeadIdVlidated = false;
  currentLeadIdstate: String;
  toHighlight = '';
  stateName: any[];
  agencyName: string;
  singleCaseId: any;
  caseidOpenFlag = false;
  getCaseIdTriggered = false;
  validstates = [];
  constructor(
    private actionsSubject$: ActionsSubject,
    private formBuilder: FormBuilder,
    private router: Router,
    private store: Store<any>,
    private agentStore: Store<Agent>,
    private getRetrieveStore: Store<HomeState>,
    private productStore: Store<ProductState>,
    private cmsService: CmsService,
    private el: ElementRef
  ) {}
  // temp to override login in dev/local env
  envName = urlConfig.envName;

  getQuoteForm = new FormGroup({
    leadId: new FormControl(),
    state: new FormControl('-1'),
    age: new FormControl(),
    caseId: new FormControl('-1')
  });

  ngOnInit() {
    this.getInitData();
    this.getLookupData();
    sessionStorage.setItem('state-retrieveQuote', '');
    this.getProfileInfo();
    this.getCaseIdInfo();
    this.getLeadIdInfo();
    this.getStateList();
  }

  getLookupData() {
    this.cmsService.getKey('lookup').subscribe(lookup => {
      this.statesList = lookup.us_states;
      // temp to override login in dev/local env
      if (this.envName === 'local' || this.envName === 'dev') {
        this.agentStore.dispatch(
          filteredStateListAction({ stateList: this.statesList })
        );
      }
    });
  }
  getStateList() {
    //getting state list from the
    this.agentStore.select(getStates).subscribe(res => {
      if (res && res.status) {
        this.validstates = [];
        res.data.forEach(element => {
          const statedata = this.statesList.filter(
            data => data.code === element.stateCode
          )[0];
          if (statedata) this.validstates.push(statedata);
        });
        // temp to override login in dev/local env
        if (this.envName !== 'local' && this.envName !== 'dev') {
          this.agentStore.dispatch(
            filteredStateListAction({ stateList: this.validstates })
          );
        }
      }
    });
  }

  getProfileInfo() {
    this.agentStore.select(getAgentProfile).subscribe(data => {
      this.agencyName = data && data.agencyName ? data.agencyName : undefined;
    });
  }
  getLeadIdInfo() {
    this.getRetrieveStore
      .select(getRetrieveLeadIdData)
      .subscribe((res: any) => {
        this.case_ids = [];
        if (res !== undefined && this.getQuoteForm.value.leadId !== '') {
          this.getCaseIdTriggered = false;
          if (res && res.status === true) {
            if (
              res.data[0].caseId === '' &&
              res.data[0].age === 0 &&
              res.data[0].state === ''
            ) {
              this.getQuoteNoDataFlag = true;
            } else {
              this.getQuoteNoDataFlag = false;
              this.CheckLeadData(res.data);
              if (this.currentLeadIdstate !== '') {
                this.el.nativeElement.querySelector('#lead_id').blur();
                if (res.data[0].age)
                  this.getQuoteForm.controls['age'].setValue(res.data[0].age);
                this.getQuoteForm.controls['state'].setValue(
                  this.currentLeadIdstate
                );
                if (res.data[0].caseId && res.data[0].caseId.length > 0) {
                  const item = {
                    label: res.data[0].caseId,
                    value: res.data[0].caseId
                  };
                  this.case_ids.push(item);
                  this.getCaseIdDefaultValue();
                } else {
                  this.getCaseIdTriggered = true;
                  this.fetchCaseId({
                    code: res.data[0].state,
                    name: this.currentLeadIdstate
                  });
                }
                this.invalidLeadID = false;
                this.LeadIdVlidated = true;
              } else {
                this.invalidLeadID = true;
                this.LeadIdVlidated = false;
              }
            }
          } else if (res && res.status === false) {
            this.invalidLeadID = true;
            this.LeadIdVlidated = false;
          }
        }
      });
  }
  getCaseIdInfo() {
    this.getRetrieveStore.select(getCaseIds).subscribe(res => {
      this.case_ids = [];
      this.getQuoteForm.get('caseId').setValue('');
      if (res && res.status) {
        res.data.forEach(element => {
          const item = {
            label: element.caseId,
            value: element.caseId
          };
          this.case_ids.push(item);
        });
      }
      this.getCaseIdTriggered
        ? this.getQuoteForm.get('caseId').enable()
        : this.getCaseIdDefaultValue();
    });
  }
  getCaseIdDefaultValue() {
    const defaultId = this.case_ids.length === 1 ? this.case_ids[0].value : '';
    this.getQuoteForm.get('caseId').setValue(defaultId);
    this.singleCaseId = defaultId !== '' ? true : false;
    if (this.singleCaseId) this.getQuoteForm.get('caseId').disable();
    else this.getQuoteForm.get('caseId').enable();
  }
  fetchCaseId(state) {
    const data = {
      agencyName: this.agencyName, // Possible Values: "QA Agency", "AK Agency"
      issueStateCd: state && state.code
    };
    if (this.agencyName && state && state.code)
      this.getRetrieveStore.dispatch(getCaseIdAction({ payload: data }));
  }

  getSelectedState(data) {
    this.getCaseIdTriggered = false;
    if (data && data.selected && data.selected.code)
      this.fetchCaseId(data.selected);
  }

  get f() {
    return this.getQuoteForm.controls;
  }
  clearSearchLeadData() {
    //Clearing the Exting Data befor Lead Search
    this.currentLeadIdstate = '';
    this.getQuoteForm.controls['age'].setValue('');
    this.getQuoteForm.get('state').setValue('');
  }
  public stateSelection(event) {}
  public searchleadId() {
    if (this.getQuoteForm.value.leadId !== '') {
      this.clearSearchLeadData();
      const formData = this.getQuoteForm.value;
      this.getRetrieveStore.dispatch(retrieveLeadIDAction({ quote: formData }));
    }
  }

  public CheckLeadData(resdata) {
    if (resdata[0].state) {
      this.currentLeadIdstate = '';
      if (this.states && this.states.length > 0) {
        this.currentLeadIdstate = this.states.filter(
          data => data.code === resdata[0].state
        )[0].name;
      }
    }
  }

  public getInitData() {
    this.setFormControlData();
    this.invalidLeadID = false;
    this.LeadIdVlidated = true;
    //reset lead is search result store
    this.getRetrieveStore.dispatch(
      retrieveLeadIDSuccessAction({ payload: undefined })
    );
  }
  //Recives the states and satename from the agent-state.component
  reciveStates(stateArray) {
    this.states = stateArray.states;
    this.stateName = stateArray.stateName;
    //Dynamically Add Validators for state
    this.getQuoteForm.controls['state'].setValidators([
      FieldValidator.isEmpty('lookup.find_plans_state_error_required'),
      FieldValidator.isNotAvailableOption(
        this.stateName,
        'lookup.find_plans_state_error_invalid'
      )
    ]);
  }
  // Set Form control data
  public setFormControlData() {
    this.getQuoteForm = this.formBuilder.group({
      leadId: [''],
      state: [''],
      age: [
        '',
        [
          FieldValidator.isEmpty('lookup.find_plans_age_error_required'),
          FieldValidator.isNotNumber('lookup.find_plans_age_error_valid_age'),
          FieldValidator.isNumberLess(
            this.minAgeValue,
            'lookup.find_plans_age_error_minimum'
          ),
          FieldValidator.isNumberHigh(
            this.maxAgeValue,
            'lookup.find_plans_age_error_maximum'
          )
        ]
      ],
      caseId: [
        '',
        FieldValidator.isEmpty(
          'agent_portal.landing_case_id_error_required_text'
        )
      ]
    });
  }
  setStateProvCode() {
    if (this.states && this.states.length > 0) {
      this.getQuoteForm.value.stateProvCd = this.states.filter(
        data => data.name === this.getQuoteForm.value.state
      )[0].code;
    }
  }
  public LeadIdDatareset() {
    this.invalidLeadID = false;
    this.LeadIdVlidated = false;
    this.getQuoteNoDataFlag = false;
  }
  public onSubmit() {
    if (this.getQuoteForm.valid) {
      this.setStateProvCode();
      this.store.dispatch(storeCustomerDetailsAction({ payload: undefined }));
      sessionStorage.setItem('state-customerDetails', '');
      this.store.dispatch(agentEditedQuoteAction({ payload: undefined }));
      sessionStorage.setItem('state-edit-quote-status', null);
      this.store.dispatch(ResetRetrieveCart());
      this.resetStoreAndSessions();
      //To get the Form values of Disabled Elements that are prepopulated
      const formData = this.getQuoteForm.getRawValue();
      //To clear the  Invalid Lead Id user entered
      const agentInfo = JSON.parse(sessionStorage.getItem('agent-information'));
      if (agentInfo) {
        formData.partnerId = agentInfo.agencyCd;
      }
      if (!this.LeadIdVlidated) formData.leadId = '';
      formData.stateProvCd = this.getQuoteForm.value.stateProvCd;
      this.store.dispatch(agentGetQuote({ agentGetQuote: formData }));
      this.productStore.dispatch(findProductsAction({ startQuote: formData }));
      sessionStorage.setItem('state-retrieveQuote', '');
      this.store.dispatch(resetRetrieveQuoteAction());
      this.productStore.dispatch(initCart());
      this.subsc = this.actionsSubject$.subscribe((action: any) => {
        if (action.type === SuccessFindProductsAction.type) {
          const data = action.payload;
          this.store.dispatch(agentGetQuoteStateAction({ payload: true }));
          this.router.navigateByUrl('quotes');
        }
      });
    }
  }

  resetStoreAndSessions() {
    // Remove all sessions
    sessionStorage.removeItem('state-agent-buy-flow-elements');
    sessionStorage.removeItem('state-agent-user-details');
    sessionStorage.removeItem('state-agent-cart-details');
    sessionStorage.removeItem('state-agent-product-details');
    sessionStorage.removeItem('state-agent-bundleId');
    this.store.dispatch(agentSSNValidatedAction({ payload: undefined }));
    this.store.dispatch(saveQuoteSuccessAction({ payload: undefined }));
    this.store.dispatch(
      getQuoteDataFromBundleIdSuccess({ payload: undefined })
    );
    this.store.dispatch(resetBuyFlowElements());
    this.store.dispatch(getPersonalDetailsSuccess({ payload: undefined }));
    this.productStore.dispatch(
      SaveAgentCriticalIllnessPlansAction({ data: undefined })
    );
    this.store.dispatch(SetNavigationSource({ payload: undefined }));
  }

  ngOnDestroy() {
    this.subsc.unsubscribe();
  }
}
