import {
  async,
  ComponentFixture,
  TestBed,
  inject
} from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { Router } from '@angular/router';
import { TranslateModule } from '@ngx-translate/core';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { MatSelectModule } from '@angular/material/select';
import { MatAutocompleteModule } from '@angular/material/autocomplete';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { provideMockStore, MockStore } from '@ngrx/store/testing';
import { StoreModule, Store, MemoizedSelector } from '@ngrx/store';
import { of } from 'rxjs';
import { By } from '@angular/platform-browser';
import { CUSTOM_ELEMENTS_SCHEMA, DebugElement } from '@angular/core';
import { SharedPipesModule } from '@aflac/shared/pipes';
import { ProductReducer } from '@aflac/agent/shared';
import * as fromAgentSearchQuote from '@aflac/agent/shared';
import * as fromProduct from '@aflac/agent/shared';
import * as fromAgentGetRetrieveQuote from '../../state/get-retrieve-quote.actions'; // Actions
import { ProductState } from '@aflac/agent/shared'; // Reducer
import { GetQuoteComponent } from './get-quote.component';
import { AgentStateComponent } from '@aflac/agent/shared';
import { SharedCmsModule, CmsService } from '@aflac/shared/cms';
import {
  getCaseIds,
  getRetrieveLeadIdData
} from '../../state/get-retrieve-quote.selectors';
class MockCmsService {
  getKey(key: string | Array<string>, interpolateParams?: Object): any {
    return of({
      us_states: [
        { code: 'AL', name: 'Alabama' },
        { code: 'AK', name: 'Alaska' },
        {
          code: 'TN',
          name: 'Tennessee'
        },
        {
          code: 'TX',
          name: 'Texas'
        },
        {
          code: 'WA',
          name: 'Washington'
        },
        {
          code: 'WI',
          name: 'Wisconsin'
        }
      ]
    });
  }
}
const startQuoteObj = {
  state: 'Alabama',
  age: 45,
  leadId: '11111',
  caseId: 'PROMO123'
};
const filteredStateListMock = [
  {
    code: 'AL',
    name: 'Alabama'
  },
  {
    code: 'AK',
    name: 'Alaska'
  },
  {
    code: 'CO',
    name: 'Colorado'
  },
  {
    code: 'CT',
    name: 'Connecticut'
  },
  {
    code: 'FL',
    name: 'Florida'
  },
  {
    code: 'GA',
    name: 'Georgia'
  },
  {
    code: 'IL',
    name: 'Illinois'
  },
  {
    code: 'MA',
    name: 'Massachusetts'
  },
  {
    code: 'MI',
    name: 'Michigan'
  },
  {
    code: 'MO',
    name: 'Missouri'
  },
  {
    code: 'NE',
    name: 'Nebraska'
  },
  {
    code: 'NJ',
    name: 'New Jersey'
  },
  {
    code: 'NM',
    name: 'New Mexico'
  },
  {
    code: 'NV',
    name: 'Nevada'
  },
  {
    code: 'PA',
    name: 'Pennsylvania'
  },
  {
    code: 'TN',
    name: 'Tennessee'
  },
  {
    code: 'TX',
    name: 'Texas'
  },
  {
    code: 'WA',
    name: 'Washington'
  },
  {
    code: 'WI',
    name: 'Wisconsin'
  }
];
const getstateMock = {
  status: true,
  data: [
    {
      stateCode: 'AL',
      jitAllowed: 'N',
      loa: [
        {
          lineOfAuthority: 'H',
          lineOfAuthorityStatus: 'Active',
          appointed: 'N'
        },
        {
          lineOfAuthority: 'L',
          lineOfAuthorityStatus: 'Active',
          appointed: 'N'
        }
      ]
    },
    {
      stateCode: 'AK',
      jitAllowed: 'N',
      loa: [
        {
          lineOfAuthority: 'H',
          lineOfAuthorityStatus: 'Active',
          appointed: 'N'
        },
        {
          lineOfAuthority: 'L',
          lineOfAuthorityStatus: 'Active',
          appointed: 'N'
        }
      ]
    },
    {
      stateCode: 'NE',
      jitAllowed: 'N',
      loa: [
        {
          lineOfAuthority: 'H',
          lineOfAuthorityStatus: 'Inactive',
          appointed: 'N'
        },
        {
          lineOfAuthority: 'L',
          lineOfAuthorityStatus: 'Inactive',
          appointed: 'N'
        }
      ]
    },
    {
      stateCode: 'NJ',
      jitAllowed: 'N',
      loa: [
        {
          lineOfAuthority: 'H',
          lineOfAuthorityStatus: 'Inactive',
          appointed: 'N'
        },
        {
          lineOfAuthority: 'L',
          lineOfAuthorityStatus: 'Inactive',
          appointed: 'N'
        }
      ]
    },
    {
      stateCode: 'NM',
      jitAllowed: 'N',
      loa: [
        {
          lineOfAuthority: 'H',
          lineOfAuthorityStatus: 'Inactive',
          appointed: 'N'
        },
        {
          lineOfAuthority: 'L',
          lineOfAuthorityStatus: 'Inactive',
          appointed: 'N'
        }
      ]
    }
  ],
  message: 'success'
};
const LeadIdData = {
  status: true,
  data: [
    {
      sfReferenceNumber: 'sfcrm-12',
      fname: 'John',
      lname: 'Richard',
      phone: '9088767564',
      email: 'j@gmail.com',
      state: 'AL',
      caseId: 'QWESR2315 WE',
      DOB: '1990-09-01',
      age: 29
    }
  ],
  message: 'success'
};

const caseidData = {
  status: true,
  data: [
    {
      caseId: 'QWESR2314 WE',
      caseName: 'eHealth',
      agencyCd: 'QAG',
      agencyName: 'QA Agency',
      issueStateCd: 'AL',
      productCd: 'PREC-IA',
      productName: 'Individual Accident',
      effectiveDate: '2020-02-27T00:00:00Z',
      expirationDate: '2025-02-27T00:00:00Z'
    },
    {
      caseId: 'QWESR2315 WE',
      caseName: 'eHealth-direct',
      agencyCd: 'QAG',
      agencyName: 'QA Agency',
      issueStateCd: 'AL',
      productCd: 'PREC-IA',
      productName: 'Individual Accident',
      effectiveDate: '2020-02-27T00:00:00Z',
      expirationDate: '2025-02-27T00:00:00Z'
    }
  ],
  message: 'Success'
};
const agentprofile = {
  agencyCd: 'QAG',
  agencyName: 'QA Agency',
  subProducerCd: '1',
  electronicSignature: false,
  firstName: 'John',
  lastName: 'Smith',
  middleName: 'R',
  voiceRecording: false
};
const product = [
  {
    features: [
      'Accidental Death & Dismemberment',
      'Accidental Injury',
      'Non-Injury hospital admission benefits'
    ],
    id: 1001,
    image: 'assets/images/accident_2.svg',
    productName: 'Accident Insurance',
    riders: [
      { description: '', id: 5001, name: 'Accident Rider 1', value: 14.23 },
      { description: '', id: 5002, name: 'Accident Rider 2', value: 24.23 }
    ],
    startingPrice: 12.32,
    states: ['AK', 'AZ', 'CA'],
    name: 'test'
  },
  {
    features: [
      'Accidental Death & Dismemberment',
      'Accidental Injury',
      'Non-Injury hospital admission benefits'
    ],
    id: 1002,
    image: 'assets/images/cancer_2.svg',
    productName: 'Cancer Insurance',
    riders: [
      { description: '', id: 5001, name: 'Cancer Rider 1', value: 14.23 },
      { description: '', id: 5002, name: 'Cancer Rider 2', value: 24.23 }
    ],
    startingPrice: 17.32,
    states: ['AK', 'AZ', 'CA'],
    name: 'test'
  }
];

class RouterStub {
  navigateByUrl(url: string) {
    console.log('url : ', url);
    return url;
  }
}

describe('GetQuoteComponent', () => {
  let component: GetQuoteComponent;
  let fixture: ComponentFixture<GetQuoteComponent>;
  let de: DebugElement;
  let el: HTMLElement;
  let mockStore: MockStore<any>;
  let productStore: Store<ProductState>;
  let getRetrieveStore: Store<any>;
  let mockQuoteSelector: MemoizedSelector<any, any>;
  let mockProductSelector: MemoizedSelector<any, any>;
  let mockgetAgentProfile: MemoizedSelector<any, any>;
  let mockLeadIdSelector: MemoizedSelector<any, any>;
  let mockCaseIdSelector: MemoizedSelector<any, any>;
  let mockgetStatesSelector: MemoizedSelector<any, any>;
  let mockgefilteredStateListSelector: MemoizedSelector<any, any>;

  let router: Router;
  let navigateSpy;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [GetQuoteComponent, AgentStateComponent],
      imports: [
        TranslateModule.forRoot(),
        RouterTestingModule,
        MatSelectModule,
        MatAutocompleteModule,
        MatFormFieldModule,
        MatInputModule,
        BrowserAnimationsModule,
        ReactiveFormsModule,
        FormsModule,
        SharedPipesModule,
        SharedCmsModule,
        StoreModule.forRoot(ProductReducer)
      ],
      providers: [
        provideMockStore({}),
        { provide: Router, useClass: RouterStub },
        { provide: CmsService, useClass: MockCmsService }
      ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(GetQuoteComponent);
    router = TestBed.get(Router);
    component = fixture.componentInstance;
    mockStore = TestBed.get(Store);
    productStore = TestBed.get(Store);
    getRetrieveStore = TestBed.get(Store);

    mockQuoteSelector = mockStore.overrideSelector(
      fromAgentSearchQuote.agentSelectedQuote,
      startQuoteObj
    );
    mockgetAgentProfile = mockStore.overrideSelector(
      fromAgentSearchQuote.getAgentProfile,
      agentprofile
    );
    mockgetStatesSelector = mockStore.overrideSelector(
      fromAgentSearchQuote.getStates,
      getstateMock
    );
    mockgefilteredStateListSelector = mockStore.overrideSelector(
      fromAgentSearchQuote.filteredStateList,
      filteredStateListMock
    );
    mockCaseIdSelector = mockStore.overrideSelector(getCaseIds, caseidData);

    mockLeadIdSelector = mockStore.overrideSelector(
      getRetrieveLeadIdData,
      LeadIdData
    );

    mockProductSelector = mockStore.overrideSelector(
      fromProduct.products,
      product
    );

    de = fixture.debugElement.query(By.css('form'));
    el = de.nativeElement;
    fixture.detectChanges();
    navigateSpy = spyOn(router, 'navigateByUrl');
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should call getInitData funtion', () => {
    component.getInitData();
    expect(component as any).toBeDefined();
  });

  it('should update product state on form submit', () => {
    spyOn(productStore, 'dispatch').and.returnValue(of(true));
    component.onSubmit();
    expect((component as any).productStore).toBeDefined();
  });

  it('should get the products', () => {
    const products = product;
    spyOn(productStore, 'select').and.returnValue(of(products));
    component.onSubmit();
    expect((component as any).productStore).toBeDefined();
  });

  it('should call the onSubmit method', async(() => {
    fixture.detectChanges();
    spyOn(component, 'onSubmit');
    el = fixture.debugElement.query(By.css('button')).nativeElement;
    el.click();
    expect(component.onSubmit).toHaveBeenCalledTimes(0);
  }));

  it('form should be invalid ', () => {
    component.getQuoteForm.controls['leadId'].setValue('');
    component.getQuoteForm.controls['state'].setValue('');
    component.getQuoteForm.controls['age'].setValue('');
    component.getQuoteForm.controls['caseId'].setValue('');
    expect(component.getQuoteForm.valid).toBeFalsy();
  });

  it('form should be valid ', () => {
    component.getQuoteForm.controls['leadId'].setValue('111');
    component.getQuoteForm.controls['state'].setValue('Alabama');
    component.getQuoteForm.controls['age'].setValue('45');
    component.getQuoteForm.controls['caseId'].setValue('APQRETSD WE');
    expect(component.getQuoteForm.valid).toBeTruthy();
  });

  it('should call valueChange funtion', () => {
    const event = new KeyboardEvent('keyup', {
      bubbles: true,
      cancelable: true,
      shiftKey: false
    });
    const input = fixture.debugElement.query(By.css('#state'));
    const inputElement = input.nativeElement;
    inputElement.value = '';
    inputElement.dispatchEvent(event);
    component.toHighlight = '';
    expect(component as any).toBeDefined();
  });

  it('should call clearStateField funtion', () => {
    const event = new KeyboardEvent('click', {
      bubbles: true,
      cancelable: true,
      shiftKey: false
    });
    const input = fixture.debugElement.query(By.css('#state'));
    const inputElement = input.nativeElement;
    inputElement.dispatchEvent(event);
    expect(component as any).toBeDefined();
  });

  it('should call getLeadIdInfo funtion', () => {
    component.getLeadIdInfo();
    expect(component as any).toBeDefined();
  });

  it('should call searchleadId funtion', () => {
    component.searchleadId();
    expect(component as any).toBeDefined();
  });

  it('should submit form ', async(() => {
    component.states = [];
    component.getQuoteForm.setValue({
      leadId: '111111',
      state: 'Alabama',
      age: '31',
      caseId: 'APQRETSD WE'
    });
    component.getQuoteNoDataFlag = true;
    component.onSubmit();
  }));
});
