import { state } from '@angular/animations';
import { Component, OnInit, OnDestroy, Inject } from '@angular/core';
import { SelectionModel } from '@angular/cdk/collections';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { PerfectScrollbarConfigInterface } from 'ngx-perfect-scrollbar';
import { Router } from '@angular/router';
import { Store, ActionsSubject } from '@ngrx/store';
import { Subscription } from 'rxjs';
import { CmsService } from '@aflac/shared/cms';
import * as RetrieveQuoteActions from '../../state/get-retrieve-quote.actions';
import {
  agentGetQuote,
  agentGetQuoteStateAction,
  storeCustomerDetailsAction
} from '@aflac/agent/shared'; // Actions
import { initCart } from '@aflac/agent/shared'; // Product Actions
import { getRetrieveQuoteData } from '../../state/get-retrieve-quote.selectors';

export interface PeriodicElement {
  id: number;
  name: string;
  state: string;
  dob: string;
  email: string;
  products: string;
}

@Component({
  selector: 'aflac-customer-search-result-modal',
  templateUrl: './customer-search-result-modal.component.html',
  styleUrls: ['./customer-search-result-modal.component.scss']
})
export class CustomerSearchResultModalComponent implements OnInit, OnDestroy {
  subsc: Subscription;
  public config: PerfectScrollbarConfigInterface = {
    scrollingThreshold: 0,
    minScrollbarLength: 148,
    maxScrollbarLength: 148,
    wheelSpeed: 0.6
  };
  displayedColumns: string[] = [
    'select',
    'name',
    'state',
    'dob',
    'email',
    'products'
  ];
  dataSource: any;
  selection = new SelectionModel<PeriodicElement>(true, []);
  errorFlag = false;
  errorMsg: string;
  states: any;
  stateProvCd: string;
  selectedCustomer: any;
  enablescrollbar = false;

  constructor(
    private store: Store<any>,
    private actionsSubject$: ActionsSubject,
    private router: Router,
    private cmsService: CmsService,
    private dialogRef: MatDialogRef<CustomerSearchResultModalComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) {}

  ngOnInit() {
    this.getLookupData();
    this.dataSource = this.data.payload;
    this.dataSource.length > 4
      ? (this.enablescrollbar = true)
      : (this.enablescrollbar = false);
    this.retrieveQuoteSub();
  }
  retrieveQuoteSub() {
    this.subsc = this.store
      .select(getRetrieveQuoteData)
      .subscribe(retrieveData => {
        if (retrieveData && retrieveData.status) {
          if (Object.keys(retrieveData.data).length > 0) {
            const agentInfo = JSON.parse(
              sessionStorage.getItem('agent-information')
            );
            const searchObj = {
              state: this.getStateName(retrieveData.data.quotes[0].riskStateCd),
              stateProvCd: retrieveData.data.quotes[0].riskStateCd,
              age: this.ageFromDateOfBirthday(
                retrieveData.data.quotes[0].insureds[0].dateOfBirth
              ),
              caseId: retrieveData.data.quotes[0].caseId,
              partnerId: agentInfo.agencyCd
            };
            const selectedCustomerData = this.dataSource[
              this.selectedCustomer - 1
            ];
            const customerPayload = {
              firstName: selectedCustomerData.firstName,
              lastName: selectedCustomerData.lastName,
              email: selectedCustomerData.email
            };
            this.storeRetrieveQuoteDataToSession(retrieveData.data.quotes);
            this.store.dispatch(agentGetQuote({ agentGetQuote: searchObj }));
            this.store.dispatch(
              storeCustomerDetailsAction({ payload: customerPayload })
            );
            sessionStorage.setItem(
              'state-customerDetails',
              JSON.stringify(customerPayload)
            );
            this.store.dispatch(initCart());
            this.store.dispatch(agentGetQuoteStateAction({ payload: false }));
            this.dialogRef.close(true);
            this.router.navigate(['quotes']);
          }
        }
      });
  }
  getLookupData() {
    this.cmsService.getKey('lookup').subscribe(lookup => {
      this.states = lookup.us_states;
    });
  }

  // The label for the checkbox on the passed row
  checkboxLabel(row?: PeriodicElement): string {
    return `${this.selection.isSelected(row) ? 'deselect' : 'select'} row ${
      row.name
    }`;
  }
  public getStateName(stateCode): string {
    let statename: string;
    if (stateCode) {
      statename = '';
      if (this.states && this.states.length > 0) {
        statename = this.states.filter(data => data.code === stateCode)[0].name;
      }
    }
    return statename;
  }

  public getproductNames(index): string {
    let productNames = '';
    if (
      this.dataSource[index].bundle.quoteList &&
      this.dataSource[index].bundle.quoteList.length > 0
    ) {
      this.dataSource[index].bundle.quoteList.forEach(item => {
        productNames === ''
          ? (productNames += item.productName)
          : (productNames += ', ' + item.productName);
      });
    }
    return productNames;
  }

  onSubmit() {
    const formData = this.selectedCustomer;
    const customerSRValue = this.dataSource[formData - 1];
    this.store.dispatch(
      RetrieveQuoteActions.retrieveQuoteAction({
        quote: customerSRValue.bundle.id
      })
    );
  }

  // Save retrieve quote data from store to session
  public storeRetrieveQuoteDataToSession(quoteData) {
    sessionStorage.setItem('state-retrieveQuote', JSON.stringify(quoteData));
  }

  private ageFromDateOfBirthday(dateOfBirth: any): number {
    const today = new Date();
    const birthDate = new Date(dateOfBirth);
    let age = today.getFullYear() - birthDate.getFullYear();
    const m = today.getMonth() - birthDate.getMonth();

    if (m < 0 || (m === 0 && today.getDate() < birthDate.getDate())) {
      age--;
    }
    return age;
  }

  ngOnDestroy() {
    this.subsc.unsubscribe();
  }
}
