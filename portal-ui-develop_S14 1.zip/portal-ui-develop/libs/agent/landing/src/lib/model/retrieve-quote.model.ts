export interface RetrieveQuote {
  message: string;
  data: any[];
  status: boolean;
  isCloned?: boolean;
}
