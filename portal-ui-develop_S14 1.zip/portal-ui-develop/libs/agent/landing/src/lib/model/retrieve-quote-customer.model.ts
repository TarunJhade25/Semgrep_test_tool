export interface RetrieveQuoteCustomer {
  name: string;
  state: string;
  dob?: string;
  email: string;
  products: string;
}
