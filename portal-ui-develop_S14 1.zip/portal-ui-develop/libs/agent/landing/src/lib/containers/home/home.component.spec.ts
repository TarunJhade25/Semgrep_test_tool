import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { StoreModule, Store, MemoizedSelector } from '@ngrx/store';
import { provideMockStore, MockStore } from '@ngrx/store/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { TranslateModule } from '@ngx-translate/core';
import { EffectsModule } from '@ngrx/effects';
import { RouterModule } from '@angular/router';
import { APP_BASE_HREF } from '@angular/common';
import { of } from 'rxjs';

import { HomeComponent } from './home.component';
import { AgentLandingModule } from '../../agent-landing.module';
import { AuthModule } from '@aflac/agent/auth';
import { GetRetrieveQuoteEffects } from '@aflac/agent/landing';
import { Agent } from '@aflac/agent/shared';
import { HomeState } from '@aflac/agent/landing';
import * as AgentActions from '@aflac/agent/shared';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

describe('HomeComponent', () => {
  let component: HomeComponent;
  let fixture: ComponentFixture<HomeComponent>;
  let mockStore: MockStore<any>;
  // const mockUsernameSelector: MemoizedSelector<any, any>;
  let agentStore: Store<Agent>;
  let getQuoteStore: Store<HomeState>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        AgentLandingModule,
        AuthModule,
        HttpClientTestingModule,
        TranslateModule.forRoot(),
        EffectsModule.forRoot([]),
        RouterModule.forRoot([]),
        BrowserAnimationsModule,
        StoreModule.forRoot([])
      ],
      providers: [{ provide: APP_BASE_HREF, useValue: '/' }]
    }).compileComponents();
  }));

  beforeEach(() => {
    agentStore = TestBed.get(Store);
    getQuoteStore = TestBed.get(Store);
    mockStore = TestBed.get(Store);
    fixture = TestBed.createComponent(HomeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
  it('should update state on component init', () => {
    spyOn(agentStore, 'dispatch').and.returnValue(of(true));
    component.ngOnInit();
    expect(agentStore.dispatch).toHaveBeenCalledWith(AgentActions.loadAgent());
  });
});
