import { Component, OnInit } from '@angular/core';
import { CmsService } from '@aflac/shared/cms';
import { Store } from '@ngrx/store';
import { Agent } from '@aflac/agent/shared';
import * as AgentActions from '@aflac/agent/shared';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'aflac-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent implements OnInit {
  state_list = [
    { value: 'state_1', label: 'state_1 label' },
    { value: 'state_2', label: 'state_2 label' },
    { value: 'state_3', label: 'state_3 label' }
  ];
  case_id_list = [
    { value: 'case_1', label: 'case_1 label' },
    { value: 'case_2', label: 'case_2 label' },
    { value: 'case_3', label: 'case_3 label' }
  ];

  constructor(
    private cmsService: CmsService,
    private agentStore: Store<Agent>,
    private http: HttpClient
  ) {}

  ngOnInit() {
    this.agentStore.dispatch(AgentActions.loadAgent());
  }
}
