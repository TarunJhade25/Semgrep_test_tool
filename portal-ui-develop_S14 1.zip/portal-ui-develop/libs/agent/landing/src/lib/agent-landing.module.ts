import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { EffectsModule } from '@ngrx/effects';
import { StoreModule } from '@ngrx/store';
import { SelectProductEffects } from '@aflac/agent/shared';
import { GetRetrieveQuoteEffects } from './state/get-retrieve-quote.effects';
import * as fromHome from './state/reducers';
import * as fromAgentSearchQuote from '@aflac/agent/shared';
import * as fromProduct from '@aflac/agent/shared';
import * as fromSaveYourQuote from '@aflac/agent/shared';
import { SaveYourQuoteEffects } from '@aflac/agent/shared';
import { SharedMaterialModule } from '@aflac/shared/material';
import { SharedCmsModule } from '@aflac/shared/cms';
import { AgentSharedModule } from '@aflac/agent/shared';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { SharedvalidatorsModule } from '@aflac/shared/validators';
import { SharedUiModule } from '@aflac/shared/ui';
import { HomeComponent } from './containers/home/home.component';
import { GetQuoteComponent } from './components/get-quote/get-quote.component';
import { RetrieveQuoteComponent } from './components/retrieve-quote/retrieve-quote.component';
import { CustomerSearchResultModalComponent } from './components/customer-search-result-modal/customer-search-result-modal.component';
import {
  PerfectScrollbarModule,
  PerfectScrollbarConfigInterface,
  PERFECT_SCROLLBAR_CONFIG
} from 'ngx-perfect-scrollbar';
import { SharedPipesModule } from '@aflac/shared/pipes';

const DEFAULT_PERFECT_SCROLLBAR_CONFIG: PerfectScrollbarConfigInterface = {
  wheelPropagation: true
};

@NgModule({
  imports: [
    CommonModule,
    SharedMaterialModule,
    AgentSharedModule,
    SharedCmsModule,
    FormsModule,
    ReactiveFormsModule,
    SharedvalidatorsModule,
    SharedPipesModule,
    SharedUiModule,
    StoreModule.forFeature(fromHome.homeFeatureKey, fromHome.homeReducer),
    StoreModule.forFeature(
      fromAgentSearchQuote.agentSearchQuoteFeatureKey,
      fromAgentSearchQuote.agentSearchQuoteReducer
    ),
    EffectsModule.forFeature([GetRetrieveQuoteEffects]),
    StoreModule.forFeature(
      fromProduct.ProductFeatureKey,
      fromProduct.ProductReducer
    ),
    EffectsModule.forFeature([SelectProductEffects]),
    StoreModule.forFeature(
      fromSaveYourQuote.saveYourQuoteFeatureKey,
      fromSaveYourQuote.saveYourQuoteReducer
    ),
    EffectsModule.forFeature([SaveYourQuoteEffects]),
    RouterModule.forChild([
      {
        path: '',
        pathMatch: 'full',
        component: HomeComponent
      }
    ]),
    PerfectScrollbarModule
  ],
  providers: [
    {
      provide: PERFECT_SCROLLBAR_CONFIG,
      useValue: DEFAULT_PERFECT_SCROLLBAR_CONFIG
    }
  ],
  declarations: [
    HomeComponent,
    GetQuoteComponent,
    RetrieveQuoteComponent,
    CustomerSearchResultModalComponent
  ],

  entryComponents: [CustomerSearchResultModalComponent]
})
export class AgentLandingModule {}
