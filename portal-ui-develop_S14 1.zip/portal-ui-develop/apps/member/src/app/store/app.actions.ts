import { createAction, props } from '@ngrx/store';

export const saveAppRoutes = createAction(
  '[App-sales]  Save App Routes',
  props<{ appRoutes: any }>()
);
