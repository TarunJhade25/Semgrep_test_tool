import { BrowserModule, Title } from '@angular/platform-browser';
import { NgModule, APP_INITIALIZER, Injector } from '@angular/core';

import { AppComponent } from './app.component';
import { MatFormFieldModule, MatInputModule } from '@angular/material';
import { RouterModule } from '@angular/router';
import { StoreModule } from '@ngrx/store';
import { EffectsModule } from '@ngrx/effects';
import { StoreDevtoolsModule } from '@ngrx/store-devtools';
import { environment } from '../environments/environment';
import { StoreRouterConnectingModule } from '@ngrx/router-store';
import { TranslateModule, TranslateLoader } from '@ngx-translate/core';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';
import { HttpClientModule, HttpClient } from '@angular/common/http';
import { SharedCmsModule } from '@aflac/shared/cms';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { MatVideoModule } from 'mat-video';
import {
  entityConfig,
  defaultDataServiceConfig
} from '@aflac/shared/data-model';
import { EntityDataModule, DefaultDataServiceConfig } from '@ngrx/data';
import { MemberSharedModule, interceptorProviders } from '@aflac/member/shared';
import {
  TestComponent,
  ContactUsComponent,
  MemberSystemErrorComponent
} from '@aflac/member/shared';
import {
  PolicySummaryComponent,
  PolicyDetailsComponent,
  PolicyManageBeneficiaryComponent,
  PolicyAddEditBeneficiaryComponent,
  ManageCoveredPersonComponent,
  PolicyManageCoveredPersonsComponent,
  PolicyRemoveDependentComponent,
  PolicyManageCoveredPersonReviewComponent,
  PolicyDependentEligibilityComponent,
  MemberPoliciesModule
} from '@aflac/member/policies';
import { SharedLayoutModule, BreadcrumbComponent } from '@aflac/shared/layout';
import { NguCarouselModule } from '@ngu/carousel';
import { AuthCallbackComponent } from '@aflac/member/shared';
import { CarouselModule } from 'ngx-owl-carousel-o';
import { PostMessageInitializer } from './PostMessageInitializer';
import { RouteInitializer } from './RouteInitializer';
import { ErrorInterceptorModule } from '@aflac/sales/shared';
import * as appReducer from './store/app.reducers';
import {
  BillingPaymentComponent,
  MemberBillingModule
} from '@aflac/member/billing';
import { HomeComponent, MemberLandingModule } from '@aflac/member/landing';
import {
  ManagePaymentComponent,
  AddPaymentComponent,
  RemovePaymentComponent,
  UpdateDraftDateComponent,
  OnetimePaymentComponent,
  PayNowComponent,
  MemberPaymentModule
} from '@aflac/member/payment';
import {
  MemberResourceCenterModule,
  ResourceCenterComponent
} from '@aflac/member/resource-center';
import {
  AccountDetailsComponent,
  AccountEditComponent,
  MemberAccountModule
} from '@aflac/member/account';
import {
  ClaimsDDSetupComponent,
  ClaimsLandingComponent,
  ClaimsSubmitComponent,
  ClaimsUploadDocumentsComponent,
  MemberClaimsModule
} from '@aflac/member/claims';
export function cmsLoaderFactory(http: HttpClient) {
  return new TranslateHttpLoader(http, environment.cmsUrl, '');
}
@NgModule({
  declarations: [AppComponent, BreadcrumbComponent],
  imports: [
    ErrorInterceptorModule,
    BrowserModule,
    HttpClientModule,
    MatFormFieldModule,
    MatInputModule,
    BrowserAnimationsModule,
    CarouselModule,
    MatVideoModule,
    NguCarouselModule,
    StoreModule.forFeature(
      appReducer.appStateFeatureKey,
      appReducer.appStateReducer
    ),
    RouterModule.forRoot(
      [
        //TODO redirection is added for testing purpose only
        // {
        //   path: '',
        //   data: { activeTab: 'Home' },
        //   loadChildren: () =>
        //     import('@aflac/member/landing').then(
        //       module => module.MemberLandingModule
        //     ),
        //   pathMatch: 'full'
        // },
        // {
        //   path: 'contact-us',
        //   component: ContactUsComponent,
        //   canActivate: [MemberAuthGuardService]
        // },
        // {
        //   path: 'home',
        //   data: { activeTab: 'Home' },
        //   loadChildren: () =>
        //     import('@aflac/member/landing').then(
        //       module => module.MemberLandingModule
        //     )
        // },
        // {
        //   path: 'policies',
        //   data: { activeTab: 'Policies' },
        //   loadChildren: () =>
        //     import('@aflac/member/policies').then(
        //       module => module.MemberPoliciesModule
        //     )
        // },
        // {
        //   path: 'billing',
        //   data: { activeTab: 'Billing & Payments' },
        //   loadChildren: () =>
        //     import('@aflac/member/billing').then(
        //       module => module.MemberBillingModule
        //     )
        // },
        // {
        //   path: 'payment',
        //   data: { activeTab: 'Billing & Payments' },
        //   loadChildren: () =>
        //     import('@aflac/member/payment').then(
        //       module => module.MemberPaymentModule
        //     )
        // },
        // {
        //   path: 'account',
        //   data: { activeTab: 'Account' },
        //   loadChildren: () =>
        //     import('@aflac/member/account').then(
        //       module => module.MemberAccountModule
        //     )
        // },
        // {
        //   path: 'resource-center',
        //   data: { activeTab: 'Resource Center' },
        //   loadChildren: () =>
        //     import('@aflac/member/resource-center').then(
        //       module => module.MemberResourceCenterModule
        //     )
        // },
        // {
        //   //load claims module
        //   path: 'claims',
        //   data: { activeTab: 'Claims' },
        //   loadChildren: () =>
        //     import('@aflac/member/claims').then(
        //       module => module.MemberClaimsModule
        //     )
        // },
        // /* {
        //   path: 'page-not-found',
        //   component: PageNotFoundComponent
        // },*/
        // //TODO redirection is added for testing purpose
        // {
        //   path: 'test-page',
        //   component: TestComponent,
        //   canActivate: [TestPageGuard],
        //   data: { plainHeader: true }
        // },
        // {
        //   path: 'auth-callback',
        //   component: AuthCallbackComponent,
        //   data: { plainHeader: true }
        // },
        // { path: '**', redirectTo: 'test-page' }
      ],
      {
        initialNavigation: 'enabled',
        scrollPositionRestoration: 'enabled',
        anchorScrolling: 'enabled',
        onSameUrlNavigation: 'reload'
      }
    ),
    BrowserAnimationsModule,
    SharedLayoutModule,
    SharedCmsModule,
    MemberSharedModule,
    MemberPoliciesModule,
    MemberBillingModule,
    MemberLandingModule,
    MemberPaymentModule,
    MemberResourceCenterModule,
    MemberAccountModule,
    MemberClaimsModule,
    HttpClientModule,
    StoreModule.forRoot(
      {},
      {
        metaReducers: [], //!environment.production ? [] : [],
        runtimeChecks: {
          strictActionImmutability: true,
          strictStateImmutability: true
        }
      }
    ),
    EffectsModule.forRoot([]),
    !environment.production ? StoreDevtoolsModule.instrument() : [],
    StoreRouterConnectingModule.forRoot(),
    TranslateModule.forRoot({
      loader: {
        provide: TranslateLoader,
        useFactory: cmsLoaderFactory,
        deps: [HttpClient]
      }
    }),
    EntityDataModule.forRoot(entityConfig)
  ],
  providers: [
    Title,
    { provide: DefaultDataServiceConfig, useValue: defaultDataServiceConfig },
    {
      provide: APP_INITIALIZER,
      multi: true,
      useFactory: RouteInitializer,
      deps: [Injector]
    },
    {
      provide: APP_INITIALIZER,
      multi: true,
      useFactory: PostMessageInitializer
    },
    interceptorProviders
  ],

  bootstrap: [AppComponent],
  entryComponents: [
    HomeComponent,
    ContactUsComponent,
    TestComponent,
    AuthCallbackComponent,
    PolicySummaryComponent,
    PolicyDetailsComponent,
    PolicyManageBeneficiaryComponent,
    PolicyAddEditBeneficiaryComponent,
    ManageCoveredPersonComponent,
    PolicyManageCoveredPersonsComponent,
    PolicyRemoveDependentComponent,
    PolicyManageCoveredPersonReviewComponent,
    PolicyDependentEligibilityComponent,
    BillingPaymentComponent,
    ManagePaymentComponent,
    AddPaymentComponent,
    RemovePaymentComponent,
    UpdateDraftDateComponent,
    OnetimePaymentComponent,
    PayNowComponent,
    ResourceCenterComponent,
    AccountDetailsComponent,
    AccountEditComponent,
    ClaimsLandingComponent,
    ClaimsDDSetupComponent,
    ClaimsSubmitComponent,
    ClaimsUploadDocumentsComponent,
    MemberSystemErrorComponent
  ]
})
export class AppModule {}
