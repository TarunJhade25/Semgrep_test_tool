import { Component, ElementRef, ViewChild } from '@angular/core';
import { ColorSchemeService } from '@aflac/shared/ui';
import { Title } from '@angular/platform-browser';
import { Event, NavigationStart, Router } from '@angular/router';
import { Store } from '@ngrx/store';
import { AppData } from './model/app.model';
import { saveAppRoutes } from './store/app.actions';
import { urlConfig } from '@aflac/shared/data-model';
import { SessionService } from '@aflac/member/shared';

@Component({
  selector: 'aflac-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  @ViewChild('main', { static: true }) mainContainer: ElementRef;
  globalRoutes: any;
  showComponents;
  constructor(
    private colorSvc: ColorSchemeService,
    private titleService: Title,
    public router: Router,
    private store: Store<{ appData: AppData }>,
    private sessionService: SessionService
  ) {
    this.scrollUp();
    colorSvc.load();
    this.storeRoutes();
    this.setComponentVisibilty();
  }
  title = 'member';
  navigateToMain() {
    this.mainContainer.nativeElement.setAttribute('tabindex', '-1');
    this.mainContainer.nativeElement.focus();
    this.mainContainer.nativeElement.scrollIntoView();
    this.mainContainer.nativeElement.removeAttribute('tabindex');
  }
  public scrollUp() {
    this.router.events.subscribe((event: Event) => {
      if (event instanceof NavigationStart) {
        window.scroll(0, 0);
      }
    });
  }

  /**Store Routes in NgRx Store */
  public storeRoutes() {
    this.globalRoutes = window['_availableRoutes'];
    this.store.dispatch(saveAppRoutes({ appRoutes: this.globalRoutes }));
  }

  setComponentVisibilty() {
    console.log('setComponentVisibilty called');
    const isAuthenticated = sessionStorage.getItem('authInfo');
    const isLocal =
      urlConfig.envName && urlConfig.envName.toLowerCase() === 'local';
    const isDev =
      urlConfig.envName && urlConfig.envName.toLowerCase() === 'dev';

    this.showComponents = isAuthenticated || isLocal || isDev;
    console.log('showComponents value: ', isAuthenticated || isLocal || isDev);

    if (!this.showComponents) {
      this.sessionService.getAuthInfoSub().subscribe(isAuthInfoAvailable => {
        // this.showComponents = isAuthInfoAvailable;
        this.showComponents = true; // to be removed
        console.log(
          'showComponents value inside subscriber: ',
          isAuthInfoAvailable
        );
      });
    }
    this.showComponents = true; // to be removed
  }
}
