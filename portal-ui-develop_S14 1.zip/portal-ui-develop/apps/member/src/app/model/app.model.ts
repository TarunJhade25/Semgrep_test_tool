export interface AppData {
  route: any;
}
