import { HttpClient } from '@angular/common/http';
import { Injector } from '@angular/core';
import { NavigationStart, Router } from '@angular/router';
import { of } from 'rxjs';
import { tap } from 'rxjs/operators';
import { urlConfig } from '@aflac/shared/data-model';
import {
  ContactUsComponent,
  MemberAuthGuardService,
  TestComponent,
  TestPageGuard,
  AuthCallbackComponent,
  PolicyGuardService,
  AccountGuardService,
  MemberSystemErrorComponent
} from '@aflac/member/shared';
import {
  PolicySummaryComponent,
  PolicyDetailsComponent,
  PolicyManageBeneficiaryComponent,
  PolicyAddEditBeneficiaryComponent,
  ManageCoveredPersonComponent,
  PolicyManageCoveredPersonsComponent,
  PolicyRemoveDependentComponent,
  PolicyManageCoveredPersonReviewComponent,
  PolicyDependentEligibilityComponent
} from '@aflac/member/policies';
import {
  ManagePaymentComponent,
  AddPaymentComponent,
  RemovePaymentComponent,
  UpdateDraftDateComponent,
  OnetimePaymentComponent,
  PayNowComponent
} from '@aflac/member/payment';
import { BillingPaymentComponent } from '@aflac/member/billing';
import { HomeComponent } from '@aflac/member/landing';
import { ResourceCenterComponent } from '@aflac/member/resource-center';
import {
  AccountDetailsComponent,
  AccountEditComponent
} from '@aflac/member/account';
import {
  ClaimsDDSetupComponent,
  ClaimsLandingComponent,
  ClaimsSubmitComponent,
  ClaimsUploadDocumentsComponent
} from '@aflac/member/claims';
export function RouteInitializer(injector: Injector) {
  return function(): Promise<void> {
    const baseURL = urlConfig.cmsUrl;
    const http = injector.get(HttpClient);
    const router = injector.get(Router);
    let currentUrl: string;
    /* get the current url*/
    const navSub$ = router.events.subscribe(async routerEvent => {
      if (routerEvent instanceof NavigationStart) {
        currentUrl = routerEvent.url;
      }
      navSub$.unsubscribe();
    });
    /* On page refresh, fetch the details from session storage and reset the router */
    if (sessionStorage.getItem('_availableRoutes')) {
      return of(JSON.parse(sessionStorage.getItem('_availableRoutes')))
        .pipe(
          tap(config => {
            configDynamicData(config, router);
          })
        )
        .toPromise();
    } else {
      /* Fetch the urls for the first time or deep link scenarios */
      console.log(baseURL);
      return http
        .get(baseURL + 'routes/en')
        .toPromise()
        .then(config => {
          configDynamicData(config, router);
          if (currentUrl) {
            router.navigateByUrl(currentUrl);
          } else {
            router.navigateByUrl(config['empty']);
          }
        });
    }
  };

  /**
   * Configure dynamic URL Structure
   * @config: Router details from CMS;
   * @routerInstance: Router instance;
   * @url: the url from deep link scenario;
   */
  function configDynamicData(config: any, routerInstance: Router) {
    /* Setting the routes to session for first time app load */
    if (!sessionStorage.getItem('_availableRoutes')) {
      sessionStorage.setItem('_availableRoutes', JSON.stringify(config));
    }
    window['_availableRoutes'] = config;
    const staticRoutes = [];
    staticRoutes.push(...routerInstance.config);
    const dynamicRoutes = [
      // {
      //   path: config['empty'],
      //   data: { activeTab: 'Home' },
      //   component: HomeComponent,
      //   canActivate: [MemberAuthGuardService]
      // },
      {
        path: config['empty'],
        pathMatch: 'full',
        data: { activeTab: 'Home' },
        component: HomeComponent,
        canActivate: [MemberAuthGuardService]
      },
      {
        path: config['contact_us'],
        component: ContactUsComponent,
        canActivate: [MemberAuthGuardService]
      },
      {
        path: config['policies'],
        data: { activeTab: 'Policies' },
        canActivate: [MemberAuthGuardService],
        component: PolicySummaryComponent
      },
      {
        path: config['policy_details'],
        canActivate: [MemberAuthGuardService, PolicyGuardService],
        // PolicyGuardService
        data: { policyNumber: '', activeTab: 'Policies' },
        component: PolicyDetailsComponent
      },
      {
        path: config['manage_beneficiaries'],
        canActivate: [MemberAuthGuardService, PolicyGuardService],
        // PolicyGuardService
        data: { activeTab: 'Policies' },
        children: [
          {
            path: config['empty'],
            pathMatch: 'full',
            component: PolicyManageBeneficiaryComponent
          },
          {
            path: config['beneficiaries_add'],
            component: PolicyAddEditBeneficiaryComponent,
            data: { plainHeader: true }
          },
          {
            path: config['beneficiaries_edit'],
            component: PolicyAddEditBeneficiaryComponent,
            data: { plainHeader: true }
          }
        ]
      },
      {
        path: config['manage_covered_persons'],
        canActivate: [MemberAuthGuardService, PolicyGuardService],
        data: { activeTab: 'Policies' },
        component: ManageCoveredPersonComponent
      },
      {
        path: config['add_dependent'],
        canActivate: [MemberAuthGuardService, PolicyGuardService],
        data: { plainHeader: true, activeTab: 'Policies' },
        component: PolicyManageCoveredPersonsComponent
      },
      {
        path: config['remove_dependent'],
        canActivate: [MemberAuthGuardService, PolicyGuardService],
        data: { plainHeader: true, activeTab: 'Policies' },
        component: PolicyRemoveDependentComponent
      },
      {
        path: config['dependent_review'],
        canActivate: [MemberAuthGuardService, PolicyGuardService],
        data: { plainHeader: true, activeTab: 'Policies' },
        component: PolicyManageCoveredPersonReviewComponent
      },
      {
        path: config['dependent_eligibility'],
        canActivate: [MemberAuthGuardService, PolicyGuardService],
        data: { plainHeader: true, activeTab: 'Policies' },
        component: PolicyDependentEligibilityComponent
      },
      {
        path: config['billing_and_payment'],
        data: { activeTab: 'Billing & Payments' },
        canActivate: [MemberAuthGuardService],
        component: BillingPaymentComponent
      },
      {
        path: config['manage_payment'],
        pathMatch: 'full',
        data: { activeTab: 'Billing & Payments' },
        canActivate: [MemberAuthGuardService],
        component: ManagePaymentComponent
      },
      {
        path: config['add_payment'],
        pathMatch: 'full',
        canActivate: [MemberAuthGuardService],
        component: AddPaymentComponent,
        data: { plainHeader: true, activeTab: 'Billing & Payments' }
      },
      {
        path: config['edit_payment'],
        pathMatch: 'full',
        canActivate: [MemberAuthGuardService],
        component: AddPaymentComponent,
        data: { plainHeader: true, activeTab: 'Billing & Payments' }
      },
      {
        path: config['change_payment_method'],
        pathMatch: 'full',
        canActivate: [MemberAuthGuardService],
        component: AddPaymentComponent,
        data: { plainHeader: true, activeTab: 'Billing & Payments' }
      },
      {
        path: config['remove_payement'],
        pathMatch: 'full',
        canActivate: [MemberAuthGuardService],
        component: RemovePaymentComponent,
        data: { plainHeader: true, activeTab: 'Billing & Payments' }
      },
      {
        path: config['change_autopay_date'],
        pathMatch: 'full',
        canActivate: [MemberAuthGuardService],
        component: UpdateDraftDateComponent,
        data: { plainHeader: true, activeTab: 'Billing & Payments' }
      },
      {
        path: config['one_time_payment'],
        pathMatch: 'full',
        canActivate: [MemberAuthGuardService],
        component: OnetimePaymentComponent,
        data: { plainHeader: true, activeTab: 'Billing & Payments' }
      },
      {
        path: config['add_one_time_payment'],
        pathMatch: 'full',
        canActivate: [MemberAuthGuardService],
        component: PayNowComponent,
        data: { plainHeader: true, activeTab: 'Billing & Payments' }
      },
      {
        path: config['edit_one_time_payment'],
        pathMatch: 'full',
        canActivate: [MemberAuthGuardService],
        component: PayNowComponent,
        data: { plainHeader: true, activeTab: 'Billing & Payments' }
      },
      {
        path: config['account'],
        data: { activeTab: 'Account' },
        canActivate: [MemberAuthGuardService],
        component: AccountDetailsComponent
      },
      {
        path: config['edit_account_details'],
        data: { plainHeader: true, activeTab: 'Account' },
        canActivate: [MemberAuthGuardService, AccountGuardService],
        // AccountGuardService
        component: AccountEditComponent
      },
      {
        path: config['resource_center'],
        data: { activeTab: 'Resource Center' },
        canActivate: [MemberAuthGuardService],
        component: ResourceCenterComponent
      },
      {
        //load claims module
        path: config['claims'],
        data: { activeTab: 'Claims' },
        canActivate: [MemberAuthGuardService],
        component: ClaimsLandingComponent
      },
      {
        path: config['claims_direct_deposit'],
        data: { activeTab: 'Claims', plainHeader: true },
        canActivate: [MemberAuthGuardService],
        component: ClaimsDDSetupComponent
      },
      {
        path: config['submit_a_claim'],
        data: { activeTab: 'Claims' },
        canActivate: [MemberAuthGuardService],
        component: ClaimsSubmitComponent
      },
      {
        path: config['submit_claim_documents'],
        data: { activeTab: 'Claims', plainHeader: true },
        canActivate: [MemberAuthGuardService],
        component: ClaimsUploadDocumentsComponent
      },
      {
        path: config['test_page'],
        component: TestComponent,
        canActivate: [TestPageGuard],
        data: { plainHeader: true }
      },
      {
        path: config['auth_callback'],
        component: AuthCallbackComponent,
        data: { plainHeader: true }
      },
      {
        path: config['system_error'],
        data: { plainHeader: true },
        component: MemberSystemErrorComponent,
        canActivate: [MemberAuthGuardService]
      },
      { path: config['wild_card'], redirectTo: config['test_page'] }
    ];
    staticRoutes.push(...dynamicRoutes);
    routerInstance.resetConfig(staticRoutes);
  }
}
