import { urlConfig } from '@aflac/shared/data-model';

export const environment = {
  production: true,
  cmsUrl: urlConfig.cmsUrl,
  securityServiceBaseUrl: urlConfig.securityServiceBaseUrl
};
