const config = [
  {
    context: '/cms',
    target: 'http://localhost:8084',
    secure: false,
    logLevel: 'debug',
    changeOrigin: true
  },
  {
    context: ['/customer', '/member', '/afl-address-rs'],
    target: 'http://localhost:8000',
    secure: false,
    logLevel: 'debug',
    changeOrigin: true
  },

  {
    context: ['/sso', '/portal-redirect', '/jpmc'],
    target: 'http://localhost:8080',
    secure: false,
    logLevel: 'debug',
    changeOrigin: true
  }
];

module.exports = config;
