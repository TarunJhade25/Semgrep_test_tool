const config = [
  {
    context: [
      '/cms',
      '/customer',
      '/member',
      '/afl-address-rs',
      '/sso',
      '/portal-redirect',
      '/jpmc'
    ],
    target: 'https://myaccount-dev.aflac.com',
    secure: true,
    logLevel: 'debug',
    changeOrigin: true
  }
];

module.exports = config;
