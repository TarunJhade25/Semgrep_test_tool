(function(window) {
  window.__aflac_env = window.__aflac_env || {};
  window.__aflac_env.name = 'dev';
  window.__aflac_env.production = false;
  window.__aflac_env.baseUrl = 'http://d3vmpzpku3rirw.cloudfront.net/cms/';
  window.__aflac_env.cmsUrl =
    'http://d3vmpzpku3rirw.cloudfront.net/cms/agent/1/';
  window.__aflac_env.eisMicroServiceBaseUrl =
    'http://d3vmpzpku3rirw.cloudfront.net/';
  window.__aflac_env.securityServiceBaseUrl =
    'https://distribute-dev.aflac.com/';
  window.__aflac_env.enableDebug = true;
  window.__aflac_env.portal = 'agent';
})(this);
