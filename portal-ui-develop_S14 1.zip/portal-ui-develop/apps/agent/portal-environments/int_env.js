(function(window) {
  window.__aflac_env = window.__aflac_env || {};
  window.__aflac_env.name = 'int';
  window.__aflac_env.production = false;
  window.__aflac_env.baseUrl = 'http://localhost:8084/cms/';
  window.__aflac_env.cmsUrl = 'http://localhost:8084/cms/agent/';
  window.__aflac_env.eisMicroServiceBaseUrl = 'http://localhost:8000/';
  window.__aflac_env.securityServiceBaseUrl =
    'https://distribute-intg.aflac.com/';
  window.__aflac_env.enableDebug = true;
  window.__aflac_env.portal = 'agent';
})(this);
