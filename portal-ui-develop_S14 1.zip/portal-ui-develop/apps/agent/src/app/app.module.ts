import { BrowserModule } from '@angular/platform-browser';
import { NgModule, APP_INITIALIZER } from '@angular/core';
import { AppComponent } from './app.component';
import { RouterModule } from '@angular/router';
import { StoreModule } from '@ngrx/store';
import { EffectsModule } from '@ngrx/effects';
import { StoreDevtoolsModule } from '@ngrx/store-devtools';
import { environment } from '../environments/environment';
import { StoreRouterConnectingModule } from '@ngrx/router-store';
import { TranslateModule, TranslateLoader } from '@ngx-translate/core';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';
import {
  HTTP_INTERCEPTORS,
  HttpClientModule,
  HttpClient
} from '@angular/common/http';
import { SharedCmsModule } from '@aflac/shared/cms';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import {
  AgentSharedModule,
  IdentityValidationErrorDisplayComponent,
  AgentSystemErrorComponent
} from '@aflac/agent/shared';
import { AgentBuyFlowModule } from '@aflac/agent/buy-flow';
import { SharedLayoutModule, BreadcrumbComponent } from '@aflac/shared/layout';
import {
  AuthGuardService,
  AuthInterceptor,
  LoginCallBackComponent
} from '@aflac/agent/auth';
import { DeepLinkModule } from '@aflac/shared/deep-link'; // to remove deeplink-url error
import {
  BuyFlowHomeComponent,
  EligibilityComponent,
  DependentsComponent,
  QuoteReviewComponent,
  PersonalDetailsComponent,
  OrderReviewComponent,
  PaymentCheckoutComponent,
  CheckoutComponent
} from '@aflac/agent/buy-flow';
import { AgentLayoutModule } from '@aflac/agent/layout';
import { PostMessageInitializer } from './PostMessageInitializer';

export function cmsLoaderFactory(http: HttpClient) {
  return new TranslateHttpLoader(http, environment.cmsUrl, '');
}

@NgModule({
  declarations: [AppComponent, LoginCallBackComponent, BreadcrumbComponent],
  imports: [
    BrowserModule,
    BrowserModule,
    HttpClientModule,
    BrowserAnimationsModule,
    DeepLinkModule,
    SharedLayoutModule,
    AgentBuyFlowModule,
    AgentLayoutModule,
    RouterModule.forRoot(
      [
        //TODO redirection is added for testing purpose only
        { path: '', redirectTo: 'home', pathMatch: 'full' },
        {
          path: 'login-callback',
          component: LoginCallBackComponent
        },
        {
          path: 'home',
          data: { agentHeaderFlag: true },
          loadChildren: () =>
            import('@aflac/agent/landing').then(
              module => module.AgentLandingModule
            ),
          canActivate: [AuthGuardService]
        },
        {
          path: 'quotes',
          data: { agentHeaderFlag: false },
          loadChildren: () =>
            import('@aflac/agent/quote').then(
              module => module.AgentQuoteModule
            ),
          canActivate: [AuthGuardService]
        },
        /*
        {
          path: 'buy-flow',
          data: { agentHeaderFlag: false },
          loadChildren: () =>
            import('@aflac/agent/buy-flow').then(
              module => module.AgentBuyFlowModule
            ),
          canActivate: [AuthGuardService, AuthTokenService]
        }, */
        {
          path: '',
          component: BuyFlowHomeComponent,
          children: [
            {
              pathMatch: 'full',
              path: '',
              component: BuyFlowHomeComponent
            },
            {
              path: 'review',
              component: QuoteReviewComponent
            },
            {
              path: 'dependents',
              component: DependentsComponent
            },
            {
              path: 'eligibility',
              component: EligibilityComponent
            },
            {
              path: 'my-details',
              component: PersonalDetailsComponent
            },
            {
              path: 'order-review',
              component: OrderReviewComponent
            },
            {
              path: 'check-out-payment-details',
              component: PaymentCheckoutComponent
            },
            {
              path: 'checkout',
              component: CheckoutComponent
            }
          ]
        },
        {
          path: 'identity-error',
          component: IdentityValidationErrorDisplayComponent
        },
        {
          path: 'system-error',
          component: AgentSystemErrorComponent
        }
      ],
      { initialNavigation: 'enabled' }
    ),
    BrowserAnimationsModule,
    SharedCmsModule,
    AgentSharedModule,
    HttpClientModule,
    StoreModule.forRoot(
      {},
      {
        metaReducers: [],
        runtimeChecks: {
          strictActionImmutability: true,
          strictStateImmutability: true
        }
      }
    ),
    EffectsModule.forRoot([]),
    !environment.production ? StoreDevtoolsModule.instrument() : [],
    StoreRouterConnectingModule.forRoot(),
    TranslateModule.forRoot({
      loader: {
        provide: TranslateLoader,
        useFactory: cmsLoaderFactory,
        deps: [HttpClient]
      }
    })
  ],
  providers: [
    { provide: HTTP_INTERCEPTORS, useClass: AuthInterceptor, multi: true },
    {
      provide: APP_INITIALIZER,
      multi: true,
      useFactory: PostMessageInitializer
    }
  ],
  bootstrap: [AppComponent]
})
export class AppModule {}
