import { TestBed, async } from '@angular/core/testing';
import { AppComponent } from './app.component';
import { RouterTestingModule } from '@angular/router/testing';
import { CUSTOM_ELEMENTS_SCHEMA, Component } from '@angular/core';
import { StoreModule, Store } from '@ngrx/store';

@Component({
  selector: 'aflac-agent-header',
  template: '<header></header>'
})
export class AgentHeaderComponent {}
@Component({
  selector: 'aflac-agent-footer',
  template: '<footer></footer>'
})
export class AgentFooterComponent {}

describe('AppComponent', () => {
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [RouterTestingModule, StoreModule.forRoot({})],

      declarations: [AppComponent, AgentHeaderComponent, AgentFooterComponent],
      schemas: [CUSTOM_ELEMENTS_SCHEMA]
    }).compileComponents();
  }));

  it('should create the app', () => {
    const fixture = TestBed.createComponent(AppComponent);
    const app = fixture.debugElement.componentInstance;
    expect(app).toBeTruthy();
  });
});
