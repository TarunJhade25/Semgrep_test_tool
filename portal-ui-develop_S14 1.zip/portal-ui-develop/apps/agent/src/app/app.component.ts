import { Component } from '@angular/core';
import { ColorSchemeService, SeoService } from '@aflac/shared/ui';
import { AgentLoaderService } from '@aflac/agent/shared';
import {
  Event,
  NavigationCancel,
  NavigationEnd,
  NavigationError,
  NavigationStart,
  Router
} from '@angular/router';

@Component({
  selector: 'aflac-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss'],
  providers: [SeoService]
})
export class AppComponent {
  constructor(
    private router: Router,
    private colorSvc: ColorSchemeService,
    private loaderSvc: AgentLoaderService
  ) {
    colorSvc.load();
    this.router.events.subscribe((event: Event) => {
      switch (true) {
        case event instanceof NavigationStart: {
          this.loaderSvc.setLoader(true);
          break;
        }
        case event instanceof NavigationEnd:
        case event instanceof NavigationCancel:
        case event instanceof NavigationError: {
          this.loaderSvc.setLoader(false);
          break;
        }
        default: {
          break;
        }
      }
    });
  }
  title = 'agent';
}
