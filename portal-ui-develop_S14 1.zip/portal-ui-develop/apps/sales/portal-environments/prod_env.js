(function(window) {
  window.__aflac_env = window.__aflac_env || {};
  window.__aflac_env.name = 'prod';
  window.__aflac_env.production = true;
  window.__aflac_env.baseUrl = 'http://localhost:8084/cms/';
  window.__aflac_env.cmsUrl = 'http://localhost:8084/cms/sales/';
  window.__aflac_env.eisMicroServiceBaseUrl = 'http://localhost:8000/';
  window.__aflac_env.enableDebug = true;
  window.__aflac_env.portal = 'sales';
  window.__aflac_env.portalHome = 'https://myaccount.aflac.com';
  window.__aflac_env.enableIDV = true;
  window.__aflac_env.logoutUrl =
    'https://mylogin-prod.nt.lab.com/Authentication/Signout';
})(this);
