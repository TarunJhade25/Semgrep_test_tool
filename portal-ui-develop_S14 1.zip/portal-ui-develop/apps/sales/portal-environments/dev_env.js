(function(window) {
  window.__aflac_env = window.__aflac_env || {};
  window.__aflac_env.name = 'dev';
  window.__aflac_env.production = false;
  window.__aflac_env.baseUrl = 'https://buy-dev.aflac.com/cms/';
  window.__aflac_env.cmsUrl = 'https://buy-dev.aflac.com/cms/sales/';
  window.__aflac_env.eisMicroServiceBaseUrl = 'https://buy-dev.aflac.com/';
  window.__aflac_env.securityServiceBaseUrl =
    'http://devportalalb-74324206.us-east-1.elb.amazonaws.com:8080/';
  window.__aflac_env.enableDebug = true;
  window.__aflac_env.portal = 'sales';
  window.__aflac_env.portalHome = 'https://myaccount-dev.aflac.com';
  window.__aflac_env.enableIDV = true;
  window.__aflac_env.logoutUrl =
    'https://mylogin-dev.nt.lab.com/Authentication/Signout';
})(this);
