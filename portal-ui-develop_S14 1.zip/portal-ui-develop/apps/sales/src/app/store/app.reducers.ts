import { createReducer, on } from '@ngrx/store';
import * as appActions from './app.actions';
export const appStateFeatureKey = 'app-sales';

export const initialAppStateState: any = {};

export const _appStateReducer = createReducer(
  initialAppStateState,
  on(appActions.saveAppRoutes, (state, action) => ({
    ...state,
    route: action.appRoutes
  }))
);

export function appStateReducer(state, action) {
  return _appStateReducer(state, action);
}
