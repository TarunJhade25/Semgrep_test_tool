export function PostMessageInitializer() {
  //The below function is a utility that will get the query string part decode the same
  //and create a key, val pair array of query string values which we can iterate through.
  function getSearchParams(key?) {
    const keyList = {};
    let keyItem = null;
    // get the query string without the ?
    const qs = location.search.substring(1);
    // make a regex pattern to grab key/value
    const pattern = /([^&=]+)=([^&]*)/g;
    // Build the (key,val) based on regex
    while ((keyItem = pattern.exec(qs))) {
      if (key !== false && decodeURIComponent(keyItem[1]) === key)
        return decodeURIComponent(keyItem[2]);
      else if (key === false)
        keyList[decodeURIComponent(keyItem[1])] = decodeURIComponent(
          keyItem[2]
        );
    }
    return key === false ? keyList : null;
  }
  return function(): Promise<void> {
    //The below lines are only useful for modern browsers.
    const jpmcFrame = getSearchParams('DLAction');
    return new Promise<void>((resolve, reject) => {
      //If the url has valid searh param means the action is happening inside an Iframe
      //And we hence we need to post the url containing the info to the parent to decode the same
      if (jpmcFrame) {
        window.parent.postMessage(
          'JPMC-' + location.search.substring(1),
          window.location.origin
        ); //Removed '*' and added the window.location.origin inorder to resolve the security issue
        //Reject the promise as we dont want the angular app to bootstrap further.
        reject('jframe');
      } else {
        //We are resolving the promise here as the url is not a returning url and the bootstrap
        //flow need to continue further to other initializers or the app itself
        resolve();
      }
    });
  };
}
