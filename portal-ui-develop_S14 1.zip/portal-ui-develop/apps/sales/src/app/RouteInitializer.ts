import { DeepLinkComponent } from '@aflac/shared/deep-link';
import {
  PlanSelectionComponent,
  ProductLandingComponent,
  PurchaseConfirmationComponent,
  ComparePlansComponent,
  CriticalIllnessProductComponent
} from '@aflac/shared/product';
import {
  BuyFlowComponent,
  CheckoutComponent,
  DependentsComponent,
  EligibilityComponent,
  IdentityValidationComponent,
  IdentityValidationErrorDisplayComponent,
  KbaValidationComponent,
  OrderReviewComponent,
  PageNotFoundComponent,
  PersonalDetailsComponent,
  QuoteErrorPageComponent,
  ReviewQuoteComponent,
  SaveYourQuoteComponent,
  TestPageComponent,
  PaymentCheckoutComponent,
  SystemErrorComponent
} from '@aflac/shared/ui';
import { HttpClient } from '@angular/common/http';
import { Injector } from '@angular/core';
import { NavigationStart, Router } from '@angular/router';
import * as _ from 'lodash';
import { of } from 'rxjs';
import { tap } from 'rxjs/operators';
import { urlConfig, RouterService } from '@aflac/shared/data-model';
import { PinValidationComponent } from '@aflac/sales/pin-validation';
import {
  EsignIdentityComponent,
  EsignPurchaseComponent,
  EsignCreateAccountComponent,
  EsignApplicationExpiredComponent
} from '@aflac/sales/e-verify';
export function RouteInitializer(injector: Injector) {
  return function(): Promise<void> {
    const baseURL = urlConfig.cmsUrl;
    const http = injector.get(HttpClient);
    const router = injector.get(Router);
    const routerService = injector.get(RouterService);
    let currentUrl: string;
    /* get the current url in case of deeplink scenarios */
    const navSub$ = router.events.subscribe(async routerEvent => {
      if (routerEvent instanceof NavigationStart) {
        if (!currentUrl) {
          currentUrl = routerEvent.url;
          routerService.setParam(currentUrl);
        }
      }
      navSub$.unsubscribe();
    });
    /* On page refresh, fetch the details from session storage and reset the router */
    if (sessionStorage.getItem('_availableRoutes')) {
      return of(JSON.parse(sessionStorage.getItem('_availableRoutes')))
        .pipe(
          tap(config => {
            configDynamicData(config, router, null);
          })
        )
        .toPromise();
    } else {
      /* Fetch the urls for the first time or deep link scenarios */
      return http
        .get(baseURL + 'routes/en')
        .toPromise()
        .then(config => {
          configDynamicData(config, router, currentUrl);
        });
    }
  };

  /**
   * Configure dynamic URL Structure
   * @config: Router details from CMS;
   * @routerInstance: Router instance;
   * @url: the url from deep link scenario;
   */
  function configDynamicData(config: any, routerInstance: Router, url: string) {
    /* Setting the routes to session for first time app load */
    if (!sessionStorage.getItem('_availableRoutes')) {
      sessionStorage.setItem('_availableRoutes', JSON.stringify(config));
    }
    window['_availableRoutes'] = config;
    const staticRoutes = [];
    staticRoutes.push(...routerInstance.config);
    const dynamicRoutes = [
      {
        path: config['quote_error'],
        pathMatch: 'full',
        component: QuoteErrorPageComponent
      },
      {
        path: config['buy_flow'],
        component: BuyFlowComponent,
        children: [
          {
            pathMatch: 'full',
            path: config['empty'],
            component: BuyFlowComponent
          },
          {
            path: config['buy_flow_review_accident'],
            component: ReviewQuoteComponent
          },
          {
            path: config['buy_flow_review_cancer'],
            component: ReviewQuoteComponent
          },
          {
            path: config['buy_flow_review_critical_illness'],
            component: ReviewQuoteComponent
          },
          {
            path: config['buy_flow_dependents'],
            component: DependentsComponent
          },
          {
            path: config['buy_flow_eligibility'],
            component: EligibilityComponent
          },
          {
            path: config['buy_flow_personal_details'],
            component: PersonalDetailsComponent
          },
          {
            path: config['buy_flow_order_review'],
            component: OrderReviewComponent
          },
          {
            path: config['buy_flow_payment'],
            component: PaymentCheckoutComponent
          },
          {
            path: config['buy_flow_checkout'],
            component: CheckoutComponent
          },
          {
            path: config['buy_flow_payment'],
            component: PaymentCheckoutComponent
          }
        ]
      },
      {
        path: config['identity_validation'],
        component: IdentityValidationComponent
      },
      {
        path: config['kba_validation'],
        component: KbaValidationComponent
      },
      {
        path: config['error_validation'],
        component: IdentityValidationErrorDisplayComponent
      },
      {
        path: config['save_your_quote'],
        component: SaveYourQuoteComponent
      },
      {
        path: config['review'],
        component: ReviewQuoteComponent
      },
      {
        path: config['lead_form'],
        component: DeepLinkComponent
      },
      {
        path: 'retrieve-quote',
        component: DeepLinkComponent
      },
      {
        path: config['purchase_confirmation'],
        component: PurchaseConfirmationComponent
      },
      {
        path: config['compare_plan_accident'],
        component: ComparePlansComponent
      },
      {
        path: config['compare_plan_critical_illness'],
        component: CriticalIllnessProductComponent
      },
      {
        path: config['compare_plan_cancer'],
        component: ComparePlansComponent
      },
      {
        path: config['partner'],
        component: DeepLinkComponent
      },
      {
        path: config['plan_selection_accident'],
        component: PlanSelectionComponent
      },
      {
        path: config['plan_selection_cancer'],
        component: PlanSelectionComponent
      },
      {
        path: config['plan_selection_critical_illness'],
        component: PlanSelectionComponent
      },
      {
        path: config['campaign'],
        component: DeepLinkComponent
      },
      {
        path: config['customer_number'],
        component: DeepLinkComponent
      },
      {
        path: config['partner_campaign'],
        component: DeepLinkComponent
      },
      {
        path: config['products'],
        component: ProductLandingComponent
      },
      {
        path: config['pin_validation'],
        component: PinValidationComponent
      },
      {
        path: config['test_page'],
        component: TestPageComponent
      },
      {
        path: config['idv_customer'],
        component: DeepLinkComponent
      },
      {
        path: config['system_error'],
        component: SystemErrorComponent
      },
      {
        path: config['page_not_found'],
        component: PageNotFoundComponent
      },
      {
        path: config['e_verify'],
        component: EsignIdentityComponent
      },
      {
        path: config['esign_purchase'],
        component: EsignPurchaseComponent
      },
      {
        path: config['esign_create_account'],
        component: EsignCreateAccountComponent
      },
      {
        path: config['esign_application_expired'],
        component: EsignApplicationExpiredComponent
      },
      {
        path: config['wild_card'],
        redirectTo: config['page_not_found']
      }
    ];
    /* Maintaining the Native URL's to differentiate from the Deeplink URL's */
    const nativeURLs = [
      config['quote_error'],
      config['buy_flow'],
      config['empty'],
      config['buy_flow_payment'],
      config['buy_flow_review_accident'],
      config['buy_flow_review_cancer'],
      config['buy_flow_review_critical_illness'],
      config['buy_flow_dependents'],
      config['buy_flow_eligibility'],
      config['buy_flow_personal_details'],
      config['system_error'],
      config['buy_flow_checkout'],
      config['buy_flow_payment'],
      config['identity_validation'],
      config['kba_validation'],
      config['error_validation'],
      config['save_your_quote'],
      config['review'],
      config['purchase_confirmation'],
      config['compare_plan_accident'],
      config['compare_plan_critical_illness'],
      config['compare_plan_cancer'],
      config['plan_selection_accident'],
      config['plan_selection_cancer'],
      config['plan_selection_critical_illness'],
      config['products'],
      config['page_not_found'],
      config['wild_card'],
      config['e_verify'],
      config['esign_purchase'],
      config['esign_create_account'],
      config['esign_application_expired']
    ];
    staticRoutes.push(...dynamicRoutes);
    routerInstance.resetConfig(staticRoutes);
    /* If deeplink URL, set the property in sessionstorage */
    if (url) {
      if (_.indexOf(nativeURLs, url.substr(1, url.length)) === -1) {
        sessionStorage.setItem('state-breadcrumb', JSON.stringify([])); //Reverting back
        routerInstance.navigateByUrl(url);
      } else {
        routerInstance.navigateByUrl('');
      }
    }
  }
}
