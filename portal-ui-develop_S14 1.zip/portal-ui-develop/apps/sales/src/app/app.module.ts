import { HomeComponent, SalesLandingModule } from '@aflac/sales/landing';
import { SharedCmsModule } from '@aflac/shared/cms';
import {
  defaultDataServiceConfig,
  entityConfig
} from '@aflac/shared/data-model';
import { DeepLinkComponent, DeepLinkModule } from '@aflac/shared/deep-link';
import { BreadcrumbComponent, SharedLayoutModule } from '@aflac/shared/layout';
import {
  PlanComparisionComponent,
  PlanSelectionComponent,
  ProductLandingComponent,
  SalesProductModule,
  PurchaseConfirmationComponent,
  CriticalIllnessProductComponent,
  ComparePlansComponent
} from '@aflac/shared/product';
import {
  BuyFlowComponent,
  CheckoutComponent,
  DependentsComponent,
  EligibilityComponent,
  IdentityValidationComponent,
  IdentityValidationErrorDisplayComponent,
  KbaValidationComponent,
  OrderReviewComponent,
  PageNotFoundComponent,
  PersonalDetailsComponent,
  QuoteErrorPageComponent,
  ReviewQuoteComponent,
  SaveYourQuoteComponent,
  TestPageComponent,
  PaymentCheckoutComponent,
  SystemErrorComponent
} from '@aflac/shared/ui';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { APP_INITIALIZER, Injector, NgModule } from '@angular/core';
import { MatFormFieldModule, MatInputModule } from '@angular/material';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { RouterModule } from '@angular/router';
import { DefaultDataServiceConfig, EntityDataModule } from '@ngrx/data';
import { EffectsModule } from '@ngrx/effects';
import { StoreRouterConnectingModule } from '@ngrx/router-store';
import { StoreModule } from '@ngrx/store';
import { StoreDevtoolsModule } from '@ngrx/store-devtools';
import { TranslateLoader, TranslateModule } from '@ngx-translate/core';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';
import { environment } from '../environments/environment';
import { AppComponent } from './app.component';
import { RouteInitializer } from './RouteInitializer';
import {
  ErrorInterceptorModule,
  SsoCallbackComponent
} from '@aflac/sales/shared';
import * as appReducer from './store/app.reducers';
import { PostMessageInitializer } from './PostMessageInitializer';
import { AuthInterceptorModule } from '@aflac/sales/shared';
import {
  SalesPinValidationModule,
  PinValidationComponent
} from '@aflac/sales/pin-validation';
import {
  SalesEVerifyModule,
  EsignIdentityComponent,
  EsignPurchaseComponent,
  EsignCreateAccountComponent,
  EsignApplicationExpiredComponent
} from '@aflac/sales/e-verify';
export function cmsLoaderFactory(http: HttpClient) {
  return new TranslateHttpLoader(http, environment.cmsUrl, '');
}

@NgModule({
  declarations: [AppComponent, BreadcrumbComponent],
  imports: [
    BrowserModule,
    ErrorInterceptorModule,
    HttpClientModule,
    DeepLinkModule,
    MatFormFieldModule,
    MatInputModule,
    AuthInterceptorModule,
    StoreModule.forFeature(
      appReducer.appStateFeatureKey,
      appReducer.appStateReducer
    ),
    RouterModule.forRoot(
      [
        {
          path: '',
          component: HomeComponent
        },
        {
          path: 'auth-callback',
          component: SsoCallbackComponent,
          data: { plainHeader: true }
        }
      ],
      {
        initialNavigation: 'enabled',
        anchorScrolling: 'enabled',
        onSameUrlNavigation: 'reload'
      }
    ),
    StoreModule.forRoot(
      {},
      {
        metaReducers: [],
        runtimeChecks: {
          strictActionImmutability: true,
          strictStateImmutability: true
        }
      }
    ),
    EffectsModule.forRoot([]),
    !environment.production ? StoreDevtoolsModule.instrument() : [],
    StoreRouterConnectingModule.forRoot(),
    SharedCmsModule,
    TranslateModule.forRoot({
      loader: {
        provide: TranslateLoader,
        useFactory: cmsLoaderFactory,
        deps: [HttpClient]
      }
    }),
    BrowserAnimationsModule,
    SharedLayoutModule,
    SalesLandingModule,
    SalesProductModule,
    SalesPinValidationModule,
    DeepLinkModule,
    EntityDataModule.forRoot(entityConfig),
    SalesEVerifyModule
  ],
  providers: [
    {
      provide: APP_INITIALIZER,
      multi: true,
      useFactory: RouteInitializer,
      deps: [Injector]
    },
    {
      provide: APP_INITIALIZER,
      multi: true,
      useFactory: PostMessageInitializer
    },
    { provide: DefaultDataServiceConfig, useValue: defaultDataServiceConfig }
  ],
  bootstrap: [AppComponent],
  entryComponents: [
    ProductLandingComponent,
    DeepLinkComponent,
    ReviewQuoteComponent,
    PageNotFoundComponent,
    TestPageComponent,
    PlanSelectionComponent,
    PlanComparisionComponent,
    SaveYourQuoteComponent,
    QuoteErrorPageComponent,
    BuyFlowComponent,
    IdentityValidationComponent,
    KbaValidationComponent,
    IdentityValidationErrorDisplayComponent,
    BuyFlowComponent,
    DependentsComponent,
    EligibilityComponent,
    PersonalDetailsComponent,
    OrderReviewComponent,
    PaymentCheckoutComponent,
    CheckoutComponent,
    PurchaseConfirmationComponent,
    ComparePlansComponent,
    PaymentCheckoutComponent,
    CriticalIllnessProductComponent,
    ComparePlansComponent,
    SystemErrorComponent,
    PinValidationComponent,
    EsignIdentityComponent,
    EsignPurchaseComponent,
    EsignCreateAccountComponent,
    EsignApplicationExpiredComponent
  ]
})
export class AppModule {}
