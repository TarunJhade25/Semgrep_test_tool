import { TestBed, async } from '@angular/core/testing';
import { AppComponent } from './app.component';
import { RouterTestingModule } from '@angular/router/testing';
import { HeaderComponent, HeaderService } from '@aflac/shared/layout';
import { CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA } from '@angular/core';
import { TranslateModule } from '@ngx-translate/core';
import {
  SeoService,
  DeviceCheckerService,
  quoteReducer
} from '@aflac/shared/ui';
import { StoreModule } from '@ngrx/store';
import { BehaviorSubject, of } from 'rxjs';
import { MatDialogModule } from '@angular/material';
import { CookieService, StateEntityService } from '@aflac/shared/data-model';

describe('AppComponent', () => {
  beforeEach(async(() => {
    window['_availableRoutes'] = {
      system_error: 'system-error'
    };
    TestBed.configureTestingModule({
      imports: [
        RouterTestingModule,
        TranslateModule.forRoot(),
        StoreModule.forRoot(quoteReducer),
        MatDialogModule
      ],
      declarations: [AppComponent, HeaderComponent],
      schemas: [CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA],
      providers: [
        { provide: SeoService, useClass: MockSeoServiceService },
        { provide: HeaderService, useClass: MockHeaderService },
        { provide: DeviceCheckerService, useClass: MockDeviceCheckerService },
        { provide: StateEntityService, useClass: MockStateEntityService },
        CookieService
      ]
    }).compileComponents();
  }));

  it('should create the sales app', () => {
    const fixture = TestBed.createComponent(AppComponent);
    const app = fixture.debugElement.componentInstance;
    fixture.componentInstance.ngOnInit();
    expect(app).toBeTruthy();
  });

  it(`should have as title 'sales'`, () => {
    const fixture = TestBed.createComponent(AppComponent);
    const app = fixture.debugElement.componentInstance;
    expect(app.title).toEqual('sales');
  });

  // it('should render title', () => {
  //   const fixture = TestBed.createComponent(AppComponent);
  //   fixture.detectChanges();
  //   const compiled = fixture.debugElement.nativeElement;
  //   expect(compiled.querySelector('h1').textContent).toContain(
  //     'Welcome to sales!'
  //   );
  // });
});
//MockClass
class MockSeoServiceService {
  updateTitle(title: string) {}

  /**Update Description tag */
  updateDescription(desc: string) {}
}
class MockHeaderService {
  private _headerName = new BehaviorSubject({ header: 'Schedule a Call' });

  setHeaderName(headerName: string) {
    this._headerName.next({ header: headerName });
  }

  getHeaderName(): any {
    return of({});
  }
}
class MockDeviceCheckerService {
  isLargeDevice() {
    return true;
  }
  isMediumDevice() {
    return true;
  }
  isSmallDevice() {
    return true;
  }
}
class MockStateEntityService {
  entities$ = of({ state: 'AL', age: '44', coverage: 'MySelf' });
}
