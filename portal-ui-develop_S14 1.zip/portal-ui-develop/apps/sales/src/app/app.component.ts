import { ColorSchemeService, SeoService } from '@aflac/shared/ui';
import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { Event, NavigationStart, Router, NavigationEnd } from '@angular/router';
import { Store } from '@ngrx/store';
import { AppData } from './model/app.model';
import { saveAppRoutes } from './store/app.actions';

@Component({
  selector: 'aflac-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss'],
  providers: [SeoService]
})
export class AppComponent implements OnInit {
  showSkip = true;
  globalRoutes: any;
  constructor(
    public seoService: SeoService,
    public router: Router,
    private colorSvc: ColorSchemeService,
    private store: Store<{ appData: AppData }>
  ) {
    this.scrollUp();
    colorSvc.load();
    this.storeRoutes();
    this.router.events.subscribe(val => {
      if (val instanceof NavigationEnd) {
        this.showHideSkipToMain(val.url.substring(1, val.url.length));
      }
    });
  }
  @ViewChild('main', { static: true }) mainContainer: ElementRef;
  title = 'sales';

  navigateToMain() {
    this.mainContainer.nativeElement.setAttribute('tabindex', '-1');
    this.mainContainer.nativeElement.focus();
    this.mainContainer.nativeElement.scrollIntoView();
    this.mainContainer.nativeElement.removeAttribute('tabindex');
  }

  ngOnInit() {
    this.addSEOTags();
  }

  /* Add in the urls, which don't have header & skip to main in the below condition */
  showHideSkipToMain(url: string) {
    if (
      url.indexOf(this.globalRoutes['identity_validation']) !== -1 ||
      url.indexOf(this.globalRoutes['kba_validation']) !== -1 ||
      url.indexOf(this.globalRoutes['system_error']) !== -1 ||
      url.indexOf(this.globalRoutes['error_validation']) !== -1
    ) {
      this.showSkip = false;
    } else {
      this.showSkip = true;
    }
  }

  /**Add SEO tags dynamicaly */
  public addSEOTags() {
    this.seoService.updateTitle(
      'Supplemental Coverage | Insurance Plans | Buy.Aflac.com'
    );
    this.seoService.updateDescription(
      'Find supplemental coverage insurance plans for accident, cancer, critical illness, and more. Visit Aflac.com for plan detail information.'
    );
  }

  /**Scroll up on page change */
  public scrollUp() {
    this.router.events.subscribe((event: Event) => {
      if (event instanceof NavigationStart) {
        window.scroll(0, 0);
      }
    });
  }

  /**Store Routes in NgRx Store */
  public storeRoutes() {
    this.globalRoutes = window['_availableRoutes'];
    this.store.dispatch(saveAppRoutes({ appRoutes: this.globalRoutes }));
  }
}
