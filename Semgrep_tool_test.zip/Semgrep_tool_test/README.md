# Semgrep SAST Scanner

An efficient Static Application Security Testing (SAST) tool with web interface built on Semgrep.

## Features

- 🔍 **Multiple Scan Configurations**: CI/CD, Security Audit, OWASP Top 10
- 🌐 **Web Interface**: Modern, responsive UI for easy scanning
- 📊 **Excel Export**: Export results to Excel format
- ⚡ **CLI Support**: Command-line interface for automation
- 🛡️ **Error Handling**: Robust error handling and timeout protection

## Quick Start

### 1. Install Dependencies
```bash
pip install -r requirements.txt
```

### 2. Install Semgrep
```bash
pip install semgrep
```

### 3. Run Web Interface
```bash
python run.py
```
Open http://localhost:5000 in your browser

### 4. CLI Usage
```bash
# Basic scan
python run.py --cli --repo "C:\path\to\your\repo"

# Custom config
python run.py --cli --repo "C:\path\to\your\repo" --config "p/security-audit"

# Different output format
python run.py --cli --repo "C:\path\to\your\repo" --format "sarif"
```

## Configuration Options

- `p/ci` - CI/CD focused rules (default)
- `p/security-audit` - Comprehensive security audit
- `p/owasp-top-ten` - OWASP Top 10 vulnerabilities
- `auto` - Auto-detect based on languages

## Project Structure

```
├── backend/
│   ├── sast_scanner.py    # Core scanner logic
│   └── app.py            # Flask web API
├── templates/
│   └── index.html        # Web interface
├── static/
│   ├── style.css         # Styling
│   └── script.js         # Frontend logic
├── requirements.txt      # Dependencies
└── run.py               # Main entry point
```