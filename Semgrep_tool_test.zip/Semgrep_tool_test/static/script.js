let currentResults = null;

document.getElementById('scanForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    
    const repoPath = document.getElementById('repoPath').value;
    const config = document.getElementById('config').value;
    
    showLoading();
    hideResults();
    
    try {
        const response = await fetch('/api/scan', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                repo_path: repoPath,
                config: config
            })
        });
        
        const results = await response.json();
        currentResults = results;
        
        hideLoading();
        displayResults(results);
        
    } catch (error) {
        hideLoading();
        alert('Scan failed: ' + error.message);
    }
});

document.getElementById('exportBtn').addEventListener('click', async () => {
    if (!currentResults) return;
    
    try {
        const response = await fetch('/api/export', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                results: currentResults
            })
        });
        
        if (response.ok) {
            const blob = await response.blob();
            const url = window.URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = 'semgrep_results.xlsx';
            a.click();
        }
    } catch (error) {
        alert('Export failed: ' + error.message);
    }
});

function showLoading() {
    document.getElementById('loading').classList.remove('hidden');
}

function hideLoading() {
    document.getElementById('loading').classList.add('hidden');
}

function hideResults() {
    document.getElementById('results').classList.add('hidden');
}

function displayResults(results) {
    if (!results.success) {
        alert('Scan failed: ' + results.error);
        return;
    }
    
    const resultsDiv = document.getElementById('results');
    const summaryDiv = document.getElementById('summary');
    const findingsDiv = document.getElementById('findings');
    
    // Display summary
    const scanInfo = results.scan_info;
    summaryDiv.innerHTML = `
        <h3>Scan Summary</h3>
        <p><strong>Repository:</strong> ${scanInfo.repository}</p>
        <p><strong>Scan Time:</strong> ${new Date(scanInfo.timestamp).toLocaleString()}</p>
        <p><strong>Total Findings:</strong> ${scanInfo.total_findings}</p>
        <div style="margin-top: 10px;">
            <span class="severity-high">ERROR: ${scanInfo.severity_breakdown.ERROR || 0}</span> |
            <span class="severity-medium">WARNING: ${scanInfo.severity_breakdown.WARNING || 0}</span> |
            <span class="severity-low">INFO: ${scanInfo.severity_breakdown.INFO || 0}</span>
        </div>
    `;
    
    // Display findings
    findingsDiv.innerHTML = '';
    results.findings.forEach(finding => {
        const findingDiv = document.createElement('div');
        findingDiv.className = 'finding';
        findingDiv.innerHTML = `
            <div class="finding-header">
                <h4>${finding.rule_id}</h4>
                <span class="severity-badge severity-${finding.severity}">${finding.severity}</span>
            </div>
            <p><strong>File:</strong> ${finding.file_path} (Lines ${finding.start_line}-${finding.end_line})</p>
            <p><strong>Message:</strong> ${finding.message}</p>
            ${finding.code_snippet ? `<div class="code-snippet">${finding.code_snippet}</div>` : ''}
        `;
        findingsDiv.appendChild(findingDiv);
    });
    
    resultsDiv.classList.remove('hidden');
}