#!/usr/bin/env python3
"""
Semgrep SAST Scanner - Main Entry Point
Usage: python run.py [--cli] [--repo PATH] [--config CONFIG]
"""

import sys
import argparse
from backend.sast_scanner import SemgrepSASTScanner
from backend.app import app

def cli_mode(repo_path, config, output_format):
    """Run scanner in CLI mode"""
    scanner = SemgrepSASTScanner(config)
    results = scanner.scan_repository(repo_path, output_format)
    
    if results.get("success"):
        print(f"Scan completed successfully!")
        print(f"Total findings: {results['scan_info']['total_findings']}")
        
        # Export to Excel if requested
        if output_format == "json":
            excel_path = "semgrep_results.xlsx"
            if scanner.export_to_excel(results, excel_path):
                print(f"Results exported to: {excel_path}")
    else:
        print(f"Scan failed: {results.get('error')}")

def main():
    parser = argparse.ArgumentParser(description="Semgrep SAST Scanner")
    parser.add_argument("--cli", action="store_true", help="Run in CLI mode")
    parser.add_argument("--repo", help="Repository path to scan")
    parser.add_argument("--config", default="p/ci", help="Semgrep config (default: p/ci)")
    parser.add_argument("--format", default="json", choices=["json", "sarif", "text"], help="Output format")
    
    args = parser.parse_args()
    
    if args.cli:
        if not args.repo:
            print("Repository path required for CLI mode")
            sys.exit(1)
        cli_mode(args.repo, args.config, args.format)
    else:
        print("Starting web interface...")
        print("Open http://localhost:5000 in your browser")
        app.run(debug=True, port=5000)

if __name__ == "__main__":
    main()