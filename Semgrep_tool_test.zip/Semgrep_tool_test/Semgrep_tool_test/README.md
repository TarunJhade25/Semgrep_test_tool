# Semgrep SAST Scanner

A web-based Static Application Security Testing (SAST) tool powered by Semgrep for scanning code repositories and ZIP files.

## Features

- 🔍 Scan local folders or upload ZIP files
- 🛡️ Security vulnerability detection using Semgrep
- 📊 Export results to Excel
- 🎨 Clean, intuitive web interface
- ⚡ Fast scanning with detailed findings

## Prerequisites

- Python 3.8 or higher
- pip package manager

## Installation

1. Clone the repository:
```bash
git clone https://github.com/yourusername/semgrep-sast-scanner.git
cd semgrep-sast-scanner
```

2. Install dependencies:
```bash
pip install -r requirements.txt
```

3. Set your Semgrep token:
```bash
# Windows (Permanent)
setx SEMGREP_APP_TOKEN "your_token_here"

# Windows (Current session only)
set SEMGREP_APP_TOKEN=your_token_here

# Linux/Mac
export SEMGREP_APP_TOKEN="your_token_here"
```

**Get your token from:** https://semgrep.dev/login

## Usage

1. Start the application:
```bash
python run.py
```

2. Open your browser and navigate to:
```
http://localhost:5000
```

3. Choose scan method:
   - **Folder Path**: Enter the path to your local repository
   - **Upload ZIP**: Upload a ZIP file containing your code

4. Click "Start Scan" and wait for results

5. Export results to Excel using the "Export to Excel" button

## Configuration

The scanner uses Semgrep's Security Audit ruleset (`p/security-audit`) which includes:
- SQL injection detection
- XSS vulnerabilities
- Authentication issues
- Cryptographic weaknesses
- And more security patterns

## Project Structure

```
semgrep-sast-scanner/
├── backend/
│   ├── app.py              # Flask application
│   └── sast_scanner.py     # Semgrep scanner logic
├── static/
│   ├── script.js           # Frontend JavaScript
│   └── style.css           # Styling
├── templates/
│   └── index.html          # Main UI
├── requirements.txt        # Python dependencies
└── run.py                  # Application entry point
```

## Technologies Used

- **Backend**: Flask, Python
- **Scanner**: Semgrep
- **Frontend**: HTML, CSS, JavaScript
- **Export**: Pandas, OpenPyXL

## License

MIT License

## Contributing

Pull requests are welcome. For major changes, please open an issue first.

## Support

For issues or questions, please open an issue on GitHub.
