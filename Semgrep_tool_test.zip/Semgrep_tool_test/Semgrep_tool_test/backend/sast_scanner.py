import subprocess
import json
import os
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional

class SemgrepSASTScanner:
    def __init__(self, config_path: str = "p/ci"):
        self.config_path = config_path
        self.supported_formats = ["json", "sarif", "text"]
    
    def scan_repository(self, repo_path: str, output_format: str = "json") -> Dict:
        """Run Semgrep scan on repository"""
        if not os.path.exists(repo_path):
            raise FileNotFoundError(f"Repository path not found: {repo_path}")
        
        if output_format not in self.supported_formats:
            raise ValueError(f"Unsupported format: {output_format}")
        
        semgrep_paths = [
            r"C:\Users\HP5CD\AppData\Local\Packages\PythonSoftwareFoundation.Python.3.13_qbz5n2kfra8p0\LocalCache\local-packages\Python313\Scripts\semgrep.exe",
            r"C:\Users\HP5CD\AppData\Local\Programs\Python\Python312\Scripts\semgrep.exe"
        ]
        
        semgrep_path = None
        for path in semgrep_paths:
            if os.path.exists(path):
                semgrep_path = path
                break
        
        if not semgrep_path:
            return {"success": False, "error": "Semgrep not found. Please install semgrep."}
        
        cmd = [semgrep_path, "scan", "--config", self.config_path, f"--{output_format}", repo_path]
        
        env = os.environ.copy()
        
        try:
            result = subprocess.run(cmd, capture_output=True, text=True, timeout=300, env=env, cwd=os.path.dirname(semgrep_path), encoding='utf-8', errors='replace')
            
            if result.returncode not in [0, 1]:
                return {
                    "success": False,
                    "error": result.stderr if result.stderr else result.stdout,
                    "timestamp": datetime.now().isoformat()
                }
            
            if output_format == "json":
                findings = json.loads(result.stdout)
                return self._process_findings(findings, repo_path)
            
            return {
                "success": True,
                "raw_output": result.stdout,
                "timestamp": datetime.now().isoformat()
            }
            
        except subprocess.TimeoutExpired:
            return {"success": False, "error": "Scan timeout (5 minutes)"}
        except Exception as e:
            return {"success": False, "error": str(e)}
    
    def _process_findings(self, semgrep_results: Dict, repo_path: str) -> Dict:
        """Process and structure findings"""
        findings = semgrep_results.get("results", [])
        
        processed = []
        severity_counts = {"ERROR": 0, "WARNING": 0, "INFO": 0}
        
        for finding in findings:
            severity = finding.get("extra", {}).get("severity", "INFO").upper()
            severity_counts[severity] = severity_counts.get(severity, 0) + 1
            
            processed.append({
                "rule_id": finding.get("check_id"),
                "severity": severity,
                "message": finding.get("extra", {}).get("message"),
                "file_path": finding.get("path"),
                "start_line": finding.get("start", {}).get("line"),
                "end_line": finding.get("end", {}).get("line"),
                "code_snippet": finding.get("extra", {}).get("lines")
            })
        
        return {
            "success": True,
            "scan_info": {
                "repository": repo_path,
                "timestamp": datetime.now().isoformat(),
                "total_findings": len(processed),
                "severity_breakdown": severity_counts
            },
            "findings": processed
        }
    
    def export_to_excel(self, scan_results: Dict, output_path: str) -> bool:
        """Export results to Excel"""
        try:
            import pandas as pd
            
            if not scan_results.get("success"):
                return False
            
            df = pd.DataFrame(scan_results["findings"])
            df.to_excel(output_path, index=False)
            return True
        except ImportError:
            raise ImportError("pandas and openpyxl required for Excel export")
        except Exception:
            return False