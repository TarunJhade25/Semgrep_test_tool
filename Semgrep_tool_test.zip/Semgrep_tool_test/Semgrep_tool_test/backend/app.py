from flask import Flask, request, jsonify, render_template, send_file
from flask_cors import CORS
import os
import tempfile
from .sast_scanner import SemgrepSASTScanner
from werkzeug.utils import secure_filename

app = Flask(__name__, template_folder='../templates', static_folder='../static')
CORS(app)

scanner = SemgrepSASTScanner()

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/api/scan', methods=['POST'])
def scan_repository():
    data = request.get_json()
    repo_path = data.get('repo_path')
    config = data.get('config', 'p/ci')
    
    if not repo_path:
        return jsonify({'error': 'Repository path required'}), 400
    
    scanner.config_path = config
    results = scanner.scan_repository(repo_path)
    return jsonify(results)

@app.route('/api/scan-zip', methods=['POST'])
def scan_zip():
    if 'file' not in request.files:
        return jsonify({'error': 'No file uploaded'}), 400
    
    file = request.files['file']
    config = request.form.get('config', 'p/ci')
    
    if file.filename == '':
        return jsonify({'error': 'No file selected'}), 400
    
    if not file.filename.endswith('.zip'):
        return jsonify({'error': 'Only ZIP files are allowed'}), 400
    
    import zipfile
    with tempfile.TemporaryDirectory() as temp_dir:
        zip_path = os.path.join(temp_dir, secure_filename(file.filename))
        file.save(zip_path)
        
        extract_dir = os.path.join(temp_dir, 'extracted')
        os.makedirs(extract_dir)
        
        with zipfile.ZipFile(zip_path, 'r') as zip_ref:
            zip_ref.extractall(extract_dir)
        
        scanner.config_path = config
        results = scanner.scan_repository(extract_dir)
        return jsonify(results)

@app.route('/api/export', methods=['POST'])
def export_results():
    data = request.get_json()
    scan_results = data.get('results')
    
    if not scan_results:
        return jsonify({'error': 'No results to export'}), 400
    
    with tempfile.NamedTemporaryFile(suffix='.xlsx', delete=False) as tmp:
        if scanner.export_to_excel(scan_results, tmp.name):
            return send_file(tmp.name, as_attachment=True, 
                           download_name='semgrep_results.xlsx')
    
    return jsonify({'error': 'Export failed'}), 500

if __name__ == '__main__':
    app.run(debug=True, port=5000)